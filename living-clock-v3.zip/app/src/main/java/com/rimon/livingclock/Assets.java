package com.rimon.livingclock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One-time import of the background photo and the subject. Never runs in the wallpaper service. */
final class Assets {

    static final String BG = "background.jpg";
    static final String SUBJ = "subject.png";

    private static final int BG_SIDE = 2048, SUBJ_SIDE = 1600, ML_SIDE = 768;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    interface Done {
        void done(boolean ok, String message);
    }

    private Assets() {}

    static void importBackground(Context c, Uri uri, Done done) {
        Context app = c.getApplicationContext();
        IO.execute(() -> {
            boolean ok = false;
            String msg = "Couldn't use that photo.";
            try {
                File tmp = copy(app, uri, "bg.tmp");
                Bitmap b = decodeOriented(tmp, BG_SIDE);
                tmp.delete();
                if (b == null) throw new IOException("decode");
                save(b, new File(app.getFilesDir(), BG), Bitmap.CompressFormat.JPEG, 92);
                b.recycle();
                Prefs.bump(app);
                ok = true;
                msg = "Background updated.";
            } catch (Throwable ignored) {
                // Keep the default message.
            }
            post(done, ok, msg);
        });
    }

    static void importSubject(Context c, Uri uri, Done done) {
        Context app = c.getApplicationContext();
        IO.execute(() -> {
            boolean ok = false;
            String msg = "Couldn't use that photo.";
            try {
                File tmp = copy(app, uri, "subject.tmp");
                Bitmap photo = decodeOriented(tmp, SUBJ_SIDE);
                tmp.delete();
                if (photo == null) throw new IOException("decode");

                Bitmap cut = hasCutoutAlpha(photo) ? photo : segment(photo);
                if (cut == null) {
                    msg = "No person found. Try a clearer photo or a transparent PNG.";
                } else {
                    save(cut, new File(app.getFilesDir(), SUBJ), Bitmap.CompressFormat.PNG, 100);
                    if (cut != photo) photo.recycle();
                    cut.recycle();
                    Prefs.resetSubject(app);
                    ok = true;
                    msg = "Subject cut out. Drag it into place.";
                }
            } catch (Throwable ignored) {
                // Keep the default message.
            }
            post(done, ok, msg);
        });
    }

    /** Decodes a file at a size that still covers maxSide. */
    static Bitmap decode(File f, int maxSide) {
        String path = f.getAbsolutePath();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        BitmapFactory.Options o = new BitmapFactory.Options();
        int longest = Math.max(bounds.outWidth, bounds.outHeight);
        o.inSampleSize = 1;
        while (longest / (o.inSampleSize * 2) >= maxSide) o.inSampleSize *= 2;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(path, o);
    }

    // ---------- cutout ----------

    /** A PNG that already has transparency is used as the cutout as is. */
    private static boolean hasCutoutAlpha(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int step = Math.max(1, Math.min(w, h) / 200);
        int total = 0, clear = 0;
        for (int y = 0; y < h; y += step) {
            for (int x = 0; x < w; x += step) {
                total++;
                if (Color.alpha(b.getPixel(x, y)) < 128) clear++;
            }
        }
        return clear > total * 0.02f;
    }

    private static Bitmap segment(Bitmap photo) throws Exception {
        Bitmap small = scaleToSide(photo, ML_SIDE);
        Bitmap mask = maskOf(small);
        if (small != photo) small.recycle();
        if (mask == null) return null;

        Bitmap m = Bitmap.createScaledBitmap(mask, photo.getWidth(), photo.getHeight(), true);
        Bitmap out = Bitmap.createBitmap(photo.getWidth(), photo.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        cv.drawBitmap(photo, 0f, 0f, null);
        Paint keep = new Paint();
        keep.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        cv.drawBitmap(m, 0f, 0f, keep);
        if (m != mask) m.recycle();
        mask.recycle();
        return out;
    }

    /** Returns a black bitmap whose alpha is the person mask, or null if no person is found. */
    private static Bitmap maskOf(Bitmap img) throws Exception {
        SelfieSegmenterOptions opts = new SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build();
        Segmenter segmenter = Segmentation.getClient(opts);
        try {
            SegmentationMask sm = Tasks.await(segmenter.process(InputImage.fromBitmap(img, 0)));
            int mw = sm.getWidth(), mh = sm.getHeight();
            ByteBuffer buf = sm.getBuffer();
            buf.rewind();
            FloatBuffer fb = buf.asFloatBuffer();

            int n = mw * mh;
            int[] px = new int[n];
            int covered = 0;
            for (int i = 0; i < n; i++) {
                // Contrast curve removes grey half-transparent patches inside the body.
                float t = (fb.get() - 0.30f) / 0.45f;
                t = t < 0f ? 0f : (t > 1f ? 1f : t);
                t = t * t * (3f - 2f * t);
                int a = (int) (t * 255f + 0.5f);
                if (a > 127) covered++;
                px[i] = a << 24;
            }
            float cov = covered / (float) n;
            if (cov < 0.02f || cov > 0.97f) return null;

            Bitmap out = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888);
            out.setPixels(px, 0, mw, 0, 0, mw, mh);
            return out;
        } finally {
            segmenter.close();
        }
    }

    // ---------- helpers ----------

    private static File copy(Context app, Uri uri, String name) throws IOException {
        File dest = new File(app.getCacheDir(), name);
        try (InputStream in = app.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(dest)) {
            if (in == null) throw new IOException("cannot open");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
        return dest;
    }

    private static void save(Bitmap b, File f, Bitmap.CompressFormat fmt, int quality) throws IOException {
        try (OutputStream out = new FileOutputStream(f)) {
            b.compress(fmt, quality, out);
        }
    }

    private static Bitmap decodeOriented(File f, int maxSide) {
        Bitmap bm = decode(f, maxSide);
        if (bm == null) return null;
        int rot = rotation(f);
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            Bitmap r = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            bm.recycle();
            bm = r;
        }
        Bitmap scaled = scaleToSide(bm, maxSide);
        if (scaled != bm) bm.recycle();
        return scaled;
    }

    /** Returns src itself when it is already small enough. The caller handles recycling. */
    private static Bitmap scaleToSide(Bitmap src, int side) {
        int longest = Math.max(src.getWidth(), src.getHeight());
        if (longest <= side) return src;
        float s = side / (float) longest;
        return Bitmap.createScaledBitmap(src,
                Math.max(1, Math.round(src.getWidth() * s)),
                Math.max(1, Math.round(src.getHeight() * s)), true);
    }

    private static int rotation(File f) {
        try {
            int o = new ExifInterface(f.getAbsolutePath())
                    .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) return 90;
            if (o == ExifInterface.ORIENTATION_ROTATE_180) return 180;
            if (o == ExifInterface.ORIENTATION_ROTATE_270) return 270;
        } catch (IOException ignored) {
            // No EXIF data: assume upright.
        }
        return 0;
    }

    private static void post(Done d, boolean ok, String msg) {
        MAIN.post(() -> d.done(ok, msg));
    }
}
