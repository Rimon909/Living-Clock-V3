package com.rimon.livingclock;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.os.Handler;
import android.os.Looper;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lumen Edge, the hidden premium effect. Unlocked with four taps on the clock, then two taps on the top centre
 * of the cutout while the gold ring is still counting down.
 *
 * Your silhouette becomes a source of light: a warm rim hugs its outline, and one bright comet laps around you
 * every twelve seconds, locked to the real clock (a flare at every full minute). Tiny motes of light lift off
 * your shoulders, the corners of the photo settle into a soft vignette. Switching on sends a shockwave out from
 * the crown of the head while the comet spins up and lands on the real time; switching off draws it back in.
 *
 * Cost: three alpha masks are built once, off the UI thread, per scene. Each frame is two clipped layers, a few
 * bitmaps and at most 34 dots, at about 24 frames a second (12 on a low battery).
 */
final class Lumen {

    static final long ARM_MS = 6000L;

    private static final long RING_MS = 1500L, FADE_MS = 800L, LAP_MS = 12_000L;
    private static final int MOTES = 34;
    private static final int GOLD = 0xFFFFD27A, WARM = 0xFFFFE9BD, MOTE = 0xFFFFF1CC;
    private static final int[] SWEEP = {0x00FFD98A, 0x00FFD98A, 0x40FFD98A, 0xB8FFE3A6, 0xFFFFFFF0};
    private static final float[] SWEEP_AT = {0f, 0.52f, 0.78f, 0.95f, 1f};

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** Wanted state. Saved by the renderer. */
    boolean on;

    private long changedAt = -1L, readyAt = -1L, armedAt = -1L, lastMs = -1L;
    private boolean quiet;
    private float level, levelFrom, vis, str;
    private int width, height;

    // masks built off the UI thread: wide glow, tight glow (both outside the cutout), thin rim (inside it)
    private Bitmap wide, tight, rim;
    private final int[] offWide = new int[2], offTight = new int[2];
    private float[] edge;
    private int edgeN, maskW;
    private int gen;
    private boolean building;

    private final Paint maskPaint = new Paint();
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sweepPaint = new Paint();
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vignette = new Paint();
    private final RectF oval = new RectF();
    private final Matrix m = new Matrix();
    private SweepGradient sweep;
    private int vigW, vigH;
    private final Random random = new Random();

    private final float[] mx = new float[MOTES], my = new float[MOTES], mvx = new float[MOTES], mvy = new float[MOTES];
    private final float[] mAge = new float[MOTES], mLife = new float[MOTES], mSize = new float[MOTES], mPhase = new float[MOTES];
    private float spawnAcc, frameDt = 0.04f, centreY;

    Lumen() {
        maskPaint.setColor(Color.WHITE);
        sweepPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeCap(Paint.Cap.ROUND);
        sweep = new SweepGradient(0f, 0f, SWEEP, SWEEP_AT);
        for (int i = 0; i < MOTES; i++) mLife[i] = 0f;
    }

    // ---------- state ----------

    void arm(long now) {
        armedAt = now;
    }

    boolean armed(long now) {
        return armedAt >= 0 && now - armedAt < ARM_MS;
    }

    void disarm() {
        armedAt = -1L;
    }

    /** The unlock succeeded: switch on or off with the full show. Returns the new state. */
    boolean toggle(long now) {
        on = !on;
        changedAt = now;
        levelFrom = level;
        quiet = false;
        readyAt = (on && wide != null) ? now : -1L;
        armedAt = -1L;
        return on;
    }

    /** Settings changed from outside (startup, the app): follow quietly, no shockwave. */
    void sync(boolean want, long now) {
        if (want == on) return;
        on = want;
        changedAt = now;
        levelFrom = level;
        quiet = true;
        readyAt = (on && wide != null) ? now : -1L;
    }

    /** The scene changed: masks belong to the old cutout. */
    void reset() {
        gen++;
        wide = null;
        tight = null;
        rim = null;
        edge = null;
        edgeN = 0;
        building = false;
        readyAt = -1L;
        quiet = true;                                      // a rebuilt cutout should not replay the show
        java.util.Arrays.fill(mLife, 0f);
    }

    /** True while something smooth is changing and frames should follow the display. */
    boolean transition(long now) {
        if (changedAt < 0) return false;
        long span = on ? RING_MS + 1500L : FADE_MS + 150L;
        return now - changedAt < span || (on && wide == null && building);
    }

    /** True while there is anything on screen that needs steady frames. */
    boolean live(long now) {
        return level > 0.002f || armed(now) || (on && building);
    }

    // ---------- per frame ----------

    /** Call once per frame before drawing. enabled = false while the bands or the sleep clock own the screen. */
    void step(long now, boolean enabled, Scene s, float gate, int w, int h) {
        width = w;
        height = h;
        float dt = lastMs < 0 ? 0.016f : Math.min(0.1f, (now - lastMs) / 1000f);
        lastMs = now;
        frameDt = dt;
        boolean subject = s != null && s.subject != null && !s.subject.isRecycled();
        if (on && enabled && subject && wide == null && !building) build(s.subject);
        if (on && wide != null && readyAt < 0) readyAt = now;

        if (on) {
            float t = readyAt < 0 ? 0f : (now - readyAt) / (quiet ? 600f : 1400f);
            t = Math.max(0f, Math.min(1f, t));
            level = t * t * (3f - 2f * t);
        } else if (changedAt >= 0) {
            float t = Math.max(0f, Math.min(1f, (now - changedAt) / (float) FADE_MS));
            level = levelFrom * (1f - t * t * (3f - 2f * t));
        } else {
            level = 0f;
        }
        float to = enabled ? 1f : 0f;
        vis += Math.max(-dt * 2f, Math.min(dt * 2f, to - vis));
        str = level * vis * Math.max(0f, Math.min(1f, gate));
    }

    // ---------- drawing ----------

    /** Soft darkening of the corners, above the photo and below everything else. */
    void drawVignette(Canvas c) {
        float a = str * 0.36f;
        if (a < 0.01f || width <= 0) return;
        if (vigW != width || vigH != height) {
            vigW = width;
            vigH = height;
            vignette.setShader(new RadialGradient(width / 2f, height / 2f, (float) Math.hypot(width, height) * 0.55f,
                    new int[]{0x00000000, 0x00000000, 0xFF000000}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        }
        vignette.setAlpha((int) (255 * Math.min(1f, a)));
        c.drawRect(0f, 0f, width, height, vignette);
    }

    /** Glow outside the outline plus the travelling light. Drawn before the cutout. */
    void drawBehind(Canvas c, long now, float left, float top) {
        if (str < 0.01f || wide == null || tight == null) return;
        float breath = 0.78f + 0.22f * (float) Math.sin(now / 1100.0);
        float xw = left + offWide[0], yw = top + offWide[1];
        glow.setColor(GOLD);
        glow.setAlpha((int) (255 * str * 0.34f * breath));
        c.drawBitmap(wide, xw, yw, glow);
        glow.setAlpha((int) (255 * str * 0.50f * breath));
        c.drawBitmap(tight, left + offTight[0], top + offTight[1], glow);

        // the comet: both glows as one mask, lit by a sweeping gradient
        int sc = c.saveLayer(xw, yw, xw + wide.getWidth(), yw + wide.getHeight(), null);
        maskPaint.setAlpha(150);
        c.drawBitmap(wide, xw, yw, maskPaint);
        maskPaint.setAlpha(255);
        c.drawBitmap(tight, left + offTight[0], top + offTight[1], maskPaint);
        lightSweep(c, now, left, top, xw, yw, wide.getWidth(), wide.getHeight(), 1f);
        c.restoreToCount(sc);
    }

    /** Rim inside the outline, motes and the shockwave. Drawn after the cutout. */
    void drawFront(Canvas c, long now, float left, float top, float crownX, float crownY) {
        if (str >= 0.01f && rim != null) {
            float breath = 0.78f + 0.22f * (float) Math.sin(now / 1100.0 + 1.3);
            glow.setColor(WARM);
            glow.setAlpha((int) (255 * str * 0.34f * breath));
            c.drawBitmap(rim, left, top, glow);
            int sc = c.saveLayer(left, top, left + rim.getWidth(), top + rim.getHeight(), null);
            c.drawBitmap(rim, left, top, maskPaint);
            lightSweep(c, now, left, top, left, top, rim.getWidth(), rim.getHeight(), 1.15f);
            c.restoreToCount(sc);
            motes(c, now, left, top);
        }
        shockwave(c, now, crownX, crownY);
    }

    /** The countdown ring around the clock while the unlock is waiting for its last two taps. */
    void drawArm(Canvas c, long now, float cx, float cy, float r) {
        if (!armed(now)) return;
        float t = now - armedAt;
        float a = smooth(t / 260f) * smooth((ARM_MS - t) / 500f);
        float rem = 1f - t / (float) ARM_MS;
        float rr = r * 1.14f;
        float pulse = 0.5f + 0.5f * (float) Math.sin(t / 170.0);
        oval.set(cx - rr, cy - rr, cx + rr, cy + rr);

        ring.setColor(GOLD);
        ring.setStrokeWidth(Math.max(6f, r * 0.085f));
        ring.setAlpha((int) (255 * a * (0.14f + 0.08f * pulse)));
        c.drawArc(oval, -90f, 360f * rem, false, ring);
        ring.setStrokeWidth(Math.max(2.2f, r * 0.024f));
        ring.setColor(0xFFFFE6A8);
        ring.setAlpha((int) (255 * a * 0.95f));
        c.drawArc(oval, -90f, 360f * rem, false, ring);

        double ang = Math.toRadians(-90.0 + 360.0 * rem);
        float hx = cx + (float) Math.cos(ang) * rr, hy = cy + (float) Math.sin(ang) * rr;
        dot.setColor(GOLD);
        dot.setAlpha((int) (255 * a * 0.30f));
        c.drawCircle(hx, hy, r * 0.085f * (1f + 0.3f * pulse), dot);
        dot.setColor(0xFFFFFFF4);
        dot.setAlpha((int) (255 * a));
        c.drawCircle(hx, hy, r * 0.036f, dot);

        if (t < 420f) {                                    // the moment it arms: one clean ripple off the dial
            float p = t / 420f;
            float e = 1f - (1f - p) * (1f - p) * (1f - p);
            ring.setColor(GOLD);
            ring.setStrokeWidth(Math.max(2f, r * 0.02f));
            ring.setAlpha((int) (255 * (1f - p) * 0.7f));
            c.drawCircle(cx, cy, r * (1.0f + 0.55f * e), ring);
        }
    }

    // ---------- pieces ----------

    private void lightSweep(Canvas c, long now, float left, float top, float x, float y, int w, int h, float amp) {
        float cxs = left + maskW / 2f, cys = top + (edge != null ? centreY : h / 2f);
        long t = now % LAP_MS;
        float deg = t * 360f / LAP_MS - 90f;
        if (!quiet && readyAt >= 0 && on) {                // switching on: spin up fast, decelerate, land on the real time
            float p = Math.max(0f, Math.min(1f, (now - readyAt) / 1900f));
            float e = 1f - (1f - p) * (1f - p) * (1f - p);
            deg -= 720f * (1f - e);
        }
        long sinceMinute = now % 60_000L;                   // a flare each full minute
        float flare = 1f + 0.7f * (float) Math.exp(-sinceMinute / 650.0);
        m.setRotate(deg, 0f, 0f);
        m.postTranslate(cxs, cys);
        sweep.setLocalMatrix(m);
        sweepPaint.setShader(sweep);
        sweepPaint.setAlpha((int) (255 * Math.min(1f, str * amp * flare)));
        c.drawRect(x, y, x + w, y + h, sweepPaint);
    }

    private void motes(Canvas c, long now, float left, float top) {
        float dt = frameDt;
        if (edge != null && str > 0.3f) {
            spawnAcc += dt * 16f * str;
            while (spawnAcc >= 1f) {
                spawnAcc -= 1f;
                int slot = -1;
                for (int i = 0; i < MOTES; i++) {
                    if (mAge[i] >= mLife[i]) {
                        slot = i;
                        break;
                    }
                }
                if (slot < 0) break;
                int k = random.nextInt(edgeN) * 2;
                float u = width / 400f;
                mx[slot] = left + edge[k];
                my[slot] = top + edge[k + 1];
                mvx[slot] = (edge[k] < maskW / 2f ? -1f : 1f) * (4f + random.nextFloat() * 14f) * u;
                mvy[slot] = -(14f + random.nextFloat() * 38f) * u;
                mSize[slot] = (1.1f + random.nextFloat() * 2.3f) * u;
                mLife[slot] = 1.8f + random.nextFloat() * 2.2f;
                mAge[slot] = 0f;
                mPhase[slot] = random.nextFloat() * 6.28f;
            }
        }
        for (int i = 0; i < MOTES; i++) {
            if (mAge[i] >= mLife[i]) continue;
            mAge[i] += dt;
            mx[i] += mvx[i] * dt + (float) Math.sin(mPhase[i] + mAge[i] * 2.2f) * 0.25f;
            my[i] += mvy[i] * dt;
            float p = mAge[i] / mLife[i];
            float a = (float) Math.sin(Math.PI * Math.min(1f, p)) * (0.55f + 0.45f * (float) Math.sin(mPhase[i] + mAge[i] * 9f));
            a = Math.max(0f, a) * str;
            if (a < 0.02f) continue;
            dot.setColor(GOLD);
            dot.setAlpha((int) (255 * a * 0.22f));
            c.drawCircle(mx[i], my[i], mSize[i] * 3.2f, dot);
            dot.setColor(MOTE);
            dot.setAlpha((int) (255 * Math.min(1f, a)));
            c.drawCircle(mx[i], my[i], mSize[i], dot);
        }
    }

    private void shockwave(Canvas c, long now, float x, float y) {
        if (quiet || changedAt < 0 || width <= 0) return;
        long t = now - changedAt;
        if (t < 0 || t >= RING_MS + 200) return;
        float maxR = (float) Math.hypot(width, height) * 0.55f;
        for (int i = 0; i < 2; i++) {
            float p = (t - i * 160f) / RING_MS;
            if (p <= 0f || p >= 1f) continue;
            float k = i == 0 ? 1f : 0.5f;
            float radius, a;
            if (on) {
                float e = 1f - (1f - p) * (1f - p) * (1f - p);
                radius = e * maxR;
                a = (float) Math.pow(1f - p, 1.4) * 0.8f * k;
            } else {
                float e = 1f - (1f - p) * (1f - p);
                radius = (1f - e) * maxR * 0.5f;
                a = (float) Math.sin(Math.PI * p) * 0.5f * k;
            }
            float wdt = Math.max(2f, width * 0.005f) * (1f + (1f - p));
            ring.setColor(GOLD);
            ring.setStrokeWidth(wdt * 5f);
            ring.setAlpha((int) (255 * a * 0.16f));
            c.drawCircle(x, y, radius, ring);
            ring.setColor(0xFFFFEBBF);
            ring.setStrokeWidth(wdt);
            ring.setAlpha((int) (255 * a));
            c.drawCircle(x, y, radius, ring);
        }
    }

    private static float smooth(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x * x * (3f - 2f * x);
    }

    // ---------- masks, built once per scene on a worker thread ----------

    private void build(final Bitmap src) {
        final int g = gen;
        building = true;
        POOL.execute(() -> {
            Bitmap w = null, t = null, r = null;
            int[] ow = new int[2], ot = new int[2], oi = new int[2];
            float[] pts = new float[1024];
            int n = 0, mw = 0;
            float midY = 0f;
            try {
                if (!src.isRecycled()) {
                    int sw = src.getWidth(), sh = src.getHeight();
                    mw = sw;
                    float rad = Math.max(10f, sw * 0.024f);
                    Paint p = new Paint();
                    p.setMaskFilter(new BlurMaskFilter(rad, BlurMaskFilter.Blur.OUTER));
                    w = src.extractAlpha(p, ow);
                    p.setMaskFilter(new BlurMaskFilter(rad * 0.3f, BlurMaskFilter.Blur.OUTER));
                    t = src.extractAlpha(p, ot);

                    // thin rim inside the outline = the silhouette minus its blurred inside
                    p.setMaskFilter(new BlurMaskFilter(rad * 0.34f, BlurMaskFilter.Blur.INNER));
                    Bitmap inner = src.extractAlpha(p, oi);
                    Bitmap hard = src.extractAlpha();
                    Bitmap tmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
                    Canvas cv = new Canvas(tmp);
                    Paint white = new Paint();
                    white.setColor(Color.WHITE);
                    cv.drawBitmap(hard, 0f, 0f, white);
                    Paint cut = new Paint();
                    cut.setColor(Color.WHITE);
                    cut.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
                    cv.drawBitmap(inner, oi[0], oi[1], cut);
                    r = tmp.extractAlpha();
                    tmp.recycle();
                    inner.recycle();
                    hard.recycle();

                    // points on the outline, for the motes; and the vertical middle of the person for the comet
                    int step = Math.max(3, sh / 220), first = -1, last = 0;
                    int[] row = new int[sw];
                    for (int y = 0; y < sh && n < pts.length - 4; y += step) {
                        src.getPixels(row, 0, sw, 0, y, sw, 1);
                        int a = -1, b = -1;
                        for (int x = 0; x < sw; x += 2) {
                            if ((row[x] >>> 24) > 128) {
                                if (a < 0) a = x;
                                b = x;
                            }
                        }
                        if (a >= 0) {
                            if (first < 0) first = y;
                            last = y;
                            pts[n++] = a;
                            pts[n++] = y;
                            pts[n++] = b;
                            pts[n++] = y;
                        }
                    }
                    midY = first < 0 ? sh / 2f : (first + last) / 2f;
                }
            } catch (RuntimeException | OutOfMemoryError e) {
                w = null;
                t = null;
                r = null;
                n = 0;
            }
            final Bitmap fw = w, ft = t, fr = r;
            final int[] fow = ow, fot = ot;
            final float[] fpts = pts;
            final int fn = n / 2, fmw = mw;
            final float fmid = midY;
            MAIN.post(() -> {
                if (g != gen) return;
                building = false;
                if (fw == null || ft == null || fr == null || fn == 0) return;
                offWide[0] = fow[0];
                offWide[1] = fow[1];
                offTight[0] = fot[0];
                offTight[1] = fot[1];
                edge = fpts;
                edgeN = fn;
                maskW = fmw;
                centreY = fmid;
                tight = ft;
                rim = fr;
                wide = fw;
            });
        });
    }
}
