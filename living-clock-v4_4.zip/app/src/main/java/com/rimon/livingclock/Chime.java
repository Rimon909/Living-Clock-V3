package com.rimon.livingclock;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The sounds of Lumen Edge, synthesised in code (no audio files): glass notes with a short echo, a low boom and
 * a rising air sweep. They play on the system-sound stream, so they follow the ringer and system volume, stay
 * silent in silent mode, and are never mistaken for music by the bands. Each sound has a matching haptic tick.
 */
final class Chime {

    static final int ARM = 0, IGNITE = 1, OFF = 2;

    private static final int RATE = 32_000;
    private static final long[][] BUZZ = {{0, 10, 55, 16}, {0, 14, 60, 12, 60, 40}, {0, 22}};

    private final Context app;
    private final Handler main;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final short[][] bank = new short[3][];
    private final List<AudioTrack> playing = new ArrayList<>();
    private boolean building, released;

    Chime(Context c, Handler main) {
        this.app = c.getApplicationContext();
        this.main = main;
    }

    /** Builds the three sounds in the background so the first tap is instant. */
    void warm() {
        if (building || released || bank[0] != null) return;
        building = true;
        pool.execute(() -> {
            short[] a = arm(), b = ignite(), c = off();
            main.post(() -> {
                building = false;
                if (released) return;
                bank[ARM] = a;
                bank[IGNITE] = b;
                bank[OFF] = c;
            });
        });
    }

    void play(int id) {
        if (released) return;
        buzz(id);
        short[] pcm = bank[id];
        if (pcm == null) {
            warm();
            return;
        }
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build();
            final AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(pcm.length * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            if (track.write(pcm, 0, pcm.length) <= 0) {
                track.release();
                return;
            }
            playing.add(track);
            track.play();
            long ms = pcm.length * 1000L / RATE + 250L;
            main.postDelayed(() -> free(track), ms);
        } catch (RuntimeException e) {
            // No audio output right now: the visual still plays.
        }
    }

    private void free(AudioTrack t) {
        if (!playing.remove(t)) return;
        try {
            t.stop();
        } catch (RuntimeException ignored) {
            // Already stopped.
        }
        t.release();
    }

    void release() {
        released = true;
        for (AudioTrack t : new ArrayList<>(playing)) free(t);
        pool.shutdown();
    }

    @SuppressWarnings("deprecation")
    private void buzz(int id) {
        try {
            Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(BUZZ[id], -1));
            else v.vibrate(BUZZ[id], -1);
        } catch (RuntimeException ignored) {
            // No vibrator permission or hardware.
        }
    }

    // ---------- synthesis ----------

    private static short[] arm() {
        float[] b = new float[(int) (RATE * 0.9f)];
        glass(b, 0.00f, 1318.5f, 0.30f, 0.20f);     // E6
        glass(b, 0.11f, 1975.5f, 0.26f, 0.26f);     // B6
        return finish(b, 0.5f, true);
    }

    private static short[] ignite() {
        float[] b = new float[(int) (RATE * 2.6f)];
        boom(b, 0f, 0.55f);
        air(b, 0f, 0.72f, 0.20f);
        float[] notes = {523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f};   // C5 E5 G5 C6 E6, rising
        for (int i = 0; i < notes.length; i++) glass(b, 0.40f + 0.075f * i, notes[i], 0.24f, 0.55f);
        glass(b, 0.80f, 1567.98f, 0.20f, 0.95f);    // G6, the long top note
        glass(b, 0.80f, 1046.5f, 0.18f, 0.95f);     // C6 under it
        return finish(b, 0.62f, true);
    }

    private static short[] off() {
        float[] b = new float[(int) (RATE * 1.0f)];
        glass(b, 0.00f, 1318.5f, 0.22f, 0.22f);     // E6
        glass(b, 0.10f, 880f, 0.24f, 0.34f);        // A5, stepping down
        return finish(b, 0.45f, true);
    }

    /** A struck-glass note: a few inharmonic partials, the higher ones dying faster, a faint detuned twin for shimmer. */
    private static void glass(float[] out, float at, float freq, float amp, float tau) {
        int start = (int) (at * RATE);
        float[] ratio = {1f, 2.0f, 2.76f, 5.4f};
        float[] gain = {1f, 0.34f, 0.2f, 0.08f};
        for (int p = 0; p < ratio.length; p++) {
            float f = freq * ratio[p];
            if (f > RATE * 0.45f) continue;
            float decay = tau / (1f + 0.7f * p);
            double w = 2.0 * Math.PI * f / RATE, w2 = 2.0 * Math.PI * f * 1.0032 / RATE;
            for (int i = 0; start + i < out.length; i++) {
                float t = i / (float) RATE;
                if (t > decay * 9f) break;
                float env = (float) Math.exp(-t / decay) * Math.min(1f, t / 0.004f);
                out[start + i] += amp * gain[p] * env * (float) (Math.sin(w * i) + 0.45 * Math.sin(w2 * i));
            }
        }
    }

    /** A low thump whose pitch falls as it fades. */
    private static void boom(float[] out, float at, float amp) {
        int start = (int) (at * RATE);
        double phase = 0.0;
        for (int i = 0; start + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > 0.9f) break;
            double f = 44.0 + 52.0 * Math.exp(-t / 0.07);
            phase += 2.0 * Math.PI * f / RATE;
            float env = (float) Math.exp(-t / 0.22) * Math.min(1f, t / 0.006f);
            out[start + i] += amp * env * (float) Math.sin(phase);
        }
    }

    /** A swell of air that brightens as it rises: low-passed noise with a climbing cutoff. */
    private static void air(float[] out, float at, float len, float amp) {
        int start = (int) (at * RATE), n = (int) (len * RATE);
        Random rnd = new Random(7);
        float lp = 0f;
        for (int i = 0; i < n && start + i < out.length; i++) {
            float p = i / (float) n;
            float k = 0.015f + 0.34f * p * p;
            lp += k * ((rnd.nextFloat() * 2f - 1f) - lp);
            float env = (float) Math.sin(Math.PI * Math.pow(p, 0.65)) * p;
            out[start + i] += amp * 2.4f * env * lp;
        }
    }

    /** Adds a soft two-tap echo, tames peaks, fades the tail and converts to 16-bit. */
    private static short[] finish(float[] b, float peak, boolean echo) {
        if (echo) {
            float[] dry = b.clone();
            int d1 = (int) (0.19f * RATE), d2 = (int) (0.37f * RATE);
            for (int i = 0; i < b.length; i++) {
                if (i >= d1) b[i] += 0.30f * dry[i - d1];
                if (i >= d2) b[i] += 0.15f * dry[i - d2];
            }
        }
        float max = 1e-6f;
        for (float v : b) max = Math.max(max, Math.abs(v));
        float g = peak / max;
        int fade = (int) (RATE * 0.08f);
        short[] pcm = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            float v = b[i] * g;
            v = (float) Math.tanh(v * 1.25f) / 1.25f;                   // soft ceiling, never clips
            int left = b.length - i;
            if (left < fade) v *= left / (float) fade;
            pcm[i] = (short) Math.max(-32767, Math.min(32767, Math.round(v * 32767f)));
        }
        return pcm;
    }
}
