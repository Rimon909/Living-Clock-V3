# Living Clock

A live wallpaper: your photo, a glass clock behind you, and three shooting stars each time the minute changes.

- Choose a background photo and a subject photo separately (the subject is cut out automatically, or use a transparent PNG).
- Drag the subject or the clock on the live preview to place them.
- Adjust subject size, clock size, and turn shooting stars on or off.
- Set it as your live wallpaper from the app.

Build: push to `main`. GitHub Actions builds the debug APK and uploads it as the `Living-Clock-debug` artifact.

## Intro

When the wallpaper appears (returning home, screen on, unlock) it plays a short intro, at most once every few seconds: the subject enters in one of three random styles (settle, bloom, sheen), then the clock lifts above the subject with a soft glow while the background dims, rewinds, returns to now and settles back behind the subject. It can be switched off in the app.

### Rewind styles (choose in the app, each previews when selected)

1. **Luminous wake + spring landing**: a gold wedge and faint ghost hands trail the minute hand; the hands overshoot slightly on the way home, then a soft ring pulses.
2. **Mechanical ticking snap**: the hands ratchet in crisp steps that speed up going back and slow down coming home.
3. **Dial ticks light up**: ticks glow as the minute hand passes; numerals appear briefly at the old time.
4. **Quick and subtle**: a single fast, clean sweep of about 1.3 seconds.
5. **Wake + ticks combined**.

The seconds hand fades out while time is moving, because at rewind speed it would only flicker.

## Tap the clock

Tapping the clock face on the home screen drops dark numbers that leave thin rays. This relies on the launcher forwarding taps on empty wallpaper areas. Use **Test number drop** in the app to preview it.

## Battery

**Indicator on the dial** (choose in the app): off, rim arc, lit ticks, tiny percentage, intro-only arc, arc + percentage. At 15% or lower it turns coral; while charging a small bolt appears.

**Gestures on the clock** (home screen):
- 1 tap: numbers fall.
- 2 taps in the centre: a small battery clock swings out on a thread. It drops, snaps taut, bounces and settles, and reacts to tilt, shakes and pokes. Double tap the centre again to reel it in.
- 3 taps: the clock lifts and turns around. A dense liquid fills slowly to the battery level, tilts with gravity and changes colour with the charge. The pendulum swings out too. Triple tap again to turn back.

Everything closes by itself after 25 quiet seconds. The accelerometer runs only while the pendulum or the liquid is on screen. Taps rely on the launcher forwarding taps on empty wallpaper areas; **Test pendulum** and **Test flip** in the app preview both.

## Clock themes

Choose in the app, or double tap the top of the cutout (the head) to cycle. The change plays as a ring of light that grows out of the clock while the new theme grows into place.

1. **Classic glass**
2. **Orbit**: a ringed planet (hour), a moon (minute) and a comet with a tail (seconds) circle on orbits.
3. **Rings**: the hands are arcs that grow around the dial.
4. **Kinetic numerals**: numerals swell and glow where the hands point.
5. **Noir**: smoked glass, slim dauphine blades, a crimson accent. It also darkens the whole wallpaper: a wave of night spreads out from the clock, and switching away pulls it back in.

## Lightsaber forge (intro animation)

Three blades ignite at 12 and spin clockwise. The hour blade paints the dial behind it, throwing sparks and sweeping light across the background, then the blades swing to the real time and melt into the theme's own hands. No enlargement; only the background dims.

## Hanging numerals

One tap on the clock: the twelve numerals drop on threads from their places on the dial, one by one from 12 to 11, bounce on the thread and swing like small pendulums. Tap once more and the threads zip up and vanish while the numerals fall away. They also let go on their own after 30 quiet seconds. Four presets (choose in the app):

1. **Classic drop**: plain numerals, a clean bounce, a calm swing that settles.
2. **Wind chime**: brass plates that ring when they land, swayed by a travelling breeze.
3. **Lanterns**: numerals ignite as they arrive, with a slow floating descent and a soft flicker.
4. **Gravity**: glass drops that follow the tilt of the phone; the accelerometer is on only while they hang.

(Double tap the centre: battery pendulum. Triple tap: flip.)

## Charging sleep

When the phone is plugged in, every feature shuts down and all three hands rest at 6, with no face and no symbols. Two styles (or off):

- **Settle**: the hands are released and swing down under gravity, each as a damped pendulum with its own length, and come to rest at 6. After that nothing moves and the wallpaper wakes only every 30 seconds.
- **Breathing**: the hands glide to 6, then the dial dims and brightens on a 4.6 s cycle (about 13 breaths a minute, the calm range of an adult asleep), with a warm halo. It redraws about 12 times a second.

Unplugging swings the hands back to the real time, hour first, with a small spring on landing.

## Music bands (v3.7)

When music plays, the clock becomes twelve band members and the background dims. When it stops, the clock rebuilds itself.

- **Trigger**: Android's playback callback (event driven, nothing polls while silent). Stops 2.5 s after the music ends, so a pause between songs keeps the bands.
- **Real sync**: the system Visualizer FFT, read once per drawn frame. Needs the microphone permission; nothing is recorded. Without it (or if the device blocks the output) a simulated 118 BPM groove plays instead.
- **Twelve members**, each with its own range and character: kick, bass, toms, snare body, low vocal, vocal presence, keys, snare crack, guitar bite, hi-hats, cymbals, air. Kick and snare snap in, bass and cymbals ring out. A small tempo tracker locks a beat clock to the kicks.
- **Five styles, matched to the clock theme**: glass capsules, planets and moons, resonance rings, kinetic numerals, noir blades. Each is a core, a thin film of glow and a soft halo.
- **Five entrances** (choose or random): unwind, drop and bounce, implode and burst, wave slide, card flip. The hands are drawn into the hub by a soft-edged circle, tip first.
- **Transformer reassembly**: power-down flicker, bars fold into plates, plates swing back in ratcheting steps and dock with a spark, a ring locks around the rim, the glass fades in and the hands unfold to the real time.
- **Battery**: no work when silent; while playing, 60 Hz requested from the display (Android 11+), twelve springs, about forty strokes, no bitmaps, no blur filters, no allocation per frame.

## v3.8

- **Music bands follow real sound only.** Pausing or muting sends the bands home within about a second; a short listener wakes them when sound returns. The app asks for the microphone permission on start (nothing is recorded). Real mode is balanced across the spectrum (kick tall, air small).
- **Four new band patterns**: sunburst, mirror ribbon, LED matrix with falling peak dots, liquid wave. **Two new rebuild animations**: comet gather and card fan.
- **Charging repair**: the clock turns around and is serviced (inspect, clean, mend, oil, regulate), progress follows the battery, then it turns back polished. Choose "Repair" under While charging.
- **Kill switch** at the top of the app. Turning it on again needs the password.

## v3.9 - Developer More (scenes engine)

Main screen -> "Developer More" (same password as the kill switch). Rules of the form "when X, change Y":
signals music, charging, battery, saver, hour, weekday; conditions all/any/not with > < = between and a "for" debounce;
set pattern, exit, sleep, bands, sens, dim, fps (values can follow a signal). Higher priority wins, scenes stack.
Packs export/import as validated JSON (data only). Off by default; when on it runs about twice a second.

## v4.3 - Super 5, elemental clocks

Triple tap the top of the cutout to switch between the ordinary themes and the Super 5 (and back). Double tap loops
through the Super 5 (it never leaves them); only a triple tap goes back to the ordinary themes. The photo is never
replaced: each Super adds a faint tint, a vignette and its own atmosphere. The tap logic is unchanged from v4.2.

Each clock forms out of its own element, plays its own animation on a single tap, and comes apart in its own way. When
you glide from one to the next, the old one dies while a ring of the new colour opens from the clock.

5 **Inferno**: basalt dial split by living lava, a crown of flame, rising embers, hands forged white-hot.
  Forms: sparks spiral in, the rim ignites clockwise, fissures spread from the core. Tap: an eruption (flames surge,
  shockwaves, a fountain of sparks). Out: the cracks flare white and the dial burns to ash.
6 **Nature**: moss-glass dial in a ring of bark, a living vine with leaves and blossoms, branch hands, a dew drop for
  the seconds, fireflies and light shafts. Forms: a seed wakes, the dial grows, the vine climbs clockwise, blossoms open.
  Tap: a gust ripples the leaves and shakes petals loose. Out: the leaves turn and the wind carries everything away.
7 **Cosmos**: a spiral galaxy turning inside a photon ring, stars for the hours, hands of light, a comet for the
  seconds. Forms: a point of light breaks open and stardust accretes into a galaxy that spins down into place.
  Tap: a supernova (flash, shockwaves, a shooting star). Out: it collapses into a singularity.
8 **Nexus**: a living network of 31 nodes and 72 links with data pulses; the hands are bridges that light the nodes
  they point at. Forms: node by node, hub outward. Tap: a signal floods the network ring by ring.
  Out: links snap, nodes drift apart and the grid glitches away.
9 **Obsidian**: a volcanic-glass jewel cut into 60 facets, a polished rim, glass shard markers, blades of black glass.
  Forms: shards fly together and lock in with a flash, then a polish sweep. Tap: light runs along the cracks from the
  core. Out: it shatters.

Static art is cached in one bitmap per clock; about 20 to 115 draw calls per frame, nothing allocated while drawing.
Ambient motion about 30 fps (15 on a low battery); transitions follow the display.

## Lumen Edge (hidden premium effect)

Unlock: **four taps on the clock** (a gold ring starts counting down around the dial, with a glass chime and a haptic tick), then **two taps on the top centre of the cutout** within six seconds. Repeat the same combo to switch it off. Two taps on the head without the ring still cycle the theme, so nothing else changes.

Your silhouette becomes a source of light: a warm rim hugs the outline of the cutout and one bright comet laps around you every twelve seconds, locked to the real clock, with a flare at every full minute. Tiny motes lift off your shoulders and the corners of the photo settle into a soft vignette. Switching on sends a shockwave out from the crown of your head while the comet spins up and lands on the real time. Switching off draws it back in.

- Sounds are synthesised in code (glass notes, a low boom, a rising air sweep), no audio files. They play on the system-sound stream, so they follow the ringer and system volume, stay silent in silent mode and are never mistaken for music by the bands.
- Developer More has a switch for Lumen Edge and one for its sound and haptics.
- It stays out of the way: it hides while the music bands play, while charging with the sleep clock, and under the kill switch. About 24 frames a second, 12 on a low battery, and the glow masks are built once per photo off the UI thread.
- Three taps on the clock (flip) now wait a third of a second to be sure a fourth is not coming.
