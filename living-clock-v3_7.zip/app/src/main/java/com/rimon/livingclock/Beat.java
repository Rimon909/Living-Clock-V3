package com.rimon.livingclock;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.audiofx.Visualizer;
import android.os.Build;

/**
 * Turns music into twelve moving values, one per "band member", plus a steady beat clock.
 *
 * Real mode (microphone permission granted): the system Visualizer on the output mix delivers an FFT. It is
 * polled once per drawn frame, so nothing runs between frames and nothing at all runs when no music plays.
 * No audio is recorded or stored; the Visualizer only exposes a coarse, low-quality spectrum.
 *
 * Simulated mode (no permission, blocked output, or the preview button): a 118 BPM four-on-the-floor groove,
 * so the animation always has something to dance to.
 *
 * Each member has its own character (attack, release, flash length), like players in a real band:
 *  0 kick      1 bass       2 toms/low warmth   3 snare body   4 low vocal/chords   5 vocal presence
 *  6 keys/guitar body       7 snare crack/vocal clarity        8 guitar bite       9 hi-hats
 * 10 cymbals/shimmer       11 air/sparkle
 */
final class Beat {

    static final int N = 12;

    // Band edges in Hz. Twelve log-spaced slices from the kick to the air.
    private static final float[] HZ = {40, 80, 130, 200, 300, 450, 700, 1100, 1800, 3000, 5000, 8000, 14000};
    // Seconds. Kick and snare snap in; bass and cymbals ring out.
    private static final float[] ATTACK = {0.008f, 0.020f, 0.030f, 0.015f, 0.040f, 0.040f, 0.035f, 0.012f, 0.010f, 0.006f, 0.008f, 0.006f};
    private static final float[] RELEASE = {0.160f, 0.280f, 0.220f, 0.120f, 0.300f, 0.260f, 0.220f, 0.100f, 0.090f, 0.070f, 0.320f, 0.180f};
    private static final float[] HIT_TAU = {0.14f, 0.18f, 0.12f, 0.10f, 0.20f, 0.20f, 0.20f, 0.08f, 0.07f, 0.05f, 0.25f, 0.12f};
    private static final long[] COOL_MS = {120, 140, 110, 100, 160, 160, 140, 90, 70, 55, 120, 80};
    private static final float[] SIM_TAU = {0.12f, 0.35f, 0.16f, 0.11f, 0.40f, 0.30f, 0.24f, 0.09f, 0.08f, 0.05f, 0.30f, 0.10f};

    final float[] level = new float[N];   // smoothed 0..1, shaped by each member's attack and release
    final float[] hit = new float[N];     // 1 at an onset, then decays: drives flashes and punches
    float energy;                          // overall loudness 0..1
    float phase;                           // beats since start; the fraction is the position inside the beat
    float beatPulse;                       // 1 on the beat, falls away: a steady pulse even between onsets
    float bpm = 118f;
    boolean real;

    private Visualizer vis;
    private byte[] fft;
    private float[] mag;
    private int cap, fails;
    private float binHz, zeroSec;

    private final float[] peak = new float[N], prev = new float[N], avgFlux = new float[N], simEnv = new float[N];
    private final long[] lastHit = new long[N];
    private final float[] iois = new float[8], tmp = new float[8];
    private int ioiCount, ioiPos, lastStep = -1;
    private long lastKick;
    private float period = 60f / 118f;

    boolean start(Context c, boolean wantReal) {
        stop();
        java.util.Arrays.fill(level, 0f);
        java.util.Arrays.fill(hit, 0f);
        java.util.Arrays.fill(prev, 0f);
        java.util.Arrays.fill(prevX, 0f);
        java.util.Arrays.fill(avgFlux, 0f);
        java.util.Arrays.fill(simEnv, 0f);
        java.util.Arrays.fill(peak, 6f);
        energy = 0f;
        phase = 0f;
        ioiCount = 0;
        ioiPos = 0;
        lastStep = -1;
        lastKick = 0L;
        fails = 0;
        zeroSec = 0f;
        period = 60f / 118f;
        bpm = 118f;
        real = false;
        if (wantReal && c != null && Build.VERSION.SDK_INT >= 23
                && c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            try {
                vis = new Visualizer(0);
                cap = Visualizer.getCaptureSizeRange()[1];
                vis.setCaptureSize(cap);
                vis.setScalingMode(Visualizer.SCALING_MODE_AS_PLAYED);
                vis.setEnabled(true);
                fft = new byte[cap];
                mag = new float[cap / 2];
                binHz = vis.getSamplingRate() / 1000f / cap;
                real = binHz > 1f;
            } catch (RuntimeException e) {
                real = false;
            }
            if (!real) release();
        }
        return real;
    }

    void stop() {
        release();
        real = false;
    }

    private void release() {
        if (vis == null) return;
        try {
            vis.setEnabled(false);
        } catch (RuntimeException ignored) {
            // Already gone.
        }
        try {
            vis.release();
        } catch (RuntimeException ignored) {
            // Already gone.
        }
        vis = null;
    }

    /** Called once per drawn frame while the bands are on screen. */
    void update(long now, float dt) {
        if (dt <= 0f) return;
        float[] x = prevX;                          // real mode reads the spectrum; otherwise the groove drives
        if (real) {
            if (!readSpectrum(now, dt) && !real) {  // the Visualizer was blocked: carry on with the groove
                groove(dt, now);
                x = simEnv;
            }
        } else {
            groove(dt, now);
            x = simEnv;
        }

        float sum = 0f;
        for (int i = 0; i < N; i++) {
            float target = x[i];
            float tau = target > level[i] ? ATTACK[i] : RELEASE[i];
            level[i] += (target - level[i]) * (1f - (float) Math.exp(-dt / tau));
            hit[i] *= (float) Math.exp(-dt / HIT_TAU[i]);
            sum += level[i];
        }
        float e = sum / N;
        energy += (e - energy) * (1f - (float) Math.exp(-dt / 0.25f));

        phase += dt / period;
        float f = phase - (float) Math.floor(phase);
        float inv = 1f - f;
        beatPulse = inv * inv * inv;
    }

    // ---------- real audio ----------

    private final float[] prevX = new float[N];

    private boolean readSpectrum(long now, float dt) {
        int s;
        try {
            s = vis.getFft(fft);
        } catch (RuntimeException e) {
            s = Visualizer.ERROR;
        }
        if (s != Visualizer.SUCCESS) {
            if (++fails > 30) {
                release();
                real = false;
            }
            return false;
        }
        fails = 0;
        int half = cap / 2;
        float total = 0f;
        for (int k = 1; k < half; k++) {
            float re = fft[2 * k], im = fft[2 * k + 1];
            float m = (float) Math.sqrt(re * re + im * im);
            mag[k] = m;
            total += m;
        }
        if (total < 1f) {                           // some devices hand out silence for protected output
            zeroSec += dt;
            if (zeroSec > 2.0f) {
                release();
                real = false;
            }
            return false;
        }
        zeroSec = 0f;

        float decay = (float) Math.exp(-dt / 6f), fluxK = 1f - (float) Math.exp(-dt / 0.5f);
        for (int i = 0; i < N; i++) {
            float m = bandMag(HZ[i], HZ[i + 1]);
            peak[i] = Math.max(Math.max(m, peak[i] * decay), 6f);   // per-band auto gain: every member moves
            float v = m / peak[i];
            v = (float) Math.pow(v < 0f ? 0f : (v > 1f ? 1f : v), 1.3);
            prevX[i] = v;

            float flux = Math.max(0f, v - prev[i]);
            prev[i] = v;
            avgFlux[i] += (flux - avgFlux[i]) * fluxK;
            if (flux > avgFlux[i] * 2.2f + 0.05f && now - lastHit[i] > COOL_MS[i]) {
                lastHit[i] = now;
                hit[i] = 1f;
                if (i <= 1) kick(now);
            }
        }
        return true;
    }

    /** Mean magnitude between two frequencies; narrow slices are read by interpolating between bins. */
    private float bandMag(float lo, float hi) {
        int half = mag.length;
        float a = lo / binHz, b = hi / binHz;
        if (b - a < 1f) return sample((a + b) * 0.5f, half);
        int i0 = Math.max(1, (int) Math.ceil(a)), i1 = Math.min(half - 1, (int) Math.floor(b));
        if (i1 < i0) return sample((a + b) * 0.5f, half);
        float t = 0f;
        for (int k = i0; k <= i1; k++) t += mag[k];
        return t / (i1 - i0 + 1);
    }

    private float sample(float pos, int half) {
        int k = (int) pos;
        if (k < 1) return mag[1];
        if (k >= half - 1) return mag[half - 1];
        float f = pos - k;
        return mag[k] * (1f - f) + mag[k + 1] * f;
    }

    // ---------- tempo ----------

    /** Kick onsets feed a small tempo estimate and nudge the beat clock so it stays locked to the music. */
    private void kick(long now) {
        if (now - lastKick < 200) return;
        if (lastKick > 0) {
            float ioi = (now - lastKick) / 1000f;
            if (ioi < 2f) {
                while (ioi < 0.30f) ioi *= 2f;
                while (ioi > 0.75f) ioi *= 0.5f;
                iois[ioiPos] = ioi;
                ioiPos = (ioiPos + 1) & 7;
                if (ioiCount < 8) ioiCount++;
                if (ioiCount >= 4) {
                    System.arraycopy(iois, 0, tmp, 0, ioiCount);
                    for (int a = 1; a < ioiCount; a++) {
                        float v = tmp[a];
                        int b = a - 1;
                        while (b >= 0 && tmp[b] > v) {
                            tmp[b + 1] = tmp[b];
                            b--;
                        }
                        tmp[b + 1] = v;
                    }
                    float med = tmp[ioiCount / 2];
                    period += (med - period) * 0.35f;
                    bpm = 60f / period;
                }
            }
        }
        lastKick = now;
        float err = phase - Math.round(phase);      // the kick should land on a whole beat
        phase -= 0.3f * err;
    }

    // ---------- simulated groove ----------

    private void groove(float dt, long now) {
        for (int i = 0; i < N; i++) simEnv[i] *= (float) Math.exp(-dt / SIM_TAU[i]);

        int step = (int) Math.floor(phase * 4f);
        if (step != lastStep) {
            lastStep = step;
            int s = step & 15, bar = (step >> 4) & 7;
            if (s == 0 || s == 8 || (s == 6 && (bar & 1) == 1) || (s == 11 && (bar & 3) == 3)) fire(0, 1f);
            if (s == 0 || s == 3 || s == 6 || s == 10) fire(1, s == 0 ? 0.95f : 0.7f);
            if (s == 4 || s == 12) {
                fire(3, 0.95f);
                fire(7, 0.85f);
                fire(2, 0.5f);
            }
            if (s == 0 && (bar & 1) == 0 || s == 7) {
                fire(4, 0.8f);
                fire(6, 0.75f);
                fire(8, 0.5f);
            }
            if (bar >= 2 && bar <= 3 || bar >= 6) {
                if (s == 0 || s == 8) fire(5, 0.9f);
            }
            if ((s & 1) == 0) fire(9, (s & 3) == 2 ? 0.8f : 0.5f);
            if (s == 14) fire(10, 0.9f);
            if (s == 0 && bar == 0) fire(10, 1f);
            if ((step * 7 + bar) % 5 == 0) fire(11, 0.6f);
        }
        float w = 0.5f + 0.5f * (float) Math.sin(now * 0.0061);   // a little vibrato on the sustained vocal member
        simEnv[5] *= 0.9f + 0.1f * w;
    }

    private void fire(int i, float amp) {
        if (amp > simEnv[i]) simEnv[i] = amp;
        hit[i] = 1f;
    }
}
