package com.rimon.livingclock;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.Random;

/**
 * The clock turns into twelve band members while music plays, and builds itself back when it stops.
 *
 * Members: the twelve hour ticks. Each one becomes a player with its own frequency range and character
 * (see Beat). They line up in a straight row at the clock's height.
 *
 * Styles follow the clock theme: 0 glass capsules, 1 planets and moons, 2 resonance rings,
 * 3 kinetic numerals, 4 noir blades. Each is a core, a thin film of glow and a soft halo.
 *
 * Five entrances: 0 unwind (a swirling cascade), 1 drop and bounce, 2 implode and burst,
 * 3 wave slide from the centre, 4 card flip. The hands never snap away: a soft-edged circle closes
 * around the hub and draws them in, tip first.
 *
 * Reassembly ("transformer"): the bars power down with a flicker and fold into plates, the plates swing
 * back along the dial in ratcheting steps and dock with a spark, a thin ring locks around the rim,
 * the glass fades in and the hands unfold from the hub to the real time while the dim lifts.
 *
 * Cost: nothing runs when no music plays. While playing: twelve springs and about forty strokes per frame,
 * no bitmaps, no blur filters, no allocation.
 */
final class Band {

    static final int N = Beat.N;

    private static final int OFF = 0, ENTER = 1, PLAY = 2, EXIT = 3;
    private static final long ENTER_MS = 1900, EXIT_MS = 2700, STOP_AFTER_MS = 2500;
    private static final long[] ENTER_DUR = {1000, 1100, 1100, 950, 1000};

    private static final int IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A, CRIMSON = 0xFFD94452, ICE = 0xFF9ED2FF, AMBER = 0xFFFFA94D;
    private static final int[] CORE = {IVORY, IVORY, IVORY, IVORY, 0xFFFFE9EA};
    private static final int[] HALO = {GOLD, ICE, AMBER, GOLD, CRIMSON};
    private static final String[] LABEL = {"12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"};

    // Each member is a spring so a kick overshoots and settles while a cymbal shivers.
    private static final float[] STIFF = {900f, 260f, 520f, 1100f, 380f, 420f, 480f, 1200f, 1300f, 1700f, 700f, 1500f};
    private static final float[] DAMP = {26f, 22f, 24f, 34f, 24f, 24f, 24f, 36f, 38f, 44f, 20f, 40f};
    private static final float[] PUNCH = {0.34f, 0.20f, 0.26f, 0.30f, 0.14f, 0.14f, 0.16f, 0.24f, 0.22f, 0.20f, 0.18f, 0.22f};

    final Beat beat = new Beat();

    // Read by the renderer every frame.
    float clockAlpha = 1f;   // how much of the glass clock is still visible
    float cut = 1f;          // radius of the circle that keeps the hands visible (1 = all, 0 = none)
    float dim = 0f;          // how far the background has dimmed

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path blade = new Path();
    private final RectF oval = new RectF();
    private final Random random = new Random();

    private Context ctx;
    private boolean enabled = true, wantReal = true, music, demo;
    private int enterPref = 5, enterStyle, state = OFF, theme;
    private long t0, last = -1L, offSince = -1L, tNow;
    private float cx, cy, radius, width, height;
    private float rowX0, rowStep, rowY, barW, minH, maxH, tickLen, tickW;

    private final float[] sp = new float[N], sv = new float[N], delay = new float[N], frozen = new float[N];
    private final int[] order = new int[N];

    // Scratch pose for the member being drawn.
    private float px, py, pw, ph, prot, pa, pglow, ptick, psx;

    Band() {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    // ---------- control ----------

    void attach(Context c) {
        ctx = c.getApplicationContext();
    }

    void readConfig(SharedPreferences p) {
        enabled = p.getBoolean(Prefs.BAND, true);
        enterPref = Math.max(0, Math.min(5, p.getInt(Prefs.BAND_ENTER, 5)));
        wantReal = p.getBoolean(Prefs.BAND_REAL, true);
        if (!enabled && !demo && state != OFF) kill();
    }

    /** True from the first frame of the entrance to the last frame of the reassembly. */
    boolean active() {
        return state != OFF;
    }

    boolean playing() {
        return state == ENTER || state == PLAY;
    }

    /** A real signal from the system: music started or stopped. */
    void setMusic(boolean on) {
        if (on == music) return;
        music = on;
        if (on) offSince = -1L;
    }

    /** The app's test button: bands with the simulated groove, until switched off. */
    void setDemo(boolean on, long now) {
        demo = on;
        if (on) offSince = -1L;
        else if (state == PLAY || state == ENTER) offSince = now - STOP_AFTER_MS;   // leave at once
    }

    boolean demo() {
        return demo;
    }

    /** Hard stop: wallpaper hidden, charging started, or the feature switched off. */
    void kill() {
        beat.stop();
        state = OFF;
        music = false;
        demo = false;
        offSince = -1L;
        clockAlpha = 1f;
        cut = 1f;
        dim = 0f;
    }

    void place(float cx, float cy, float radius, int w, int h) {
        this.cx = cx;
        this.cy = cy;
        this.radius = radius;
        width = w;
        height = h;
        float rowW = Math.min(w * 0.9f, radius * 5.4f);
        rowStep = rowW / (N - 1);
        rowX0 = w / 2f - rowW / 2f;
        rowY = cy;
        barW = Math.min(rowStep * 0.46f, radius * 0.20f);
        minH = radius * 0.16f;
        maxH = Math.min(radius * 1.9f, h * 0.30f);
        tickLen = radius * 0.14f;
        tickW = radius * 0.035f;
    }

    // ---------- state machine ----------

    void update(long now, int theme) {
        this.theme = theme;
        tNow = now;
        float dt = last < 0 ? 0f : Math.min(0.05f, (now - last) / 1000f);
        last = now;

        boolean want = enabled && (music || demo);
        if (state == OFF) {
            if (want) begin(now);
        } else if (state == ENTER) {
            if (now - t0 >= ENTER_MS) state = PLAY;
        } else if (state == PLAY) {
            if (want) {
                offSince = -1L;
            } else {
                if (offSince < 0) offSince = now;
                if (now - offSince >= STOP_AFTER_MS) beginExit(now);
            }
        } else if (now - t0 >= EXIT_MS) {
            state = OFF;
            clockAlpha = 1f;
            cut = 1f;
            dim = 0f;
            return;
        }
        if (state == OFF) return;

        long t = now - t0;
        if (state == ENTER || state == PLAY) {
            beat.update(now, dt);
            springs(dt);
        }
        if (state == ENTER) {
            clockAlpha = 1f - smooth((t - 250f) / 650f);
            cut = 1f - easeInOut(clamp(t / 650f, 0f, 1f));
            dim = smooth(t / 1400f);
        } else if (state == PLAY) {
            clockAlpha = 0f;
            cut = 0f;
            dim = 1f;
        } else {
            dim = 1f - smooth((t - 1300f) / 1200f);
            clockAlpha = smooth((t - 1450f) / 500f);
            cut = t < 1900 ? 0f : backOut(clamp((t - 1900f) / 700f, 0f, 1f));
        }
    }

    private void begin(long now) {
        state = ENTER;
        t0 = now;
        enterStyle = enterPref < 5 ? enterPref : random.nextInt(5);
        beat.start(ctx, wantReal && !demo);
        java.util.Arrays.fill(sp, 0f);
        java.util.Arrays.fill(sv, 0f);
        for (int i = 0; i < N; i++) order[i] = i;
        if (enterStyle == 1) {
            for (int i = N - 1; i > 0; i--) {
                int j = random.nextInt(i + 1), v = order[i];
                order[i] = order[j];
                order[j] = v;
            }
        }
        for (int i = 0; i < N; i++) {
            float mid = Math.abs(i - 5.5f);
            switch (enterStyle) {
                case 0: delay[i] = i * 45f; break;
                case 1: delay[i] = order[i] * 40f; break;
                case 2: delay[i] = mid * 25f; break;
                case 3: delay[i] = mid * 50f; break;
                default: delay[i] = (i & 1) * 120f + i * 22f; break;
            }
        }
    }

    private void beginExit(long now) {
        state = EXIT;
        t0 = now;
        beat.stop();
        System.arraycopy(sp, 0, frozen, 0, N);
    }

    private void springs(float dt) {
        float h = dt * 0.5f;
        for (int s = 0; s < 2; s++) {
            for (int i = 0; i < N; i++) {
                float target = 0.05f + 0.95f * beat.level[i] + PUNCH[i] * beat.hit[i];
                if (target > 1.15f) target = 1.15f;
                sv[i] += (STIFF[i] * (target - sp[i]) - DAMP[i] * sv[i]) * h;
                sp[i] += sv[i] * h;
                if (sp[i] < 0f) {
                    sp[i] = 0f;
                    sv[i] = 0f;
                }
            }
        }
    }

    // ---------- drawing ----------

    /** Dim overlay: a flat veil with a breath of the beat, so the room seems to pulse with the music. */
    void drawDim(Canvas c) {
        if (dim <= 0.002f) return;
        float pulse = state == PLAY || state == ENTER ? beat.beatPulse * beat.energy : 0f;
        float a = dim * (0.58f - 0.07f * pulse);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(0x05070C, (int) (255 * a)));
        c.drawRect(0f, 0f, width, height, paint);
    }

    void draw(Canvas c) {
        if (state == OFF) return;
        cv = c;
        long t = tNow - t0;
        boolean exit = state == EXIT;

        // Row hairline, a faint stage line under the players.
        float rowA = state == PLAY ? 1f : (state == ENTER ? smooth((t - 900f) / 500f) : 1f - smooth(t / 400f));
        if (rowA > 0.01f) {
            float pulse = state == PLAY || state == ENTER ? beat.beatPulse : 0f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(Math.max(1f, radius * 0.008f));
            paint.setColor(withAlpha(HALO[theme], (int) ((38 + 60 * pulse) * rowA)));
            c.drawLine(rowX0 - barW, rowY, rowX0 + rowStep * (N - 1) + barW, rowY, paint);
        }

        if (state == ENTER && enterStyle == 2) hubFlash(c, t);

        for (int i = 0; i < N; i++) {
            if (exit) exitPose(i, t);
            else enterPose(i, t);
            if (pa > 0.01f) drawMember(i);
        }

        if (exit) ringLock(c, t);
    }

    // ---------- poses ----------

    private float audioH(int i, float s) {
        float v = s > 1.15f ? 1.15f : s;
        return minH + (maxH - minH) * v;
    }

    private float slotX(int i) {
        float sway = state == PLAY ? (float) Math.sin(beat.phase * Math.PI + i * 0.45f) * barW * 0.22f * beat.energy : 0f;
        return rowX0 + rowStep * i + sway;
    }

    private float dialX(int i, float rr) {
        return cx + Renderer.COS[i * 5] * rr;
    }

    private float dialY(int i, float rr) {
        return cy + Renderer.SIN[i * 5] * rr;
    }

    private void enterPose(int i, long t) {
        float dur = ENTER_DUR[enterStyle];
        float u = clamp((t - delay[i]) / dur, 0f, 1f);
        float sx = dialX(i, radius * 0.87f), sy = dialY(i, radius * 0.87f);
        float ex = slotX(i), ey = rowY;
        float ang = i * 30f, dAng = wrap180(-ang);
        float hs = smooth((u - 0.5f) / 0.5f);
        float barH = audioH(i, sp[i]);
        float e;

        pa = 1f;
        psx = 1f;
        pglow = hs;
        switch (enterStyle) {
            case 0: {                                           // unwind: a swirling cascade
                e = easeInOut(u);
                float dx = ex - sx, dy = ey - sy, len = Math.max(1f, (float) Math.hypot(dx, dy));
                float sw = (float) Math.sin(Math.PI * e) * radius * 0.6f;
                px = sx + dx * e - dy / len * sw;
                py = sy + dy * e + dx / len * sw;
                prot = ang + dAng * e;
                break;
            }
            case 1: {                                           // drop and bounce
                px = sx + (ex - sx) * easeOutCubic(clamp(u * 1.4f, 0f, 1f));
                py = sy + (ey - sy) * bounce(u);
                e = easeOutCubic(u);
                prot = ang + dAng * e;
                break;
            }
            case 2: {                                           // implode to the hub, then burst
                if (u < 0.35f) {
                    e = easeIn(u / 0.35f);
                    px = sx + (cx - sx) * e;
                    py = sy + (cy - sy) * e;
                    prot = ang + 90f * e;
                    float shrink = 1f - 0.8f * e;
                    ph = tickLen * shrink;
                    pw = tickW * shrink;
                    ptick = 1f;
                    pglow = e;
                    return;
                }
                e = backOut((u - 0.35f) / 0.65f);
                px = cx + (ex - cx) * e;
                py = cy + (ey - cy) * e;
                prot = (ang + 90f) * (1f - clamp(e, 0f, 1f)) + 0f;
                break;
            }
            case 3: {                                           // wave slide: x leads, y follows with a spring
                px = sx + (ex - sx) * easeInOut(u);
                py = sy + (ey - sy) * backOut(clamp(u * 1.12f, 0f, 1f));
                e = easeInOut(u);
                prot = ang + dAng * e;
                break;
            }
            default: {                                          // card flip: turns twice on its way
                e = easeInOut(u);
                px = sx + (ex - sx) * e;
                py = sy + (ey - sy) * e;
                prot = ang + dAng * e;
                psx = Math.max(0.06f, Math.abs((float) Math.cos(Math.PI * 2f * e)));
                pglow = hs + (u > 0.9f ? (1f - u) * 6f : 0f);
                break;
            }
        }
        float wu = smooth(u);
        ph = tickLen + (barH - tickLen) * hs;
        pw = tickW + (barW - tickW) * wu;
        ptick = 1f - smooth(u / 0.4f);
    }

    private void exitPose(int i, long t) {
        float fa = smooth(t / 450f);
        float barH = audioH(i, frozen[i]);
        float plate = tickLen;
        float startX = rowX0 + rowStep * i, startY = rowY;
        float flick = (t < 360 && ((t / 45) & 1) == 1) ? 0.55f : 1f;   // power-down flicker

        ph = barH + (plate - barH) * fa;
        pw = barW + (tickW * 1.6f - barW) * fa;
        pa = flick * (1f - smooth((t - 1700f) / 400f));
        psx = 1f;
        pglow = 0.6f * (1f - fa);
        ptick = 0f;

        float u = clamp((t - 400f - i * 55f) / 1000f, 0f, 1f);
        float er = ratchet(u);
        float r0 = (float) Math.hypot(startX - cx, startY - cy), r1 = radius * 0.87f;
        float a0 = (float) Math.atan2(startY - cy, startX - cx);
        float a1 = (float) Math.toRadians(i * 30f - 90f);
        float da = a1 - a0;
        da = (float) (da - 2 * Math.PI * Math.floor((da + Math.PI) / (2 * Math.PI)));
        float r = r0 + (r1 - r0) * er, a = a0 + da * er;
        px = cx + (float) Math.cos(a) * r;
        py = cy + (float) Math.sin(a) * r;
        prot = (i * 30f) * er;
        ph = ph + (tickLen - ph) * er;
        pw = pw + (tickW - pw) * er;
        ptick = smooth((u - 0.75f) / 0.25f);

        float dock = (t - (400f + i * 55f + 1000f)) / 260f;     // a spark where each plate locks in
        if (dock > 0f && dock < 1f) pglow = 1f + 1.6f * (1f - dock);
    }

    private void hubFlash(Canvas c, long t) {
        float p = clamp((t - 250f) / 650f, 0f, 1f);
        if (p <= 0f || p >= 1f) return;
        float k = (float) Math.sin(Math.PI * p);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(GOLD, (int) (70 * k)));
        c.drawCircle(cx, cy, radius * (0.1f + 0.35f * k), paint);
        paint.setColor(withAlpha(0xFFFFFF, (int) (200 * k)));
        c.drawCircle(cx, cy, radius * 0.06f * (0.5f + k), paint);
    }

    /** A thin ring draws itself clockwise around the rim as the plates lock in. */
    private void ringLock(Canvas c, long t) {
        float p = clamp((t - 1450f) / 600f, 0f, 1f);
        if (p <= 0f) return;
        float fade = 1f - smooth((t - 2050f) / 450f);
        if (fade <= 0.01f) return;
        float e = easeInOut(p), r = radius * 0.98f;
        oval.set(cx - r, cy - r, cx + r, cy + r);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.05f);
        paint.setColor(withAlpha(HALO[theme], (int) (60 * fade)));
        c.drawArc(oval, -90f, 360f * e, false, paint);
        paint.setStrokeWidth(radius * 0.012f);
        paint.setColor(withAlpha(CORE[theme], (int) (230 * fade)));
        c.drawArc(oval, -90f, 360f * e, false, paint);
        if (p < 1f) {                                           // the bright head of the sweep
            double a = Math.toRadians(-90f + 360f * e);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(0xFFFFFF, (int) (255 * fade)));
            c.drawCircle(cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, radius * 0.03f, paint);
        }
    }

    // ---------- member shapes ----------

    private void drawMember(int i) {
        float lv = state == EXIT ? frozen[i] : sp[i];
        float hit = state == EXIT ? 0f : beat.hit[i];
        float shape = 1f - ptick;

        saveMember();
        if (shape > 0.02f) {
            switch (theme) {
                case 1: planet(i, lv, hit, shape); break;
                case 2: resonance(i, lv, hit, shape); break;
                case 3: numeral(i, lv, hit, shape); break;
                case 4: noir(i, lv, hit, shape); break;
                default: glass(i, hit, shape); break;
            }
        }
        if (ptick > 0.02f) tick(ptick);
        restoreMember();
    }

    private Canvas cv;

    private void saveMember() {
        cv.save();
        cv.translate(px, py);
        cv.rotate(prot);
        if (psx != 1f) cv.scale(psx, 1f);
    }

    private void restoreMember() {
        cv.restore();
    }

    private void glowLine(float hl, float w, int core, int halo, float a, float g) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(w * 2.8f);
        paint.setColor(withAlpha(halo, (int) (62 * a * g)));
        cv.drawLine(0f, -hl, 0f, hl, paint);
        paint.setStrokeWidth(w * 1.5f);
        paint.setColor(withAlpha(halo, (int) (105 * a * g)));
        cv.drawLine(0f, -hl, 0f, hl, paint);
        paint.setStrokeWidth(w);
        paint.setColor(withAlpha(core, (int) (255 * a)));
        cv.drawLine(0f, -hl, 0f, hl, paint);
    }

    private void tick(float a) {
        glowLine(Math.max(0f, ph / 2f - pw / 2f), pw, IVORY, GOLD, pa * a, Math.min(1f, pglow + 0.3f));
    }

    /** 0: frosted capsule with a bright rim and a spark on the hit. */
    private void glass(int i, float hit, float a) {
        float hl = Math.max(0f, ph / 2f - pw / 2f);
        glowLine(hl, pw, IVORY, GOLD, pa * a * 0.62f, pglow + 0.4f);
        paint.setStrokeWidth(Math.max(1f, pw * 0.2f));
        paint.setColor(withAlpha(0xFFFFFF, (int) (210 * pa * a)));
        cv.drawLine(-pw * 0.22f, -hl * 0.82f, -pw * 0.22f, hl * 0.82f, paint);
        if (hit > 0.35f) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(0xFFFFFF, (int) (255 * hit * pa * a)));
            cv.drawCircle(0f, -ph / 2f, pw * 0.5f * hit, paint);
        }
    }

    /** 1: a ringed planet at the top of a hairline orbit, a small moon below. Hits swell the ring. */
    private void planet(int i, float lv, float hit, float a) {
        float hl = Math.max(0f, ph / 2f - pw / 2f);
        float pr = pw * (0.55f + 0.45f * Math.min(1f, lv));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, pw * 0.12f));
        paint.setColor(withAlpha(0xFFFFFF, (int) (90 * pa * a)));
        cv.drawLine(0f, -hl, 0f, hl * 0.6f, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(ICE, (int) (60 * pa * a * (pglow + 0.4f))));
        cv.drawCircle(0f, -hl, pr * 2.1f, paint);
        paint.setColor(withAlpha(IVORY, (int) (255 * pa * a)));
        cv.drawCircle(0f, -hl, pr, paint);
        paint.setColor(withAlpha(ICE, (int) (240 * pa * a)));
        cv.drawCircle(0f, hl * 0.6f, pr * 0.45f, paint);

        cv.save();
        cv.scale(1f, 0.35f, 0f, -hl);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, pw * 0.14f));
        paint.setColor(withAlpha(ICE, (int) ((150 + 80 * hit) * pa * a)));
        cv.drawCircle(0f, -hl, pr * (1.9f + 0.9f * hit), paint);
        cv.restore();
    }

    /** 2: a resonance ring whose arc grows with the level and turns with the beat. */
    private void resonance(int i, float lv, float hit, float a) {
        float rr = Math.min(rowStep * 0.40f, radius * 0.36f);
        float sweep = 28f + 320f * Math.min(1f, lv);
        float start = -90f + beat.phase * 90f * ((i & 1) == 0 ? 1f : -1f);
        oval.set(-rr, -rr, rr, rr);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, pw * 0.9f));
        paint.setColor(withAlpha(AMBER, (int) (60 * pa * a * (pglow + 0.4f))));
        cv.drawArc(oval, start, sweep, false, paint);
        paint.setStrokeWidth(Math.max(1f, pw * 0.34f));
        paint.setColor(withAlpha(IVORY, (int) (255 * pa * a)));
        cv.drawArc(oval, start, sweep, false, paint);
        if (hit > 0.05f) {
            paint.setStrokeWidth(Math.max(1f, pw * 0.14f));
            paint.setColor(withAlpha(GOLD, (int) (150 * hit * pa * a)));
            cv.drawCircle(0f, 0f, rr * (1f + 0.7f * (1f - hit)), paint);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(GOLD, (int) (255 * pa * a)));
        cv.drawCircle(0f, 0f, pw * 0.2f * (1f + hit), paint);
    }

    /** 3: the member is its own numeral; it swells with the level and bounces on a hit. */
    private void numeral(int i, float lv, float hit, float a) {
        float size = pw * (1.5f + 2.2f * Math.min(1f, lv)) * (1f + 0.25f * hit);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(size * 1.28f);
        paint.setColor(withAlpha(GOLD, (int) (38 * pa * a * (pglow + 0.4f))));
        cv.drawText(LABEL[i], 0f, size * 0.45f, paint);
        paint.setTextSize(size * 1.1f);
        paint.setColor(withAlpha(GOLD, (int) (80 * pa * a)));
        cv.drawText(LABEL[i], 0f, size * 0.40f, paint);
        paint.setTextSize(size);
        paint.setColor(withAlpha(IVORY, (int) (255 * pa * a)));
        cv.drawText(LABEL[i], 0f, size * 0.35f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, pw * 0.16f));
        paint.setColor(withAlpha(GOLD, (int) (170 * pa * a)));
        cv.drawLine(-pw * 0.7f, size * 0.7f, pw * 0.7f, size * 0.7f, paint);
    }

    /** 4: a slim dauphine blade that sways with the beat, crimson core and a white-hot edge. */
    private void noir(int i, float lv, float hit, float a) {
        float sway = ((i & 1) == 0 ? 1f : -1f) * 8f * Math.min(1f, lv) * (float) Math.sin(beat.phase * Math.PI * 2f);
        cv.rotate(sway);
        float hh = ph / 2f, ww = pw * 0.65f;
        blade.rewind();
        blade.moveTo(0f, -hh);
        blade.lineTo(ww, 0f);
        blade.lineTo(0f, hh);
        blade.lineTo(-ww, 0f);
        blade.close();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(pw * 1.3f);
        paint.setColor(withAlpha(CRIMSON, (int) (66 * pa * a * (pglow + 0.4f))));
        cv.drawPath(blade, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(CRIMSON, (int) (225 * pa * a)));
        cv.drawPath(blade, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, pw * 0.12f));
        paint.setColor(withAlpha(0xFFFFFF, (int) ((170 + 80 * hit) * pa * a)));
        cv.drawPath(blade, paint);
        paint.setStrokeJoin(Paint.Join.MITER);
    }

    // ---------- easing ----------

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static float easeInOut(float x) {
        x = clamp(x, 0f, 1f);
        return x < 0.5f ? 4f * x * x * x : 1f - (float) Math.pow(-2f * x + 2f, 3) / 2f;
    }

    private static float easeOutCubic(float x) {
        float u = 1f - clamp(x, 0f, 1f);
        return 1f - u * u * u;
    }

    private static float easeIn(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * x;
    }

    /** Ends exactly at 1 after overshooting by about 2%. */
    private static float backOut(float p) {
        p = clamp(p, 0f, 1f);
        float u = p - 1f;
        return 1f + 1.8f * u * u * u + 0.8f * u * u;
    }

    private static float bounce(float x) {
        x = clamp(x, 0f, 1f);
        if (x < 1f / 2.75f) return 7.5625f * x * x;
        if (x < 2f / 2.75f) {
            x -= 1.5f / 2.75f;
            return 7.5625f * x * x + 0.75f;
        }
        if (x < 2.5f / 2.75f) {
            x -= 2.25f / 2.75f;
            return 7.5625f * x * x + 0.9375f;
        }
        x -= 2.625f / 2.75f;
        return 7.5625f * x * x + 0.984375f;
    }

    /** Six crisp steps with a quick glide between them, like a ratcheting mechanism. */
    private static float ratchet(float x) {
        float v = clamp(x, 0f, 1f) * 6f, f = (float) Math.floor(v);
        if (f >= 6f) return 1f;
        return (f + smooth((v - f) * 1.7f)) / 6f;
    }

    private static float wrap180(float d) {
        return d - 360f * (float) Math.floor((d + 180f) / 360f);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }
}
