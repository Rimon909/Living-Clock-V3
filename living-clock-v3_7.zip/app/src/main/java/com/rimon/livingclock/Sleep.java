package com.rimon.livingclock;

import java.util.Random;

/**
 * Charging: the clock goes to sleep. Every feature shuts down and all three hands rest at 6, with no
 * face and no symbols, just a quieter clock. Two styles:
 *   1 Settle     the hands are released and swing down under gravity, each as a damped pendulum with its
 *                own length (longer hands swing slower), and come to rest at 6. After that nothing moves.
 *   2 Breathing  the hands glide to 6, then the dial dims and brightens slowly on a 4.6 s cycle, about
 *                13 breaths a minute, the calm range of an adult asleep. It redraws about 12 times a second.
 * Unplugging swings the hands back to the real time, hour first, with a small spring on landing.
 */
final class Sleep {

    private static final int AWAKE = 0, ASLEEP = 1, WAKING = 2;
    private static final float[] W = {4.16f, 3.35f, 3.13f};          // hour, minute, seconds swing rates, rad/s
    private static final long[] GLIDE = {4200L, 3600L, 3000L};
    private static final long BREATH_MS = 4600L;

    int style = 1;                       // 0 off, 1 settle, 2 breathing
    float amount;                        // 0 awake, 1 fully asleep, smoothed

    private final float[] a0 = new float[3], phi = new float[3], vel = new float[3], from = new float[3];
    private final Random rnd = new Random();
    private int state;
    private boolean settled;
    private float lin;
    private long sleepAt, wakeAt, tNow, last = -1L;

    boolean off() {
        return state != AWAKE;
    }

    boolean sleeping() {
        return state == ASLEEP;
    }

    boolean active() {
        return state != AWAKE;
    }

    void reset() {
        state = AWAKE;
        lin = amount = 0f;
        last = -1L;
    }

    void setPlugged(boolean on, long now, boolean instant, float h, float m, float s) {
        last = -1L;
        tNow = now;
        if (on) {
            a0[0] = h;
            a0[1] = m;
            a0[2] = s;
            state = ASLEEP;
            sleepAt = now;
            settled = false;
            for (int i = 0; i < 3; i++) {
                phi[i] = clamp((float) Math.toRadians(shortest(180f, a0[i])), -3.1f, 3.1f);
                vel[i] = (rnd.nextFloat() - 0.5f) * 0.4f;              // a tiny nudge so a hand at 12 still falls
            }
            if (instant) {
                lin = amount = 1f;
                settled = true;
                sleepAt = now - 10_000L;
                for (int i = 0; i < 3; i++) {
                    phi[i] = 0f;
                    vel[i] = 0f;
                }
            }
        } else if (state != AWAKE) {
            for (int i = 0; i < 3; i++) from[i] = rest(i);
            if (instant) {
                state = AWAKE;
                lin = amount = 0f;
            } else {
                state = WAKING;
                wakeAt = now;
            }
        }
    }

    void update(long now) {
        float dt = last < 0 ? 0f : Math.min(0.05f, (now - last) / 1000f);
        last = now;
        tNow = now;
        if (state == ASLEEP) {
            lin = Math.min(1f, lin + dt / 2.5f);
            if (style == 1 && !settled) physics(dt);
            if (style == 2 && now - sleepAt >= GLIDE[0]) settled = true;
        } else if (state == WAKING) {
            lin = Math.max(0f, lin - dt / 1.2f);
            if (now - wakeAt > 1800L) {
                state = AWAKE;
                lin = 0f;
            }
        }
        amount = smooth(lin);
    }

    /** Each hand a damped pendulum about the centre; equilibrium is straight down, which is 6 o'clock. */
    private void physics(float dt) {
        int steps = Math.max(1, (int) Math.ceil(dt / 0.004f));
        float hs = dt / steps;
        boolean rest = true;
        for (int i = 0; i < 3; i++) {
            float w = W[i];
            for (int k = 0; k < steps; k++) {
                vel[i] += (-w * w * (float) Math.sin(phi[i]) - 2f * 0.16f * w * vel[i]) * hs;
                phi[i] += vel[i] * hs;
            }
            if (Math.abs(phi[i]) > 0.0009f || Math.abs(vel[i]) > 0.01f) rest = false;
        }
        if (rest) {
            for (int i = 0; i < 3; i++) {
                phi[i] = 0f;
                vel[i] = 0f;
            }
            settled = true;
        }
    }

    /** The angle to draw for hand i (0 hour, 1 minute, 2 seconds); real is the true angle in degrees. */
    float angle(int i, float real) {
        if (state == ASLEEP) return rest(i);
        if (state == WAKING) {
            float p = clamp((tNow - wakeAt - i * 150L) / 1500f, 0f, 1f);
            return from[i] + shortest(from[i], real) * backOut(p);
        }
        return real;
    }

    private float rest(int i) {
        if (style == 1) return 180f + (float) Math.toDegrees(phi[i]);
        float p = clamp((tNow - sleepAt) / (float) GLIDE[i], 0f, 1f);
        return a0[i] + shortest(a0[i], 180f) * sine(p);
    }

    /** True while something is moving and frames should follow the display. */
    boolean moving(long now) {
        if (state == WAKING) return true;
        if (state != ASLEEP) return false;
        if (lin < 1f) return true;
        return style == 1 ? !settled : now - sleepAt < GLIDE[0];
    }

    private float breath(long now) {
        float ph = ((now - sleepAt) % BREATH_MS) / (float) BREATH_MS;
        return 0.5f - 0.5f * (float) Math.cos(2.0 * Math.PI * ph);
    }

    /** Brightness of the clock: quieter asleep, and in the breathing style it rises and falls. */
    float dim(long now) {
        if (state == AWAKE) return 1f;
        return 1f - amount * (style == 2 ? 0.40f - 0.16f * breath(now) : 0.34f);
    }

    /** A warm halo that breathes with the dial. */
    float glow(long now) {
        if (state == AWAKE || style != 2) return 0f;
        return amount * (0.10f + 0.30f * breath(now));
    }

    private static float shortest(float a, float b) {
        float d = (b - a) % 360f;
        if (d > 180f) d -= 360f;
        else if (d < -180f) d += 360f;
        return d;
    }

    private static float sine(float p) {
        return 0.5f - 0.5f * (float) Math.cos(Math.PI * clamp(p, 0f, 1f));
    }

    private static float backOut(float p) {
        float u = p - 1f;
        return 1f + 1.8f * u * u * u + 0.8f * u * u;
    }

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
