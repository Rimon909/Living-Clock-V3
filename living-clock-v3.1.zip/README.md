# Living Clock

A live wallpaper: your photo, a glass clock behind you, and three shooting stars each time the minute changes.

- Choose a background photo and a subject photo separately (the subject is cut out automatically, or use a transparent PNG).
- Drag the subject or the clock on the live preview to place them.
- Adjust subject size, clock size, and turn shooting stars on or off.
- Set it as your live wallpaper from the app.

Build: push to `main`. GitHub Actions builds the debug APK and uploads it as the `Living-Clock-debug` artifact.

## Intro

When the wallpaper appears (returning home, or after apps are minimised) and when the screen turns on or the device is unlocked, the subject enters in one of three random styles. The clock then rewinds to an older time and returns to now, glowing above the subject while the background dims. Use **Preview intro** in the app to test it.
