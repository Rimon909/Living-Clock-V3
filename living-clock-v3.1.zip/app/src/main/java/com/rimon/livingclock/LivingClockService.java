package com.rimon.livingclock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

/**
 * Live wallpaper. Draws once a second, 30 times a second during the intro and the shooting stars.
 * The intro plays when the wallpaper becomes visible (returning home, or after apps are minimised)
 * and when the screen turns on or the device is unlocked. Nothing draws while hidden.
 */
public class LivingClockService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new ClockEngine();
    }

    private final class ClockEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {

        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Renderer renderer = new Renderer();
        private final Runnable tick = this::frame;

        private final BroadcastReceiver wakeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renderer.playIntro(System.currentTimeMillis());
                schedule(0);
            }
        };

        private SharedPreferences prefs;
        private Scene scene;
        private boolean visible, ready, destroyed, receiverOn;
        private int width, height, generation, imageVersion;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            prefs = Prefs.get(LivingClockService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            imageVersion = prefs.getInt(Prefs.IMG, 0);
            renderer.readConfig(prefs);

            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            LivingClockService.this.registerReceiver(wakeReceiver, filter);
            receiverOn = true;
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                renderer.playIntro(System.currentTimeMillis());
                schedule(0);
            } else {
                handler.removeCallbacks(tick);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            ready = w > 0 && h > 0;
            if (!ready) return;
            if (w == width && h == height && scene != null) {
                schedule(0);
                return;
            }
            width = w;
            height = h;
            renderer.setSize(w, h);
            rebuild();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            ready = false;
            handler.removeCallbacks(tick);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            destroyed = true;
            handler.removeCallbacks(tick);
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            if (receiverOn) {
                try {
                    LivingClockService.this.unregisterReceiver(wakeReceiver);
                } catch (IllegalArgumentException ignored) {
                    // Already unregistered.
                }
                receiverOn = false;
            }
            renderer.release();
            if (scene != null) scene.recycle();
            scene = null;
            super.onDestroy();
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences p, String key) {
            renderer.readConfig(p);
            int v = p.getInt(Prefs.IMG, 0);
            if (v != imageVersion) {
                imageVersion = v;
                rebuild();
            } else {
                schedule(0);
            }
        }

        private void rebuild() {
            if (!ready || destroyed) return;
            final int gen = ++generation;
            Scene.buildAsync(LivingClockService.this, width, height,
                    prefs.getFloat(Prefs.SUBJ_SCALE, 1f), built -> {
                        if (destroyed || gen != generation) {
                            built.recycle();
                            return;
                        }
                        Scene old = scene;
                        scene = built;
                        renderer.setScene(built);
                        if (old != null) old.recycle();
                        schedule(0);
                    });
        }

        private void schedule(long delayMs) {
            handler.removeCallbacks(tick);
            if (visible && ready && !destroyed) handler.postDelayed(tick, delayMs);
        }

        private void frame() {
            if (!visible || !ready || destroyed) return;
            drawFrame(System.currentTimeMillis());
            schedule(renderer.delay(System.currentTimeMillis()));
        }

        private void drawFrame(long now) {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) canvas = holder.lockHardwareCanvas();
                if (canvas == null) canvas = holder.lockCanvas();
                if (canvas != null) renderer.draw(canvas, now);
            } catch (RuntimeException ignored) {
                // The surface can vanish mid-frame during rotation or lock-screen changes.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (RuntimeException ignored) {
                        // Surface no longer valid.
                    }
                }
            }
        }
    }
}
