package com.rimon.livingclock;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.Calendar;
import java.util.Random;

/**
 * Draws one frame: photo, glass dial, gold seconds trail, hands, subject, shooting stars.
 * On wake or when returning home, plays a short intro: the subject enters in a random style, then the
 * clock rewinds to an older time and returns, glowing above the subject while the background dims.
 */
final class Renderer {

    private static final int BG = 0xFF0E1420;
    private static final int IVORY = 0xFFFFF4E2;
    private static final int GOLD = 0xFFFFDC8A;
    private static final int AMBER = 0xFFFFA94D;
    private static final int STAR = 0xFFFFF6DC;
    private static final int TRAIL = 10;

    // Shooting stars: slow and bold.
    private static final long STAR_MS = 1800;
    private static final long[] STAR_DELAY = {0, 300, 600};
    private static final long STAR_END = 600 + 1800;

    // Intro timeline, in milliseconds from the start.
    private static final long INTRO_MS = 3200;
    private static final long ENTER_MS = 700;
    private static final long REWIND_START = 700, REWIND_END = 2600;
    private static final long LIFT_IN_START = 650, LIFT_IN_LEN = 250, LIFT_OUT_LEN = 600;
    private static final long REWIND_SPAN_MS = 14_400_000L; // four hours of old time
    private static final long INTRO_DEBOUNCE_MS = 1000;

    private static final float[] COS = new float[60];
    private static final float[] SIN = new float[60];

    static {
        for (int i = 0; i < 60; i++) {
            double a = Math.toRadians(i * 6 - 90);
            COS[i] = (float) Math.cos(a);
            SIN[i] = (float) Math.sin(a);
        }
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint dimPaint = new Paint();
    private final Path hourPath = new Path();
    private final Path minutePath = new Path();
    private final Calendar calendar = Calendar.getInstance();
    private final Random random = new Random();

    private Scene scene;
    private Bitmap dial;
    private int width, height, clockSize = 100;
    private boolean dirty = true, stars = true;
    private float cx, cy, radius;
    private float clockX = 0.34f, clockY = 0.27f, subjX = 0.5f, subjY = 0.5f;
    private int lastMinute = -1;
    private long starBase = -1L;
    private long introBase = -1L;
    private int introStyle;

    Renderer() {
        dimPaint.setColor(0xFF000000);
    }

    // ---------- configuration ----------

    void setSize(int w, int h) {
        if (w != width || h != height) {
            width = w;
            height = h;
            dirty = true;
        }
    }

    void setScene(Scene s) {
        scene = s;
    }

    void readConfig(SharedPreferences p) {
        clockX = p.getFloat(Prefs.CLOCK_X, 0.34f);
        clockY = p.getFloat(Prefs.CLOCK_Y, 0.27f);
        clockSize = p.getInt(Prefs.CLOCK_SIZE, 100);
        subjX = p.getFloat(Prefs.SUBJ_X, 0.5f);
        subjY = p.getFloat(Prefs.SUBJ_Y, 0.5f);
        stars = p.getBoolean(Prefs.STARS, true);
        dirty = true;
    }

    void setClock(float x, float y) {
        clockX = clamp(x, 0f, 1f);
        clockY = clamp(y, 0f, 1f);
        cx = clockX * width;
        cy = clockY * height;
    }

    void setSubject(float x, float y) {
        subjX = clamp(x, -0.5f, 1.5f);
        subjY = clamp(y, -0.5f, 1.5f);
    }

    void setClockSize(int pct) {
        clockSize = pct;
        dirty = true;
    }

    void setStars(boolean on) {
        stars = on;
    }

    void spawnStars(long now) {
        starBase = now;
    }

    /** Starts the intro. Calls within one second of the last start are ignored. */
    void playIntro(long now) {
        if (introBase >= 0 && now - introBase < INTRO_DEBOUNCE_MS) return;
        introBase = now;
        introStyle = random.nextInt(3);
    }

    float clockX() { return clockX; }
    float clockY() { return clockY; }
    float subjX() { return subjX; }
    float subjY() { return subjY; }

    void release() {
        if (dial != null) {
            dial.recycle();
            dial = null;
        }
    }

    /** Milliseconds until the next frame: 30 fps during the intro and the stars, otherwise once a second. */
    long delay(long now) {
        if (introActive(now) || starsActive(now)) return 33;
        return 1000 - now % 1000 + 5;
    }

    private boolean introActive(long now) {
        return introBase >= 0 && now - introBase < INTRO_MS;
    }

    private boolean starsActive(long now) {
        return stars && starBase >= 0 && now - starBase < STAR_END;
    }

    // ---------- drawing ----------

    void draw(Canvas c, long now) {
        if (width <= 0 || height <= 0) return;
        if (dirty) layout();

        calendar.setTimeInMillis(now);
        int realSec = calendar.get(Calendar.SECOND);
        int realMin = calendar.get(Calendar.MINUTE);
        if (realMin != lastMinute) {
            if (lastMinute >= 0 && stars) starBase = now;
            lastMinute = realMin;
        }

        // Intro state: lift (glow, dim, emerge), entrance, and the rewind offset.
        long t = introBase >= 0 ? now - introBase : -1L;
        boolean intro = t >= 0 && t < INTRO_MS;
        float lift = 0f, dialAlpha = 1f, clockScale = 1f, clockDy = 0f;
        float subjScale = 1f, subjDy = 0f, subjAlpha = 1f, spin = 0f;
        long shown = now;

        if (intro) {
            lift = clamp((t - LIFT_IN_START) / (float) LIFT_IN_LEN, 0f, 1f)
                    * clamp((INTRO_MS - t) / (float) LIFT_OUT_LEN, 0f, 1f);
            if (t < ENTER_MS) {
                float p = t / (float) ENTER_MS;
                float e = 1f - (1f - p) * (1f - p) * (1f - p);
                float travel = height * 0.15f * (1f - e);
                dialAlpha = e;
                if (introStyle == 0) {            // rise from below
                    subjDy = travel;
                    subjAlpha = e;
                    clockDy = travel * 0.6f;
                } else if (introStyle == 1) {     // drop from above
                    subjDy = -travel;
                    subjAlpha = e;
                    clockDy = -travel * 0.6f;
                } else {                          // zoom in
                    subjScale = 0.6f + 0.4f * e;
                    clockScale = subjScale;
                    subjAlpha = e;
                }
            }
            if (t >= REWIND_START && t < REWIND_END) {
                double phase = Math.PI * (t - REWIND_START) / (double) (REWIND_END - REWIND_START);
                float s = (float) Math.sin(phase);  // 0 -> 1 -> 0: back to old time, then forward to now
                shown = now - (long) (REWIND_SPAN_MS * s);
                spin = -1440f * s;                  // seconds hand spins backwards too
            }
        }

        calendar.setTimeInMillis(shown);
        int shownHour = calendar.get(Calendar.HOUR);
        int shownMin = calendar.get(Calendar.MINUTE);
        int shownSec = calendar.get(Calendar.SECOND);
        float hourDeg = (shownHour + shownMin / 60f) * 30f;
        float minuteDeg = (shownMin + shownSec / 60f) * 6f;
        float secDeg = realSec * 6f + spin;
        float clockS = clockScale * (1f + 0.12f * lift);

        // 1. Background, dimmed while the clock is lifted.
        if (scene != null && scene.bg != null) c.drawBitmap(scene.bg, 0f, 0f, bitmapPaint);
        else c.drawColor(BG);
        if (lift > 0f) {
            dimPaint.setAlpha((int) (120 * lift));
            c.drawRect(0f, 0f, width, height, dimPaint);
        }

        // 2. Clock behind the subject, or in front of it during the rewind.
        boolean lifted = lift > 0f;
        if (!lifted) drawClock(c, hourDeg, minuteDeg, secDeg, realSec, clockS, clockDy, dialAlpha, 0f);

        // 3. Subject.
        if (scene != null && scene.subject != null) drawSubject(c, subjDy, subjScale, subjAlpha);

        if (lifted) drawClock(c, hourDeg, minuteDeg, secDeg, realSec, clockS, clockDy, dialAlpha, lift);

        // 4. Shooting stars on top.
        if (stars && starBase >= 0) drawStars(c, now);
    }

    private void layout() {
        dirty = false;
        radius = Math.min(width * 0.21f * clockSize / 100f, width * 0.46f);
        cx = clockX * width;
        cy = clockY * height;

        int size = (int) Math.ceil(radius * 2.1f) + 4;
        if (dial == null || dial.getWidth() != size) {
            if (dial != null) dial.recycle();
            dial = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        } else {
            dial.eraseColor(0);
        }
        drawDial(new Canvas(dial), size / 2f);

        float hourLen = radius * 0.52f, minLen = radius * 0.80f, hw = radius * 0.05f;
        hourPath.rewind();
        hourPath.moveTo(0, radius * 0.12f);
        hourPath.quadTo(hw * 1.8f, -hourLen * 0.35f, 0, -hourLen);
        hourPath.quadTo(-hw * 1.8f, -hourLen * 0.35f, 0, radius * 0.12f);
        hourPath.close();

        minutePath.rewind();
        float mw = radius * 0.016f, d = radius * 0.07f, dy = -minLen * 0.78f;
        minutePath.addRect(-mw, -minLen, mw, radius * 0.14f, Path.Direction.CW);
        minutePath.moveTo(0, dy - d);
        minutePath.lineTo(d * 0.55f, dy);
        minutePath.lineTo(0, dy + d);
        minutePath.lineTo(-d * 0.55f, dy);
        minutePath.close();
    }

    /** The clock, with an optional intro transform and glow. glow is 0 when the clock sits behind the subject. */
    private void drawClock(Canvas c, float hourDeg, float minuteDeg, float secDeg, int realSec,
                           float scale, float dy, float alpha, float glow) {
        c.save();
        c.translate(0f, dy);
        c.scale(scale, scale, cx, cy);
        if (glow > 0f) drawGlow(c, glow);
        bitmapPaint.setAlpha((int) (255 * alpha));
        c.drawBitmap(dial, cx - dial.getWidth() / 2f, cy - dial.getHeight() / 2f, bitmapPaint);
        bitmapPaint.setAlpha(255);
        drawTrail(c, realSec);
        drawHands(c, hourDeg, minuteDeg, secDeg);
        c.restore();
    }

    private void drawGlow(Canvas c, float k) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(GOLD, (int) (55 * k)));
        c.drawCircle(cx, cy, radius * 1.9f, paint);
        paint.setColor(withAlpha(GOLD, (int) (85 * k)));
        c.drawCircle(cx, cy, radius * 1.45f, paint);
        paint.setColor(withAlpha(AMBER, (int) (110 * k)));
        c.drawCircle(cx, cy, radius * 1.1f, paint);
    }

    private void drawSubject(Canvas c, float dy, float scale, float alpha) {
        Bitmap s = scene.subject;
        c.save();
        c.translate(subjX * width, subjY * height + dy);
        c.scale(scale, scale);
        bitmapPaint.setAlpha((int) (255 * alpha));
        c.drawBitmap(s, -s.getWidth() / 2f, -s.getHeight() / 2f, bitmapPaint);
        bitmapPaint.setAlpha(255);
        c.restore();
    }

    private void drawDial(Canvas k, float c0) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(c0, c0, radius,
                new int[]{0x40FFFFFF, 0x1CFFFFFF, 0x66000000},
                new float[]{0f, 0.8f, 1f}, Shader.TileMode.CLAMP));
        k.drawCircle(c0, c0, radius, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.02f);
        paint.setColor(0x33000000);
        k.drawCircle(c0, c0, radius * 0.98f, paint);
        paint.setStrokeWidth(radius * 0.006f);
        paint.setColor(0x80FFFFFF);
        k.drawCircle(c0, c0, radius * 0.98f, paint);

        for (int i = 0; i < 60; i++) {
            boolean hour = i % 5 == 0;
            float rin = radius * (hour ? 0.80f : 0.90f), rout = radius * 0.94f;
            float x1 = c0 + COS[i] * rin, y1 = c0 + SIN[i] * rin;
            float x2 = c0 + COS[i] * rout, y2 = c0 + SIN[i] * rout;
            float w = radius * (hour ? 0.035f : 0.013f);
            paint.setStrokeWidth(w + radius * 0.02f);
            paint.setColor(0x55000000);
            k.drawLine(x1, y1, x2, y2, paint);
            paint.setStrokeWidth(w);
            paint.setColor(IVORY);
            k.drawLine(x1, y1, x2, y2, paint);
        }
    }

    private void drawTrail(Canvas c, int sec) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int t = 0; t < TRAIL; t++) {
            float f = 1f - t / (float) TRAIL;
            float a = f * f;
            int i = (sec - t + 60) % 60;
            float rin = radius * (i % 5 == 0 ? 0.80f : 0.90f), rout = radius * 0.94f;
            float x1 = cx + COS[i] * rin, y1 = cy + SIN[i] * rin;
            float x2 = cx + COS[i] * rout, y2 = cy + SIN[i] * rout;

            paint.setStrokeWidth(radius * 0.05f * (0.5f + 0.5f * f));
            paint.setColor(withAlpha(AMBER, (int) (120 * a)));
            c.drawLine(x1, y1, x2, y2, paint);
            paint.setStrokeWidth(radius * 0.016f);
            paint.setColor(withAlpha(GOLD, (int) (255 * a)));
            c.drawLine(x1, y1, x2, y2, paint);
        }
    }

    private void drawHands(Canvas c, float hourDeg, float minuteDeg, float secDeg) {
        hand(c, hourPath, hourDeg, 0.03f);
        hand(c, minutePath, minuteDeg, 0.024f);

        c.save();
        c.translate(cx, cy);
        c.rotate(secDeg);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.05f);
        paint.setColor(withAlpha(GOLD, 70));
        c.drawLine(0, radius * 0.18f, 0, -radius * 0.9f, paint);
        paint.setStrokeWidth(radius * 0.012f);
        paint.setColor(GOLD);
        c.drawLine(0, radius * 0.18f, 0, -radius * 0.9f, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawCircle(0, radius * 0.18f, radius * 0.035f, paint);
        c.restore();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x80000000);
        c.drawCircle(cx, cy, radius * 0.065f, paint);
        paint.setColor(IVORY);
        c.drawCircle(cx, cy, radius * 0.05f, paint);
        paint.setColor(GOLD);
        c.drawCircle(cx, cy, radius * 0.018f, paint);
    }

    private void hand(Canvas c, Path p, float deg, float outline) {
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(radius * outline);
        paint.setColor(0x80000000);
        c.drawPath(p, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(IVORY);
        c.drawPath(p, paint);
        c.restore();
    }

    /** Three slow, bold stars leave the top centre and drift to the bottom-left, bottom-right and bottom-centre. */
    private void drawStars(Canvas c, long now) {
        float x0 = width * 0.5f, y0 = -height * 0.02f;
        float[] tx = {-width * 0.03f, width * 1.03f, width * 0.5f};
        float ty = height * 1.03f;
        float bw = Math.max(3f, width * 0.0075f);

        for (int i = 0; i < 3; i++) {
            float t = (now - starBase - STAR_DELAY[i]) / (float) STAR_MS;
            if (t < 0f || t > 1f) continue;

            float e = t * t * (3f - 2f * t);            // smooth in and out: slow start and slow landing
            float fade = t < 0.75f ? 1f : (1f - t) / 0.25f;
            float dx = tx[i] - x0, dy = ty - y0;
            float tail = Math.max(0f, e - 0.45f);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int k = 0; k < 6; k++) {
                float p0 = tail + (e - tail) * k / 6f;
                float p1 = tail + (e - tail) * (k + 1) / 6f;
                paint.setStrokeWidth(bw * (0.35f + 0.65f * (k + 1) / 6f));
                paint.setColor(withAlpha(STAR, (int) (255 * fade * (k + 1) / 6f)));
                c.drawLine(x0 + dx * p0, y0 + dy * p0, x0 + dx * p1, y0 + dy * p1, paint);
            }

            float hx = x0 + dx * e, hy = y0 + dy * e;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(STAR, (int) (90 * fade)));
            c.drawCircle(hx, hy, bw * 2.6f, paint);
            paint.setColor(withAlpha(0xFFFFFF, (int) (255 * fade)));
            c.drawCircle(hx, hy, bw, paint);
        }
    }

    // ---------- helpers ----------

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
