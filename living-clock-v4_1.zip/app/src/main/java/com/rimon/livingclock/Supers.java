package com.rimon.livingclock;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/**
 * Super 5: five clocks from five movie genres, reached by triple-tapping the top of the cutout. The wallpaper
 * itself is never replaced: each Super only lays a light tint, a vignette and a little ambient motion over it.
 * Entering one is a short jump through a "dimension" door of its own, then the clock builds itself slowly.
 *
 *   5 Mech Transform  giant-robot action: a block splits into armour plates, gears spin up, hands are jointed arms;
 *                     the jump is mechanical shutters
 *   6 Code Rain       cyber thriller: glyph streams fall and lock into the numerals; the jump is a glitch tear
 *   7 High Noon       western: a revolver cylinder spins up and locks, brass bezel, bullet hand; the jump is an iris wipe
 *   8 Vault Run       heist: a vault door whose bolts retract, a combination ring, laser beams; the jump is iris blades
 *   9 Arcane Circle   fantasy: a magic circle inscribes itself, runes light in a wave; the jump is expanding sigils
 *
 * Cost: the environment is a tint, a vignette and one or two batched point/line draws. The static art of each
 * clock is drawn once into the cached dial; only what moves is drawn per frame. Ambient motion runs at about
 * 24 frames a second (12 on a low battery), the transitions follow the display.
 */
final class Supers {

    static final int FIRST = 5, N = 5;
    static final long BUILD_MS = 3600, EXIT_MS = 2600;
    static final String[] NAMES = {"Mech Transform", "Code Rain", "High Noon", "Vault Run", "Arcane Circle"};

    private static final int[] LOOK = {4, 7, 2, 6, 5};                      // the band pattern each Super borrows
    private static final int[] TINT = {0xFF0A1830, 0xFF021208, 0xFF3A2008, 0xFF0B0F18, 0xFF160A30};
    private static final int[] RIM = {0xFF5CC8FF, 0xFF33FF88, 0xFFFF8A3D, 0xFFFF2A3A, 0xFFFFD27A};
    private static final float[] TINT_A = {0.30f, 0.34f, 0.26f, 0.36f, 0.30f};
    private static final float TAU = 6.2831855f;
    private static final int STEEL = 0xFFB8C4D4, ACC = 0xFF5CC8FF, AMBER = 0xFFFFB347, GREEN = 0xFF33FF88, BRASS = 0xFFE0B25A;
    private static final int RED = 0xFFFF2A3A, GOLD = 0xFFFFD27A, VIO = 0xFFB08CFF;

    static boolean is(int th) {
        return th >= FIRST;
    }

    static int look(int th) {
        return LOOK[th - FIRST];
    }

    // ---------- state ----------

    private final float[] a = new float[N];
    private long last = -1L;
    private int w, h;
    private float cx, cy, r, u;
    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG), gp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path(), disc = new Path(), ring = new Path();
    private final PathMeasure pm = new PathMeasure();
    private final RectF rc = new RectF();
    private RadialGradient vignette, redEdge, glare;
    private final float[] dust = new float[40 * 3], col = new float[16 * 3], rune = new float[12 * 8];
    private final float[] buf = new float[256], pts = new float[96], pts2 = new float[96], pts3 = new float[96];
    private final char[] txt = {'0', '0', ':', '0', '0'}, ch = {'0'};
    private static final char[] GLYPH = "01234567890ABCDEF<>/+=#$%".toCharArray();

    Supers() {
        pt.setStrokeCap(Paint.Cap.ROUND);
        pt.setStrokeJoin(Paint.Join.ROUND);
    }

    /** Each Super's presence moves slowly toward its target. True while any is moving. */
    boolean step(int theme, long now) {
        float dt = last < 0 ? 0f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        boolean moving = false;
        for (int i = 0; i < N; i++) {
            float target = theme == FIRST + i ? 1f : 0f;
            if (a[i] == target) continue;
            float rate = dt / (target > a[i] ? 2.4f : 2.0f);
            a[i] += Math.max(-rate, Math.min(rate, target - a[i]));
            moving |= a[i] != target;
        }
        return moving;
    }

    void snap(int theme) {
        for (int i = 0; i < N; i++) a[i] = theme == FIRST + i ? 1f : 0f;
    }

    boolean active() {
        for (int i = 0; i < N; i++) if (a[i] > 0.003f) return true;
        return false;
    }

    /** A little of the Super's light for the cut-out subject, so it belongs to the scene. */
    int tintColor() {
        int best = 0;
        for (int i = 1; i < N; i++) if (a[i] > a[best]) best = i;
        float e = smooth(a[best]);
        return e < 0.02f ? 0 : (RIM[best] & 0x00FFFFFF) | (((int) (e * 34f)) << 24);
    }

    // ---------- layout ----------

    void layout(int width, int height, float clockX, float clockY, float radius) {
        boolean same = width == w && height == h && radius == r && vignette != null;
        w = width;
        h = height;
        cx = clockX;
        cy = clockY;
        r = radius;
        u = width / 1080f;
        if (!same) {
            Shader.TileMode cl = Shader.TileMode.CLAMP;
            float[] f3 = {0f, 0.55f, 1f};
            float big = Math.max(w, h);
            vignette = new RadialGradient(0f, 0f, big * 0.75f, new int[]{0x00000000, 0x00000000, 0xB0000000}, f3, cl);
            redEdge = new RadialGradient(0f, 0f, big * 0.75f, new int[]{0x00FF2A3A, 0x00FF2A3A, 0x55FF2A3A}, f3, cl);
            glare = new RadialGradient(0f, 0f, w * 0.8f, new int[]{0x66FFD08A, 0x22FFB35A, 0x00FFB35A}, f3, cl);
            for (int i = 0; i < 40; i++) {
                dust[3 * i] = hash(i * 3 + 1) * w;
                dust[3 * i + 1] = 14f + hash(i * 3 + 2) * 26f;
                dust[3 * i + 2] = hash(i * 3 + 3) * h;
            }
            for (int i = 0; i < 16; i++) {                         // rain columns hug the two edges so the subject stays clear
                float side = i < 8 ? hash(i + 50) * 0.17f : 0.83f + hash(i + 50) * 0.17f;
                col[3 * i] = side * w;
                col[3 * i + 1] = 160f + hash(i + 90) * 220f;
                col[3 * i + 2] = hash(i + 130) * h;
            }
        }
        disc.rewind();
        disc.addCircle(cx, cy, r * 0.97f, Path.Direction.CW);
        for (int i = 0; i < 12; i++) {                              // rune glyphs: a stem plus three random strokes
            for (int k = 0; k < 4; k++) {
                rune[8 * i + 2 * k] = Math.round(hash(i * 11 + k * 3 + 1) * 2f) - 1f;
                rune[8 * i + 2 * k + 1] = Math.round(hash(i * 11 + k * 3 + 2) * 2f) - 1f;
            }
        }
    }

    // ---------- helpers ----------

    private static float hash(int n) {
        n = (n << 13) ^ n;
        return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483647f;
    }

    private static float smooth(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        return x * x * (3f - 2f * x);
    }

    private static float seg(float b, float from, float to) {
        return smooth((b - from) / (to - from));
    }

    private static float outBack(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        float v = x - 1f;
        return 1f + 2.7f * v * v * v + 1.7f * v * v;
    }

    private static float sn(double td, double period, double phase) {
        return (float) Math.sin(td * TAU / period + phase);
    }

    private static float drift(double td, double speed, float mod) {
        float v = (float) ((td * speed) % mod);
        return v < 0f ? v + mod : v;
    }

    /** Eases in steps, like a ratchet: n clicks across 0..1. */
    private static float ratchet(float x, int n) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        float v = x * n, i = (float) Math.floor(v);
        return (i + smooth((v - i) * 1.8f)) / n;
    }

    private static int al(int color, float f) {
        int v = (int) ((color >>> 24) * (f < 0f ? 0f : (f > 1f ? 1f : f)));
        return (color & 0x00FFFFFF) | (v << 24);
    }

    private static float hx(float c0, float rr, float deg) {
        return c0 + (float) Math.sin(Math.toRadians(deg)) * rr;
    }

    private static float hy(float c0, float rr, float deg) {
        return c0 - (float) Math.cos(Math.toRadians(deg)) * rr;
    }

    private void blob(Canvas c, RadialGradient g, float x, float y, float rad, float alpha) {
        gp.setStyle(Paint.Style.FILL);
        gp.setShader(g);
        gp.setAlpha((int) (255 * Math.max(0f, Math.min(1f, alpha))));
        c.save();
        c.translate(x, y);
        c.drawCircle(0f, 0f, rad, gp);
        c.restore();
        gp.setShader(null);
        gp.setAlpha(255);
    }

    private void line(Canvas c, float x0, float y0, float x1, float y1, float wid, int color, float alpha) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, wid));
        pt.setColor(al(color, alpha));
        c.drawLine(x0, y0, x1, y1, pt);
    }

    private void dot(Canvas c, float x, float y, float rad, int color, float alpha) {
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(color, alpha));
        c.drawCircle(x, y, rad, pt);
    }

    private void star4(Canvas c, float x, float y, float s, int color, float alpha) {
        line(c, x - s, y, x + s, y, s * 0.14f, color, alpha);
        line(c, x, y - s, x, y + s, s * 0.14f, color, alpha);
        dot(c, x, y, s * 0.16f, 0xFFFFFFFF, alpha);
    }

    // ---------- the overlay: a tint, a vignette and a little ambient life ----------

    void env(Canvas c, long now) {
        double td = now / 1000.0;
        for (int i = 0; i < N; i++) {
            if (a[i] < 0.004f) continue;
            float e = smooth(a[i]);
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(al(TINT[i], TINT_A[i] * e));
            c.drawRect(0f, 0f, w, h, gp);
            blob(c, vignette, w / 2f, h / 2f, Math.max(w, h), 0.55f * e);
            if (i == 0) mechAmbient(c, td, e);
            else if (i == 1) rainAmbient(c, td, e);
            else if (i == 2) westAmbient(c, td, e);
            else if (i == 3) vaultAmbient(c, td, e);
            else arcaneAmbient(c, td, e);
        }
    }

    private void mechAmbient(Canvas c, double td, float e) {
        float y = drift(td, 70 * u, h + 160f * u) - 80f * u;               // a slow scan bar
        gp.setColor(al(0xFF5CC8FF, 0.05f * e));
        c.drawRect(0f, y - 40f * u, w, y + 40f * u, gp);
        for (int k = 0; k < 6; k++) {                                       // sparks near the clock, a few at a time
            long n = (long) Math.floor(td * 3.0) + k * 17;
            if (hash((int) n) < 0.55f) continue;
            float ang = hash((int) n + 3) * TAU, rad = r * (0.95f + 0.5f * hash((int) n + 5));
            pts[2 * k] = cx + (float) Math.cos(ang) * rad;
            pts[2 * k + 1] = cy + (float) Math.sin(ang) * rad;
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(4f * u);
        pt.setColor(al(AMBER, 0.9f * e * (0.5f + 0.5f * sn(td, 0.33, 0))));
        c.drawPoints(pts, 0, 12, pt);
    }

    private void rainAmbient(Canvas c, double td, float e) {
        for (int i = 0; i < 16; i++) {
            float y = drift(td + col[3 * i + 2], col[3 * i + 1] * u, h + 400f * u);
            pts[2 * i] = col[3 * i];
            pts[2 * i + 1] = y - 100f * u;
            pts2[2 * i] = col[3 * i];
            pts2[2 * i + 1] = y - 100f * u - 34f * u;
            pts3[2 * i] = col[3 * i];
            pts3[2 * i + 1] = y - 100f * u - 68f * u;
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(5f * u);
        pt.setColor(al(0xFFD8FFE8, 0.75f * e));
        c.drawPoints(pts, 0, 32, pt);
        pt.setStrokeWidth(4f * u);
        pt.setColor(al(GREEN, 0.5f * e));
        c.drawPoints(pts2, 0, 32, pt);
        pt.setStrokeWidth(3f * u);
        pt.setColor(al(GREEN, 0.25f * e));
        c.drawPoints(pts3, 0, 32, pt);
    }

    private void westAmbient(Canvas c, double td, float e) {
        blob(c, glare, w * 0.1f, h * 0.05f, w * 0.8f, 0.55f * e);            // low sun glare in the corner
        int n = 0;
        for (int i = 0; i < 40; i++) {
            float x = w - drift(td + dust[3 * i + 2], dust[3 * i + 1] * u, w + 40f) + 20f;
            buf[2 * n] = x;
            buf[2 * n + 1] = dust[3 * i + 2] % h + 18f * u * (float) Math.sin(td * 0.6 + i);
            n++;
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(3f * u);
        pt.setColor(al(0xFFFFE0B0, 0.38f * e));
        c.drawPoints(buf, 0, 2 * n, pt);
    }

    private void vaultAmbient(Canvas c, double td, float e) {
        for (int k = 0; k < 3; k++) {                                        // laser beams sweeping slowly across the frame
            float y0 = h * (0.25f + 0.22f * k) + h * 0.06f * sn(td, 7 + k * 2, k * 2);
            float y1 = y0 + h * 0.05f * sn(td, 9 + k, k);
            line(c, 0f, y0, w, y1, 7f * u, RED, 0.07f * e);
            line(c, 0f, y0, w, y1, 1.6f * u, RED, 0.40f * e);
        }
        blob(c, redEdge, w / 2f, h / 2f, Math.max(w, h), e * (0.5f + 0.5f * sn(td, 4.5, 0)));   // a faint alarm pulse at the edges
    }

    private void arcaneAmbient(Canvas c, double td, float e) {
        for (int i = 0; i < 34; i++) {                                       // motes rising from below
            float y = h - drift(td + dust[3 * (i % 40) + 2], (14f + dust[3 * (i % 40) + 1]) * u, h + 40f) + 20f;
            float x = dust[3 * (i % 40)] + 26f * u * (float) Math.sin(td * 0.5 + i * 1.3);
            buf[2 * i] = x;
            buf[2 * i + 1] = y;
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(4f * u);
        pt.setColor(al(GOLD, 0.65f * e));
        c.drawPoints(buf, 0, 34, pt);
        pt.setStrokeWidth(3f * u);
        pt.setColor(al(VIO, 0.6f * e));
        c.drawPoints(buf, 34, 34, pt);
    }

    // ---------- the jump: a door into another space, different for each genre ----------

    /** q runs 0..1 and the door is shut at 0.5, hidden behind it the old clock is replaced. */
    void portal(Canvas c, int th, float q, long now) {
        if (q <= 0f || q >= 1f) return;
        double td = now / 1000.0;
        float f = (float) Math.sin(Math.PI * q);                              // 0 open, 1 closed, 0 open
        float diag = (float) Math.hypot(w, h);
        gp.setStyle(Paint.Style.FILL);
        pt.setStyle(Paint.Style.FILL);
        if (th == 5) {                                                         // mechanical shutters
            float cell = w / 6f;
            for (int i = 0; i < 6; i++) {
                float k = Math.max(0f, Math.min(1f, f * 1.5f - Math.abs(i - 2.5f) * 0.12f));
                float half = cell * 0.5f * smooth(k);
                float mid = cell * (i + 0.5f);
                pt.setColor(al(0xFF1B2433, 0.92f));
                c.drawRect(mid - half, 0f, mid + half, h, pt);
                line(c, mid - half, 0f, mid - half, h, 3f * u, ACC, 0.8f * k);
                line(c, mid + half, 0f, mid + half, h, 3f * u, ACC, 0.8f * k);
            }
            line(c, 0f, cy, w * (float) Math.sin(Math.PI * Math.min(1f, q * 1.2f)), cy, 6f * u, 0xFFFFFFFF, 0.9f * f);
        } else if (th == 6) {                                                  // a glitch tear: bands shift and flash green
            long n = (long) Math.floor(td * 24);
            for (int k = 0; k < 9; k++) {
                float y = hash((int) n + k * 7) * h, bh = (18f + hash((int) n + k * 11) * 90f) * u;
                float off = (hash((int) n + k * 5) - 0.5f) * w * 0.35f * f;
                pt.setColor(al(0xFF03180C, 0.85f * f));
                c.drawRect(off, y, w + off, y + bh, pt);
                pt.setColor(al(GREEN, 0.28f * f));
                c.drawRect(off, y, w + off, y + 3f * u, pt);
                pt.setColor(al(0xFFFF2FC8, 0.22f * f));
                c.drawRect(off + 8f * u, y + bh - 4f * u, w + off + 8f * u, y + bh, pt);
            }
            gp.setColor(al(GREEN, 0.14f * f));
            c.drawRect(0f, 0f, w, h, gp);
        } else if (th == 7) {                                                  // an old film iris closing on the clock and opening again
            float rho = diag * (float) Math.abs(Math.cos(Math.PI * q)) * (1f + 0.02f * sn(td, 0.05, 0));
            float wide = diag * 1.2f;
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(wide);
            pt.setColor(al(0xFF140B04, 0.94f));
            c.drawCircle(cx, cy, rho + wide / 2f, pt);
            pt.setStrokeWidth(10f * u);
            pt.setColor(al(0xFFFF8A3D, 0.8f * f));
            c.drawCircle(cx, cy, rho + 4f * u, pt);
            gp.setColor(al(0xFFFFE0B0, 0.12f * f * (0.5f + 0.5f * sn(td, 0.08, 0))));
            c.drawRect(0f, 0f, w, h, gp);
        } else if (th == 8) {                                                  // iris blades of a vault door
            for (int k = 0; k < 8; k++) {
                float ang = k * 45f + (1f - f) * 30f, reach = diag * 0.75f * f;
                path.rewind();
                path.moveTo(cx, cy);
                path.lineTo(hx(cx, reach, ang - 24f), hy(cy, reach, ang - 24f));
                path.lineTo(hx(cx, reach, ang + 24f), hy(cy, reach, ang + 24f));
                path.close();
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(0xFF151B26, 0.94f));
                c.drawPath(path, pt);
                line(c, cx, cy, hx(cx, reach, ang + 24f), hy(cy, reach, ang + 24f), 3f * u, RED, 0.8f * f);
            }
            gp.setColor(al(RED, 0.10f * f));
            c.drawRect(0f, 0f, w, h, gp);
        } else {                                                               // sigils expanding from the clock
            for (int k = 0; k < 3; k++) {
                float e = Math.max(0f, Math.min(1f, q * 1.5f - k * 0.18f)), rad = diag * 0.62f * smooth(e);
                if (e <= 0f || e >= 1f) continue;
                float al2 = (float) Math.sin(Math.PI * e);
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(5f * u);
                pt.setColor(al(GOLD, 0.85f * al2));
                c.drawCircle(cx, cy, rad, pt);
                for (int i = 0; i < 24; i++) {
                    float ang = i * 15f + k * 7f + q * 40f * (k % 2 == 0 ? 1 : -1);
                    float l = i % 2 == 0 ? 26f * u : 14f * u;
                    line(c, hx(cx, rad, ang), hy(cy, rad, ang), hx(cx, rad + l, ang), hy(cy, rad + l, ang), 3f * u, VIO, 0.8f * al2);
                }
            }
            gp.setColor(al(0xFF8A5CFF, 0.18f * f));
            c.drawRect(0f, 0f, w, h, gp);
        }
    }

    // ---------- the clocks: static art (cached) and the animated parts under the hands ----------

    /** How much of the cached dial is showing: it takes over from the animated build at the end. */
    static float dialA(float b) {
        return b >= 1f ? 1f : smooth((b - 0.8f) / 0.2f);
    }

    void dial(int th, Canvas k, float c0, float rad) {
        k.save();
        k.translate(c0 - cx, c0 - cy);
        art(th, k, 1f);
        k.restore();
    }

    void under(int th, Canvas c, float b, long now) {
        double td = now / 1000.0;
        float da = dialA(b);
        if (da < 0.999f) {
            int sc = c.saveLayerAlpha(cx - r * 1.3f, cy - r * 1.3f, cx + r * 1.3f, cy + r * 1.3f, (int) (255 * (1f - da)));
            art(th, c, b);
            c.restoreToCount(sc);
        }
        live(th, c, b, td);
    }

    private void art(int th, Canvas c, float b) {
        pt.setShader(null);
        if (th == 5) mechArt(c, b);
        else if (th == 6) codeArt(c, b);
        else if (th == 7) westArt(c, b);
        else if (th == 8) vaultArt(c, b);
        else arcaneArt(c, b);
    }

    // ----- 5 Mech Transform -----

    private void plate(Canvas c, int k, float t) {
        float mid = k * 45f + 22.5f, inv = 1f - t, dist = r * 1.1f * inv * inv;
        c.save();
        c.translate(hx(cx, dist, mid), hy(cy, dist, mid));
        c.rotate(ratchet(inv, 4) * 70f * (k % 2 == 0 ? 1f : -1f), cx, cy);
        for (int layer = 0; layer < 2; layer++) {
            float r0 = layer == 0 ? 0.50f : 0.58f, r1 = layer == 0 ? 0.95f : 0.87f, span = layer == 0 ? 19f : 15f;
            path.rewind();
            for (int i = 0; i <= 4; i++) {
                float ang = mid - span + 2f * span * i / 4f;
                if (i == 0) path.moveTo(hx(cx, r * r1, ang), hy(cy, r * r1, ang));
                else path.lineTo(hx(cx, r * r1, ang), hy(cy, r * r1, ang));
            }
            for (int i = 4; i >= 0; i--) {
                float ang = mid - span + 2f * span * i / 4f;
                path.lineTo(hx(cx, r * r0, ang), hy(cy, r * r0, ang));
            }
            path.close();
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(layer == 0 ? 0xFF2A3548 : 0x30FFFFFF, layer == 0 ? 0.9f * t : t));
            c.drawPath(path, pt);
            if (layer == 0) {
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(r * 0.007f);
                pt.setColor(al(ACC, t));
                c.drawPath(path, pt);
            }
        }
        dot(c, hx(cx, r * 0.91f, mid - 15f), hy(cy, r * 0.91f, mid - 15f), r * 0.010f, STEEL, t);
        dot(c, hx(cx, r * 0.91f, mid + 15f), hy(cy, r * 0.91f, mid + 15f), r * 0.010f, STEEL, t);
        c.restore();
    }

    private void mechArt(Canvas c, float b) {
        float cube = 1f - seg(b, 0.10f, 0.22f);                                 // first it is a single glowing block
        if (cube > 0.01f) {
            c.save();
            c.rotate(45f + 40f * (1f - cube), cx, cy);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFF2A3548, cube));
            c.drawRect(cx - r * 0.15f, cy - r * 0.15f, cx + r * 0.15f, cy + r * 0.15f, pt);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.012f);
            pt.setColor(al(ACC, cube));
            c.drawRect(cx - r * 0.15f, cy - r * 0.15f, cx + r * 0.15f, cy + r * 0.15f, pt);
            c.restore();
        }
        for (int k = 0; k < 8; k++) {
            float t = seg(b, 0.18f + 0.035f * k, 0.58f + 0.035f * k);
            if (t > 0.01f) plate(c, k, t);
        }
        float hubA = seg(b, 0.55f, 0.85f);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.014f);
        pt.setColor(al(STEEL, hubA));
        c.drawCircle(cx, cy, r * 0.44f, pt);
        pt.setColor(al(ACC, hubA));
        c.drawCircle(cx, cy, r * 0.12f, pt);
        for (int i = 0; i < 12; i++) {                                           // hour pistons
            float ai = seg(b, 0.70f + i * 0.02f, 0.88f + i * 0.02f), deg = i * 30f, len = i % 3 == 0 ? 0.10f : 0.06f;
            line(c, hx(cx, r * 0.98f, deg), hy(cy, r * 0.98f, deg), hx(cx, r * (0.98f - len * ai), deg), hy(cy, r * (0.98f - len * ai), deg),
                    r * (i % 3 == 0 ? 0.022f : 0.014f), AMBER, ai);
        }
    }

    // ----- 6 Code Rain -----

    private void glyph(Canvas c, char g, float x, float y, float size, int color, float alpha) {
        ch[0] = g;
        pt.setStyle(Paint.Style.FILL);
        pt.setTypeface(Typeface.MONOSPACE);
        pt.setTextAlign(Paint.Align.CENTER);
        pt.setTextSize(size);
        pt.setColor(al(color, alpha));
        c.drawText(ch, 0, 1, x, y + size * 0.35f, pt);
        pt.setTypeface(Typeface.DEFAULT);
    }

    private void codeArt(Canvas c, float b) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.006f);
        pt.setColor(al(GREEN, 0.55f * seg(b, 0.4f, 0.7f)));
        c.drawCircle(cx, cy, r * 0.97f, pt);
        int n = 0;
        for (int i = 0; i < 60; i++) {
            if (i % 5 == 0) continue;
            buf[2 * n] = cx + Renderer.COS[i] * r * 0.93f;
            buf[2 * n + 1] = cy + Renderer.SIN[i] * r * 0.93f;
            n++;
        }
        pt.setStrokeWidth(r * 0.012f);
        pt.setColor(al(GREEN, 0.6f * seg(b, 0.45f, 0.8f)));
        c.drawPoints(buf, 0, 2 * n, pt);
        for (int i = 1; i <= 12; i++) {                                           // glyph streams fall and lock into each numeral
            float t0 = 0.04f + (i - 1) * 0.04f, fall = seg(b, t0, t0 + 0.30f), lock = seg(b, t0 + 0.27f, t0 + 0.40f);
            float nx = cx + Renderer.COS[(i * 5) % 60] * r * 0.80f, ny = cy + Renderer.SIN[(i * 5) % 60] * r * 0.80f;
            if (fall > 0.01f && lock < 0.99f) {
                float head = ny - (1f - fall) * r * 1.5f;
                line(c, nx, head - r * 0.35f, nx, head, r * 0.012f, GREEN, 0.55f * (1f - lock));
                glyph(c, GLYPH[(i * 5 + (int) (fall * 20)) % GLYPH.length], nx, head, r * 0.08f, 0xFFD8FFE8, 1f - lock);
            }
            if (lock > 0.01f) {
                String s = Integer.toString(i);
                float size = r * 0.11f;
                for (int k = 0; k < s.length(); k++) glyph(c, s.charAt(k), nx + (k - (s.length() - 1) * 0.5f) * size * 0.62f, ny, size, i % 3 == 0 ? 0xFFD8FFE8 : GREEN, lock);
            }
        }
    }

    // ----- 7 High Noon -----

    private void star5(Canvas c, float x, float y, float rad, int color, float alpha) {
        path.rewind();
        for (int i = 0; i < 10; i++) {
            float rr = i % 2 == 0 ? rad : rad * 0.42f, ang = i * 36f;
            if (i == 0) path.moveTo(hx(x, rr, ang), hy(y, rr, ang));
            else path.lineTo(hx(x, rr, ang), hy(y, rr, ang));
        }
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(color, alpha));
        c.drawPath(path, pt);
    }

    private void westArt(Canvas c, float b) {
        float sweep = seg(b, 0.05f, 0.40f);
        rc.set(cx - r * 0.95f, cy - r * 0.95f, cx + r * 0.95f, cy + r * 0.95f);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.075f);
        pt.setColor(al(0xFF3A2410, sweep));
        c.drawArc(rc, -90f, 360f * sweep, false, pt);
        pt.setStrokeWidth(r * 0.05f);
        pt.setColor(al(BRASS, sweep));
        c.drawArc(rc, -90f, 360f * sweep, false, pt);
        pt.setStrokeWidth(r * 0.008f);
        pt.setColor(al(0xFFFFF0C8, 0.8f * sweep));
        rc.set(cx - r * 0.93f, cy - r * 0.93f, cx + r * 0.93f, cy + r * 0.93f);
        c.drawArc(rc, -90f, 360f * sweep, false, pt);
        for (int i = 0; i < 60; i++) {                                            // engraved ticks, stamped one after another
            float ai = seg(b, 0.30f + i * 0.004f, 0.42f + i * 0.004f), len = i % 5 == 0 ? 0.06f : 0.025f;
            line(c, cx + Renderer.COS[i] * r * 0.86f, cy + Renderer.SIN[i] * r * 0.86f,
                    cx + Renderer.COS[i] * r * (0.86f - len), cy + Renderer.SIN[i] * r * (0.86f - len), r * 0.006f, 0xFFF1D79A, 0.8f * ai);
        }
        for (int i = 0; i < 12; i++) {
            float ai = seg(b, 0.45f + i * 0.025f, 0.60f + i * 0.025f), x = cx + Renderer.COS[i * 5] * r * 0.76f, y = cy + Renderer.SIN[i * 5] * r * 0.76f;
            if (i % 3 == 0) star5(c, x, y, r * 0.058f * outBack(ai), BRASS, ai);
            else dot(c, x, y, r * 0.018f * outBack(ai), BRASS, ai);
        }
    }

    // ----- 8 Vault Run -----

    private void vaultArt(Canvas c, float b) {
        float body = seg(b, 0.05f, 0.35f);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0x66121822, body));
        c.drawCircle(cx, cy, r * 0.97f, pt);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.07f);
        pt.setColor(al(0xFF7C8A9C, body));
        c.drawCircle(cx, cy, r * 0.94f, pt);
        pt.setStrokeWidth(r * 0.01f);
        pt.setColor(al(0xFFD3DCE8, 0.8f * body));
        c.drawCircle(cx, cy, r * 0.905f, pt);
        for (int i = 0; i < 12; i++) {                                             // twelve bolts retract from the frame
            float t = seg(b, 0.30f + i * 0.03f, 0.55f + i * 0.03f), deg = i * 30f, out = (1f - t) * r * 0.12f;
            c.save();
            c.rotate(deg, cx, cy);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFF9AA7B8, body));
            c.drawRect(cx - r * 0.03f, cy - r * 0.86f - out, cx + r * 0.03f, cy - r * 0.76f - out, pt);
            pt.setColor(al(0xFF3A4452, body));
            c.drawRect(cx - r * 0.012f, cy - r * 0.84f - out, cx + r * 0.012f, cy - r * 0.78f - out, pt);
            c.restore();
        }
        float sp = seg(b, 0.55f, 0.85f);                                           // the three-spoke wheel at the centre
        for (int k = 0; k < 3; k++) line(c, cx, cy, hx(cx, r * 0.40f, k * 120f), hy(cy, r * 0.40f, k * 120f), r * 0.03f, 0xFF7C8A9C, sp);
        dot(c, cx, cy, r * 0.07f, 0xFF3A4452, sp);
        dot(c, cx, cy, r * 0.03f, RED, sp);
        dot(c, cx, cy - r * 0.62f - r * 0.05f, r * 0.014f, RED, seg(b, 0.8f, 0.95f));      // the fixed marker for the combination ring
    }

    // ----- 9 Arcane Circle -----

    private void runeAt(Canvas c, int i, float x, float y, float s, int color, float alpha) {
        int n = 0;
        buf[n++] = x;
        buf[n++] = y - s;
        buf[n++] = x;
        buf[n++] = y + s;                                                          // stem
        for (int k = 0; k < 3; k++) {
            buf[n++] = x + rune[8 * i + 2 * k] * s;
            buf[n++] = y + rune[8 * i + 2 * k + 1] * s;
            buf[n++] = x + rune[8 * i + 2 * k + 2] * s;
            buf[n++] = y + rune[8 * i + 2 * k + 3] * s;
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(s * 0.22f);
        pt.setColor(al(color, alpha));
        c.drawLines(buf, 0, n, pt);
    }

    private void arcaneArt(Canvas c, float b) {
        float[] rr = {0.96f, 0.74f, 0.54f};
        for (int k = 0; k < 3; k++) {
            float sw = seg(b, 0.04f + 0.08f * k, 0.40f + 0.08f * k);
            rc.set(cx - r * rr[k], cy - r * rr[k], cx + r * rr[k], cy + r * rr[k]);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * (k == 0 ? 0.03f : 0.016f));
            pt.setColor(al(GOLD, 0.25f * sw));
            c.drawArc(rc, -90f, 360f * sw, false, pt);
            pt.setStrokeWidth(r * (k == 0 ? 0.008f : 0.005f));
            pt.setColor(al(0xFFFFF0C8, 0.95f * sw));
            c.drawArc(rc, -90f, 360f * sw, false, pt);
        }
        for (int i = 0; i < 12; i++) {                                              // runes are inscribed one by one with a flash
            float ai = seg(b, 0.35f + i * 0.04f, 0.46f + i * 0.04f), flash = (float) Math.sin(Math.PI * seg(b, 0.35f + i * 0.04f, 0.52f + i * 0.04f));
            float x = cx + Renderer.COS[i * 5] * r * 0.85f, y = cy + Renderer.SIN[i * 5] * r * 0.85f;
            if (ai > 0.01f) {
                if (flash > 0.02f) dot(c, x, y, r * 0.07f, GOLD, 0.45f * flash);
                runeAt(c, i, x, y, r * 0.05f, i % 3 == 0 ? 0xFFFFF0C8 : GOLD, ai);
            }
            dot(c, cx + Renderer.COS[i * 5] * r * 0.96f, cy + Renderer.SIN[i * 5] * r * 0.96f, r * 0.014f * outBack(ai), 0xFFFFFFFF, ai);
        }
    }

    /** What moves under the hands, scaled by how much of the clock has built. */
    private void live(int th, Canvas c, float b, double td) {
        float s = smooth(b);
        if (th == 5) mechLive(c, b, td, s);
        else if (th == 6) codeLive(c, b, td, s);
        else if (th == 7) westLive(c, b, td, s);
        else if (th == 8) vaultLive(c, b, td, s);
        else arcaneLive(c, b, td, s);
    }

    private void mechLive(Canvas c, float b, double td, float s) {
        float spin = (float) (td * 14.0) + (1f - seg(b, 0.4f, 0.8f)) * 300f, ga = seg(b, 0.5f, 0.8f);
        int n = 0;
        for (int i = 0; i < 24; i++) {                                              // the ring gear turns
            float ang = spin + i * 15f;
            buf[n++] = hx(cx, r * 0.44f, ang);
            buf[n++] = hy(cy, r * 0.44f, ang);
            buf[n++] = hx(cx, r * 0.485f, ang);
            buf[n++] = hy(cy, r * 0.485f, ang);
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.022f);
        pt.setColor(al(STEEL, ga));
        c.drawLines(buf, 0, n, pt);
        float sweepA = (float) (td * 55.0 % 360.0);                                 // a light runs around the plates
        rc.set(cx - r * 0.73f, cy - r * 0.73f, cx + r * 0.73f, cy + r * 0.73f);
        pt.setStrokeWidth(r * 0.012f);
        pt.setColor(al(ACC, 0.55f * s));
        c.drawArc(rc, sweepA, 38f, false, pt);
        for (int k = 0; k < 8; k++) {                                               // seams flare now and then
            if (hash((int) Math.floor(td * 2.0) * 8 + k) < 0.86f) continue;
            float ang = k * 45f;
            dot(c, hx(cx, r * 0.95f, ang), hy(cy, r * 0.95f, ang), r * 0.025f, AMBER, 0.8f * s);
        }
    }

    private void codeLive(Canvas c, float b, double td, float s) {
        c.save();
        c.clipPath(disc);
        for (int i = 0; i < 9; i++) {                                               // a faint rain falling inside the dial
            float x = cx - r * 0.8f + i * r * 0.2f, y = cy - r + drift(td * 1.0 + i * 3.1, (60 + i * 11) * u, r * 2.4f) - r * 0.2f;
            line(c, x, y - r * 0.30f, x, y, r * 0.008f, GREEN, 0.20f * s);
            dot(c, x, y, r * 0.012f, 0xFFD8FFE8, 0.5f * s);
        }
        float sy = cy - r + drift(td, r * 0.5, r * 2f);                             // the scanline
        line(c, cx - r, sy, cx + r, sy, r * 0.006f, GREEN, 0.28f * s);
        c.restore();
        for (int k = 0; k < 2; k++) {                                                // numerals glitch into other glyphs for a blink
            int i = 1 + (int) (hash((int) Math.floor(td * 5.0) * 2 + k) * 12f) % 12;
            if (hash((int) Math.floor(td * 5.0) + k * 9) < 0.6f) continue;
            glyph(c, GLYPH[(int) (hash((int) Math.floor(td * 15.0) + i) * GLYPH.length) % GLYPH.length],
                    cx + Renderer.COS[(i * 5) % 60] * r * 0.80f, cy + Renderer.SIN[(i * 5) % 60] * r * 0.80f, r * 0.11f, 0xFFFFFFFF, 0.9f * s);
        }
    }

    private void westLive(Canvas c, float b, double td, float s) {
        float sk = seg(b, 0.08f, 0.78f), spin = 1080f * (1f - sk) * (1f - sk);       // spins fast, slows, locks exactly as the click fires
        float lock = seg(b, 0.78f, 1f), rattle = (float) Math.sin(td * 3.0) * 0.5f * lock;
        float vis = seg(b, 0.02f, 0.25f);
        c.save();
        c.rotate(spin + rattle, cx, cy);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFF2B2622, 0.80f * vis));
        c.drawCircle(cx, cy, r * 0.70f, pt);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.012f);
        pt.setColor(al(0xFF6B5A44, vis));
        c.drawCircle(cx, cy, r * 0.70f, pt);
        for (int k = 0; k < 6; k++) {                                                // six chambers
            float x = hx(cx, r * 0.47f, k * 60f), y = hy(cy, r * 0.47f, k * 60f);
            dot(c, x, y, r * 0.155f, 0xFF0C0A09, vis);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.016f);
            pt.setColor(al(BRASS, vis));
            c.drawCircle(x, y, r * 0.155f, pt);
            dot(c, x - r * 0.04f, y - r * 0.04f, r * 0.02f, 0xFFFFF0C8, 0.5f * vis);
        }
        c.restore();
        star5(c, cx, cy, r * 0.10f, BRASS, vis);
        float gl = (float) (td * 40.0 % 360.0);                                      // a glint travels around the brass bezel
        rc.set(cx - r * 0.95f, cy - r * 0.95f, cx + r * 0.95f, cy + r * 0.95f);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.03f);
        pt.setColor(al(0xFFFFFFFF, 0.55f * s));
        c.drawArc(rc, gl, 22f, false, pt);
        if (lock > 0f && lock < 0.35f) dot(c, cx, cy - r * 0.97f, r * 0.05f, 0xFFFFFFFF, 1f - lock / 0.35f);   // the click when it locks
    }

    private void vaultLive(Canvas c, float b, double td, float s) {
        float step = (float) Math.floor(td / 6.0), fr = (float) (td / 6.0 - step);
        float turn = (step * 20f + 20f * smooth(fr * 8f)) % 360f + (1f - seg(b, 0.4f, 0.85f)) * 240f;   // clicks 20 degrees every six seconds
        float ra = seg(b, 0.4f, 0.75f);
        c.save();
        c.rotate(turn, cx, cy);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.10f);
        pt.setColor(al(0xFF55627A, ra));
        c.drawCircle(cx, cy, r * 0.66f, pt);
        int n = 0;
        for (int i = 0; i < 36; i++) {
            float ang = i * 10f, in = i % 3 == 0 ? 0.60f : 0.63f;
            buf[n++] = hx(cx, r * in, ang);
            buf[n++] = hy(cy, r * in, ang);
            buf[n++] = hx(cx, r * 0.69f, ang);
            buf[n++] = hy(cy, r * 0.69f, ang);
        }
        pt.setStrokeWidth(r * 0.007f);
        pt.setColor(al(0xFFD3DCE8, 0.9f * ra));
        c.drawLines(buf, 0, n, pt);
        c.restore();
        for (int i = 0; i < 12; i++) {                                               // sensor LEDs blink in turn
            float on = 0.35f + 0.65f * Math.max(0f, sn(td, 3.0, -i * 0.52));
            dot(c, cx + Renderer.COS[i * 5] * r * 0.985f, cy + Renderer.SIN[i * 5] * r * 0.985f, r * 0.014f, RED, on * s);
        }
        c.save();                                                                     // laser beams sweep through the dial
        c.clipPath(disc);
        for (int k = 0; k < 5; k++) {
            float y = cy + r * 0.85f * sn(td, 5.5 + k * 0.6, k * 1.3);
            line(c, cx - r, y, cx + r, y, r * 0.03f, RED, 0.08f * s);
            line(c, cx - r, y, cx + r, y, r * 0.006f, RED, 0.55f * s);
        }
        c.restore();
    }

    private void arcaneLive(Canvas c, float b, double td, float s) {
        float grow = outBack(seg(b, 0.30f, 0.80f));
        if (grow > 0.01f) {
            float rot = (float) (td * 5.0) + (1f - Math.min(1f, grow)) * 360f, rad = r * 0.52f * grow;
            for (int k = 0; k < 2; k++) {                                              // a hexagram turning inside the circle
                path.rewind();
                for (int i = 0; i < 3; i++) {
                    float ang = rot * (k == 0 ? 1f : -1f) + i * 120f + k * 60f;
                    if (i == 0) path.moveTo(hx(cx, rad, ang), hy(cy, rad, ang));
                    else path.lineTo(hx(cx, rad, ang), hy(cy, rad, ang));
                }
                path.close();
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(r * 0.012f);
                pt.setColor(al(k == 0 ? GOLD : VIO, 0.35f * s));
                c.drawPath(path, pt);
                pt.setStrokeWidth(r * 0.004f);
                pt.setColor(al(0xFFFFFFFF, 0.9f * s));
                c.drawPath(path, pt);
            }
        }
        for (int i = 0; i < 12; i++) {                                                  // a wave of light passes from rune to rune
            float wv = Math.max(0f, sn(td, 4.0, -i * 0.52));
            if (wv < 0.15f) continue;
            dot(c, cx + Renderer.COS[i * 5] * r * 0.85f, cy + Renderer.SIN[i * 5] * r * 0.85f, r * 0.07f * wv, GOLD, 0.30f * wv * s);
        }
        for (int k = 0; k < 6; k++) {                                                   // sparks orbit the outer ring
            float ang = (float) (td * 14.0) + k * 60f;
            star4(c, hx(cx, r * 0.96f, ang), hy(cy, r * 0.96f, ang), r * 0.022f, 0xFFFFF0C8, 0.7f * s);
        }
    }

    // ---------- hands ----------

    void hands(int th, Canvas c, float hDeg, float mDeg, float sDeg, float sa, float b, long now) {
        float k = seg(b, 0.78f, 1f);                                                   // hands extend at the very end of the build
        if (k < 0.01f) return;
        double td = now / 1000.0;
        if (th == 5) mechHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else if (th == 6) codeHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else if (th == 7) westHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else if (th == 8) vaultHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else arcaneHands(c, hDeg, mDeg, sDeg, sa, k, td);
    }

    /** A jointed arm: two equal segments bent either side of the true angle, so the tip still points at the time. */
    private void arm(Canvas c, float deg, float len, float wid, float bend, float alpha) {
        float half = len / 2f, a1 = deg + bend, a2 = deg - bend;
        float jx = hx(cx, half, a1), jy = hy(cy, half, a1), tx = jx + hx(0f, half, a2), ty = jy + hy(0f, half, a2);
        line(c, cx, cy, jx, jy, wid * 1.9f, 0xFF1B2433, 0.85f * alpha);
        line(c, jx, jy, tx, ty, wid * 1.9f, 0xFF1B2433, 0.85f * alpha);
        line(c, cx, cy, jx, jy, wid, STEEL, alpha);
        line(c, jx, jy, tx, ty, wid, STEEL, alpha);
        line(c, cx, cy, jx, jy, wid * 0.3f, ACC, alpha);
        line(c, jx, jy, tx, ty, wid * 0.3f, ACC, alpha);
        dot(c, jx, jy, wid * 0.95f, 0xFF1B2433, alpha);
        dot(c, jx, jy, wid * 0.55f, AMBER, alpha);
    }

    private void mechHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        arm(c, h, r * 0.50f * k, r * 0.040f, 7f, k);
        arm(c, m, r * 0.80f * k, r * 0.026f, 5f, k);
        if (sa > 0.02f) {
            for (int i = 6; i >= 1; i--) dot(c, hx(cx, r * 0.985f, s - i * 3.5f), hy(cy, r * 0.985f, s - i * 3.5f), r * 0.010f, ACC, 0.7f * sa * k * (1f - i / 7f));
            dot(c, hx(cx, r * 0.985f, s), hy(cy, r * 0.985f, s), r * 0.04f, ACC, 0.30f * sa * k);
            dot(c, hx(cx, r * 0.985f, s), hy(cy, r * 0.985f, s), r * 0.017f, 0xFFFFFFFF, sa * k);
        }
        dot(c, cx, cy, r * 0.06f, 0xFF1B2433, k);
        dot(c, cx, cy, r * 0.032f, AMBER, k);
    }

    private void codeHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        for (int i = 0; i < 7; i++) {                                                     // the hour hand is a bar of data blocks
            float f0 = i / 7f * 0.50f * k, f1 = (i + 0.72f) / 7f * 0.50f * k;
            line(c, hx(cx, r * f0 + r * 0.05f, h), hy(cy, r * f0 + r * 0.05f, h), hx(cx, r * f1 + r * 0.05f, h), hy(cy, r * f1 + r * 0.05f, h), r * 0.046f, GREEN, 0.95f * k);
        }
        float mx = hx(cx, r * 0.80f * k, m), my = hy(cy, r * 0.80f * k, m);
        line(c, cx, cy, mx, my, r * 0.034f, GREEN, 0.18f * k);
        line(c, cx, cy, mx, my, r * 0.010f, 0xFFD8FFE8, k);
        glyph(c, '>', mx, my, r * 0.10f, 0xFFFFFFFF, k);
        if (sa > 0.02f) {                                                                  // a glitching square with an RGB split
            float x = hx(cx, r * 0.97f, s), y = hy(cy, r * 0.97f, s), q = r * 0.024f, j = r * 0.012f * (hash((int) Math.floor(td * 20.0)) - 0.5f) * 2f;
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFFF2A3A, 0.7f * sa * k));
            c.drawRect(x - q + j + q * 0.5f, y - q, x + q + j + q * 0.5f, y + q, pt);
            pt.setColor(al(0xFF2A7AFF, 0.7f * sa * k));
            c.drawRect(x - q - j - q * 0.5f, y - q, x + q - j - q * 0.5f, y + q, pt);
            pt.setColor(al(GREEN, 0.95f * sa * k));
            c.drawRect(x - q, y - q, x + q, y + q, pt);
        }
        int hh = ((int) (h / 30f)) % 12, mm = ((int) (m / 6f)) % 60;
        int h12 = hh == 0 ? 12 : hh;
        txt[0] = (char) ('0' + h12 / 10);
        txt[1] = (char) ('0' + h12 % 10);
        txt[3] = (char) ('0' + mm / 10);
        txt[4] = (char) ('0' + mm % 10);
        pt.setStyle(Paint.Style.FILL);
        pt.setTypeface(Typeface.MONOSPACE);
        pt.setTextAlign(Paint.Align.CENTER);
        pt.setTextSize(r * 0.13f);
        pt.setColor(al(GREEN, 0.55f * k));
        c.drawText(txt, 0, 5, cx, cy + r * 0.42f, pt);
        pt.setTypeface(Typeface.DEFAULT);
        dot(c, cx, cy, r * 0.03f, 0xFFD8FFE8, k);
    }

    private void westHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        c.save();                                                                          // the hour hand is a cartridge
        c.translate(cx, cy);
        c.rotate(h);
        float len = r * 0.46f * k;
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFF3A2410, k));
        c.drawRect(-r * 0.045f, -len * 0.62f, r * 0.045f, r * 0.08f, pt);
        pt.setColor(al(BRASS, k));
        c.drawRect(-r * 0.038f, -len * 0.62f, r * 0.038f, r * 0.06f, pt);
        path.rewind();
        path.moveTo(-r * 0.038f, -len * 0.62f);
        path.quadTo(-r * 0.038f, -len, 0f, -len);
        path.quadTo(r * 0.038f, -len, r * 0.038f, -len * 0.62f);
        path.close();
        pt.setColor(al(0xFFC27A3A, k));
        c.drawPath(path, pt);
        pt.setColor(al(0xFFFFF0C8, 0.6f * k));
        c.drawRect(-r * 0.022f, -len * 0.55f, -r * 0.010f, r * 0.03f, pt);
        c.restore();
        c.save();                                                                          // the minute hand is a long barrel with a sight
        c.translate(cx, cy);
        c.rotate(m);
        float ml = r * 0.80f * k;
        pt.setColor(al(0xFF2A2623, k));
        c.drawRect(-r * 0.022f, -ml, r * 0.022f, r * 0.10f, pt);
        pt.setColor(al(0xFF6B6259, k));
        c.drawRect(-r * 0.010f, -ml, r * 0.004f, r * 0.08f, pt);
        pt.setColor(al(BRASS, k));
        c.drawRect(-r * 0.012f, -ml - r * 0.03f, r * 0.012f, -ml + r * 0.01f, pt);
        c.restore();
        if (sa > 0.02f) {                                                                  // a spinning spur rowel with a puff of dust
            float x = hx(cx, r * 0.95f, s), y = hy(cy, r * 0.95f, s);
            for (int i = 4; i >= 1; i--) dot(c, hx(cx, r * 0.95f, s - i * 5f), hy(cy, r * 0.95f, s - i * 5f), r * (0.012f + 0.004f * i), 0xFFE0C79A, 0.35f * sa * k * (1f - i / 5f));
            c.save();
            c.rotate((float) (td * 360.0), x, y);
            star5(c, x, y, r * 0.05f, 0xFFFFE9B0, sa * k);
            c.restore();
        }
        dot(c, cx, cy, r * 0.05f, 0xFF3A2410, k);
        dot(c, cx, cy, r * 0.03f, BRASS, k);
    }

    private void vaultHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        float hx1 = hx(cx, r * 0.46f * k, h), hy1 = hy(cy, r * 0.46f * k, h);
        line(c, cx, cy, hx1, hy1, r * 0.058f, 0xFF1B2433, 0.9f * k);
        line(c, cx, cy, hx1, hy1, r * 0.038f, 0xFFB8C4D4, k);
        dot(c, hx1, hy1, r * 0.022f, RED, k);
        float mx = hx(cx, r * 0.78f * k, m), my = hy(cy, r * 0.78f * k, m);
        line(c, cx, cy, mx, my, r * 0.030f, RED, 0.16f * k);
        line(c, cx, cy, mx, my, r * 0.008f, 0xFFFFD0D4, k);
        pt.setStyle(Paint.Style.STROKE);                                                    // a targeting reticle at the tip
        pt.setStrokeWidth(r * 0.007f);
        pt.setColor(al(RED, k));
        c.drawCircle(mx, my, r * 0.045f, pt);
        for (int i = 0; i < 4; i++) line(c, hx(mx, r * 0.03f, m + i * 90f), hy(my, r * 0.03f, m + i * 90f), hx(mx, r * 0.07f, m + i * 90f), hy(my, r * 0.07f, m + i * 90f), r * 0.007f, RED, k);
        if (sa > 0.02f) {
            rc.set(cx - r * 0.97f, cy - r * 0.97f, cx + r * 0.97f, cy + r * 0.97f);
            pt.setStrokeWidth(r * 0.03f);
            pt.setColor(al(RED, 0.25f * sa * k));
            c.drawArc(rc, s - 90f - 14f, 14f, false, pt);
            pt.setStrokeWidth(r * 0.01f);
            pt.setColor(al(0xFFFFFFFF, 0.95f * sa * k));
            c.drawArc(rc, s - 90f - 14f, 14f, false, pt);
        }
        dot(c, cx, cy, r * 0.045f, 0xFF1B2433, k);
        dot(c, cx, cy, r * 0.022f, RED, k);
    }

    private void arcaneHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        float hx1 = hx(cx, r * 0.48f * k, h), hy1 = hy(cy, r * 0.48f * k, h);
        line(c, cx, cy, hx1, hy1, r * 0.05f, GOLD, 0.16f * k);
        line(c, cx, cy, hx1, hy1, r * 0.012f, GOLD, k);
        path.rewind();                                                                      // a diamond spear head
        path.moveTo(hx(cx, r * 0.56f * k, h), hy(cy, r * 0.56f * k, h));
        path.lineTo(hx(hx1, r * 0.035f, h + 90f), hy(hy1, r * 0.035f, h + 90f));
        path.lineTo(hx(cx, r * 0.42f * k, h), hy(cy, r * 0.42f * k, h));
        path.lineTo(hx(hx1, r * 0.035f, h - 90f), hy(hy1, r * 0.035f, h - 90f));
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFFFFF0C8, k));
        c.drawPath(path, pt);
        float mx = hx(cx, r * 0.80f * k, m), my = hy(cy, r * 0.80f * k, m);
        line(c, cx, cy, mx, my, r * 0.028f, VIO, 0.20f * k);
        line(c, cx, cy, mx, my, r * 0.008f, 0xFFE6D8FF, k);
        star4(c, mx, my, r * 0.05f, 0xFFE6D8FF, k);
        if (sa > 0.02f) {
            for (int i = 6; i >= 1; i--) dot(c, hx(cx, r * 0.96f, s - i * 4.5f), hy(cy, r * 0.96f, s - i * 4.5f), r * (0.018f - i * 0.0018f), 0xFFFFF0C8, 0.7f * sa * k * (1f - i / 7f));
            dot(c, hx(cx, r * 0.96f, s), hy(cy, r * 0.96f, s), r * 0.045f, GOLD, 0.35f * sa * k);
            dot(c, hx(cx, r * 0.96f, s), hy(cy, r * 0.96f, s), r * 0.018f, 0xFFFFFFFF, sa * k);
        }
        dot(c, cx, cy, r * 0.04f, GOLD, 0.4f * k);
        dot(c, cx, cy, r * 0.02f, 0xFFFFFFFF, k);
    }
}
