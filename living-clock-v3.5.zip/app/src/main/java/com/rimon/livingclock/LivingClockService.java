package com.rimon.livingclock;

import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

/**
 * Live wallpaper. Idle: one draw a second. During the intro, falling numbers, shooting stars and the
 * battery gauge it follows the display refresh through Choreographer, then returns to idle. The
 * accelerometer is on only while the pendulum or the flipped clock is showing.
 *
 * Taps on the clock: 1 = numbers, 2 in the centre = pendulum, 3 = flip. A tap on the pendulum pokes it.
 */
public class LivingClockService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new ClockEngine();
    }

    private final class ClockEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {

        private final long tapGap = 300L;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Choreographer choreographer = Choreographer.getInstance();
        private final Renderer renderer = new Renderer();
        private final Tilt tilt = new Tilt(LivingClockService.this, handler,
                (ax, ay, az) -> renderer.gauge.setGravity(ax, ay));
        private final Runnable tick = this::frame;
        private final Choreographer.FrameCallback vsync = t -> frame();

        private int taps, kind;
        private long lastTapMs;
        private float tapX, tapY;
        private boolean touchSeen;

        private final Runnable resolveTaps = () -> {
            int n = taps;
            taps = 0;
            long now = System.currentTimeMillis();
            if (n == 2 && renderer.inCenter(tapX, tapY)) renderer.gauge.togglePendulum(now);
            else if (renderer.gauge.flipped()) {
                renderer.gauge.touched(now);
                renderer.gauge.slosh();
            } else renderer.dropNumbers(now);
            schedule(0);
        };

        private final BroadcastReceiver wakeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renderer.playIntro(System.currentTimeMillis(), false);
                schedule(0);
            }
        };

        private SharedPreferences prefs;
        private Scene scene;
        private boolean visible, ready, destroyed, receiverOn;
        private int width, height, generation, imageVersion;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
            prefs = Prefs.get(LivingClockService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            imageVersion = prefs.getInt(Prefs.IMG, 0);
            renderer.readConfig(prefs);

            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            LivingClockService.this.registerReceiver(wakeReceiver, filter);
            receiverOn = true;
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                renderer.playIntro(System.currentTimeMillis(), false);
                schedule(0);
            } else {
                stop();
                tilt.stop();
                renderer.closeGauge();
                handler.removeCallbacks(resolveTaps);
                taps = 0;
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            ready = w > 0 && h > 0;
            if (!ready) return;
            if (w == width && h == height && scene != null) {
                schedule(0);
                return;
            }
            width = w;
            height = h;
            renderer.setSize(w, h);
            rebuild();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            ready = false;
            stop();
            tilt.stop();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            destroyed = true;
            stop();
            tilt.stop();
            handler.removeCallbacks(resolveTaps);
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            if (receiverOn) {
                try {
                    LivingClockService.this.unregisterReceiver(wakeReceiver);
                } catch (IllegalArgumentException ignored) {
                    // Already unregistered.
                }
                receiverOn = false;
            }
            renderer.release();
            if (scene != null) scene.recycle();
            scene = null;
            super.onDestroy();
        }

        // ---------- touch ----------

        /** Full touch events, when the launcher forwards them: poke or drag the pendulum, else count taps. */
        @Override
        public void onTouchEvent(MotionEvent e) {
            touchSeen = true;
            long now = System.currentTimeMillis();
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                if (renderer.gauge.touch(0, e.getX(), e.getY(), now)) schedule(0);
                else tap(e.getX(), e.getY());
            } else if (action == MotionEvent.ACTION_MOVE) {
                renderer.gauge.touch(1, e.getX(), e.getY(), now);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                renderer.gauge.touch(2, e.getX(), e.getY(), now);
            }
        }

        /** Most launchers forward taps on empty home-screen areas as this command. */
        @Override
        public Bundle onCommand(String action, int x, int y, int z, Bundle extras, boolean resultRequested) {
            if (!touchSeen && WallpaperManager.COMMAND_TAP.equals(action)) tap(x, y);
            return null;
        }

        private void tap(float x, float y) {
            long now = System.currentTimeMillis();
            if (renderer.gauge.pokeAt(x, y, now)) {
                schedule(0);
                return;
            }
            int k = renderer.onClock(x, y) ? 1 : (renderer.onSubjectTop(x, y) ? 2 : 0);
            if (k == 0) {
                taps = 0;
                kind = 0;
                return;
            }
            taps = (k == kind && now - lastTapMs <= tapGap) ? taps + 1 : 1;
            kind = k;
            lastTapMs = now;
            tapX = x;
            tapY = y;
            handler.removeCallbacks(resolveTaps);
            if (k == 2) {                       // double tap on the top of the cutout: next clock theme
                if (taps >= 2) {
                    taps = 0;
                    renderer.cycleTheme(now);
                    prefs.edit().putInt(Prefs.THEME, renderer.theme()).apply();
                    schedule(0);
                }
                return;
            }
            if (taps >= 3) {
                taps = 0;
                renderer.gauge.toggleFlip(now);
                schedule(0);
            } else {
                handler.postDelayed(resolveTaps, tapGap);
            }
        }

        // ---------- settings and scene ----------

        @Override
        public void onSharedPreferenceChanged(SharedPreferences p, String key) {
            renderer.readConfig(p);
            int v = p.getInt(Prefs.IMG, 0);
            if (v != imageVersion) {
                imageVersion = v;
                rebuild();
            } else {
                schedule(0);
            }
        }

        private void rebuild() {
            if (!ready || destroyed) return;
            final int gen = ++generation;
            Scene.buildAsync(LivingClockService.this, width, height,
                    prefs.getFloat(Prefs.SUBJ_SCALE, 1f), built -> {
                        if (destroyed || gen != generation) {
                            built.recycle();
                            return;
                        }
                        Scene old = scene;
                        scene = built;
                        renderer.setScene(built);
                        if (old != null) old.recycle();
                        schedule(0);
                    });
        }

        // ---------- frame loop ----------

        private void stop() {
            handler.removeCallbacks(tick);
            choreographer.removeFrameCallback(vsync);
        }

        private void schedule(long delayMs) {
            stop();
            if (visible && ready && !destroyed) handler.postDelayed(tick, delayMs);
        }

        private void frame() {
            if (!visible || !ready || destroyed) return;
            drawFrame(System.currentTimeMillis());

            if (renderer.gauge.due) renderer.gauge.readFrom(LivingClockService.this);
            boolean need = renderer.sensing();
            if (need != tilt.running()) {
                if (need) tilt.start();
                else tilt.stop();
            }

            long now = System.currentTimeMillis();
            if (renderer.animating(now)) choreographer.postFrameCallback(vsync);
            else handler.postDelayed(tick, renderer.delay(now));
        }

        private void drawFrame(long now) {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) canvas = holder.lockHardwareCanvas();
                if (canvas == null) canvas = holder.lockCanvas();
                if (canvas != null) renderer.draw(canvas, now);
            } catch (RuntimeException ignored) {
                // The surface can vanish mid-frame during rotation or lock-screen changes.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (RuntimeException ignored) {
                        // Surface no longer valid.
                    }
                }
            }
        }
    }
}
