package com.rimon.livingclock;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.Random;

/**
 * The lightsaber intro. Three blades ignite at 12 o'clock and spin clockwise (hour once, minute three
 * times, seconds eight times). The hour blade paints the dial behind it as it goes, throwing sparks and
 * a sweeping light across the background. When the dial is complete the blades swing to the real time
 * and melt into the theme's own hands. No enlargement; only the background dims.
 */
final class Forge {

    static final long DIM_IN = 350, IGN_AT = 150, IGN_LEN = 450;
    static final long SPIN_AT = 600, SPIN_LEN = 2300;
    static final long SETTLE_AT = SPIN_AT + SPIN_LEN, SETTLE_LEN = 1100;
    static final long HAND_AT = 3600, HAND_LEN = 450;
    static final long OUT_AT = 4100, OUT_LEN = 800;

    private static final int[] HUE = {0xFF5CB8FF, 0xFFB69BFF, 0xFFFFD28A};   // hour, minute, seconds
    private static final int INK = 0xFF0B0F17, GOLD = 0xFFFFDC8A;
    private static final int SPARKS = 28;

    boolean on;
    float wedge = 360f, handA = 1f;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pool = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint[] beamPaint = new Paint[3];
    private final Path beamPath = new Path();
    private final RectF rect = new RectF();
    private final float[] sR = new float[SPARKS], sT = new float[SPARKS], sS = new float[SPARKS];

    private float ha, ma, sa, bladeA, ignite, intensity, flash, poolR, flashR, lr;
    private int lw, lh;
    private long tNow;

    Forge() {
        Random rnd = new Random(7);
        for (int i = 0; i < SPARKS; i++) {
            sR[i] = rnd.nextFloat();
            sT[i] = rnd.nextFloat();
            sS[i] = rnd.nextBoolean() ? 1f : -1f;
        }
        pool.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        for (int i = 0; i < 3; i++) {
            beamPaint[i] = new Paint(Paint.ANTI_ALIAS_FLAG);
            beamPaint[i].setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
            beamPaint[i].setColorFilter(new PorterDuffColorFilter(HUE[i], PorterDuff.Mode.SRC_IN));
        }
    }

    void layout(float r, int w, int h) {
        if (r == lr && w == lw && h == lh) return;
        lr = r;
        lw = w;
        lh = h;
        float len = (float) Math.hypot(w, h);
        beamPath.rewind();
        beamPath.moveTo(0f, 0f);
        beamPath.lineTo(-len * 0.2f, -len);
        beamPath.lineTo(len * 0.2f, -len);
        beamPath.close();
        Shader beam = new LinearGradient(0f, 0f, 0f, -len, 0x90FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
        for (int i = 0; i < 3; i++) beamPaint[i].setShader(beam);
        poolR = r * 2.6f;
        pool.setShader(new RadialGradient(0f, 0f, poolR, new int[]{0x66BFDAFF, 0x2A7AA8FF, 0x007AA8FF},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        flashR = r * 0.7f;
        flashPaint.setShader(new RadialGradient(0f, 0f, flashR, new int[]{0xCCFFFFFF, 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
    }

    /** t is milliseconds since the intro began; the angles are the real time, in degrees from 12. */
    void update(long t, float hDeg, float mDeg, float sDeg) {
        on = true;
        tNow = t;
        ignite = easeOut(clamp((t - IGN_AT) / (float) IGN_LEN, 0f, 1f));
        float e = sine((t - SPIN_AT) / (float) SPIN_LEN);
        wedge = 360f * e;                                   // the dial is revealed behind the hour blade
        if (t < SETTLE_AT) {
            ha = 360f * e;
            ma = 1080f * e;
            sa = 2880f * e;
        } else {
            float b = backOut(clamp((t - SETTLE_AT) / (float) SETTLE_LEN, 0f, 1f));
            ha = 360f + hDeg * b;                           // all clockwise, with a small spring on landing
            ma = 1080f + mDeg * b;
            sa = 2880f + sDeg * b;
        }
        handA = smooth((t - HAND_AT) / (float) HAND_LEN);
        bladeA = 1f - handA;
        intensity = ignite * (1f - smooth((t - HAND_AT) / (float) (OUT_AT + OUT_LEN - HAND_AT)));
        flash = Math.max(0f, 1f - Math.abs(t - (IGN_AT + 150)) / 350f);
    }

    /** Clips to the part of the dial painted so far: a wedge from 12 o'clock to the hour blade. */
    void clipWedge(Canvas c, float cx, float cy, float rr) {
        rect.set(cx - rr, cy - rr, cx + rr, cy + rr);
        beamTmp.rewind();
        beamTmp.moveTo(cx, cy);
        beamTmp.arcTo(rect, -90f, wedge, false);
        beamTmp.close();
        c.clipPath(beamTmp);
    }

    private final Path beamTmp = new Path();

    // ---------- light on the background ----------

    void drawLight(Canvas c, float cx, float cy) {
        if (intensity <= 0.01f || lw == 0) return;
        c.save();
        c.translate(cx, cy);
        pool.setAlpha((int) (255 * intensity));
        c.drawCircle(0f, 0f, poolR, pool);
        beam(c, sa, 0, 0.15f);
        beam(c, ma, 1, 0.40f);
        beam(c, ha, 2, 1f);
        c.restore();
    }

    private void beam(Canvas c, float ang, int i, float k) {
        beamPaint[i].setAlpha((int) (255 * intensity * k));
        c.save();
        c.rotate(ang);
        c.drawPath(beamPath, beamPaint[i]);
        c.restore();
    }

    // ---------- blades ----------

    void drawBlades(Canvas c, float cx, float cy, float r) {
        if (wedge > 1f && wedge < 359f) {                   // light painted along the rim, trailing the blade
            float fade = 1f - smooth((wedge - 320f) / 39f), rr = r * 0.975f;
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 6; i++) {
                float len = Math.min(wedge, 70f) * (1f - i / 6f);
                paint.setStrokeWidth(r * (0.06f - i * 0.006f));
                paint.setColor(withA(HUE[0], (int) (34 * fade)));
                c.drawArc(rect, wedge - 90f - len, len, false, paint);
            }
            double th = Math.toRadians(wedge - 90f);
            float hx = cx + (float) Math.cos(th) * rr, hy = cy + (float) Math.sin(th) * rr;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withA(HUE[0], (int) (90 * fade)));
            c.drawCircle(hx, hy, r * 0.09f, paint);
            paint.setColor(withA(0xFFFFFF, (int) (255 * fade)));
            c.drawCircle(hx, hy, r * 0.028f, paint);
        }
        if (flash > 0f) {
            c.save();
            c.translate(cx, cy);
            flashPaint.setAlpha((int) (255 * flash));
            c.drawCircle(0f, 0f, flashR, flashPaint);
            c.restore();
        }
        blade(c, cx, cy, r, sa, 0.92f, HUE[2], 0.85f);
        blade(c, cx, cy, r, ma, 0.80f, HUE[1], 0.95f);
        blade(c, cx, cy, r, ha, 0.52f, HUE[0], 1f);
        drawSparks(c, cx, cy, r);
        if (bladeA > 0.01f) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withA(INK, (int) (255 * bladeA)));
            c.drawCircle(cx, cy, r * 0.06f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(r * 0.012f);
            paint.setColor(withA(GOLD, (int) (255 * bladeA)));
            c.drawCircle(cx, cy, r * 0.06f, paint);
        }
    }

    private void blade(Canvas c, float cx, float cy, float r, float ang, float len, int hue, float k) {
        float a = bladeA * k;
        if (a <= 0.01f || ignite <= 0.001f) return;
        float l = r * len * ignite, s0 = r * 0.09f;
        c.save();
        c.translate(cx, cy);
        c.rotate(ang);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(r * 0.14f);
        paint.setColor(withA(hue, (int) (60 * a)));
        c.drawLine(0f, -s0, 0f, -l, paint);
        paint.setStrokeWidth(r * 0.06f);
        paint.setColor(withA(hue, (int) (150 * a)));
        c.drawLine(0f, -s0, 0f, -l, paint);
        paint.setStrokeWidth(r * 0.022f);
        paint.setColor(withA(0xFFFFFF, (int) (255 * a)));
        c.drawLine(0f, -s0, 0f, -l, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);                  // the hilt: a dark grip with a gold ring
        paint.setStrokeWidth(r * 0.05f);
        paint.setColor(withA(INK, (int) (255 * bladeA)));
        c.drawLine(0f, 0f, 0f, -s0, paint);
        paint.setStrokeWidth(r * 0.012f);
        paint.setColor(withA(GOLD, (int) (255 * bladeA)));
        c.drawLine(-r * 0.03f, -s0 * 0.55f, r * 0.03f, -s0 * 0.55f, paint);
        c.restore();
    }

    /** Sparks thrown off the hour blade's tip while it spins; positions follow from the emission time. */
    private void drawSparks(Canvas c, float cx, float cy, float r) {
        float ts = tNow / 1000f;
        paint.setStyle(Paint.Style.FILL);
        for (int k = 0; k < SPARKS; k++) {
            float te = SPIN_AT / 1000f + k * 0.075f, age = ts - te;
            if (age < 0f || age > 0.7f) continue;
            double a0 = Math.toRadians(360f * sine((te * 1000f - SPIN_AT) / SPIN_LEN));
            float dx = (float) Math.sin(a0), dy = -(float) Math.cos(a0);      // blade direction
            float tx = -dy, ty = dx;                                          // clockwise tangent
            float vr = r * (0.20f + 0.45f * sR[k]), vt = r * (0.10f + 0.5f * sT[k]) * sS[k];
            float x = cx + dx * r * 0.52f * ignite + (dx * vr + tx * vt) * age;
            float y = cy + dy * r * 0.52f * ignite + (dy * vr + ty * vt) * age;
            float life = 1f - age / 0.7f;
            paint.setColor(withA(0xFFFFFF, (int) (255 * life * life)));
            c.drawCircle(x, y, r * 0.016f * (0.4f + 0.6f * life), paint);
        }
    }

    // ---------- helpers ----------

    private static float sine(float p) {
        return 0.5f - 0.5f * (float) Math.cos(Math.PI * clamp(p, 0f, 1f));
    }

    private static float easeOut(float x) {
        return 1f - (1f - x) * (1f - x) * (1f - x);
    }

    private static float backOut(float p) {
        float u = p - 1f;
        return 1f + 1.8f * u * u * u + 0.8f * u * u;
    }

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static int withA(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
