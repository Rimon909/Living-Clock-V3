package com.rimon.livingclock;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;

/**
 * Accelerometer at about 100 Hz, only while the battery gauge is on screen. The raw accelerometer is used
 * on purpose: it carries both the tilt and sudden shakes, so the liquid and the pendulum react at once.
 */
final class Tilt implements SensorEventListener {

    interface Sink {
        void onGravity(float ax, float ay, float az);
    }

    private final SensorManager manager;
    private final Sensor accel;
    private final Handler handler;
    private final Sink sink;
    private boolean on, failed;

    Tilt(Context c, Handler handler, Sink sink) {
        this.manager = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        this.accel = manager == null ? null : manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        this.handler = handler;
        this.sink = sink;
    }

    boolean running() {
        return on;
    }

    void start() {
        if (on || failed || accel == null) return;
        on = manager.registerListener(this, accel, 10_000, handler);
        if (!on) failed = true;
    }

    void stop() {
        if (!on) return;
        manager.unregisterListener(this);
        on = false;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        sink.onGravity(e.values[0], e.values[1], e.values[2]);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}
