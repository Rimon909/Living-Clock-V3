package com.rimon.livingclock;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.PowerManager;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Scenes: rules of the form "when this is true, change that". Signals come in, conditions (all / any / not,
 * thresholds, debounce) decide which scenes are live, and the live ones are merged by priority into a single
 * Out that the renderer applies. Any value can be a constant or bound to a signal through a linear map.
 *
 * Packs are plain JSON, validated and re-serialised on import: unknown keys are dropped, numbers are clamped,
 * sizes are capped. Data only, never code. The engine is off unless the developer switch is on, and when it is
 * on it is evaluated about twice a second, so it costs next to nothing.
 */
final class Scenes {

    static final String[] SIG = {"music", "charging", "battery", "saver", "hour", "weekday"};
    static final String[] KEY = {"pattern", "exit", "sleep", "bands", "sens", "dim", "fps"};
    private static final float[][] RANGE = {{0, 4}, {0, 3}, {0, 3}, {0, 1}, {0.3f, 2f}, {0f, 0.8f}, {15, 60}};
    private static final String[] OPS = {">", "<", "=", "between"};
    private static final int MAX_SCENES = 12, MAX_LEN = 20000, MAX_NODES = 24;

    /** What the renderer applies. v[0..3] are -1 when unset; sens defaults to 1, dim to 0, fps 0 = uncapped. */
    static final class Out {
        final float[] v = {-1f, -1f, -1f, -1f, 1f, 0f, 0f};
        String names = "";
    }

    static final Out NONE = new Out();

    static final String PRESETS = "[" +
            "{\"name\":\"Low battery\",\"on\":true,\"pri\":90,\"when\":{\"any\":[{\"sig\":\"battery\",\"op\":\"<\",\"v\":15},"
            + "{\"sig\":\"saver\",\"op\":\">\",\"v\":0.5}]},\"set\":{\"fps\":30,\"pattern\":0}}," +
            "{\"name\":\"Night\",\"on\":false,\"pri\":40,\"when\":{\"sig\":\"hour\",\"op\":\"between\",\"v\":[23,6]},"
            + "\"set\":{\"dim\":0.35,\"sleep\":2,\"fps\":30}}," +
            "{\"name\":\"Dusk fade\",\"on\":false,\"pri\":30,\"when\":{\"sig\":\"hour\",\"op\":\"between\",\"v\":[17,23]},"
            + "\"set\":{\"dim\":{\"bind\":\"hour\",\"from\":[17,23],\"to\":[0,0.4]}}}," +
            "{\"name\":\"Gym\",\"on\":false,\"pri\":50,\"when\":{\"all\":[{\"sig\":\"music\",\"op\":\">\",\"v\":0.5,\"for\":0.5},"
            + "{\"sig\":\"hour\",\"op\":\"between\",\"v\":[6,9]}]},\"set\":{\"pattern\":3,\"sens\":1.2,\"exit\":1}}," +
            "{\"name\":\"Calm charging\",\"on\":false,\"pri\":30,\"when\":{\"sig\":\"charging\",\"op\":\">\",\"v\":0.5},"
            + "\"set\":{\"sleep\":3,\"bands\":false}}," +
            "{\"name\":\"Focus hours\",\"on\":false,\"pri\":20,\"when\":{\"all\":[{\"sig\":\"weekday\",\"op\":\"between\",\"v\":[2,6]},"
            + "{\"sig\":\"hour\",\"op\":\"between\",\"v\":[9,17]}]},\"set\":{\"bands\":false}}]";

    // ---------- model ----------

    private static final class Val {
        float c, a, b, x, y;
        int sig = -1;

        float get(float[] s) {
            if (sig < 0) return c;
            float f = b == a ? 0f : (s[sig] - a) / (b - a);
            return x + (y - x) * (f < 0f ? 0f : (f > 1f ? 1f : f));
        }
    }

    private static final class Node {
        int type, sig, op;                  // type 0 all, 1 any, 2 not, 3 leaf
        Node[] kid = new Node[0];
        float a, b, forS;
        long since;

        boolean eval(float[] s, long now) {
            if (type != 3) {
                boolean all = true, any = false;
                for (Node k : kid) {                     // no short-circuit: every debounce timer keeps running
                    boolean r = k.eval(s, now);
                    all &= r;
                    any |= r;
                }
                return type == 0 ? all : (type == 1 ? any : !any);
            }
            float x = s[sig];
            boolean raw = op == 0 ? x > a : op == 1 ? x < a : op == 2 ? Math.abs(x - a) < 0.5f
                    : (a <= b ? x >= a && x <= b : x >= a || x <= b);
            if (forS <= 0f) return raw;
            if (!raw) {
                since = 0L;
                return false;
            }
            if (since == 0L) since = now;
            return now - since >= forS * 1000f;
        }
    }

    static final class Scene {
        String name = "Scene";
        boolean on = true;
        int pri = 50;
        private Node when = new Node();
        private final Val[] set = new Val[KEY.length];

        String summary() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < KEY.length; i++) {
                if (set[i] == null) continue;
                if (sb.length() > 0) sb.append("  ");
                sb.append(KEY[i]).append(set[i].sig >= 0 ? "~" + SIG[set[i].sig] : "=" + fmt(set[i].c));
            }
            return sb.toString();
        }
    }

    private static double r2(float f) {
        return Math.round(f * 100.0) / 100.0;
    }

    private static String fmt(float f) {
        return f == Math.rint(f) ? String.valueOf((int) f) : String.valueOf(Math.round(f * 100f) / 100f);
    }

    // ---------- parsing and validation (this is what protects against hostile packs) ----------

    static List<Scene> parse(String text) throws Exception {
        if (text == null || text.length() > MAX_LEN) throw new Exception("Too large");
        text = text.trim();
        JSONArray arr = text.startsWith("[") ? new JSONArray(text) : new JSONObject(text).getJSONArray("scenes");
        if (arr.length() == 0 || arr.length() > MAX_SCENES) throw new Exception("1 to " + MAX_SCENES + " scenes");
        List<Scene> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) out.add(scene(arr.getJSONObject(i)));
        return out;
    }

    private static Scene scene(JSONObject o) throws Exception {
        Scene s = new Scene();
        String n = o.optString("name", "Scene").trim();
        s.name = n.isEmpty() ? "Scene" : n.substring(0, Math.min(24, n.length()));
        s.on = o.optBoolean("on", true);
        s.pri = Math.max(0, Math.min(100, o.optInt("pri", 50)));
        JSONObject w = o.optJSONObject("when");
        if (w != null) s.when = node(w, new int[]{MAX_NODES}, 0);
        JSONObject set = o.optJSONObject("set");
        if (set == null) throw new Exception("'" + s.name + "' has no set");
        boolean any = false;
        for (int k = 0; k < KEY.length; k++) {
            if (!set.has(KEY[k])) continue;
            Val v = new Val();
            Object raw = set.get(KEY[k]);
            if (raw instanceof JSONObject) {
                JSONObject b = (JSONObject) raw;
                v.sig = sig(b.optString("bind"));
                JSONArray f = b.getJSONArray("from"), t = b.getJSONArray("to");
                v.a = (float) f.getDouble(0);
                v.b = (float) f.getDouble(1);
                v.x = clamp(k, (float) t.getDouble(0));
                v.y = clamp(k, (float) t.getDouble(1));
            } else {
                v.c = clamp(k, raw instanceof Boolean ? ((Boolean) raw ? 1f : 0f) : (float) set.getDouble(KEY[k]));
            }
            s.set[k] = v;
            any = true;
        }
        if (!any) throw new Exception("'" + s.name + "' changes nothing");
        return s;
    }

    private static float clamp(int k, float v) {
        v = Math.max(RANGE[k][0], Math.min(RANGE[k][1], v));
        return k < 4 ? Math.round(v) : v;
    }

    private static int sig(String n) throws Exception {
        for (int i = 0; i < SIG.length; i++) if (SIG[i].equals(n)) return i;
        throw new Exception("Unknown signal: " + (n.length() > 12 ? n.substring(0, 12) : n));
    }

    private static Node node(JSONObject o, int[] budget, int depth) throws Exception {
        if (--budget[0] < 0 || depth > 4) throw new Exception("Condition too deep");
        Node n = new Node();
        for (int t = 0; t < 2; t++) {
            JSONArray a = o.optJSONArray(t == 0 ? "all" : "any");
            if (a == null) continue;
            n.type = t;
            n.kid = new Node[Math.min(a.length(), MAX_NODES)];
            for (int i = 0; i < n.kid.length; i++) n.kid[i] = node(a.getJSONObject(i), budget, depth + 1);
            return n;
        }
        JSONObject no = o.optJSONObject("not");
        if (no != null) {
            n.type = 2;
            n.kid = new Node[]{node(no, budget, depth + 1)};
            return n;
        }
        n.type = 3;
        n.sig = sig(o.optString("sig"));
        String op = o.optString("op", ">");
        n.op = Arrays.asList(OPS).indexOf(op);
        if (n.op < 0) throw new Exception("Unknown op");
        Object v = o.get("v");
        if (v instanceof JSONArray) {
            n.a = (float) ((JSONArray) v).getDouble(0);
            n.b = (float) ((JSONArray) v).getDouble(1);
        } else {
            n.a = (float) o.getDouble("v");
        }
        n.forS = Math.max(0f, Math.min(30f, (float) o.optDouble("for", 0)));
        return n;
    }

    private static JSONObject toJson(Scene s) throws Exception {
        JSONObject o = new JSONObject().put("name", s.name).put("on", s.on).put("pri", s.pri);
        if (!(s.when.type == 0 && s.when.kid.length == 0)) o.put("when", toJson(s.when));
        JSONObject set = new JSONObject();
        for (int k = 0; k < KEY.length; k++) {
            Val v = s.set[k];
            if (v == null) continue;
            if (v.sig >= 0) {
                set.put(KEY[k], new JSONObject().put("bind", SIG[v.sig])
                        .put("from", new JSONArray().put(r2(v.a)).put(r2(v.b))).put("to", new JSONArray().put(r2(v.x)).put(r2(v.y))));
            } else if (k == 3) {
                set.put(KEY[k], v.c > 0.5f);
            } else {
                set.put(KEY[k], k < 4 ? (Object) (int) v.c : (Object) r2(v.c));
            }
        }
        return o.put("set", set);
    }

    private static JSONObject toJson(Node n) throws Exception {
        JSONObject o = new JSONObject();
        if (n.type == 3) {
            o.put("sig", SIG[n.sig]).put("op", OPS[n.op]);
            o.put("v", n.op == 3 ? new JSONArray().put(r2(n.a)).put(r2(n.b)) : (Object) r2(n.a));
            if (n.forS > 0f) o.put("for", r2(n.forS));
            return o;
        }
        JSONArray a = new JSONArray();
        for (Node k : n.kid) a.put(toJson(k));
        return n.type == 2 ? o.put("not", n.kid[0] == null ? new JSONObject() : toJson(n.kid[0])) : o.put(n.type == 0 ? "all" : "any", a);
    }

    static String text(List<Scene> l) {
        JSONArray a = new JSONArray();
        for (Scene s : l) {
            try {
                a.put(toJson(s));
            } catch (Exception ignored) {
                // A scene that cannot be written is skipped; parse() never produces one.
            }
        }
        return a.toString();
    }

    // ---------- engine ----------

    private List<Scene> list = new ArrayList<>();
    private boolean enabled;
    private Out cur = NONE;

    boolean enabled() {
        return enabled;
    }

    void load(SharedPreferences p) {
        enabled = p.getBoolean(Prefs.SCENES_ON, false);
        try {
            list = parse(p.getString(Prefs.SCENES, PRESETS));
        } catch (Exception e) {
            try {
                list = parse(PRESETS);
            } catch (Exception ignored) {
                list = new ArrayList<>();
            }
        }
        cur = NONE;
    }

    Out eval(float[] s, long now) {
        if (!enabled) return NONE;
        Scene[] hit = new Scene[list.size()];
        int n = 0;
        for (Scene sc : list) {
            boolean t = sc.when.eval(s, now);                 // always evaluated so debounce timers stay honest
            if (!sc.on || !t) continue;
            int j = n++;
            while (j > 0 && hit[j - 1].pri > sc.pri) {        // insertion sort, lowest priority first
                hit[j] = hit[j - 1];
                j--;
            }
            hit[j] = sc;
        }
        Out o = new Out();
        StringBuilder names = new StringBuilder();
        for (int i = n - 1; i >= 0; i--) {
            if (names.length() > 0) names.append(" + ");
            names.append(hit[i].name);
        }
        for (int i = 0; i < n; i++) {                         // higher priority is applied last, so it wins
            for (int k = 0; k < KEY.length; k++) if (hit[i].set[k] != null) o.v[k] = hit[i].set[k].get(s);
        }
        o.names = names.toString();
        if (Arrays.equals(o.v, cur.v) && o.names.equals(cur.names)) return cur;
        cur = o;
        return o;
    }

    String active() {
        return cur.names.isEmpty() ? "none" : cur.names;
    }

    // ---------- signals ----------

    private static long batAt;
    private static float batPct = 50f, plug, saver;
    private static final java.util.Calendar CAL = java.util.Calendar.getInstance();

    /** Fills s with the current signals. The battery and saver reads are cached for five seconds. */
    static void sample(Context c, boolean music, float[] s) {
        long t = SystemClock.elapsedRealtime();
        if (batAt == 0L || t - batAt > 5000L) {
            batAt = t;
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i != null) {
                int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                if (lv >= 0 && sc > 0) batPct = 100f * lv / sc;
                plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0 ? 1f : 0f;
            }
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            saver = pm != null && pm.isPowerSaveMode() ? 1f : 0f;
        }
        CAL.setTimeInMillis(System.currentTimeMillis());
        s[0] = music ? 1f : 0f;
        s[1] = plug;
        s[2] = batPct;
        s[3] = saver;
        s[4] = CAL.get(java.util.Calendar.HOUR_OF_DAY) + CAL.get(java.util.Calendar.MINUTE) / 60f;
        s[5] = CAL.get(java.util.Calendar.DAY_OF_WEEK);       // 1 = Sunday
    }
}
