package com.rimon.livingclock;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.BatteryManager;

import java.util.Random;

/**
 * Battery level on the clock.
 *  - Indicator on the dial: rim arc, lit ticks, tiny percentage, intro-only arc, arc + percentage.
 *  - Pendulum (double tap the centre): a small clock with the percentage swings out on a thread.
 *    A verlet bob on an elastic rope, so it drops, snaps taut, bounces and settles; it reacts to tilt,
 *    shakes, pokes and drags.
 *  - Flip (triple tap): the clock lifts, turns in 3D and shows a dense liquid that fills to the battery
 *    level, tilts with gravity and changes colour with the charge.
 * Physics runs in small fixed sub-steps so it stays stable at any refresh rate.
 */
final class Gauge {

    private static final int IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A, INK = 0xFF0B0F17, LOW = 0xFFFF7A6B;
    private static final float[] KEY_PCT = {0f, 20f, 45f, 70f, 100f};
    private static final int[] KEY_COL = {0xFFE5484D, 0xFFF08A3C, 0xFFF2C14E, 0xFF58C98A, 0xFF2ECDA7};
    private static final long HOLD_MS = 25_000L, FILL_MS = 2800L;
    private static final int WAVE_N = 28, BUBBLES = 6;
    private static final float ROPE_K = 500f, ROPE_C = 10f;

    // Public state, read by the renderer.
    int indicator = 1;
    int pct = 50;
    boolean charging, plugged, due = true;
    float lift, angle;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint liquid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bobGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bobGlass = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tank = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glintPaint = new Paint();
    private final LinearGradient glint = new LinearGradient(-100f, 0f, 100f, 0f,
            new int[]{0x00FFFFFF, 0x88FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
    private final Camera camera = new Camera();
    private final Matrix fm = new Matrix();
    private final Path liqPath = new Path(), surfPath = new Path(), clip = new Path();
    private final Path rope = new Path(), bolt = new Path();
    private final RectF rect = new RectF();
    private final Random rnd = new Random();
    private final float[] bX = new float[BUBBLES], bY = new float[BUBBLES];
    private final float[] bV = new float[BUBBLES], bS = new float[BUBBLES];

    private String pctText = "50", pctLabel = "50%";

    // Geometry, set every frame by the renderer.
    private float cx, cy, rad, scale = 1f, br, pivotX, pivotY;
    private int sh = 1920;
    private float shaderRad = -1f;
    private int shaderCol;

    // Tilt: sensor target, smoothed value, slow baseline for parallax.
    private float gtX, gtY = 1f, gX, gY = 1f, baseX, baseY = 1f, parX, parY;
    private float lgX, lgY = 1f, lvX, lvY, wave, wavePhase, dtLast;
    private long lastMs = -1L, touchAt = -1L;

    // Flip.
    private boolean flipIntent, autoDone;
    private float angVel, angleFrom, liftLin;
    private long flipAt = -1L, fillAt = -1L, glintAt = -1L;

    // Pendulum.
    private int pend;                     // 0 hidden, 1 out, 2 retracting
    private boolean pendAuto, grabbed, candidate;
    private long pendAt;
    private float bx, by, vx, vy, restLen, grabX, grabY, downX, downY, gdx, gdy = 1f;

    Gauge() {
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        text.setTextAlign(Paint.Align.CENTER);
        glintPaint.setAntiAlias(true);
        bolt.moveTo(0.25f, -1f);
        bolt.lineTo(-0.55f, 0.1f);
        bolt.lineTo(-0.05f, 0.1f);
        bolt.lineTo(-0.25f, 1f);
        bolt.lineTo(0.55f, -0.15f);
        bolt.lineTo(0.05f, -0.15f);
        bolt.close();
        for (int i = 0; i < BUBBLES; i++) {
            bX[i] = (rnd.nextFloat() - 0.5f) * 1.3f;
            bY[i] = rnd.nextFloat();
            bV[i] = 0.08f + rnd.nextFloat() * 0.12f;
            bS[i] = 0.012f + rnd.nextFloat() * 0.02f;
        }
    }

    // ---------- inputs ----------

    void setBattery(int p, boolean ch) {
        pct = Math.max(0, Math.min(100, p));
        charging = ch;
        pctText = Integer.toString(pct);
        pctLabel = pctText + "%";
        due = false;
    }

    /** One cheap read of the sticky battery broadcast. */
    void readFrom(Context c) {
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            due = false;
            return;
        }
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int max = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        setBattery(level < 0 ? 50 : Math.round(100f * level / Math.max(1, max)),
                st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL);
    }

    /** Accelerometer reading in device coordinates; converted to "which way is down" on the screen, in g. */
    void setGravity(float ax, float ay) {
        gtX = clamp(-ax / 9.81f, -3f, 3f);
        gtY = clamp(ay / 9.81f, -3f, 3f);
    }

    float gx() {
        return gX;
    }

    float gy() {
        return gY;
    }

    void touched(long now) {
        touchAt = now;
    }

    boolean active() {
        return pend != 0 || flipIntent || angle > 0.3f || liftLin > 0.001f;
    }

    boolean flipped() {
        return flipIntent;
    }

    /** Pop while turning: the clock shrinks slightly at the edge-on moment. */
    float pop() {
        return 1f - 0.07f * (float) Math.sin(Math.toRadians(clamp(angle, 0f, 180f)));
    }

    // ---------- actions ----------

    void togglePendulum(long now) {
        touchAt = now;
        due = true;
        pendAuto = false;
        if (pend == 1) pend = 2;
        else deploy(now);
    }

    void toggleFlip(long now) {
        touchAt = now;
        due = true;
        flipIntent = !flipIntent;
        flipAt = now;
        angleFrom = angle;
        autoDone = false;
        glintAt = -1L;
        if (!flipIntent && pendAuto && pend == 1) pend = 2;
    }

    void slosh() {
        lvX += (rnd.nextFloat() - 0.5f) * 6f;
        lvY -= 2f;
        wave = Math.max(wave, 0.07f);
    }

    /** Animated close after a quiet spell. */
    private void close(long now) {
        if (flipIntent) toggleFlip(now);
        if (pend == 1) pend = 2;
        touchAt = -1L;
    }

    /** Immediate reset, for when the wallpaper is hidden. */
    void reset() {
        pend = 0;
        pendAuto = grabbed = candidate = flipIntent = false;
        angle = angVel = angleFrom = liftLin = lift = 0f;
        flipAt = fillAt = glintAt = touchAt = -1L;
    }

    private void deploy(long now) {
        if (pend == 0) {
            bx = pivotX;
            by = pivotY;
            vx = (rnd.nextFloat() - 0.5f) * 0.35f * sh;
            vy = 0f;
        }
        pend = 1;
        pendAt = now;
        restLen = sh * 0.18f;
    }

    /** A tap on the bob pushes it away from the finger. */
    boolean pokeAt(float x, float y, long now) {
        if (pend != 1) return false;
        float dx = bx - x, dy = by - y, d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d > br * 1.9f) return false;
        if (d < 1f) {
            dx = rnd.nextBoolean() ? 1f : -1f;
            dy = 0f;
            d = 1f;
        }
        vx += dx / d * sh * 0.55f;
        vy += dy / d * sh * 0.55f;
        touchAt = now;
        return true;
    }

    /** Full touch events (action 0 down, 1 move, 2 up): poke on touch, then drag if the finger moves. */
    boolean touch(int action, float x, float y, long now) {
        if (action == 0) {
            candidate = pokeAt(x, y, now);
            downX = x;
            downY = y;
            return candidate;
        }
        if (!candidate) return false;
        touchAt = now;
        if (action == 1) {
            if (!grabbed && Math.hypot(x - downX, y - downY) > 14f) grabbed = true;
            if (grabbed) {
                grabX = x;
                grabY = y;
            }
        } else {
            grabbed = false;
            candidate = false;
        }
        return true;
    }

    // ---------- simulation ----------

    void layout(float cx, float cy, float r, float scale, int w, int h) {
        this.cx = cx;
        this.cy = cy;
        this.rad = r;
        this.scale = scale;
        this.sh = h;
        this.br = r * 0.30f;
        pivotX = cx;
        pivotY = cy + r * scale * 0.98f;
        int col = colorFor(pct);
        if (r != shaderRad || col != shaderCol) buildShaders(r, col);
    }

    private void buildShaders(float r, int col) {
        shaderRad = r;
        shaderCol = col;
        float R = r * 0.915f;
        bobGlow.setShader(new RadialGradient(0f, 0f, br * 2.4f,
                new int[]{0x66FFDC8A, 0x30FFDC8A, 0x00FFDC8A}, new float[]{0.35f, 0.65f, 1f}, Shader.TileMode.CLAMP));
        bobGlass.setShader(new RadialGradient(0f, 0f, br * 0.86f,
                new int[]{0xFF222B3B, 0xFF0C1018}, null, Shader.TileMode.CLAMP));
        halo.setShader(new RadialGradient(0f, 0f, r * 1.55f,
                new int[]{withA(col, 0x70), withA(col, 0x30), withA(col, 0)},
                new float[]{0.55f, 0.78f, 1f}, Shader.TileMode.CLAMP));
        tank.setShader(new RadialGradient(0f, 0f, R,
                new int[]{0xFF1C2535, 0xFF090C12}, null, Shader.TileMode.CLAMP));
        liquid.setShader(new LinearGradient(0f, -R, 0f, R,
                mix(col, 0xFFFFFFFF, 0.14f), mix(col, 0xFF000000, 0.55f), Shader.TileMode.CLAMP));
    }

    void update(long now) {
        float dt = lastMs < 0 ? 0f : Math.min(0.05f, (now - lastMs) / 1000f);
        lastMs = now;
        if (dt <= 0f) return;
        dtLast = dt;
        if (touchAt >= 0 && active() && now - touchAt > HOLD_MS) close(now);

        // Tilt: smooth the sensor up to the display rate; a slow baseline keeps the parallax centred.
        float k = 1f - (float) Math.exp(-35f * dt), kb = 1f - (float) Math.exp(-0.25f * dt);
        gX += (gtX - gX) * k;
        gY += (gtY - gY) * k;
        baseX += (gX - baseX) * kb;
        baseY += (gY - baseY) * kb;
        parX = clamp(gX - baseX, -1f, 1f);
        parY = clamp(gY - baseY, -1f, 1f);

        // Lift in with the flip, lift out once the clock has turned back.
        float to = (flipIntent || angle >= 2f) ? 1f : 0f;
        liftLin += clamp(to - liftLin, -dt / 0.45f, dt / 0.45f);
        lift = smooth(liftLin);

        float target = angleFrom;
        if (flipAt >= 0) {
            float p = flipIntent ? (now - flipAt - 300) / 1100f : (now - flipAt) / 900f;
            target = angleFrom + ((flipIntent ? 180f : 0f) - angleFrom) * ease3(clamp(p, 0f, 1f));
        }
        if (flipIntent && angle > 90f && fillAt < 0) fillAt = now;
        if (!flipIntent && angle < 90f) fillAt = -1L;
        if (flipIntent && glintAt < 0 && angle >= 179f) glintAt = now;
        if (flipIntent && !autoDone && now - flipAt > 1300) {
            autoDone = true;
            if (pend != 1) {
                deploy(now);
                pendAuto = true;
            }
        }

        float m = (float) Math.hypot(gX, gY);
        float ex = gX, ey = gY + 0.3f * (1f - smooth(m / 0.3f));  // lying flat falls back to "down"
        float n = (float) Math.hypot(ex, ey);
        if (n > 0.01f) {
            gdx = ex / n;
            gdy = ey / n;
        }
        float G = sh * 2.4f;
        int steps = Math.max(1, (int) Math.ceil(dt / 0.004f));
        float hs = dt / steps;
        for (int i = 0; i < steps; i++) {
            angVel += (169f * (target - angle) - 14.3f * angVel) * hs;   // spring: slight overshoot on landing
            angle += angVel * hs;
            if (angle < 0f) {
                angle = 0f;
                angVel = 0f;
            }
            lvX += (80f * (ex - lgX) - 9.8f * lvX) * hs;                 // dense liquid: heavy, slow sway
            lvY += (80f * (ey - lgY) - 9.8f * lvY) * hs;
            lgX += lvX * hs;
            lgY += lvY * hs;
            if (pend != 0) stepBob(ex, ey, G, hs);
        }

        wave += (clamp((float) Math.hypot(lvX, lvY) * 0.05f, 0f, 0.09f) - wave) * Math.min(1f, dt * 5f);
        wavePhase += dt * 6.5f;

        if (pend == 2) {
            restLen -= sh * 0.18f / 0.45f * dt;
            if (restLen <= sh * 0.18f * 0.02f) {
                pend = 0;
                pendAuto = false;
            }
        }
    }

    private void stepBob(float ex, float ey, float G, float hs) {
        if (grabbed) {
            vx += (900f * (grabX - bx) - 60f * vx) * hs;
            vy += (900f * (grabY - by) - 60f * vy) * hs;
        } else {
            vx += ex * G * hs;
            vy += ey * G * hs;
            float d = 1f - 0.35f * hs;
            vx *= d;
            vy *= d;
        }
        bx += vx * hs;
        by += vy * hs;
        float dx = bx - pivotX, dy = by - pivotY, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > restLen && len > 0.001f) {
            float ux = dx / len, uy = dy / len;
            float f = ROPE_K * (len - restLen) + ROPE_C * (vx * ux + vy * uy);  // an elastic rope pulls, never pushes
            if (f > 0f) {
                vx -= ux * f * hs;
                vy -= uy * f * hs;
            }
        }
    }

    // ---------- drawing: dial indicator ----------

    void drawIndicator(Canvas c, float fade, float sweep) {
        int col = pct <= 15 ? LOW : GOLD;
        int style = indicator;
        if (style == 1 || style == 4 || style == 5) {
            float a = 360f * pct / 100f * sweep, rr = rad * 1.035f;
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(rad * 0.022f);
            paint.setColor(withA(0xFFFFFF, (int) (40 * fade)));
            c.drawCircle(cx, cy, rr, paint);
            if (a > 0.5f) {
                paint.setStrokeWidth(rad * 0.075f);
                paint.setColor(withA(col, (int) (60 * fade)));
                c.drawArc(rect, -90f, a, false, paint);
                paint.setStrokeWidth(rad * 0.026f);
                paint.setColor(withA(col, (int) (255 * fade)));
                c.drawArc(rect, -90f, a, false, paint);
                if (charging) {
                    double th = Math.toRadians(a - 90f);
                    drawBolt(c, cx + (float) Math.cos(th) * rr, cy + (float) Math.sin(th) * rr, rad * 0.07f, fade);
                }
            }
        }
        if (style == 2) {
            int n = Math.round(pct * 0.6f * sweep);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(withA(col, (int) (235 * fade)));
            for (int i = 0; i < n && i < 60; i++) {
                boolean hr = i % 5 == 0;
                float rin = rad * (hr ? 0.80f : 0.90f), rout = rad * 0.94f;
                paint.setStrokeWidth(rad * (hr ? 0.05f : 0.03f));
                c.drawLine(cx + Renderer.COS[i] * rin, cy + Renderer.SIN[i] * rin,
                        cx + Renderer.COS[i] * rout, cy + Renderer.SIN[i] * rout, paint);
            }
        }
        if (style == 3 || style == 5) {
            float size = rad * 0.15f;
            text.setTextSize(size);
            text.setColor(withA(IVORY, (int) (215 * fade)));
            c.drawText(pctLabel, cx, cy + rad * 0.5f + size * 0.35f, text);
            if (charging) drawBolt(c, cx - text.measureText(pctLabel) / 2f - size * 0.7f, cy + rad * 0.5f, size * 0.5f, fade);
        }
    }

    private void drawBolt(Canvas c, float x, float y, float s, float fade) {
        c.save();
        c.translate(x, y);
        c.scale(s, s);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withA(IVORY, (int) (255 * fade)));
        c.drawPath(bolt, paint);
        c.restore();
    }

    // ---------- drawing: pendulum ----------

    void drawPendulum(Canvas c, long now) {
        if (pend == 0) return;
        float L = sh * 0.18f;
        float s = pend == 1 ? backOut(clamp((now - pendAt) / 350f, 0f, 1f)) : smooth(restLen / (L * 0.3f));
        if (s <= 0.01f) return;
        int col = colorFor(pct);

        float x = bx + parX * rad * 0.07f, y = by + parY * rad * 0.04f;   // the bob floats nearer than the wallpaper
        float dx = bx - pivotX, dy = by - pivotY, len = (float) Math.sqrt(dx * dx + dy * dy);
        float ux = len > 1f ? dx / len : 0f, uy = len > 1f ? dy / len : 1f;
        float ang = (float) Math.atan2(dx, dy);

        // Thread: it sags toward gravity while the rope is slack.
        float ax = x - ux * br * s, ay = y - uy * br * s;
        float sag = Math.max(0f, restLen - (float) Math.hypot(ax - pivotX, ay - pivotY)) * 0.55f;
        rope.rewind();
        rope.moveTo(pivotX, pivotY);
        rope.quadTo((pivotX + ax) / 2f + gdx * sag, (pivotY + ay) / 2f + gdy * sag, ax, ay);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1.6f, rad * 0.014f));
        paint.setColor(withA(IVORY, 215));
        c.drawPath(rope, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(INK);
        c.drawCircle(pivotX, pivotY, rad * 0.045f, paint);
        paint.setColor(GOLD);
        c.drawCircle(pivotX, pivotY, rad * 0.028f, paint);

        c.save();
        c.translate(x, y);
        c.rotate(-clamp((float) Math.toDegrees(ang) * 0.8f, -35f, 35f));
        c.scale(s, s);
        c.drawCircle(0f, 0f, br * 2.4f, bobGlow);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x44000000);
        c.drawCircle(-parX * br * 0.4f, -parY * br * 0.3f + br * 0.1f, br * 1.05f, paint);
        paint.setColor(INK);
        c.drawCircle(0f, 0f, br, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(br * 0.05f);
        paint.setColor(withA(GOLD, 210));
        c.drawCircle(0f, 0f, br * 0.955f, paint);
        c.drawCircle(0f, 0f, br * 0.86f, bobGlass);

        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 12; i++) {          // twelve ticks in the liquid colour: a tiny clock face
            boolean q = i % 3 == 0;
            int k = i * 5;
            float r1 = br * (q ? 0.62f : 0.68f), r2 = br * 0.78f;
            paint.setStrokeWidth(br * (q ? 0.07f : 0.04f));
            paint.setColor(withA(col, q ? 230 : 150));
            c.drawLine(Renderer.COS[k] * r1, Renderer.SIN[k] * r1, Renderer.COS[k] * r2, Renderer.SIN[k] * r2, paint);
        }

        float size = pctText.length() > 2 ? br * 0.66f : br * 0.92f;   // inside the glass: shifts a little with tilt
        text.setTextSize(size);
        text.setColor(pct <= 15 ? LOW : IVORY);
        c.drawText(pctText, -parX * br * 0.06f, -parY * br * 0.06f + size * 0.35f, text);

        c.save();
        c.translate(parX * br * 0.06f, parY * br * 0.06f);
        rect.set(-br * 0.72f, -br * 0.72f, br * 0.72f, br * 0.72f);
        paint.setStrokeWidth(br * 0.06f);
        paint.setColor(0x55FFFFFF);
        c.drawArc(rect, 200f, 50f, false, paint);
        c.restore();
        c.restore();
    }

    // ---------- drawing: flip ----------

    /** 3D turn about the vertical axis. Beyond 90 degrees the back is drawn, so it is not mirrored. */
    void applyFlip(Canvas c) {
        camera.save();
        camera.setLocation(0f, 0f, -Math.max(8f, rad * 0.0445f));
        camera.rotateY(angle <= 90f ? angle : angle - 180f);
        camera.getMatrix(fm);
        camera.restore();
        fm.preTranslate(-cx, -cy);
        fm.postTranslate(cx, cy);
        c.concat(fm);
    }

    /** The face darkens as it turns edge-on. */
    void drawShade(Canvas c) {
        float s = (float) Math.sin(Math.toRadians(clamp(angle, 0f, 180f)));
        if (s < 0.02f) return;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withA(0x000000, (int) (150 * s)));
        c.drawCircle(cx, cy, rad * scale, paint);
    }

    void drawBack(Canvas c, long now) {
        float R = rad * 0.915f;
        int col = colorFor(pct);
        c.save();
        c.scale(scale, scale, cx, cy);

        c.save();
        c.translate(cx, cy);
        c.drawCircle(0f, 0f, rad * 1.55f, halo);
        c.drawCircle(0f, 0f, R, tank);
        c.restore();

        float fill = fillAt < 0 ? 0f
                : (1f - (float) Math.pow(1f - clamp((now - fillAt) / (float) FILL_MS, 0f, 1f), 3.0)) * pct / 100f;
        if (fill > 0.003f) {
            clip.rewind();
            clip.addCircle(cx, cy, R, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            float lm = (float) Math.hypot(lgX, lgY);
            float ux = lm > 0.01f ? lgX / lm : 0f, uy = lm > 0.01f ? lgY / lm : 1f;
            c.translate(cx - parX * R * 0.035f, cy - parY * R * 0.035f);     // the liquid sits behind the glass
            c.rotate((float) Math.toDegrees(Math.atan2(-ux, uy)));           // local +y is always "down"
            drawLiquid(c, R, fill);
            c.restore();
        }

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(rad * 0.11f);
        paint.setColor(INK);
        c.drawCircle(cx, cy, rad * 0.945f, paint);
        paint.setStrokeWidth(rad * 0.012f);
        paint.setColor(withA(GOLD, 220));
        c.drawCircle(cx, cy, rad * 0.985f, paint);
        paint.setStrokeWidth(rad * 0.008f);
        paint.setColor(withA(col, 120));
        c.drawCircle(cx, cy, rad * 0.89f, paint);

        c.save();                                   // glass reflections move against the tilt
        c.translate(parX * rad * 0.05f, parY * rad * 0.05f);
        rect.set(cx - rad * 0.78f, cy - rad * 0.78f, cx + rad * 0.78f, cy + rad * 0.78f);
        paint.setStrokeWidth(rad * 0.05f);
        paint.setColor(0x55FFFFFF);
        c.drawArc(rect, 200f, 55f, false, paint);
        paint.setStrokeWidth(rad * 0.03f);
        paint.setColor(0x22FFFFFF);
        c.drawArc(rect, 20f, 35f, false, paint);
        c.restore();

        float p = glintAt < 0 ? 1f : (now - glintAt) / 900f;     // a glint crosses the glass after landing
        if (p >= 0f && p < 1f) {
            clip.rewind();
            clip.addCircle(cx, cy, rad * 0.9f, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            fm.setScale(rad * 0.0035f, 1f);
            fm.postRotate(20f);
            fm.postTranslate(cx + rad * (-1.2f + 2.4f * smooth(p)), cy);
            glint.setLocalMatrix(fm);
            glintPaint.setShader(glint);
            c.drawRect(cx - rad, cy - rad, cx + rad, cy + rad, glintPaint);
            c.restore();
        }
        c.restore();
    }

    private void drawLiquid(Canvas c, float R, float fill) {
        float h = fill >= 0.995f ? -R * 1.2f : solve(fill) * R;
        float amp = wave * R, x0 = -R * 1.1f, step = 2.2f * R / WAVE_N;
        liqPath.rewind();
        surfPath.rewind();
        for (int i = 0; i <= WAVE_N; i++) {
            float x = x0 + step * i;
            float y = h + amp * ((float) Math.sin(x / R * 3.1f + wavePhase)
                    + 0.5f * (float) Math.sin(x / R * 5.3f - wavePhase * 1.4f));
            if (i == 0) {
                liqPath.moveTo(x, y);
                surfPath.moveTo(x, y);
            } else {
                liqPath.lineTo(x, y);
                surfPath.lineTo(x, y);
            }
        }
        liqPath.lineTo(R * 1.1f, R * 1.2f);
        liqPath.lineTo(x0, R * 1.2f);
        liqPath.close();
        c.drawPath(liqPath, liquid);

        // Slow bubbles rise toward the surface and restart at the bottom of the tank.
        float hf = h / R;
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < BUBBLES; i++) {
            bY[i] -= bV[i] * dtLast;
            if (bY[i] < hf + 0.03f) {
                bX[i] = (rnd.nextFloat() - 0.5f) * 1.3f;
                bY[i] = (float) Math.sqrt(Math.max(0f, 1f - bX[i] * bX[i])) * 0.92f;
            }
            if (bY[i] > hf) {
                float wob = (float) Math.sin(wavePhase * 0.6f + i * 1.7f) * 0.02f;
                paint.setColor(0x66FFFFFF);
                c.drawCircle((bX[i] + wob) * R, bY[i] * R, bS[i] * R, paint);
            }
        }

        if (fill < 0.995f) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(R * 0.05f);
            paint.setColor(0x28FFFFFF);
            c.drawPath(surfPath, paint);
            paint.setStrokeWidth(R * 0.016f);
            paint.setColor(0x99FFFFFF);
            c.drawPath(surfPath, paint);
        }
    }

    /** Offset of the surface from the centre, in radii, so the liquid covers `f` of a unit disc. */
    private static float solve(float f) {
        float lo = -1f, hi = 1f, target = f * (float) Math.PI;
        for (int i = 0; i < 14; i++) {
            float mid = (lo + hi) / 2f;
            float area = (float) Math.acos(mid) - mid * (float) Math.sqrt(1f - mid * mid);
            if (area > target) lo = mid;
            else hi = mid;
        }
        return (lo + hi) / 2f;
    }

    // ---------- helpers ----------

    /** Coral when low, through orange and gold to mint and emerald when full. */
    static int colorFor(int pct) {
        int i = 0;
        while (i < 3 && pct > KEY_PCT[i + 1]) i++;
        return mix(KEY_COL[i], KEY_COL[i + 1], clamp((pct - KEY_PCT[i]) / (KEY_PCT[i + 1] - KEY_PCT[i]), 0f, 1f));
    }

    private static int mix(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * f);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * f);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int withA(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static float ease3(float x) {
        return x < 0.5f ? 4f * x * x * x : 1f - (float) Math.pow(-2f * x + 2f, 3.0) / 2f;
    }

    private static float backOut(float p) {
        float u = p - 1f;
        return 1f + 2.2f * u * u * u + 1.2f * u * u;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
