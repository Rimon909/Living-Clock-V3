package com.rimon.livingclock;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Random;

/**
 * Charging: the clock turns around slowly and mends itself, following the real order of a watch service.
 *
 *   inspect, clean (ultrasonic ripples lift the grime), mend (a chipped wheel regrows its teeth), oil (a drop
 *   forms on each jewel and spreads), regulate (the balance wheel goes from erratic to a steady beat and the
 *   train stops stalling), then the clock turns back to the front, polished, with the day's scratches gone.
 *
 * Progress follows the battery: it runs from the level at plug-in to 100%, with a time floor so something
 * always happens. Turning takes 4 s; the mending phase redraws about 30 times a second, one cached bitmap
 * for the static movement and about 120 cheap strokes for everything that moves.
 */
final class Repair {

    private static final int IDLE = 0, TURN_IN = 1, WORK = 2, TURN_OUT = 3, DONE = 4, ABORT = 5;
    private static final long IN_MS = 4200, OUT_MS = 3200, ABORT_MS = 1100, SHINE_AT = 2300, SHINE_MS = 1200;
    private static final int GOLD = 0xFFFFDC8A, IVORY = 0xFFFFF4E2, TEAL = 0xFF5EEAD4, AMBER = 0xFFFFC857;
    private static final int STEEL = 0xFFC9D1DB, RUST = 0xFF8A5A3A, PLATE = 0xFF262B34;
    private static final String[] STAGE = {"Inspecting", "Cleaning", "Mending", "Oiling", "Regulating"};

    // Gears, in units of the dial radius: x, y, pitch radius, teeth. Order is the drive order E -> C -> B -> A.
    private static final float[][] G = {
            {0.039f, 0.4595f, 0.095f, 12}, {0.225f, 0.352f, 0.12f, 14},
            {0.126f, 0.079f, 0.17f, 20}, {-0.30f, -0.12f, 0.30f, 36}};
    private static final float BX = 0.42f, BY = -0.32f, BR = 0.22f;

    boolean demo;

    private int state = IDLE, pct0 = 50, pct = 50;
    private long t0, last = -1L;
    private float ang, wear, shine = -1f, progress, tm, workSec, angFrom;
    private float r = -1f, gphase0;
    private final float[] phase = new float[4];

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Path[] gear = new Path[4];
    private Path chipped, spring, circle, wheel;
    private Bitmap back;
    private final RectF oval = new RectF();
    private final Matrix mx = new Matrix();
    private LinearGradient sheen;
    private final float[][] scratch = new float[18][4], blob = new float[14][3];
    private final float[][] dust = new float[24][3];
    private final float[] crack = new float[12];

    Repair() {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        Random rnd = new Random(6549);
        for (float[] s : scratch) {
            double a = rnd.nextDouble() * Math.PI * 2, d = Math.sqrt(rnd.nextDouble()) * 0.7;
            double len = 0.12 + rnd.nextDouble() * 0.45, dir = rnd.nextDouble() * Math.PI;
            s[0] = (float) (Math.cos(a) * d);
            s[1] = (float) (Math.sin(a) * d);
            s[2] = s[0] + (float) (Math.cos(dir) * len);
            s[3] = s[1] + (float) (Math.sin(dir) * len);
        }
        for (float[] b : blob) {
            double a = rnd.nextDouble() * Math.PI * 2, d = Math.sqrt(rnd.nextDouble()) * 0.75;
            b[0] = (float) (Math.cos(a) * d);
            b[1] = (float) (Math.sin(a) * d);
            b[2] = 0.05f + rnd.nextFloat() * 0.09f;
        }
        for (float[] d : dust) {
            d[0] = rnd.nextFloat() * 6.28f;
            d[1] = 0.1f + rnd.nextFloat() * 0.7f;
            d[2] = 0.3f + rnd.nextFloat();
        }
        crack[0] = 0.55f; crack[1] = -0.62f; crack[2] = 0.44f; crack[3] = -0.47f; crack[4] = 0.47f; crack[5] = -0.33f;
        crack[6] = 0.33f; crack[7] = -0.22f; crack[8] = 0.30f; crack[9] = -0.05f; crack[10] = 0.20f; crack[11] = 0.03f;
    }

    // ---------- control ----------

    void start(long now, int level, boolean instant) {
        pct0 = pct = level;
        workSec = 0f;
        last = -1L;
        t0 = now;
        wear = 1f;
        shine = -1f;
        if (instant) {
            state = WORK;
            ang = 180f;
        } else {
            state = TURN_IN;
            ang = 0f;
        }
    }

    /** Unplugged: turn back to the front quickly; the wear that is left fades as it turns. */
    void stop(long now) {
        if (state == IDLE) return;
        if (state == DONE) {
            state = IDLE;
            return;
        }
        angFrom = ang;
        t0 = now;
        state = ABORT;
        last = -1L;
    }

    void reset() {
        state = IDLE;
        ang = 0f;
        wear = 0f;
        shine = -1f;
        release();
    }

    boolean finished() {
        return state == IDLE;
    }

    boolean active() {
        return state != IDLE;
    }

    boolean working() {
        return state == WORK;
    }

    boolean moving(long now) {
        return state == TURN_IN || state == TURN_OUT || state == ABORT;
    }

    float angle() {
        return ang;
    }

    float wear() {
        return wear;
    }

    float shine() {
        return shine;
    }

    float lift() {
        return 1f - 0.07f * (float) Math.abs(Math.sin(Math.toRadians(ang)));
    }

    void update(long now, int level) {
        float dt = last < 0 ? 0f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        pct = level;
        tm += dt;
        if (state == WORK || state == TURN_IN || state == TURN_OUT) workSec += dt;
        float rt = workSec / (demo ? 30f : 90f);
        float rb = (demo || pct0 >= 98) ? 0f : clamp((pct - pct0) / (100f - pct0), 0f, 1f);
        boolean complete = (demo || pct0 >= 98) ? rt >= 1f : rb >= 0.999f;
        if (state != TURN_OUT && state != DONE) progress = Math.min(0.995f, Math.max(rb, 0.9f * rt));
        long el = now - t0;
        switch (state) {
            case TURN_IN: {
                float u = clamp(el / (float) IN_MS, 0f, 1f);
                ang = 180f * sine(u);
                wear = smooth(el / 700f);
                if (u >= 1f) state = WORK;
                break;
            }
            case WORK:
                ang = 180f;
                wear = 1f;
                if (complete) {
                    state = TURN_OUT;
                    t0 = now;
                }
                break;
            case TURN_OUT: {
                float u = clamp(el / (float) OUT_MS, 0f, 1f);
                ang = 180f + 180f * sine(u);
                wear = 0f;
                shine = clamp((el - SHINE_AT) / (float) SHINE_MS, 0f, 1f);
                if (u >= 1f && shine >= 1f) {
                    state = DONE;
                    ang = 0f;
                    shine = -1f;
                    progress = 1f;
                }
                break;
            }
            case DONE:
                ang = 0f;
                wear = 0f;
                break;
            case ABORT: {
                float u = clamp(el / (float) ABORT_MS, 0f, 1f);
                float target = angFrom <= 180f ? 0f : 360f;
                ang = angFrom + (target - angFrom) * sine(u);
                wear = (1f - progress) * (1f - smooth(u));
                if (u >= 1f) {
                    state = IDLE;
                    ang = 0f;
                    wear = 0f;
                }
                break;
            }
            default:
                break;
        }
    }

    void release() {
        if (back != null) {
            back.recycle();
            back = null;
        }
        r = -1f;
    }

    // ---------- the front: the day's wear, and the polish that removes it ----------

    void drawWear(Canvas c, float cx, float cy, float rad, float a) {
        if (a < 0.02f) return;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(((int) (34 * a) << 24) | 0xC9A24A);                  // a little patina over everything
        c.drawCircle(cx, cy, rad, paint);
        for (float[] b : blob) {                                            // smudges
            paint.setColor(((int) (26 * a) << 24) | 0xFFFFFF);
            c.drawCircle(cx + b[0] * rad, cy + b[1] * rad, b[2] * rad, paint);
            c.drawCircle(cx + b[0] * rad, cy + b[1] * rad, b[2] * rad * 0.6f, paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, rad * 0.006f));
        paint.setColor(((int) (95 * a) << 24) | 0xFFFFFF);
        for (float[] s : scratch) c.drawLine(cx + s[0] * rad, cy + s[1] * rad, cx + s[2] * rad, cy + s[3] * rad, paint);
        paint.setStrokeWidth(Math.max(1f, rad * 0.009f));                   // one hairline crack near the rim
        paint.setColor(((int) (150 * a) << 24) | 0x10131A);
        for (int i = 0; i < 10; i += 2) c.drawLine(cx + crack[i] * rad, cy + crack[i + 1] * rad, cx + crack[i + 2] * rad, cy + crack[i + 3] * rad, paint);
        paint.setStrokeWidth(Math.max(1f, rad * 0.003f));
        paint.setColor(((int) (170 * a) << 24) | 0xFFFFFF);
        for (int i = 0; i < 10; i += 2) c.drawLine(cx + crack[i] * rad + 1f, cy + crack[i + 1] * rad, cx + crack[i + 2] * rad + 1f, cy + crack[i + 3] * rad, paint);
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < dust.length; i++) {                             // dust specks
            paint.setColor(((int) (90 * a) << 24) | 0xE8E0D0);
            c.drawCircle(cx + (float) Math.cos(dust[i][0]) * dust[i][1] * rad, cy + (float) Math.sin(dust[i][0]) * dust[i][1] * rad, rad * 0.006f * dust[i][2], paint);
        }
    }

    /** A band of light sweeps across the polished glass, then a small star on the hub. */
    void drawShine(Canvas c, float cx, float cy, float rad, float p) {
        if (p < 0f || p >= 1f) return;
        if (circle == null || sheen == null) {
            circle = new Path();
            sheen = new LinearGradient(-100f, 0f, 100f, 0f, new int[]{0x00FFFFFF, 0x99FFF4E2, 0x00FFFFFF},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        }
        circle.rewind();
        circle.addCircle(cx, cy, rad, Path.Direction.CW);
        c.save();
        c.clipPath(circle);
        float e = smooth(p / 0.8f);
        mx.setScale(rad * 0.0036f, 1f);
        mx.postRotate(24f);
        mx.postTranslate(cx - rad * 1.3f + rad * 2.6f * e, cy);
        sheen.setLocalMatrix(mx);
        paint.setShader(sheen);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(255);
        c.drawRect(cx - rad * 1.5f, cy - rad * 1.5f, cx + rad * 1.5f, cy + rad * 1.5f, paint);
        paint.setShader(null);
        c.restore();
        float s = clamp((p - 0.7f) / 0.3f, 0f, 1f), k = (float) Math.sin(Math.PI * s);
        if (k > 0.02f) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(Math.max(1f, rad * 0.012f));
            paint.setColor(((int) (230 * k) << 24) | 0xFFFFFF);
            float L = rad * 0.16f * k;
            c.drawLine(cx - L, cy, cx + L, cy, paint);
            c.drawLine(cx, cy - L, cx, cy + L, paint);
        }
    }

    // ---------- the back: an open movement being serviced ----------

    private void build(float rad) {
        release();
        r = rad;
        int size = (int) Math.ceil(rad * 2.1f) + 4;
        back = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas k = new Canvas(back);
        float m = size / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF1B1F27);
        k.drawCircle(m, m, rad, paint);
        paint.setShader(new RadialGradient(m, m * 0.9f, rad * 0.9f, new int[]{0xFF3C4350, 0xFF1F242C}, null, Shader.TileMode.CLAMP));
        k.drawCircle(m, m, rad * 0.88f, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);                                 // perlage
        paint.setStrokeWidth(Math.max(1f, rad * 0.006f));
        paint.setColor(0x1CFFFFFF);
        float step = rad * 0.085f;
        for (float y = -rad * 0.85f; y <= rad * 0.85f; y += step) {
            for (float x = -rad * 0.85f; x <= rad * 0.85f; x += step) {
                if (x * x + y * y < rad * rad * 0.74f) k.drawCircle(m + x, m + y, step * 0.55f, paint);
            }
        }
        paint.setStrokeCap(Paint.Cap.ROUND);                                // two bridges
        oval.set(m - rad * 0.62f, m - rad * 0.62f, m + rad * 0.62f, m + rad * 0.62f);
        paint.setStrokeWidth(rad * 0.15f);
        paint.setColor(0xFF4A5362);
        k.drawArc(oval, 200f, 100f, false, paint);
        k.drawArc(oval, 20f, 70f, false, paint);
        paint.setStrokeWidth(rad * 0.012f);
        paint.setColor(0x66FFFFFF);
        oval.inset(rad * 0.06f, rad * 0.06f);
        k.drawArc(oval, 200f, 100f, false, paint);
        k.drawArc(oval, 20f, 70f, false, paint);
        paint.setStrokeWidth(rad * 0.05f);                                  // case ring with notches
        paint.setColor(0xFF9AA3AF);
        k.drawCircle(m, m, rad * 0.96f, paint);
        paint.setStrokeWidth(rad * 0.012f);
        paint.setColor(0xFF4B525E);
        for (int i = 0; i < 48; i++) {
            double a = i * Math.PI / 24;
            k.drawLine(m + (float) Math.cos(a) * rad * 0.93f, m + (float) Math.sin(a) * rad * 0.93f,
                    m + (float) Math.cos(a) * rad * 0.99f, m + (float) Math.sin(a) * rad * 0.99f, paint);
        }
        paint.setStyle(Paint.Style.FILL);                                   // screws
        float[][] sc = {{-0.55f, -0.55f}, {0.58f, 0.5f}, {-0.6f, 0.45f}, {0.1f, -0.74f}};
        for (float[] s : sc) {
            paint.setColor(0xFF8D96A3);
            k.drawCircle(m + s[0] * rad, m + s[1] * rad, rad * 0.04f, paint);
            paint.setColor(0xFF2A2F38);
            k.drawRect(m + s[0] * rad - rad * 0.032f, m + s[1] * rad - rad * 0.006f, m + s[0] * rad + rad * 0.032f, m + s[1] * rad + rad * 0.006f, paint);
        }
        // Gear paths, hairspring and balance wheel are built once and only rotated afterwards.
        for (int i = 0; i < 4; i++) gear[i] = gearPath(G[i][2] * rad, (int) G[i][3], 0);
        chipped = gearPath(G[1][2] * rad, (int) G[1][3], (1 << 3) | (1 << 9));
        spring = new Path();
        for (float a = 0f; a < 6.283f * 7f; a += 0.2f) {
            float rr = rad * (0.02f + 0.085f * a / (6.283f * 7f));
            if (a == 0f) spring.moveTo(rr, 0f);
            else spring.lineTo((float) Math.cos(a) * rr, (float) Math.sin(a) * rr);
        }
        wheel = new Path();
        wheel.addCircle(0f, 0f, rad * BR, Path.Direction.CW);
        // phases so the teeth of neighbours interlock: the drive gear E starts at 0.
        phase[0] = 0f;
        for (int i = 1; i < 4; i++) {
            float dx = (G[i][0] - G[i - 1][0]), dy = (G[i][1] - G[i - 1][1]);
            float th = (float) Math.toDegrees(Math.atan2(dy, dx));
            float ta = G[i - 1][3], tb = G[i][3];
            phase[i] = th + 180f - 180f / tb + (ta / tb) * (th - phase[i - 1]);
        }
        gphase0 = 0f;
    }

    private Path gearPath(float rr, int teeth, int skip) {
        Path p = new Path();
        float pitch = (float) (2 * Math.PI * rr / teeth), add = pitch * 0.34f, ded = pitch * 0.40f;
        float ro = rr + add, rd = rr - ded;
        double da = 2 * Math.PI / teeth;
        boolean first = true;
        for (int i = 0; i < teeth; i++) {
            double a = i * da;
            float tip = ((skip >> i) & 1) != 0 ? rd * 1.02f : ro;
            double[] ang = {a - da * 0.28, a - da * 0.15, a + da * 0.15, a + da * 0.28};
            float[] rs = {rd, tip, tip, rd};
            for (int k = 0; k < 4; k++) {
                float x = (float) Math.cos(ang[k]) * rs[k], y = (float) Math.sin(ang[k]) * rs[k];
                if (first) {
                    p.moveTo(x, y);
                    first = false;
                } else {
                    p.lineTo(x, y);
                }
            }
        }
        p.close();
        p.addCircle(0f, 0f, rd * (teeth > 30 ? 0.80f : 0.45f), Path.Direction.CCW);   // hole: ring wheel or hub
        p.setFillType(Path.FillType.EVEN_ODD);
        return p;
    }

    void drawBack(Canvas c, float cx, float cy, float rad) {
        if (back == null || Math.abs(r - rad) > 0.5f) build(rad);
        c.drawBitmap(back, cx - back.getWidth() / 2f, cy - back.getHeight() / 2f, bmp);

        float p = progress;
        float clean = smooth((p - 0.08f) / 0.30f), mend = smooth((p - 0.36f) / 0.18f);
        float reg = smooth((p - 0.60f) / 0.35f);
        int stage = p < 0.08f ? 0 : p < 0.38f ? 1 : p < 0.56f ? 2 : p < 0.76f ? 3 : 4;
        int body = mixc(RUST, STEEL, clean);

        // The train: the escape wheel steps and drives everything; early on it stalls and jolts.
        float period = 4.2f, dur = 0.8f * (1f - reg);
        float rem = tm % period, stalled = (float) Math.floor(tm / period) * dur + clamp(rem - (period - dur), 0f, dur);
        float ticks = 1.6f * (tm - stalled), ti = (float) Math.floor(ticks);
        float q = ti + smooth(Math.min(1f, (ticks - ti) * 3.5f));
        float aE = q * 30f;
        for (int i = 0; i < 4; i++) {
            float ratio = G[0][3] / G[i][3];
            float a = (i % 2 == 0 ? 1f : -1f) * aE * ratio + phase[i];
            c.save();
            c.translate(cx + G[i][0] * rad, cy + G[i][1] * rad);
            c.rotate(a);
            paint.setStyle(Paint.Style.FILL);
            if (i == 1) {                                                   // the chipped wheel regrows its teeth
                paint.setColor(withA(body, (int) (255 * (1f - mend))));
                c.drawPath(chipped, paint);
                paint.setColor(withA(body, (int) (255 * mend)));
                c.drawPath(gear[1], paint);
            } else {
                paint.setColor(body);
                c.drawPath(gear[i], paint);
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, rad * 0.012f));
            paint.setColor(0x55FFFFFF);
            c.drawPath(gear[i], paint);
            if (i == 3) {                                                   // the mainspring inside the barrel
                paint.setStrokeWidth(rad * 0.008f);
                paint.setColor(withA(GOLD, 200));
                c.save();
                c.scale(2.2f, 2.2f);
                c.drawPath(spring, paint);
                c.restore();
            } else {
                paint.setStrokeWidth(G[i][2] * rad * 0.16f);
                paint.setColor(body);
                for (int s = 0; s < 4; s++) {
                    double sa = s * Math.PI / 2;
                    c.drawLine(0f, 0f, (float) Math.cos(sa) * G[i][2] * rad * 0.7f, (float) Math.sin(sa) * G[i][2] * rad * 0.7f, paint);
                }
            }
            c.restore();
        }

        // The balance wheel: erratic and weak at first, then a steady beat.
        float amp = 60f + 170f * reg, f = 1.25f;
        float tt = tm + (1f - reg) * 0.12f * (float) Math.sin(tm * 2.1);
        float bal = amp * (1f + (1f - reg) * 0.35f * (float) Math.sin(tm * 3.7)) * (float) Math.sin(2 * Math.PI * f * tt);
        c.save();
        c.translate(cx + BX * rad, cy + BY * rad);
        c.rotate(bal);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(rad * 0.04f);
        paint.setColor(mixc(0xFF9A7B4F, GOLD, clean));
        c.drawPath(wheel, paint);
        paint.setStrokeWidth(rad * 0.025f);
        for (int s = 0; s < 3; s++) {
            double sa = s * Math.PI * 2 / 3;
            c.drawLine(0f, 0f, (float) Math.cos(sa) * rad * BR, (float) Math.sin(sa) * rad * BR, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        for (int s = 0; s < 4; s++) {
            double sa = s * Math.PI / 2 + 0.4;
            c.drawCircle((float) Math.cos(sa) * rad * BR, (float) Math.sin(sa) * rad * BR, rad * 0.03f, paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(rad * 0.004f);
        paint.setColor(0xCCB7C0CC);
        float br = 1f + 0.08f * (float) Math.sin(Math.toRadians(bal));
        c.scale(br, br);
        c.drawPath(spring, paint);
        c.restore();

        // Grime lifts while it is cleaned: blobs shrink, dust drifts away, ripples spread from the centre.
        float grime = 1f - clean;
        if (grime > 0.02f) {
            paint.setStyle(Paint.Style.FILL);
            for (float[] b : blob) {
                paint.setColor(withA(0xFF3A2A1A, (int) (110 * grime)));
                c.drawCircle(cx + b[0] * rad, cy + b[1] * rad, b[2] * rad * (0.35f + 0.65f * grime), paint);
            }
            for (float[] d : dust) {
                float a = d[0] + tm * 0.2f * d[2], dd = d[1] + clean * 0.5f;
                paint.setColor(withA(0xFFD8CBB0, (int) (120 * grime)));
                c.drawCircle(cx + (float) Math.cos(a) * dd * rad, cy + (float) Math.sin(a) * dd * rad, rad * 0.008f * d[2], paint);
            }
        }
        if (p > 0.08f && p < 0.42f) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(rad * 0.012f);
            for (int k = 0; k < 3; k++) {
                float ph = (tm / 1.6f + k / 3f) % 1f;
                paint.setColor(withA(TEAL, (int) (70 * (1f - ph))));
                c.drawCircle(cx, cy, rad * 0.88f * ph, paint);
            }
        }
        // Mending sparks at the two chipped teeth of wheel C, following its turn.
        if (mend > 0.02f && mend < 0.98f) {
            float aC = -aE * (G[0][3] / G[1][3]) + phase[1];
            for (int s = 0; s < 2; s++) {
                double a = Math.toRadians(aC + (s == 0 ? 3 : 9) * 360f / G[1][3]);
                float fl = 0.5f + 0.5f * (float) Math.sin(tm * 19f + s * 2f);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(withA(0xFFFFFFFF, (int) (255 * fl)));
                c.drawCircle(cx + (G[1][0] + (float) Math.cos(a) * G[1][2]) * rad, cy + (G[1][1] + (float) Math.sin(a) * G[1][2]) * rad, rad * 0.014f * (1f + fl), paint);
            }
        }
        // Oil: a drop grows on each jewel and spreads; afterwards the ruby just glints.
        float[][] jw = {{G[0][0], G[0][1]}, {G[1][0], G[1][1]}, {BX, BY}};
        for (int j = 0; j < 3; j++) {
            float jx = cx + jw[j][0] * rad, jy = cy + jw[j][1] * rad;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(p > 0.5f ? 0xFFD0384A : 0xFF6A3A40);
            c.drawCircle(jx, jy, rad * 0.024f, paint);
            if (p > 0.5f && p < 0.86f) {
                float ph = (tm * 0.5f + j * 0.33f) % 1f;
                if (ph < 0.4f) {
                    paint.setColor(withA(AMBER, 230));
                    c.drawCircle(jx, jy - rad * 0.03f * (1f - ph * 2.5f), rad * 0.03f * Math.min(1f, ph * 3f), paint);
                } else {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(rad * 0.01f);
                    paint.setColor(withA(AMBER, (int) (160 * (1f - ph))));
                    c.drawCircle(jx, jy, rad * (0.03f + 0.07f * (ph - 0.4f) / 0.6f), paint);
                }
            } else if (p >= 0.86f) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(withA(0xFFFFFFFF, (int) (200 * (0.5f + 0.5f * Math.sin(tm * 2f + j)))));
                c.drawCircle(jx - rad * 0.007f, jy - rad * 0.007f, rad * 0.006f, paint);
            }
        }
        // Three golden motes patrol the train while it is repaired, with short tails.
        if (p < 0.9f) {
            paint.setStyle(Paint.Style.FILL);
            for (int m = 0; m < 3; m++) {
                int g = (m + (int) (tm / 3f)) % 4;
                for (int tail = 0; tail < 4; tail++) {
                    float a = tm * 1.6f + m * 2.1f - tail * 0.18f;
                    paint.setColor(withA(GOLD, (int) (230 / (1f + tail * 1.4f))));
                    c.drawCircle(cx + (G[g][0] + (float) Math.cos(a) * (G[g][2] + 0.02f)) * rad,
                            cy + (G[g][1] + (float) Math.sin(a) * (G[g][2] + 0.02f)) * rad, rad * 0.012f * (1f - tail * 0.18f), paint);
                }
            }
        }
        // Progress along the case ring, and the name of the step in hand.
        oval.set(cx - rad * 0.96f, cy - rad * 0.96f, cx + rad * 0.96f, cy + rad * 0.96f);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        int pc = mixc(GOLD, TEAL, p);
        paint.setStrokeWidth(rad * 0.07f);
        paint.setColor(withA(pc, 60));
        c.drawArc(oval, -90f, 360f * p, false, paint);
        paint.setStrokeWidth(rad * 0.022f);
        paint.setColor(withA(pc, 235));
        c.drawArc(oval, -90f, 360f * p, false, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(rad * 0.085f);
        paint.setColor(withA(IVORY, 170));
        c.drawText(STAGE[stage], cx, cy + rad * 0.78f, paint);
        // A slow glint across the window every few seconds.
        float gs = (tm % 7f) / 1.4f;
        if (gs < 1f) drawShine(c, cx, cy, rad * 0.9f, gs * 0.8f);
    }

    // ---------- helpers ----------

    private static int mixc(int a, int b, float f) {
        f = clamp(f, 0f, 1f);
        int r = (int) (((a >> 16) & 255) * (1f - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1f - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1f - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int withA(int color, int a) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static float sine(float p) {
        return 0.5f - 0.5f * (float) Math.cos(Math.PI * clamp(p, 0f, 1f));
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
