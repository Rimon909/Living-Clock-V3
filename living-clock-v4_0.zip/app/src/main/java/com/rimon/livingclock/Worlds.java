package com.rimon.livingclock;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Random;

/**
 * Five universes, themes 5 to 9, after Noir. Entering one is slow and layered: the wallpaper darkens into its
 * own environment (parallax layers, drifting light, weather), the old clock dissolves and the new one builds
 * itself in its own way. Leaving the last one hands back to the classic glass clock while the world fades out.
 *
 *   5 Nebula Atlas    armillary rings and star hours over violet nebulae and three layers of stars
 *   6 Abyss           a nautilus spiral that draws itself, tendril hands, god-rays, bubbles, jellyfish
 *   7 Ember Glass     an obsidian hexagon whose shards fly in, molten blades, lava glow and rising embers
 *   8 Neon Meridian   a neon squircle with a digital readout, a synthwave horizon, a grid floor and rain
 *   9 Event Horizon   a black hole with an accretion disc and hands bent by gravity, lensed stars, infall
 *
 * Cost: the environment is one gradient, a few big soft shapes and a handful of batched point/line draws.
 * Ambient motion runs at about 24 frames a second (12 on a low battery), the transitions follow the display.
 * The static art of each clock is drawn once into the cached dial; only what moves is drawn per frame.
 */
final class Worlds {

    static final int FIRST = 5, N = 5;
    static final long BUILD_MS = 3800, EXIT_MS = 3000;
    static final String[] NAMES = {"Nebula Atlas", "Abyss", "Ember Glass", "Neon Meridian", "Event Horizon"};

    private static final int[] LOOK = {6, 8, 5, 7, 5};                   // the band pattern each world borrows
    private static final int[] TINT = {0xFF7A5CFF, 0xFF2AD1C9, 0xFFFF6A2A, 0xFFFF3DCB, 0xFFFFB347};
    private static final float TAU = 6.2831855f;
    private static final int IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A, LAV = 0xFFB9A6FF, PINK = 0xFFFF7AD9, CYAN = 0xFF5CF2E6;
    private static final int VIOLET = 0xFFA78BFA, WARM = 0xFFFFC857, LAVA = 0xFFFF6A1F, HOT = 0xFFFFD9A0, MAG = 0xFFFF2FC8;

    static boolean is(int th) {
        return th >= FIRST;
    }

    static int look(int th) {
        return LOOK[th - FIRST];
    }

    // ---------- state ----------

    private final float[] a = new float[N];
    private long last = -1L;
    private int w, h;
    private float cx, cy, r, u;                           // u: one unit of line width, scaled to the screen
    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG), gp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path(), tmp = new Path(), spiral = new Path(), squircle = new Path(), cracks = new Path();
    private final RectF rc = new RectF();
    private final PathMeasure pmS = new PathMeasure(), pmQ = new PathMeasure();
    private final LinearGradient[] base = new LinearGradient[N];
    private final RadialGradient[] cloud = new RadialGradient[4];
    private RadialGradient planet, glowLava, smoke, vignette, ringGlow, hole;
    private LinearGradient shaft, floor, sun;
    private final float[][] st = new float[3][];
    private final float[] emb = new float[48 * 4], embPos = new float[96], ash = new float[60], rain = new float[44 * 3], rainL = new float[44 * 4];
    private final float[] bub = new float[16 * 4], bld = new float[18 * 3], win = new float[160], grid = new float[22 * 4];
    private final float[] fall = new float[40 * 4], lens = new float[70 * 4], tk = new float[240], pl = new float[96];
    private float ox, oy;                                  // result of the point helpers

    Worlds() {
        pt.setStrokeCap(Paint.Cap.ROUND);
        pt.setStrokeJoin(Paint.Join.ROUND);
    }

    /** Moves each world's presence toward its target (slowly in, a little quicker out). True while any is moving. */
    boolean step(int theme, long now) {
        float dt = last < 0 ? 0f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        boolean moving = false;
        for (int i = 0; i < N; i++) {
            float target = theme == FIRST + i ? 1f : 0f;
            float rate = dt / (target > a[i] ? BUILD_MS / 1000f : EXIT_MS / 1000f);
            if (a[i] != target) {
                a[i] += Math.max(-rate, Math.min(rate, target - a[i]));
                moving |= a[i] != target;
            }
        }
        return moving;
    }

    /** Skips the animation (first read, kill switch). */
    void snap(int theme) {
        for (int i = 0; i < N; i++) a[i] = theme == FIRST + i ? 1f : 0f;
    }

    boolean active() {
        for (int i = 0; i < N; i++) if (a[i] > 0.003f) return true;
        return false;
    }

    /** Strongest world and how present it is, for tinting the cut-out subject to match. */
    int tintColor() {
        int best = 0;
        for (int i = 1; i < N; i++) if (a[i] > a[best]) best = i;
        float e = smooth(a[best]);
        return e < 0.02f ? 0 : (TINT[best] & 0x00FFFFFF) | (((int) (e * 40f)) << 24);
    }

    // ---------- layout ----------

    /** Cheap when only the clock moved: the gradients and random layers depend on the size alone. */
    void layout(int width, int height, float clockX, float clockY, float radius) {
        boolean same = width == w && height == h && radius == r && base[0] != null;
        w = width;
        h = height;
        cx = clockX;
        cy = clockY;
        r = radius;
        u = width / 1080f;
        if (!same) buildLayers();
        buildPaths();
    }

    private void buildLayers() {
        Random rnd = new Random(5);
        int[] cnt = {90, 60, 36};
        for (int l = 0; l < 3; l++) {
            st[l] = new float[cnt[l] * 2];
            for (int i = 0; i < cnt[l]; i++) {
                st[l][2 * i] = rnd.nextFloat() * w;
                st[l][2 * i + 1] = rnd.nextFloat() * h;
            }
        }
        Shader.TileMode cl = Shader.TileMode.CLAMP;
        float[] f2 = {0f, 1f}, f3 = {0f, 0.55f, 1f};
        base[0] = new LinearGradient(0, 0, 0, h, new int[]{0xF0070416, 0xF01C0A40, 0xF0331256}, f3, cl);
        base[1] = new LinearGradient(0, 0, 0, h, new int[]{0xF0053142, 0xF0021C2A, 0xF0010910}, f3, cl);
        base[2] = new LinearGradient(0, 0, 0, h, new int[]{0xF00A0405, 0xF0160606, 0xF0420C06}, f3, cl);
        base[3] = new LinearGradient(0, 0, 0, h, new int[]{0xF008051A, 0xF01A0A38, 0xF03A0F4A}, f3, cl);
        base[4] = new LinearGradient(0, 0, 0, h, new int[]{0xF0000003, 0xF0020208, 0xF0050310}, f3, cl);
        int[] cc = {0x66FF4FD8, 0x5560A5FF, 0x55A07BFF, 0x44FFB36B};
        for (int k = 0; k < 4; k++) cloud[k] = new RadialGradient(0f, 0f, w * 0.7f, new int[]{cc[k], cc[k] & 0x00FFFFFF}, f2, cl);
        planet = new RadialGradient(0f, 0f, w * 0.09f, new int[]{0xFFFFD9A8, 0xFFB86A8A, 0xFF3A1B5C}, f3, cl);
        shaft = new LinearGradient(0, 0, 0, h * 0.85f, new int[]{0x40CFF8FF, 0x00CFF8FF}, f2, cl);
        glowLava = new RadialGradient(0f, 0f, h * 0.6f, new int[]{0xCCFF5A14, 0x55B02808, 0x00500800}, f3, cl);
        smoke = new RadialGradient(0f, 0f, w * 0.3f, new int[]{0x55402020, 0x00402020}, f2, cl);
        float sy = h * 0.60f;
        sun = new LinearGradient(0, sy - w * 0.30f, 0, sy, new int[]{0xFFFFE066, 0xFFFF4FA3, 0xFF9B2CFF}, f3, cl);
        floor = new LinearGradient(0, sy, 0, h, new int[]{0xE02A0B4A, 0xE00B0420}, f2, cl);
        vignette = new RadialGradient(0f, 0f, Math.max(w, h) * 0.75f, new int[]{0x00000000, 0x00000000, 0xCC000000}, f3, cl);
        ringGlow = new RadialGradient(0f, 0f, r * 1.7f, new int[]{0x00000000, 0x40FFB347, 0x00000000}, new float[]{0.55f, 0.72f, 1f}, cl);
        hole = new RadialGradient(0f, 0f, r * 0.7f, new int[]{0xFF000000, 0xFF000000, 0x00000000}, new float[]{0f, 0.8f, 1f}, cl);

        for (int i = 0; i < 48; i++) {                    // embers: x, speed, phase, size class
            emb[4 * i] = rnd.nextFloat() * w;
            emb[4 * i + 1] = 30f + rnd.nextFloat() * 60f;
            emb[4 * i + 2] = rnd.nextFloat() * h;
            emb[4 * i + 3] = rnd.nextFloat() * 6.28f;
        }
        for (int i = 0; i < ash.length / 3; i++) {
            ash[3 * i] = rnd.nextFloat() * w;
            ash[3 * i + 1] = 8f + rnd.nextFloat() * 14f;
            ash[3 * i + 2] = rnd.nextFloat() * h;
        }
        for (int i = 0; i < 44; i++) {
            rain[3 * i] = rnd.nextFloat() * w;
            rain[3 * i + 1] = 500f + rnd.nextFloat() * 500f;
            rain[3 * i + 2] = rnd.nextFloat() * h;
        }
        for (int i = 0; i < 16; i++) {
            bub[4 * i] = rnd.nextFloat() * w;
            bub[4 * i + 1] = 40f + rnd.nextFloat() * 70f;
            bub[4 * i + 2] = rnd.nextFloat() * h;
            bub[4 * i + 3] = 3f + rnd.nextFloat() * 7f;
        }
        float x = -20f;
        for (int i = 0; i < 18; i++) {                    // skyline: x, width, height
            float bw = w * (0.04f + rnd.nextFloat() * 0.07f);
            bld[3 * i] = x;
            bld[3 * i + 1] = bw;
            bld[3 * i + 2] = h * (0.07f + rnd.nextFloat() * 0.17f);
            x += bw * (0.7f + rnd.nextFloat() * 0.5f);
        }
        for (int i = 0; i < win.length / 2; i++) {
            int b = rnd.nextInt(18);
            win[2 * i] = bld[3 * b] + 6f + rnd.nextFloat() * Math.max(2f, bld[3 * b + 1] - 12f);
            win[2 * i + 1] = h * 0.60f - 8f - rnd.nextFloat() * Math.max(2f, bld[3 * b + 2] - 16f);
        }
        for (int i = 0; i < 40; i++) {                    // infall: phase, speed, angle, start radius
            fall[4 * i] = rnd.nextFloat();
            fall[4 * i + 1] = 0.03f + rnd.nextFloat() * 0.04f;
            fall[4 * i + 2] = rnd.nextFloat() * TAU;
            fall[4 * i + 3] = 0.6f + rnd.nextFloat() * 1.6f;
        }
        for (int i = 0; i < 70; i++) {                    // lensed stars: angle, ring radius (in r), twinkle
            lens[4 * i] = rnd.nextFloat() * TAU;
            lens[4 * i + 1] = 1.5f + rnd.nextFloat() * 3.2f;
            lens[4 * i + 2] = rnd.nextFloat() * 6f;
        }
        cracks.rewind();                                   // lava cracks: random walks in the lower half
        for (int k = 0; k < 9; k++) {
            float px = rnd.nextFloat() * w, py = h * (0.98f - rnd.nextFloat() * 0.1f);
            cracks.moveTo(px, py);
            for (int s = 0; s < 9; s++) {
                px += (rnd.nextFloat() - 0.5f) * w * 0.16f;
                py -= rnd.nextFloat() * h * 0.06f;
                if (py < h * 0.52f) break;
                cracks.lineTo(px, py);
            }
        }
    }

    private void buildPaths() {
        spiral.rewind();                                   // the nautilus: a logarithmic spiral, 2.2 turns
        for (float t = 0f; t <= 13.8f; t += 0.1f) {
            float rho = r * 0.085f * (float) Math.exp(0.171f * t);
            float sx = cx + (float) Math.sin(t) * rho, sy2 = cy - (float) Math.cos(t) * rho;
            if (t == 0f) spiral.moveTo(sx, sy2);
            else spiral.lineTo(sx, sy2);
        }
        pmS.setPath(spiral, false);
        squircle.rewind();                                 // the squircle frame, |x|^4 + |y|^4 = S^4
        for (int i = 0; i <= 96; i++) {
            sqPoint(i * TAU / 96f, 0.86f);
            if (i == 0) squircle.moveTo(ox, oy);
            else squircle.lineTo(ox, oy);
        }
        squircle.close();
        pmQ.setPath(squircle, true);
    }

    // ---------- helpers ----------

    private static float smooth(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        return x * x * (3f - 2f * x);
    }

    private static float seg(float b, float from, float to) {
        return smooth((b - from) / (to - from));
    }

    private static float outBack(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        float v = x - 1f;
        return 1f + 2.7f * v * v * v + 1.7f * v * v;
    }

    private static float sn(double td, double period, double phase) {
        return (float) Math.sin(td * TAU / period + phase);
    }

    private static float drift(double td, double speed, float mod) {
        float v = (float) ((td * speed) % mod);
        return v < 0f ? v + mod : v;
    }

    private static int al(int color, float f) {
        int v = (int) ((color >>> 24) * (f < 0f ? 0f : (f > 1f ? 1f : f)));
        return (color & 0x00FFFFFF) | (v << 24);
    }

    private float hx(float cxx, float rr, float deg) {
        return cxx + (float) Math.sin(Math.toRadians(deg)) * rr;
    }

    private float hy(float cyy, float rr, float deg) {
        return cyy - (float) Math.cos(Math.toRadians(deg)) * rr;
    }

    private void sqPoint(float theta, float size) {
        float s = (float) Math.abs(Math.sin(theta)), c = (float) Math.abs(Math.cos(theta));
        float k = size * r / (float) Math.pow(s * s * s * s + c * c * c * c, 0.25);
        ox = cx + (float) Math.sin(theta) * k;
        oy = cy - (float) Math.cos(theta) * k;
    }

    private float hexR(float deg) {                        // distance from the centre to the hexagon edge at this angle
        float d = ((deg - 30f) % 60f + 60f) % 60f - 30f;
        return 0.95f * r * 0.8660254f / (float) Math.cos(Math.toRadians(d));
    }

    private void star4(Canvas c, float x, float y, float s, int col, float alpha) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, s * 0.14f));
        pt.setColor(al(col, alpha));
        c.drawLine(x - s, y, x + s, y, pt);
        c.drawLine(x, y - s, x, y + s, pt);
        pt.setStrokeWidth(Math.max(1f, s * 0.08f));
        c.drawLine(x - s * 0.5f, y - s * 0.5f, x + s * 0.5f, y + s * 0.5f, pt);
        c.drawLine(x - s * 0.5f, y + s * 0.5f, x + s * 0.5f, y - s * 0.5f, pt);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawCircle(x, y, s * 0.16f, pt);
    }

    private void starLayer(Canvas c, double td, int layer, float speed, float width, int col, float alpha, float period) {
        float dx = drift(td, speed * u, w);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(width * u);
        pt.setColor(al(col, alpha * (0.65f + 0.35f * sn(td, period, layer * 2.1))));
        c.save();
        c.translate(dx, 0f);
        c.drawPoints(st[layer], 0, st[layer].length, pt);
        c.translate(-w, 0f);
        c.drawPoints(st[layer], 0, st[layer].length, pt);
        c.restore();
    }

    private void blob(Canvas c, RadialGradient g, float x, float y, float rad, float alpha) {
        gp.setStyle(Paint.Style.FILL);
        gp.setShader(g);
        gp.setAlpha((int) (255 * alpha));
        c.save();
        c.translate(x, y);
        c.drawCircle(0f, 0f, rad, gp);
        c.restore();
        gp.setShader(null);
        gp.setAlpha(255);
    }

    // ---------- the environment, drawn over the photo and under the clock ----------

    void env(Canvas c, long now) {
        double td = now / 1000.0;
        for (int i = 0; i < N; i++) {
            if (a[i] < 0.004f) continue;
            float e = smooth(a[i]);
            gp.setStyle(Paint.Style.FILL);
            gp.setShader(base[i]);
            gp.setAlpha((int) (255 * e));
            c.drawRect(0f, 0f, w, h, gp);
            gp.setShader(null);
            gp.setAlpha(255);
            if (i == 0) nebulaEnv(c, td, e);
            else if (i == 1) abyssEnv(c, td, e);
            else if (i == 2) emberEnv(c, td, e);
            else if (i == 3) neonEnv(c, td, e);
            else horizonEnv(c, td, e);
            blob(c, vignette, w / 2f, h / 2f, Math.max(w, h), 0.55f * e);
        }
    }

    private void nebulaEnv(Canvas c, double td, float e) {
        for (int k = 0; k < 4; k++) {
            float x = w * 0.5f + w * 0.35f * sn(td, 90 + k * 17, k * 1.9);
            float y = h * (0.22f + 0.2f * k) + h * 0.05f * sn(td, 60 + k * 11, k);
            blob(c, cloud[k], x, y, w * 0.7f, e * 0.85f);
        }
        starLayer(c, td, 0, 1.5f, 1.4f, 0xFFB9A6FF, 0.7f * e, 7f);
        starLayer(c, td, 1, 4f, 2.0f, 0xFFFFFFFF, 0.8f * e, 5f);
        starLayer(c, td, 2, 9f, 3.0f, 0xFFFFE9B0, 0.9f * e, 3.5f);
        float px = w * 0.80f, py = h * 0.15f + 6f * u * sn(td, 40, 0);       // a ringed planet far away
        blob(c, planet, px, py, w * 0.09f, e);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(4f * u);
        pt.setColor(al(0xB0FFE9C8, e));
        c.save();
        c.translate(px, py);
        c.rotate(-18f);
        rc.set(-w * 0.17f, -w * 0.035f, w * 0.17f, w * 0.035f);
        c.drawOval(rc, pt);
        c.restore();
        float s = (float) ((td % 11.0) / 1.2);                                // a shooting star every eleven seconds
        if (s < 1f) {
            float x0 = w * (0.1f + 0.5f * (float) ((Math.floor(td / 11.0) * 0.37) % 1.0)), y0 = h * 0.08f;
            pt.setStrokeWidth(2.5f * u);
            pt.setColor(al(0xFFFFFFFF, e * (1f - s)));
            c.drawLine(x0 + s * w * 0.4f, y0 + s * h * 0.14f, x0 + s * w * 0.4f - w * 0.1f, y0 + s * h * 0.14f - h * 0.03f, pt);
        }
    }

    private void abyssEnv(Canvas c, double td, float e) {
        gp.setStyle(Paint.Style.FILL);
        gp.setShader(shaft);
        for (int k = 0; k < 4; k++) {                                         // god-rays swaying from the surface
            float xt = w * (0.12f + 0.25f * k), sway = w * 0.06f * sn(td, 16 + k * 3, k * 1.3);
            path.rewind();
            path.moveTo(xt - w * 0.03f, 0f);
            path.lineTo(xt + w * 0.03f, 0f);
            path.lineTo(xt + w * 0.16f + sway, h * 0.85f);
            path.lineTo(xt - w * 0.10f + sway, h * 0.85f);
            path.close();
            gp.setAlpha((int) (255 * e * (0.5f + 0.5f * sn(td, 11 + k * 2, k))));
            c.drawPath(path, gp);
        }
        gp.setShader(null);
        gp.setAlpha(255);
        starLayer(c, td, 0, -3f, 1.6f, 0xFF9FF3E8, 0.5f * e, 6f);             // plankton drifting sideways
        starLayer(c, td, 2, 7f, 3.0f, 0xFF5CF2E6, 0.55f * e, 4f);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(1.6f * u);
        for (int i = 0; i < 16; i++) {                                        // bubbles
            float y = h - drift(td + bub[4 * i + 2], bub[4 * i + 1] * u, h + 80f) + 20f;
            float x = bub[4 * i] + 14f * u * sn(td, 5 + i * 0.37, i);
            pt.setColor(al(0xFFBFFBFF, e * 0.35f));
            c.drawCircle(x, y, bub[4 * i + 3] * u, pt);
        }
        for (int k = 0; k < 2; k++) {                                         // two jellyfish, far and slow
            float jx = w * (0.22f + 0.55f * k) + w * 0.05f * sn(td, 23 + k * 7, k), jy = h * (0.36f + 0.2f * k) + h * 0.03f * sn(td, 9, k * 2);
            float js = w * (0.07f + 0.02f * k), pulse = 1f + 0.08f * sn(td, 3.2, k);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFF5CF2E6, e * 0.14f));
            rc.set(jx - js * pulse, jy - js * 0.8f, jx + js * pulse, jy + js * 0.8f);
            c.drawArc(rc, 180f, 180f, true, pt);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(2f * u);
            pt.setColor(al(0xFFA78BFA, e * 0.5f));
            c.drawArc(rc, 180f, 180f, false, pt);
            for (int t = 0; t < 5; t++) {
                float tx = jx + (t - 2) * js * 0.4f;
                path.rewind();
                path.moveTo(tx, jy);
                path.quadTo(tx + js * 0.25f * sn(td, 2.6, t + k), jy + js * 0.9f, tx - js * 0.1f * sn(td, 3.1, t), jy + js * 1.8f);
                c.drawPath(path, pt);
            }
        }
    }

    private void emberEnv(Canvas c, double td, float e) {
        float pulse = 0.75f + 0.25f * sn(td, 5, 0);
        blob(c, glowLava, w / 2f, h * 1.02f, h * 0.6f, e * pulse);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(5f * u);
        pt.setColor(al(0x55FF5A14, e * pulse));
        c.drawPath(cracks, pt);
        pt.setStrokeWidth(1.8f * u);
        pt.setColor(al(0xFFFFD08A, e * pulse));
        c.drawPath(cracks, pt);
        for (int k = 0; k < 3; k++) {                                         // smoke columns rising and thinning out
            float v = (float) (((td + k * 7.0) * 0.045) % 1.0);
            blob(c, smoke, w * (0.2f + 0.3f * k) + 30f * u * sn(td, 9, k), h * (1.0f - 0.9f * v), w * 0.3f * (0.6f + v), e * (float) Math.sin(Math.PI * v));
        }
        for (int i = 0; i < 48; i++) {                                        // embers: rise, sway and wrap
            float y = h - drift(td + emb[4 * i + 2], emb[4 * i + 1] * u, h + 40f) + 10f;
            embPos[2 * i] = emb[4 * i] + 22f * u * (float) Math.sin(td * 0.9 + emb[4 * i + 3]);
            embPos[2 * i + 1] = y;
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(5f * u);
        pt.setColor(al(0xFFFF8A3C, e * 0.9f));
        c.drawPoints(embPos, 0, 32, pt);
        pt.setStrokeWidth(3f * u);
        pt.setColor(al(0xFFFFB35A, e * 0.8f));
        c.drawPoints(embPos, 32, 40, pt);
        pt.setStrokeWidth(2f * u);
        pt.setColor(al(0xFFFFE3A0, e * 0.7f));
        c.drawPoints(embPos, 72, 24, pt);
        for (int i = 0; i < ash.length / 3; i++) {                            // ash falling slowly
            pl[2 * i] = ash[3 * i] + 10f * u * (float) Math.sin(td * 0.5 + i);
            pl[2 * i + 1] = drift(td + ash[3 * i + 2], ash[3 * i + 1] * u, h + 20f) - 10f;
        }
        pt.setStrokeWidth(2f * u);
        pt.setColor(al(0xFF9A8F8A, e * 0.35f));
        c.drawPoints(pl, 0, ash.length / 3 * 2, pt);
    }

    private void neonEnv(Canvas c, double td, float e) {
        float hz = h * 0.60f;
        c.save();                                                              // the sun, sliced by the horizon
        c.clipRect(0f, 0f, w, hz);
        gp.setStyle(Paint.Style.FILL);
        gp.setShader(sun);
        gp.setAlpha((int) (255 * e));
        c.drawCircle(w / 2f, hz - w * 0.06f, w * 0.24f, gp);
        gp.setShader(null);
        gp.setAlpha(255);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFF1A0A38, e));
        for (int k = 0; k < 6; k++) {                                          // slits that widen toward the bottom
            float y = hz - w * 0.02f - k * w * 0.03f;
            c.drawRect(w * 0.2f, y - (1.5f + (5 - k) * 1.2f) * u, w * 0.8f, y, pt);
        }
        c.restore();
        pt.setColor(al(0xFF05030C, e));                                        // skyline
        for (int i = 0; i < 18; i++) c.drawRect(bld[3 * i], hz - bld[3 * i + 2], bld[3 * i] + bld[3 * i + 1], hz, pt);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(3f * u);
        pt.setColor(al(0xFF5CF2E6, e * (0.55f + 0.25f * sn(td, 3, 0))));
        c.drawPoints(win, 0, 80, pt);
        pt.setColor(al(0xFFFFD27A, e * (0.55f + 0.25f * sn(td, 4, 1))));
        c.drawPoints(win, 80, 80, pt);
        gp.setStyle(Paint.Style.FILL);                                         // the grid floor
        gp.setShader(floor);
        gp.setAlpha((int) (255 * e));
        c.drawRect(0f, hz, w, h, gp);
        gp.setShader(null);
        gp.setAlpha(255);
        for (int i = 0; i < 11; i++) {                                         // verticals fan out from the vanishing point
            float xb = w / 2f + (i - 5) * w * 0.26f;
            grid[4 * i] = w / 2f + (i - 5) * w * 0.012f;
            grid[4 * i + 1] = hz;
            grid[4 * i + 2] = xb;
            grid[4 * i + 3] = h;
        }
        for (int k = 0; k < 11; k++) {                                         // horizontals slide toward the viewer
            float v = (k + (float) ((td * 0.3) % 1.0)) / 11f, y = hz + (h - hz) * v * v;
            int j = 11 + k;
            grid[4 * j] = 0f;
            grid[4 * j + 1] = y;
            grid[4 * j + 2] = w;
            grid[4 * j + 3] = y;
        }
        pt.setStrokeWidth(7f * u);
        pt.setColor(al(0xFFFF2FC8, e * 0.14f));
        c.drawLines(grid, pt);
        pt.setStrokeWidth(2f * u);
        pt.setColor(al(0xFFFF4FD8, e * 0.7f));
        c.drawLines(grid, pt);
        for (int i = 0; i < 44; i++) {                                         // rain
            float y = drift(td + rain[3 * i + 2], rain[3 * i + 1] * u, h + 100f) - 50f;
            rainL[4 * i] = rain[3 * i];
            rainL[4 * i + 1] = y;
            rainL[4 * i + 2] = rain[3 * i] - 7f * u;
            rainL[4 * i + 3] = y + 36f * u;
        }
        pt.setStrokeWidth(1.6f * u);
        pt.setColor(al(0xFF8FF6FF, e * 0.28f));
        c.drawLines(rainL, pt);
    }

    private void horizonEnv(Canvas c, double td, float e) {
        starLayer(c, td, 0, 0.8f, 1.4f, 0xFFFFFFFF, 0.55f * e, 8f);
        starLayer(c, td, 1, 2f, 2.0f, 0xFFFFE9B0, 0.7f * e, 6f);
        float cr = r;                                                          // stars pulled around the hole, stretched along the pull
        for (int i = 0; i < 70; i++) {
            float ang = lens[4 * i] + (float) (td * 0.01 / lens[4 * i + 1]);
            float rad = cr * lens[4 * i + 1], len = cr * 0.35f / lens[4 * i + 1];
            float x = cx + (float) Math.cos(ang) * rad, y = cy + (float) Math.sin(ang) * rad;
            float tx = -(float) Math.sin(ang), ty = (float) Math.cos(ang);
            gridSet(i, x - tx * len, y - ty * len, x + tx * len, y + ty * len);
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(2f * u);
        pt.setColor(al(0xFFFFF0D0, e * 0.7f));
        c.drawLines(lensBuf, 0, 280, pt);
        // infalling gold dust spirals toward the centre
        pt.setStrokeWidth(3f * u);
        for (int i = 0; i < 40; i++) {
            float v = (float) ((fall[4 * i] + td * fall[4 * i + 1]) % 1.0);
            float rad = cr * (3.2f - 2.0f * v * v) * (0.6f + 0.2f * fall[4 * i + 3]), ang = fall[4 * i + 2] + v * 5f;
            pl[2 * (i % 40)] = cx + (float) Math.cos(ang) * rad;
            pl[2 * (i % 40) + 1] = cy + (float) Math.sin(ang) * rad * 0.7f;
        }
        pt.setColor(al(0xFFFFB347, e * 0.75f));
        c.drawPoints(pl, 0, 80, pt);
        blob(c, ringGlow, cx, cy, r * 1.7f, e * (0.7f + 0.3f * sn(td, 7, 0)));
        pt.setStrokeWidth(1.6f * u);
        pt.setColor(al(0xFFFFE9B0, e * 0.35f));
        c.drawCircle(cx, cy, r * 1.55f, pt);
    }

    private final float[] lensBuf = new float[280];

    private void gridSet(int i, float x0, float y0, float x1, float y1) {
        lensBuf[4 * i] = x0;
        lensBuf[4 * i + 1] = y0;
        lensBuf[4 * i + 2] = x1;
        lensBuf[4 * i + 3] = y1;
    }

    // ---------- the clocks: static art (cached) and the animated parts under the hands ----------

    /** How much of the cached dial is showing: it takes over from the animated build at the end. */
    static float dialA(float b) {
        return b >= 1f ? 1f : smooth((b - 0.8f) / 0.2f);
    }

    void dial(int th, Canvas k, float c0, float rad) {
        k.save();
        k.translate(c0 - cx, c0 - cy);                      // the art is laid out around the real centre
        art(th, k, 1f, 0.0);
        k.restore();
    }

    void under(int th, Canvas c, float x, float y, float rad, float b, long now) {
        double td = now / 1000.0;
        float da = dialA(b);
        if (da < 0.999f) {
            int sc = c.saveLayerAlpha(x - rad * 1.2f, y - rad * 1.2f, x + rad * 1.2f, y + rad * 1.2f, (int) (255 * (1f - da)));
            art(th, c, b, td);
            c.restoreToCount(sc);
        }
        live(th, c, b, td);
    }

    private void art(int th, Canvas c, float b, double td) {
        pt.setShader(null);
        if (th == 5) artNebula(c, b);
        else if (th == 6) artAbyss(c, b);
        else if (th == 7) artEmber(c, b, td);
        else if (th == 8) artNeon(c, b, td);
        else artHorizon(c, b);
    }

    private void artNebula(Canvas c, float b) {
        float o = seg(b, 0.30f, 0.60f);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.005f);
        pt.setColor(al(0x90FFFFFF, o));
        c.drawCircle(cx, cy, r * 0.97f, pt);
        for (int i = 0; i < 60; i++) {
            float len = i % 5 == 0 ? 0.06f : 0.025f;
            tk[4 * i] = cx + Renderer.COS[i] * r * (0.97f - len);
            tk[4 * i + 1] = cy + Renderer.SIN[i] * r * (0.97f - len);
            tk[4 * i + 2] = cx + Renderer.COS[i] * r * 0.97f;
            tk[4 * i + 3] = cy + Renderer.SIN[i] * r * 0.97f;
        }
        pt.setStrokeWidth(r * 0.004f);
        pt.setColor(al(0x80D9CCFF, o));
        c.drawLines(tk, 0, 240, pt);
        for (int i = 0; i < 12; i++) {
            float ai = seg(b, 0.45f + i * 0.03f, 0.58f + i * 0.03f);
            if (ai > 0.01f) star4(c, cx + Renderer.COS[i * 5] * r * 0.84f, cy + Renderer.SIN[i * 5] * r * 0.84f,
                    r * (i % 3 == 0 ? 0.055f : 0.035f) * outBack(ai), i % 3 == 0 ? GOLD : LAV, ai);
        }
    }

    private void artAbyss(Canvas c, float b) {
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0x300A3B4C, seg(b, 0.2f, 0.6f)));
        c.drawCircle(cx, cy, r * 0.97f, pt);
        float len = pmS.getLength();
        tmp.rewind();
        pmS.getSegment(0f, len * seg(b, 0.04f, 0.70f), tmp, true);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.05f);
        pt.setColor(0x2A5CF2E6);
        c.drawPath(tmp, pt);
        pt.setStrokeWidth(r * 0.016f);
        pt.setColor(0xF0BFFBF4);
        c.drawPath(tmp, pt);
        float q = seg(b, 0.55f, 0.85f);
        pt.setStrokeWidth(r * 0.006f);
        pt.setColor(al(0x907BE8E0, q));
        for (int j = 5; j < 17; j++) {                                         // the septa between the chambers
            float t = j * 0.8f, t0 = t - TAU;
            if (t > 13.8f || t0 < 0f) continue;
            float r1 = r * 0.085f * (float) Math.exp(0.171f * t), r0 = r * 0.085f * (float) Math.exp(0.171f * t0);
            c.drawLine(cx + (float) Math.sin(t) * r1, cy - (float) Math.cos(t) * r1, cx + (float) Math.sin(t0) * r0, cy - (float) Math.cos(t0) * r0, pt);
        }
        pt.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 12; i++) {                                         // twelve pearls
            float ai = seg(b, 0.5f + i * 0.03f, 0.62f + i * 0.03f), x = cx + Renderer.COS[i * 5] * r * 0.93f, y = cy + Renderer.SIN[i * 5] * r * 0.93f;
            pt.setColor(al(0x555CF2E6, ai));
            c.drawCircle(x, y, r * (i % 3 == 0 ? 0.034f : 0.024f) * outBack(ai), pt);
            pt.setColor(al(0xFFFFFFFF, ai));
            c.drawCircle(x, y, r * (i % 3 == 0 ? 0.016f : 0.011f) * outBack(ai), pt);
        }
    }

    private void artEmber(Canvas c, float b, double td) {
        float fl = r * 0.95f;
        int[] shade = {0xE01A1013, 0xE0281A1E, 0xE0120B0E, 0xE0301F24, 0xE0160E11, 0xE0241519};
        for (int k = 0; k < 6; k++) {                                          // six facets, each flies in from outside
            float t = seg(b, 0.04f + 0.07f * k, 0.50f + 0.07f * k), inv = 1f - t;
            float mid = (k * 60f + 30f), dist = r * 1.7f * inv * inv;
            c.save();
            c.translate(hx(0f, dist, mid), hy(0f, dist, mid) * 1f);
            c.translate(cx, cy);
            c.rotate((k % 2 == 0 ? 1f : -1f) * 38f * inv);
            path.rewind();
            path.moveTo(0f, 0f);
            path.lineTo(hx(0f, fl, k * 60f), hy(0f, fl, k * 60f));
            path.lineTo(hx(0f, fl, k * 60f + 60f), hy(0f, fl, k * 60f + 60f));
            path.close();
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(shade[k], t));
            c.drawPath(path, pt);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.006f);
            pt.setColor(al(0x55FFFFFF, t));
            c.drawPath(path, pt);
            c.restore();
        }
        float ig = seg(b, 0.55f, 0.85f);
        path.rewind();
        for (int k = 0; k < 6; k++) {
            if (k == 0) path.moveTo(hx(cx, fl, 0f), hy(cy, fl, 0f));
            else path.lineTo(hx(cx, fl, k * 60f), hy(cy, fl, k * 60f));
        }
        path.close();
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.05f);
        pt.setColor(al(0x44FF5A14, ig));
        c.drawPath(path, pt);
        pt.setStrokeWidth(r * 0.014f);
        pt.setColor(al(LAVA, ig));
        c.drawPath(path, pt);
        pt.setStrokeWidth(r * 0.005f);
        pt.setColor(al(HOT, ig));
        c.drawPath(path, pt);
        pt.setStrokeWidth(r * 0.006f);                                          // cracks run from the centre to the corners
        pt.setColor(al(0xCCFF7A2A, seg(b, 0.6f, 0.9f)));
        for (int k = 0; k < 6; k++) c.drawLine(cx, cy, hx(cx, fl * 0.92f, k * 60f), hy(cy, fl * 0.92f, k * 60f), pt);
        pt.setStrokeWidth(r * 0.012f);
        pt.setColor(al(0xFFFFB35A, seg(b, 0.7f, 0.95f)));
        for (int i = 0; i < 12; i++) {                                          // hour notches on the edge
            float deg = i * 30f, e0 = hexR(deg);
            c.drawLine(hx(cx, e0 - r * 0.12f, deg), hy(cy, e0 - r * 0.12f, deg), hx(cx, e0 - r * 0.04f, deg), hy(cy, e0 - r * 0.04f, deg), pt);
        }
    }

    private void artNeon(Canvas c, float b, double td) {
        float fl = (b > 0.55f && b < 0.8f && ((int) (td * 30) % 3) == 0) ? 0.35f : 1f;       // power-on flicker
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0x90100820, seg(b, 0.2f, 0.6f)));
        c.drawPath(squircle, pt);
        float len = pmQ.getLength(), g = seg(b, 0.08f, 0.70f);
        tmp.rewind();
        pmQ.getSegment(0f, len * g, tmp, true);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.05f);
        pt.setColor(al(0x55FF2FC8, fl));
        c.drawPath(tmp, pt);
        pt.setStrokeWidth(r * 0.012f);
        pt.setColor(al(0xFFFFB0EA, fl));
        c.drawPath(tmp, pt);
        c.save();                                                               // the inner frame, scaled and cyan
        c.scale(0.9f, 0.9f, cx, cy);
        pt.setStrokeWidth(r * 0.008f);
        pt.setColor(al(0xCC5CF2E6, fl * seg(b, 0.3f, 0.8f)));
        c.drawPath(tmp, pt);
        c.restore();
        float br = seg(b, 0.6f, 0.82f);
        pt.setStrokeWidth(r * 0.02f);
        pt.setColor(al(0xFFFFFFFF, br * fl));
        for (int q = 0; q < 4; q++) {                                           // corner brackets
            float th = (q * 90f + 45f) * 0.0174533f;
            sqPoint(th, 0.86f);
            float sx = (q == 0 || q == 3) ? (q == 0 ? -1f : 1f) : (q == 1 ? -1f : 1f);
            float dx = (q == 0 || q == 1) ? -1f : 1f, dy = (q == 0 || q == 3) ? 1f : -1f;
            c.drawLine(ox, oy, ox + dx * r * 0.14f, oy, pt);
            c.drawLine(ox, oy, ox, oy + dy * r * 0.14f, pt);
        }
        pt.setStrokeWidth(r * 0.016f);
        pt.setColor(al(0xFF5CF2E6, seg(b, 0.7f, 0.95f)));
        for (int i = 0; i < 12; i++) {
            float th = i * 30f * 0.0174533f;
            sqPoint(th, 0.78f);
            float x1 = ox, y1 = oy;
            sqPoint(th, 0.70f);
            c.drawLine(x1, y1, ox, oy, pt);
        }
        c.save();                                                               // faint scanlines inside the frame
        c.clipPath(squircle);
        pt.setStrokeWidth(1f);
        pt.setColor(al(0x14FFFFFF, seg(b, 0.4f, 0.8f)));
        int n = 0;
        for (float y = cy - r * 0.86f; y < cy + r * 0.86f && n < 56; y += r * 0.06f) {
            tk[4 * n] = cx - r;
            tk[4 * n + 1] = y;
            tk[4 * n + 2] = cx + r;
            tk[4 * n + 3] = y;
            n++;
        }
        c.drawLines(tk, 0, 4 * n, pt);
        c.restore();
    }

    private void artHorizon(Canvas c, float b) {
        float o = seg(b, 0.55f, 0.78f);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.035f);
        pt.setColor(al(0x44FFB347, o));
        c.drawCircle(cx, cy, r * 0.60f, pt);
        pt.setStrokeWidth(r * 0.012f);
        pt.setColor(al(0xFFFFF0D0, o));
        c.drawCircle(cx, cy, r * 0.60f, pt);
        pt.setStrokeWidth(r * 0.005f);
        pt.setColor(al(0x66FFFFFF, o));
        c.drawCircle(cx, cy, r * 0.97f, pt);
        float fl = seg(b, 0.72f, 0.84f);                                        // the flash when the ring ignites
        if (fl > 0.01f && fl < 0.99f) {
            pt.setStrokeWidth(r * 0.03f * (1f - fl));
            pt.setColor(al(0xFFFFFFFF, 1f - fl));
            c.drawCircle(cx, cy, r * (0.6f + 0.8f * fl), pt);
        }
        pt.setStrokeWidth(r * 0.012f);
        for (int i = 0; i < 12; i++) {                                          // hour marks as short stretched dashes
            float ai = seg(b, 0.7f + i * 0.02f, 0.86f + i * 0.02f), deg = i * 30f;
            pt.setColor(al(i % 3 == 0 ? 0xFFFFE9B0 : 0xFFFFFFFF, ai * 0.9f));
            c.drawLine(hx(cx, r * 0.90f, deg - 1.6f), hy(cy, r * 0.90f, deg - 1.6f), hx(cx, r * 0.90f, deg + 1.6f), hy(cy, r * 0.90f, deg + 1.6f), pt);
        }
    }

    /** What moves under the hands, scaled by how much of the clock has built. */
    private void live(int th, Canvas c, float b, double td) {
        float s = smooth(b);
        if (th == 5) {                                                          // three tilted rings turn like an armillary sphere
            int[] col = {0xFFB9A6FF, 0xFF7AD9FF, 0xFFFF9EDB};
            for (int k = 0; k < 3; k++) {
                float grow = outBack(seg(b, 0.05f + 0.12f * k, 0.55f + 0.10f * k));
                if (grow < 0.01f) continue;
                c.save();
                c.translate(cx, cy);
                c.rotate(k * 60f + (float) (td * 3.0) + (1f - Math.min(1f, grow)) * 200f);
                float rx = r * 0.80f * grow, ry = rx * (0.30f + 0.08f * sn(td, 14, k));
                rc.set(-rx, -ry, rx, ry);
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(r * 0.012f);
                pt.setColor(al(col[k], 0.22f * s));
                c.drawOval(rc, pt);
                pt.setStrokeWidth(r * 0.004f);
                pt.setColor(al(col[k], 0.85f * s));
                c.drawOval(rc, pt);
                float ph = (float) (td * 0.4 + k * 2.0);
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(0xFFFFFFFF, s));
                c.drawCircle(rx * (float) Math.cos(ph), ry * (float) Math.sin(ph), r * 0.014f, pt);
                c.restore();
            }
        } else if (th == 6) {                                                   // a slow ripple leaves the middle of the shell
            float v = (float) ((td % 6.0) / 6.0);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.012f);
            pt.setColor(al(0xFF5CF2E6, 0.30f * (1f - v) * s));
            c.drawCircle(cx, cy, r * (0.1f + 0.85f * v), pt);
            for (int i = 0; i < 12; i++) {                                      // the pearls breathe
                float br = 0.5f + 0.5f * sn(td, 4, i * 0.5);
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(0xFF5CF2E6, 0.22f * br * s));
                c.drawCircle(cx + Renderer.COS[i * 5] * r * 0.93f, cy + Renderer.SIN[i * 5] * r * 0.93f, r * 0.05f, pt);
            }
        } else if (th == 7) {                                                   // the edge of the shard glows and fades like breathing lava
            float fl = 0.5f + 0.5f * sn(td, 3.4, 0);
            path.rewind();
            for (int k = 0; k < 6; k++) {
                if (k == 0) path.moveTo(hx(cx, r * 0.95f, 0f), hy(cy, r * 0.95f, 0f));
                else path.lineTo(hx(cx, r * 0.95f, k * 60f), hy(cy, r * 0.95f, k * 60f));
            }
            path.close();
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.03f);
            pt.setColor(al(0x55FF5A14, 0.5f * fl * seg(b, 0.6f, 0.9f)));
            c.drawPath(path, pt);
        } else if (th == 8) {                                                   // a scan beam sweeps down the screen
            float v = (float) ((td % 4.0) / 4.0), y = cy - r * 0.86f + r * 1.72f * v;
            c.save();
            c.clipPath(squircle);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.05f);
            pt.setColor(al(0xFF5CF2E6, 0.10f * s));
            c.drawLine(cx - r, y, cx + r, y, pt);
            pt.setStrokeWidth(r * 0.006f);
            pt.setColor(al(0xFFB6FFF8, 0.45f * s));
            c.drawLine(cx - r, y, cx + r, y, pt);
            c.restore();
        } else {
            horizonLive(c, b, td);
        }
    }

    /** The black hole itself: back of the disc, the hole, the front of the disc, a lensed arc over the top. */
    private void horizonLive(Canvas c, float b, double td) {
        float grow = seg(b, 0.08f, 0.60f), hs = outBack(seg(b, 0.05f, 0.35f));
        float tilt = -12f + 2f * sn(td, 45, 0);
        float rx = r * 0.98f, ry = r * 0.20f;
        c.save();
        c.translate(cx, cy);
        c.rotate(tilt);
        rc.set(-rx, -ry, rx, ry);
        for (int pass = 0; pass < 2; pass++) {                                  // pass 0 = behind the hole (upper half), 1 = in front
            float start = pass == 0 ? 180f : 0f;
            float sweep = 180f * grow;
            float from = pass == 0 ? 180f + (180f - sweep) / 2f : (180f - sweep) / 2f;
            if (pass == 1) {
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(0xFF000000);
                c.drawCircle(0f, 0f, r * 0.56f * hs, pt);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.15f);
            pt.setColor(al(0xFFFF7A1F, 0.14f * (pass == 0 ? 0.7f : 1f)));
            c.drawArc(rc, from, sweep, false, pt);
            pt.setStrokeWidth(r * 0.07f);
            pt.setColor(al(0xFFFFB347, 0.45f * (pass == 0 ? 0.7f : 1f)));
            c.drawArc(rc, from, sweep, false, pt);
            pt.setStrokeWidth(r * 0.012f);
            pt.setColor(al(0xFFFFF4DC, 0.95f * (pass == 0 ? 0.7f : 1f)));
            c.drawArc(rc, from, sweep, false, pt);
        }
        float ph = (float) (td * 0.5);                                           // a hot spot orbits; it is brightest coming toward us
        float hxp = rx * (float) Math.cos(ph), hyp = ry * (float) Math.sin(ph), br = 0.5f + 0.5f * (float) Math.sin(ph + 1.57f);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFFFFE9B0, 0.35f * br * grow));
        c.drawCircle(hxp, hyp, r * 0.07f, pt);
        pt.setColor(al(0xFFFFFFFF, 0.9f * br * grow));
        c.drawCircle(hxp, hyp, r * 0.02f, pt);
        c.restore();
        float arc = seg(b, 0.45f, 0.75f);                                        // light bent over the top of the hole
        pt.setStyle(Paint.Style.STROKE);
        rc.set(cx - r * 0.66f, cy - r * 0.66f, cx + r * 0.66f, cy + r * 0.66f);
        pt.setStrokeWidth(r * 0.05f);
        pt.setColor(al(0xFFFFB347, 0.25f * arc));
        c.drawArc(rc, 200f, 140f, false, pt);
        pt.setStrokeWidth(r * 0.012f);
        pt.setColor(al(0xFFFFF0D0, 0.9f * arc));
        c.drawArc(rc, 200f, 140f, false, pt);
    }

    // ---------- hands ----------

    void hands(int th, Canvas c, float x, float y, float rad, float hDeg, float mDeg, float sDeg, float sa, float b, long now) {
        double td = now / 1000.0;
        float k = seg(b, 0.78f, 1f);                                             // hands extend at the very end of the build
        if (k < 0.01f) return;
        if (th == 5) nebulaHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else if (th == 6) abyssHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else if (th == 7) emberHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else if (th == 8) neonHands(c, hDeg, mDeg, sDeg, sa, k, td);
        else horizonHands(c, hDeg, mDeg, sDeg, sa, k, td);
    }

    private void beam(Canvas c, float deg, float len, float wide, int col, float alpha) {
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        path.rewind();
        path.moveTo(-r * 0.012f, r * 0.06f);
        path.lineTo(-wide, -len * 0.9f);
        path.lineTo(0f, -len);
        path.lineTo(wide, -len * 0.9f);
        path.lineTo(r * 0.012f, r * 0.06f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(col, 0.30f * alpha));
        c.drawPath(path, pt);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.007f);
        pt.setColor(al(col, alpha));
        c.drawLine(0f, r * 0.04f, 0f, -len, pt);
        c.restore();
    }

    private void nebulaHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        beam(c, h, r * 0.50f * k, r * 0.07f, GOLD, k);
        star4(c, hx(cx, r * 0.50f * k, h), hy(cy, r * 0.50f * k, h), r * 0.05f, GOLD, k);
        beam(c, m, r * 0.80f * k, r * 0.035f, LAV, k);
        star4(c, hx(cx, r * 0.80f * k, m), hy(cy, r * 0.80f * k, m), r * 0.035f, 0xFFFFFFFF, k);
        if (sa > 0.02f) {
            for (int i = 5; i >= 1; i--) {
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(0xFFFFE9B0, 0.5f * sa * k * (1f - i / 6f)));
                c.drawCircle(hx(cx, r * 0.97f, s - i * 5f), hy(cy, r * 0.97f, s - i * 5f), r * 0.012f, pt);
            }
            star4(c, hx(cx, r * 0.97f, s), hy(cy, r * 0.97f, s), r * 0.04f, 0xFFFFFFFF, sa * k);
        }
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(IVORY, k));
        c.drawCircle(cx, cy, r * 0.028f, pt);
    }

    /** A wavering tendril: a polyline whose sideways offset travels outward along its length. */
    private void tendril(Canvas c, float deg, float len, float wid, int col, float alpha, double td, float phase) {
        float sx = (float) Math.sin(Math.toRadians(deg)), sy = -(float) Math.cos(Math.toRadians(deg));
        float nx = -sy, ny = sx;
        path.rewind();
        for (int i = 0; i <= 12; i++) {
            float f = i / 12f, off = len * 0.04f * f * (float) Math.sin(td * 1.7 - i * 0.55 + phase);
            float x = cx + sx * len * f + nx * off, y = cy + sy * len * f + ny * off;
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
            if (i == 12) {
                ox = x;
                oy = y;
            }
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(wid * 2.4f);
        pt.setColor(al(col, 0.18f * alpha));
        c.drawPath(path, pt);
        pt.setStrokeWidth(wid);
        pt.setColor(al(col, 0.95f * alpha));
        c.drawPath(path, pt);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(col, 0.30f * alpha));
        c.drawCircle(ox, oy, wid * 2.2f, pt);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawCircle(ox, oy, wid * 0.9f, pt);
    }

    private void abyssHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        tendril(c, h, r * 0.50f * k, r * 0.032f, VIOLET, k, td, 0f);
        tendril(c, m, r * 0.80f * k, r * 0.020f, CYAN, k, td, 2f);
        if (sa > 0.02f) {
            pt.setStyle(Paint.Style.FILL);
            for (int i = 6; i >= 1; i--) {
                pt.setColor(al(WARM, 0.6f * sa * k * (1f - i / 7f)));
                c.drawCircle(hx(cx, r * 0.93f, s - i * 4f), hy(cy, r * 0.93f, s - i * 4f), r * (0.016f - i * 0.0016f), pt);
            }
            pt.setColor(al(WARM, 0.35f * sa * k));
            c.drawCircle(hx(cx, r * 0.93f, s), hy(cy, r * 0.93f, s), r * 0.045f, pt);
            pt.setColor(al(0xFFFFFFFF, sa * k));
            c.drawCircle(hx(cx, r * 0.93f, s), hy(cy, r * 0.93f, s), r * 0.016f, pt);
        }
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFFBFFBF4, k));
        c.drawCircle(cx, cy, r * 0.03f, pt);
    }

    private void blade(Canvas c, float deg, float len, float wide, float flick, float alpha) {
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        path.rewind();
        path.moveTo(0f, r * 0.10f);
        path.lineTo(wide, -len * 0.25f);
        path.lineTo(0f, -len);
        path.lineTo(-wide, -len * 0.25f);
        path.close();
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(wide * 2.6f);
        pt.setColor(al(0xFFFF5A14, 0.22f * alpha * flick));
        c.drawPath(path, pt);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(LAVA, alpha));
        c.drawPath(path, pt);
        path.rewind();
        path.moveTo(0f, r * 0.04f);
        path.lineTo(wide * 0.4f, -len * 0.25f);
        path.lineTo(0f, -len * 0.92f);
        path.lineTo(-wide * 0.4f, -len * 0.25f);
        path.close();
        pt.setColor(al(HOT, alpha * (0.75f + 0.25f * flick)));
        c.drawPath(path, pt);
        c.restore();
    }

    private void emberHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        float fl = 0.6f + 0.4f * sn(td, 1.7, 0);
        blade(c, h, r * 0.50f * k, r * 0.055f, fl, k);
        blade(c, m, r * 0.78f * k, r * 0.034f, fl, k);
        if (sa > 0.02f) {                                                        // a spark runs along the edge of the hexagon
            pt.setStyle(Paint.Style.FILL);
            for (int i = 7; i >= 1; i--) {
                float d = s - i * 3.5f, e0 = hexR(d) * 0.97f;
                pt.setColor(al(0xFFFF9A3C, 0.8f * sa * k * (1f - i / 8f)));
                c.drawCircle(hx(cx, e0, d), hy(cy, e0, d), r * 0.014f * (1f - i * 0.08f), pt);
            }
            float e0 = hexR(s) * 0.97f;
            pt.setColor(al(0xFFFF7A1F, 0.35f * sa * k));
            c.drawCircle(hx(cx, e0, s), hy(cy, e0, s), r * 0.05f, pt);
            pt.setColor(al(0xFFFFF0D0, sa * k));
            c.drawCircle(hx(cx, e0, s), hy(cy, e0, s), r * 0.018f, pt);
        }
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFF140A0C, k));
        c.drawCircle(cx, cy, r * 0.05f, pt);
        pt.setColor(al(LAVA, k));
        c.drawCircle(cx, cy, r * 0.028f, pt);
    }

    private final char[] clockText = {'0', '0', ':', '0', '0'};

    private void neonHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        pt.setStyle(Paint.Style.FILL);                                           // a quiet digital readout under the hands
        pt.setTypeface(Typeface.MONOSPACE);
        pt.setTextAlign(Paint.Align.CENTER);
        pt.setTextSize(r * 0.17f);
        int hh = ((int) (h / 30f)) % 12, mm = ((int) (m / 6f)) % 60;
        clockText[0] = (char) ('0' + (hh == 0 ? 12 : hh) / 10);
        clockText[1] = (char) ('0' + (hh == 0 ? 12 : hh) % 10);
        clockText[3] = (char) ('0' + mm / 10);
        clockText[4] = (char) ('0' + mm % 10);
        pt.setColor(al(0xFFFF2FC8, 0.30f * k));
        c.drawText(clockText, 0, 5, cx + 2f * u, cy + r * 0.40f + 2f * u, pt);
        pt.setColor(al(0xFF8FF6FF, 0.65f * k));
        c.drawText(clockText, 0, 5, cx, cy + r * 0.40f, pt);
        pt.setTypeface(Typeface.DEFAULT);
        bar(c, h, r * 0.46f * k, r * 0.046f, MAG, k);
        bar(c, m, r * 0.74f * k, r * 0.026f, CYAN, k);
        if (sa > 0.02f) {                                                        // a dot slides around the frame
            pt.setStyle(Paint.Style.FILL);
            for (int i = 6; i >= 1; i--) {
                sqPoint((s - i * 3f) * 0.0174533f, 0.86f);
                pt.setColor(al(0xFFFFFFFF, 0.5f * sa * k * (1f - i / 7f)));
                c.drawCircle(ox, oy, r * 0.014f, pt);
            }
            sqPoint(s * 0.0174533f, 0.86f);
            pt.setColor(al(0xFFFF2FC8, 0.4f * sa * k));
            c.drawCircle(ox, oy, r * 0.055f, pt);
            pt.setColor(al(0xFFFFFFFF, sa * k));
            c.drawCircle(ox, oy, r * 0.02f, pt);
        }
        pt.setColor(al(0xFFFFFFFF, k));
        c.drawCircle(cx, cy, r * 0.022f, pt);
    }

    private void bar(Canvas c, float deg, float len, float wid, int col, float alpha) {
        float x = hx(cx, len, deg), y = hy(cy, len, deg);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(wid * 2.6f);
        pt.setColor(al(col, 0.20f * alpha));
        c.drawLine(cx, cy, x, y, pt);
        pt.setStrokeWidth(wid);
        pt.setColor(al(col, alpha));
        c.drawLine(cx, cy, x, y, pt);
        pt.setStrokeWidth(wid * 0.35f);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawLine(cx, cy, x, y, pt);
    }

    /** A hand that gravity has bent: it leaves the centre straight and curves as it climbs. */
    private void curved(Canvas c, float deg, float len, float bend, float wid, int col, float alpha) {
        float sx = (float) Math.sin(Math.toRadians(deg)), sy = -(float) Math.cos(Math.toRadians(deg));
        float mx = cx + sx * len * 0.55f - sy * len * bend, my = cy + sy * len * 0.55f + sx * len * bend;
        float tx = cx + sx * len + sy * len * bend * 0.3f, ty = cy + sy * len - sx * len * bend * 0.3f;
        path.rewind();
        path.moveTo(cx, cy);
        path.quadTo(mx, my, tx, ty);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(wid * 3f);
        pt.setColor(al(col, 0.16f * alpha));
        c.drawPath(path, pt);
        pt.setStrokeWidth(wid);
        pt.setColor(al(col, alpha));
        c.drawPath(path, pt);
        pt.setStrokeWidth(wid * 0.3f);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawPath(path, pt);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(col, 0.35f * alpha));
        c.drawCircle(tx, ty, wid * 2.4f, pt);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawCircle(tx, ty, wid * 0.8f, pt);
    }

    private void horizonHands(Canvas c, float h, float m, float s, float sa, float k, double td) {
        curved(c, h, r * 0.50f * k, 0.16f, r * 0.026f, 0xFFFFD27A, k);
        curved(c, m, r * 0.80f * k, 0.10f, r * 0.016f, 0xFFFFF0D0, k);
        if (sa > 0.02f) {                                                        // a satellite circles the disc at the seconds angle
            float tilt = (float) Math.toRadians(-12f + 2f * sn(td, 45, 0)), rx = r * 0.98f, ry = r * 0.20f;
            float cs = (float) Math.cos(Math.toRadians(s - 90f)), sn2 = (float) Math.sin(Math.toRadians(s - 90f));
            pt.setStyle(Paint.Style.FILL);
            for (int i = 5; i >= 0; i--) {
                float a2 = (float) Math.toRadians(s - 90f - i * 4f), ex = rx * (float) Math.cos(a2), ey = ry * (float) Math.sin(a2);
                float px = cx + ex * (float) Math.cos(tilt) - ey * (float) Math.sin(tilt), py = cy + ex * (float) Math.sin(tilt) + ey * (float) Math.cos(tilt);
                pt.setColor(al(0xFFFFE9B0, 0.7f * sa * k * (1f - i / 6f)));
                c.drawCircle(px, py, r * (i == 0 ? 0.024f : 0.014f), pt);
            }
        }
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFFFFF0D0, k));
        c.drawCircle(cx, cy, r * 0.024f, pt);
    }
}
