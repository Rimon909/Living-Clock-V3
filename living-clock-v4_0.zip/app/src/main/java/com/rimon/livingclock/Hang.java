package com.rimon.livingclock;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.Random;

/**
 * Hanging numerals. One tap on the clock: the twelve numerals drop on threads from their own places
 * on the dial, one by one from 12 to 11, bounce on the thread and swing like small pendulums. Tap
 * again once they hang and they let go: the threads zip up and vanish, the numerals fall away.
 *
 * Each numeral is a pendulum (absolute rope angle, damped, pulled toward the direction of gravity) on a
 * thread whose length is a spring, so a drop overshoots and settles. Four presets:
 *   0 Classic drop  plain numerals, a clean bounce, a calm swing that settles
 *   1 Wind chime    brass plates that ring when they land, swayed by a travelling breeze
 *   2 Lanterns      numerals ignite as they arrive, a slow floating descent, a soft flicker
 *   3 Gravity       glass drops that follow the tilt of the phone (the accelerometer is on only now)
 * Once the swing has died away (presets 0 and 2) the clock goes back to one redraw per second.
 */
final class Hang {

    static final String[] NAMES = {"Classic drop", "Wind chime", "Lanterns", "Gravity"};

    private static final int N = 12;
    private static final long STEP_MS = 130L, EXIT_STEP_MS = 70L, HOLD_MS = 30_000L;
    private static final int IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A;
    private static final String[] NUM = {"12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"};
    private static final int[] STRING = {0xFFFFF4E2, 0xFFFFDC8A, 0xFFFFD27A, 0xFFCFE8FF};
    private static final float[] W0 = {5.2f, 4.6f, 4.0f, 6.0f};      // swing rate, rad/s
    private static final float[] ZETA = {0.10f, 0.05f, 0.14f, 0.12f};
    private static final float[] LW = {17f, 15f, 11f, 14f};           // thread spring rate
    private static final float[] LZ = {0.38f, 0.30f, 0.50f, 0.60f};   // thread spring damping

    int preset;

    private final float[] alp = new float[N], omg = new float[N], len = new float[N], lv = new float[N];
    private final float[] fx = new float[N], fy = new float[N], fvx = new float[N], fvy = new float[N];
    private final float[] rot = new float[N], rotV = new float[N], fAge = new float[N];
    private final long[] sAt = new long[N], eAt = new long[N], ringAt = new long[N];
    private final boolean[] started = new boolean[N], falling = new boolean[N];
    private final boolean[] gone = new boolean[N], landed = new boolean[N];
    private final Paint lantern = new Paint(Paint.ANTI_ALIAS_FLAG), ice = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();

    private int state;                     // 0 hidden, 1 appearing, 2 hanging, 3 dropping
    private long t0, holdAt, lastMs = -1L;
    private float cx, cy, r, ropeL, screenH = 1920f, shaderR = -1f, psi, gdx, gdy = 1f;
    private boolean calm;

    // ---------- control ----------

    void layout(float cx, float cy, float r, float h) {
        this.cx = cx;
        this.cy = cy;
        this.r = r;
        this.screenH = h;
        ropeL = r * 0.15f;
        if (r != shaderR) {
            shaderR = r;
            float nr = r * 0.07f;
            lantern.setShader(new RadialGradient(0f, 0f, nr * 2.8f, new int[]{0xAAFFB84D, 0x44FF9A3C, 0x00FF9A3C},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            ice.setShader(new RadialGradient(0f, 0f, nr * 2.2f, new int[]{0x66BFE3FF, 0x22BFE3FF, 0x00BFE3FF},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        }
    }

    void toggle(long now) {
        if (state == 0) {
            reset();
            state = 1;
            t0 = now;
            holdAt = now;
            lastMs = now;
        } else if (state == 1 || state == 2) {
            startExit(now);
        }
    }

    void dismiss(long now) {
        if (state == 1 || state == 2) startExit(now);
    }

    void reset() {
        state = 0;
        lastMs = -1L;
        calm = false;
        for (int k = 0; k < N; k++) {
            started[k] = falling[k] = gone[k] = landed[k] = false;
            eAt[k] = ringAt[k] = -1L;
        }
    }

    boolean active() {
        return state != 0;
    }

    boolean needsSensor() {
        return preset == 3 && (state == 1 || state == 2);
    }

    /** True while frames should follow the display refresh; hanging and calm, it returns to idle. */
    boolean moving(long now) {
        if (state == 0) return false;
        if (state != 2) return true;
        return preset == 1 || preset == 3 || !calm;
    }

    private void startExit(long now) {
        state = 3;
        for (int k = 0; k < N; k++) {
            if (!started[k]) gone[k] = true;
            else if (!falling[k] && !gone[k]) eAt[k] = now + k * EXIT_STEP_MS;
        }
    }

    private void begin(int k, long now) {
        started[k] = true;
        falling[k] = gone[k] = landed[k] = false;
        sAt[k] = now;
        eAt[k] = ringAt[k] = -1L;
        alp[k] = psi + (rnd.nextFloat() - 0.5f) * 0.5f;
        omg[k] = (rnd.nextFloat() - 0.5f) * 1.5f;
        len[k] = 0f;
        lv[k] = ropeL * (preset == 3 ? 3f : 5f);          // the drop
    }

    private void release(int k, long now) {
        float ax = cx + Renderer.COS[k * 5] * r * 0.74f, ay = cy + Renderer.SIN[k * 5] * r * 0.74f;
        float ux = (float) Math.sin(alp[k]), uy = (float) Math.cos(alp[k]);
        fx[k] = ax + ux * len[k];
        fy[k] = ay + uy * len[k];
        fvx[k] = len[k] * omg[k] * uy + lv[k] * ux;        // velocity of the bob at the moment it lets go
        fvy[k] = -len[k] * omg[k] * ux + lv[k] * uy;
        rot[k] = (float) Math.toDegrees(alp[k] - psi) * 0.8f;
        rotV[k] = (rnd.nextFloat() - 0.5f) * 220f;
        fAge[k] = 0f;
        falling[k] = true;
        ringAt[k] = now;
    }

    // ---------- physics ----------

    void update(long now, float gX, float gY) {
        float dt = lastMs < 0 ? 0f : Math.min(0.05f, (now - lastMs) / 1000f);
        lastMs = now;
        if (state == 0 || dt <= 0f) return;

        float gx = 0f, gy = 1f, gm = 1f;
        if (preset == 3) {                                  // gravity follows the phone; shakes strengthen it
            float m = (float) Math.hypot(gX, gY);
            float ey = gY + 0.3f * (1f - smooth(m / 0.3f));
            gm = (float) Math.hypot(gX, ey);
            if (gm > 0.01f) {
                gx = gX / gm;
                gy = ey / gm;
            }
            gm = clamp(gm, 0.4f, 2.2f);
        }
        psi = (float) Math.atan2(gx, gy);
        gdx = gx;
        gdy = gy;

        if (state == 1 && now - t0 > 11 * STEP_MS + 900) state = 2;
        if (state == 2 && now - holdAt > HOLD_MS) startExit(now);

        float w0 = W0[preset], w2 = w0 * w0 * gm, c2 = 2f * ZETA[preset] * w0;
        float sw = LW[preset], sk = sw * sw, sc = 2f * LZ[preset] * sw;
        int steps = Math.max(1, (int) Math.ceil(dt / 0.004f));
        float hs = dt / steps, tw = (now - t0) / 1000f;
        boolean alive = false, still = true;

        for (int k = 0; k < N; k++) {
            if (gone[k]) continue;
            if (!started[k]) {
                if (state == 1 && now - t0 >= k * STEP_MS) begin(k, now);
                else continue;
            }
            alive = true;
            if (falling[k]) {
                stepFall(k, dt);
                continue;
            }
            if (eAt[k] >= 0 && now >= eAt[k]) {
                release(k, now);
                continue;
            }
            float wind = preset == 1
                    ? 3f * (float) Math.sin(tw * 1.3f - k * 0.55f) + 1.2f * (float) Math.sin(tw * 2.1f + k * 0.9f)
                    : 0f;
            for (int i = 0; i < steps; i++) {
                omg[k] += (-w2 * (float) Math.sin(alp[k] - psi) - c2 * omg[k] + wind) * hs;
                alp[k] += omg[k] * hs;
                lv[k] += (sk * (ropeL - len[k]) - sc * lv[k]) * hs;
                len[k] += lv[k] * hs;
            }
            if (!landed[k] && len[k] >= ropeL * 0.97f) {
                landed[k] = true;
                ringAt[k] = now;
            }
            if (Math.abs(omg[k]) > 0.03f || Math.abs(alp[k] - psi) > 0.02f || Math.abs(lv[k]) > ropeL * 0.05f
                    || Math.abs(len[k] - ropeL) > ropeL * 0.01f) still = false;
        }
        calm = still && state == 2;
        if (state == 3 && !alive) state = 0;
    }

    private void stepFall(int k, float dt) {
        float g = screenH * 2.6f;
        fvx[k] += gdx * g * dt;
        fvy[k] += gdy * g * dt;
        fx[k] += fvx[k] * dt;
        fy[k] += fvy[k] * dt;
        rot[k] += rotV[k] * dt;
        fAge[k] += dt;
        if (fAge[k] > 1.2f) gone[k] = true;
    }

    // ---------- drawing ----------

    void draw(Canvas c, long now, Paint p, Paint t) {
        if (state == 0) return;
        float nr = r * 0.07f;
        float tw = (now - t0) / 1000f;
        for (int k = 0; k < N; k++) {
            if (!started[k] || gone[k]) continue;
            float ax = cx + Renderer.COS[k * 5] * r * 0.74f, ay = cy + Renderer.SIN[k * 5] * r * 0.74f;
            float age = (now - sAt[k]) / 1000f;
            float appear = smooth(age / 0.18f);
            float pop = 0.7f + 0.3f * backOut(clamp(age / 0.28f, 0f, 1f));
            float x, y, rotD, strA = appear, pinA = appear, bodyA = appear, ex, ey, glow;
            if (falling[k]) {
                float fa = fAge[k], q = clamp(fa / 0.25f, 0f, 1f), e = 1f - (1f - q) * (1f - q);
                x = fx[k];
                y = fy[k];
                rotD = rot[k];
                strA = pinA = 1f - q;
                bodyA = clamp((1.15f - fa) / 0.4f, 0f, 1f);
                ex = x + (ax - x) * e;                       // the thread zips back up to its pin
                ey = y + (ay - y) * e;
                glow = clamp(1f - fa / 0.5f, 0f, 1f);
            } else {
                float ux = (float) Math.sin(alp[k]), uy = (float) Math.cos(alp[k]);
                x = ax + ux * len[k];
                y = ay + uy * len[k];
                ex = x - ux * nr * pop;
                ey = y - uy * nr * pop;
                rotD = (float) Math.toDegrees(alp[k] - psi) * 0.8f;
                glow = smooth((age - 0.25f) / 0.5f) * (0.92f + 0.08f * (float) Math.sin(tw * 7f + k * 1.9f));
            }

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Math.max(1.2f, r * 0.008f));
            p.setColor(withA(STRING[preset], (int) (200 * strA)));
            c.drawLine(ax, ay, ex, ey, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(withA(GOLD, (int) (255 * pinA)));
            c.drawCircle(ax, ay, r * 0.014f, p);

            String s = NUM[k];
            float size = r * 0.105f * (s.length() > 1 ? 0.82f : 1f), base = size * 0.35f;
            t.setTextSize(size);
            c.save();
            c.translate(x, y);
            c.rotate(rotD);
            c.scale(pop, pop);
            if (preset == 1) {                              // brass plate
                p.setStyle(Paint.Style.FILL);
                p.setColor(withA(0xFF141A24, (int) (215 * bodyA)));
                c.drawCircle(0f, 0f, nr, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(r * 0.012f);
                p.setColor(withA(GOLD, (int) (240 * bodyA)));
                c.drawCircle(0f, 0f, nr, p);
                t.setStyle(Paint.Style.FILL);
                t.setColor(withA(GOLD, (int) (255 * bodyA)));
                c.drawText(s, 0f, base, t);
            } else if (preset == 2) {                       // lantern
                lantern.setAlpha((int) (255 * glow * bodyA));
                c.drawCircle(0f, 0f, nr * 2.8f, lantern);
                p.setStyle(Paint.Style.FILL);
                p.setColor(withA(0xFFFFC27A, (int) (70 * bodyA)));
                c.drawCircle(0f, 0f, nr, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(r * 0.010f);
                p.setColor(withA(0xFFFFD27A, (int) (200 * bodyA)));
                c.drawCircle(0f, 0f, nr, p);
                t.setStyle(Paint.Style.FILL);
                t.setColor(withA(IVORY, (int) (255 * bodyA)));
                c.drawText(s, 0f, base, t);
            } else if (preset == 3) {                       // glass drop
                ice.setAlpha((int) (255 * bodyA));
                c.drawCircle(0f, 0f, nr * 2.2f, ice);
                p.setStyle(Paint.Style.FILL);
                p.setColor(withA(0xFFCFE8FF, (int) (50 * bodyA)));
                c.drawCircle(0f, 0f, nr, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(r * 0.008f);
                p.setColor(withA(0xFFDCEFFF, (int) (170 * bodyA)));
                c.drawCircle(0f, 0f, nr, p);
                t.setStyle(Paint.Style.FILL);
                t.setColor(withA(0xFFEAF6FF, (int) (255 * bodyA)));
                c.drawText(s, 0f, base, t);
            } else {                                        // plain numeral with a soft outline
                t.setStyle(Paint.Style.STROKE);
                t.setStrokeWidth(size * 0.14f);
                t.setColor(withA(0xFF000000, (int) (150 * bodyA)));
                c.drawText(s, 0f, base, t);
                t.setStyle(Paint.Style.FILL);
                t.setColor(withA(IVORY, (int) (255 * bodyA)));
                c.drawText(s, 0f, base, t);
            }
            c.restore();
            t.setStyle(Paint.Style.FILL);

            if (preset == 1 && ringAt[k] >= 0) {            // a ring where it lands, and where it lets go
                float rp = (now - ringAt[k]) / 600f;
                if (rp >= 0f && rp < 1f) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(r * 0.010f * (1f - rp));
                    p.setColor(withA(GOLD, (int) (150 * (1f - rp) * bodyA)));
                    c.drawCircle(x, y, nr * (1f + 1.8f * rp), p);
                }
            }
        }
    }

    // ---------- helpers ----------

    private static float backOut(float p) {
        float u = p - 1f;
        return 1f + 2.2f * u * u * u + 1.2f * u * u;
    }

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static int withA(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
