package com.rimon.livingclock;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Camera;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Random;

/**
 * One frame: photo, glass dial, gold seconds trail, hands, subject, falling numbers, shooting stars.
 *
 * Intro: the subject enters in one of three styles, the clock lifts above the subject with a soft glow
 * while the background dims, rewinds and returns to now, then settles back behind the subject.
 * Five rewind styles (see REWIND_NAMES in MainActivity):
 *   0 luminous wake + spring landing   1 mechanical ticking snap   2 dial ticks light up
 *   3 quick and subtle                 4 wake + ticks combined
 * Tapping the clock drops dark numbers that leave thin rays behind them.
 */
final class Renderer {

    private static final int BG = 0xFF0E1420, IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A;
    private static final int AMBER = 0xFFFFA94D, STAR = 0xFFFFF6DC;
    private static final int TRAIL = 10;

    // Shooting stars: slow and bold.
    private static final long STAR_MS = 1800, STAR_END = 600 + 1800;
    private static final long[] STAR_DELAY = {0, 300, 600};

    // Intro timeline in milliseconds. The rewind part depends on the chosen style.
    private static final long ENTER_MS = 1300;
    private static final long LIFT_IN_AT = 500, LIFT_IN_LEN = 700, LIFT_OUT_LEN = 900;
    private static final long BACK_AT = 1200;
    private static final long[] BACK_LEN = {1500, 1800, 1800, 600, 1600, 0};
    private static final long[] HOLD_LEN = {250, 150, 600, 80, 500, 0};
    private static final long[] FWD_LEN = {1700, 1800, 1800, 700, 1800, Forge.SETTLE_LEN};
    private static final long H = 3_600_000L;
    private static final long[] SPAN = {3 * H, 3 * H, 3 * H, H * 3 / 2, 3 * H, 3 * H};
    private static final int RATCHET = 48, FORGE = 5;
    private static final long THEME_MS = 1000;

    /** Entering a universe is slow; leaving one for the classic clock is a little quicker; ordinary changes stay short. */
    private long themeDur() {
        return Worlds.is(theme) ? Worlds.BUILD_MS : (Worlds.is(prevTheme) ? 2800L : THEME_MS);
    }

    private static final String[] NUM = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};

    static final float[] COS = new float[60];
    static final float[] SIN = new float[60];

    static {
        for (int i = 0; i < 60; i++) {
            double a = Math.toRadians(i * 6 - 90);
            COS[i] = (float) Math.cos(a);
            SIN[i] = (float) Math.sin(a);
        }
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint();
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint revealPaint = new Paint();
    private final Paint sheenPaint = new Paint();
    private final RadialGradient reveal = new RadialGradient(0f, 0f, 100f,
            new int[]{0xFF000000, 0xFF000000, 0x00000000}, new float[]{0f, 0.72f, 1f}, Shader.TileMode.CLAMP);
    private final LinearGradient sheen = new LinearGradient(-100f, 0f, 100f, 0f,
            new int[]{0x00FFF1D6, 0x70FFF1D6, 0x00FFF1D6}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
    private final Matrix fx = new Matrix();
    private final Matrix fm = new Matrix();
    private final Camera camera = new Camera();
    private boolean killed, worldMoving;
    private final Worlds worlds = new Worlds();
    private float worldBuild = 1f;
    private int lastTint;
    private PorterDuffColorFilter tintFilter;
    private int baseSleep = 3;
    private Scenes.Out sceneOut = Scenes.NONE;
    int fpsCap;
    private float sceneDim;
    private final RectF wedgeRect = new RectF();
    private final Path hourPath = new Path();
    private final Path minutePath = new Path();
    private final Calendar calendar = Calendar.getInstance();
    private final Random random = new Random();

    private final float[] lit = new float[60];
    final Gauge gauge = new Gauge();
    final Forge saber = new Forge();
    final Hang hang = new Hang();
    final Sleep sleep = new Sleep();
    final Band band = new Band();
    private boolean bandPrev;
    private float trailK = 1f, realH, realM, realS;
    private final ColorMatrix cm = new ColorMatrix(), cm2 = new ColorMatrix();
    private final Paint vignette = new Paint();
    private ColorMatrixColorFilter bgGrade, subjGrade;
    private float indFade = 1f, indSweep = 1f, nightLin, nightTarget, dialRadius = -1f;
    private int theme, prevTheme;
    private boolean themeInit;
    private long themeAt = -1L, nightMs = -1L, frameNow;

    private Scene scene;
    private final Bitmap[] dials = new Bitmap[Themes.COUNT];
    private int width, height, clockSize = 100;
    private boolean dirty = true, stars = true, introOn = true;
    private float cx, cy, radius;
    private float clockX = 0.34f, clockY = 0.27f, subjX = 0.5f, subjY = 0.5f;
    private int lastMinute = -1, introStyle, rewindStyle, rs, prevTick = -1;
    private long starBase = -1L, introBase = -1L;
    private long fwdAt, liftOutAt, introMs, lastFxMs = -1L, prevShown = -1L;
    private float fxWedge, fxNums, fxPulse = -1f, secA = 1f;

    Renderer() {
        revealPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        sheenPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextAlign(Paint.Align.CENTER);
        plan(0);
        cm.setSaturation(0.55f);                    // night grade for the wallpaper: darker, cooler, less colour
        cm2.setScale(0.36f, 0.40f, 0.52f, 1f);
        cm.postConcat(cm2);
        bgGrade = new ColorMatrixColorFilter(cm);
        cm.setSaturation(0.8f);                     // gentler on the person
        cm2.setScale(0.62f, 0.66f, 0.78f, 1f);
        cm.postConcat(cm2);
        subjGrade = new ColorMatrixColorFilter(cm);
    }

    // ---------- configuration ----------

    void setSize(int w, int h) {
        if (w != width || h != height) {
            width = w;
            height = h;
            dirty = true;
        }
    }

    void setScene(Scene s) {
        scene = s;
    }

    void readConfig(SharedPreferences p) {
        clockX = p.getFloat(Prefs.CLOCK_X, 0.34f);
        clockY = p.getFloat(Prefs.CLOCK_Y, 0.27f);
        clockSize = p.getInt(Prefs.CLOCK_SIZE, 100);
        subjX = p.getFloat(Prefs.SUBJ_X, 0.5f);
        subjY = p.getFloat(Prefs.SUBJ_Y, 0.5f);
        stars = p.getBoolean(Prefs.STARS, true);
        introOn = p.getBoolean(Prefs.INTRO, true);
        setRewind(p.getInt(Prefs.REWIND, 0));
        gauge.indicator = Math.max(0, Math.min(5, p.getInt(Prefs.INDICATOR, 1)));
        setTheme(p.getInt(Prefs.THEME, 0), System.currentTimeMillis());
        hang.preset = Math.max(0, Math.min(3, p.getInt(Prefs.NUMERALS, 0)));
        baseSleep = Math.max(0, Math.min(3, p.getInt(Prefs.SLEEP, 3)));
        sleep.changeStyle(sceneOut.v[2] >= 0 ? (int) sceneOut.v[2] : baseSleep, System.currentTimeMillis(), realH, realM, realS);
        band.readConfig(p);
        if (sleep.style == 0 && sleep.active()) sleep.reset();
        dirty = true;
    }

    void setClock(float x, float y) {
        clockX = clamp(x, 0f, 1f);
        clockY = clamp(y, 0f, 1f);
        cx = clockX * width;
        cy = clockY * height;
    }

    void setSubject(float x, float y) {
        subjX = clamp(x, -0.5f, 1.5f);
        subjY = clamp(y, -0.5f, 1.5f);
    }

    void setClockSize(int pct) {
        clockSize = pct;
        dirty = true;
    }

    void setStars(boolean on) {
        stars = on;
    }

    void setIntro(boolean on) {
        introOn = on;
    }

    void setRewind(int style) {
        rewindStyle = Math.max(0, Math.min(BACK_LEN.length - 1, style));
    }

    void spawnStars(long now) {
        starBase = now;
    }

    /** Starts the intro. Ignored while one is playing, unless forced (the app's preview). */
    void playIntro(long now, boolean force) {
        if (sleep.off() && !force) return;
        if (band.active()) return;                      // the music bands own the clock while they play
        if (!force && (!introOn || (introBase >= 0 && now - introBase < introMs + 1000))) return;
        introBase = now;
        gauge.due = true;
        introStyle = random.nextInt(3);
        plan(rewindStyle);
        Arrays.fill(lit, 0f);
        prevTick = -1;
        prevShown = -1L;
        lastFxMs = -1L;
    }

    private void plan(int style) {
        rs = style;
        if (style == FORGE) {
            fwdAt = Forge.SETTLE_AT;
            liftOutAt = Forge.OUT_AT;
            introMs = Forge.OUT_AT + Forge.OUT_LEN;
            return;
        }
        fwdAt = BACK_AT + BACK_LEN[style] + HOLD_LEN[style];
        liftOutAt = fwdAt + FWD_LEN[style] + 100;
        introMs = liftOutAt + LIFT_OUT_LEN;
    }

    boolean onClock(float x, float y) {
        float dx = x - cx, dy = y - cy, r = radius * 1.15f;
        return dx * dx + dy * dy <= r * r;
    }

    boolean inCenter(float x, float y) {
        float dx = x - cx, dy = y - cy, r = radius * 0.4f;
        return dx * dx + dy * dy <= r * r;
    }

    /** True while the pendulum or the flipped clock is out and the sensor is needed. */
    boolean sensing() {
        return gauge.active() || hang.needsSensor();
    }

    void closeGauge() {
        gauge.reset();
        hang.reset();
        band.kill();
    }

    /** One tap on the clock: the numerals hang, or (tapped again) let go. */
    void tapNumerals(long now) {
        hang.toggle(now);
    }

    boolean asleep() {
        return sleep.off();
    }

    boolean sleeping() {
        return sleep.sleeping();
    }

    void setSleepStyle(int style) {
        sleep.changeStyle(Math.max(0, Math.min(3, style)), System.currentTimeMillis(), realH, realM, realS);
    }

    /** Applies the merged result of the live scenes: overrides on top of what the app settings say. */
    void applyScene(Scenes.Out o) {
        sceneOut = o;
        float[] v = o.v;
        band.override((int) v[0], (int) v[1], (int) v[3]);
        band.beat.gain = v[4];
        sceneDim = v[5];
        fpsCap = (int) v[6];
        sleep.changeStyle(v[2] >= 0 ? (int) v[2] : baseSleep, System.currentTimeMillis(), realH, realM, realS);
    }

    /** Kill switch: one still frame of the photo, no clock, no timers. */
    void setKilled(boolean on) {
        killed = on;
        if (on) {
            gauge.reset();
            hang.reset();
            band.kill();
            sleep.reset();
            saber.on = false;
        }
        dirty = true;
    }

    /** Plugged in: every feature shuts down and the hands settle at 6. Unplugged: they return to the time. */
    void setSleeping(boolean on, long now, boolean instant) {
        if (sleep.style == 0) on = false;
        if (on == sleep.sleeping()) return;
        if (on) {
            gauge.reset();
            hang.reset();
            band.kill();
            introBase = -1L;
            starBase = -1L;
            themeAt = -1L;
            saber.on = false;
        }
        sleep.setPlugged(on, now, instant, realH, realM, realS);
    }

    float clockX() { return clockX; }
    float clockY() { return clockY; }
    float subjX() { return subjX; }
    float subjY() { return subjY; }

    void release() {
        sleep.repair.release();
        for (int i = 0; i < dials.length; i++) {
            if (dials[i] != null) {
                dials[i].recycle();
                dials[i] = null;
            }
        }
    }

    /** True while something is moving and frames should follow the display refresh. */
    boolean animating(long now) {
        if (killed) return false;
        return (introBase >= 0 && now - introBase < introMs)
                || (stars && starBase >= 0 && now - starBase < STAR_END)
                || gauge.active()
                || band.active()
                || hang.moving(now)
                || sleep.moving(now)
                || (themeAt >= 0 && now - themeAt < themeDur())
                || worldMoving
                || nightLin != nightTarget;
    }

    /** Idle: wake once a second, just after the second changes. */
    long delay(long now) {
        if (killed) return 60_000L;
        if (sleep.style == 3 && sleep.sleeping() && !sleep.moving(now)) {
            return sleep.repair.working() ? 33L : 1000 - now % 1000 + 5;   // mending: about 30 frames a second
        }
        if (sleep.sleeping() && !sleep.moving(now)) return sleep.style == 2 ? 83L : 30_000L;   // asleep: next to nothing
        if (Worlds.is(theme) || worlds.active()) {       // a universe breathes: about 24 frames a second, 12 on a low battery
            int fps = fpsCap > 0 ? Math.min(fpsCap, 24) : 24;
            if (!gauge.charging && gauge.pct < 15) fps = Math.min(fps, 12);
            return 1000L / fps;
        }
        return 1000 - now % 1000 + 5;
    }

    // ---------- rewind timing ----------

    /** 0 = now, 1 = fully rewound. Slightly negative while a spring overshoots past now. */
    private float rewindAt(long t) {
        if (t < BACK_AT) return 0f;
        if (t < fwdAt) return ease(false, (t - BACK_AT) / (float) BACK_LEN[rs]);
        return 1f - ease(true, (t - fwdAt) / (float) FWD_LEN[rs]);
    }

    private float ease(boolean forward, float p) {
        p = clamp(p, 0f, 1f);
        switch (rs) {
            case 1:  // mechanical: ticks that speed up going back and slow down coming home
                return forward ? ratchet(1f - (float) Math.pow(1f - p, 1.8))
                        : ratchet((float) Math.pow(p, 1.5));
            case 2:  // calm sine both ways
                return sine(p);
            case 3:  // quick and clean
                return smooth(p);
            default: // 0 and 4: calm back, spring landing
                return forward ? backOut(p) : sine(p);
        }
    }

    /** Steps in small quick moves, like a ratcheting movement. */
    private static float ratchet(float x) {
        float v = clamp(x, 0f, 1f) * RATCHET;
        float i = (float) Math.floor(v);
        return (i + smooth((v - i) * 1.7f)) / RATCHET;
    }

    /** Ends exactly at 1 after overshooting by about 2%. */
    private static float backOut(float p) {
        float u = p - 1f;
        return 1f + 1.8f * u * u * u + 0.8f * u * u;
    }

    // ---------- drawing ----------

    void draw(Canvas c, long now) {
        drawInner(c, now);
        if (!killed && sceneDim > 0.01f) c.drawColor(((int) (Math.min(0.85f, sceneDim) * 255f)) << 24);
    }

    private void drawInner(Canvas c, long now) {
        if (width <= 0 || height <= 0) return;
        if (dirty) layout();
        if (killed) {
            drawBackground(c, 0f);
            if (worlds.active()) worlds.env(c, 0L);
            if (scene != null && scene.subject != null) drawSubject(c, -1L, 0f);
            return;
        }

        frameNow = now;
        calendar.setTimeInMillis(now);
        int realMin = calendar.get(Calendar.MINUTE);
        if (realMin != lastMinute) {
            if (lastMinute >= 0 && stars && !sleep.off()) starBase = now;
            lastMinute = realMin;
            gauge.due = true;
        }

        long t = introBase >= 0 ? now - introBase : -1L;
        boolean intro = t >= 0 && t < introMs;
        float lift = 0f, dialAlpha = 1f, rewind = 0f;
        long shown = now;
        fxWedge = 0f;
        fxNums = 0f;
        fxPulse = -1f;
        secA = 1f;
        boolean forging = intro && rs == FORGE;
        if (forging) {
            lift = smooth(t / (float) Forge.DIM_IN) * (1f - smooth((t - Forge.OUT_AT) / (float) Forge.OUT_LEN));
        } else if (intro) {
            lift = smooth((t - LIFT_IN_AT) / (float) LIFT_IN_LEN)
                    * (1f - smooth((t - liftOutAt) / (float) LIFT_OUT_LEN));
            dialAlpha = smooth(t / 700f);
            rewind = rewindAt(t);
            if (rewind != 0f) {
                shown = now - (long) (SPAN[rs] * rewind);
                calendar.setTimeInMillis(shown);
            }
            // The seconds hand would strobe at this speed, so it fades out while time is moving.
            secA = 1f - smooth(Math.abs(rewind) * 8f);
        }

        int sec = calendar.get(Calendar.SECOND);
        float secF = intro ? sec + calendar.get(Calendar.MILLISECOND) / 1000f : sec;
        float minF = calendar.get(Calendar.MINUTE) + secF / 60f;
        float hourF = calendar.get(Calendar.HOUR) + minF / 60f;
        sleep.pct = gauge.pct;
        gauge.update(now);
        lift = Math.max(lift, gauge.lift);
        if (band.active()) lift = 0f;
        float scale = (1f + 0.12f * (forging ? gauge.lift : lift)) * gauge.pop();
        gauge.layout(cx, cy, radius, scale, width, height);
        indFade = 1f;
        indSweep = 1f;
        if (gauge.indicator == 4) {          // intro-only arc: fills as the clock lands, then fades
            indFade = 0f;
            if (intro && t >= fwdAt) {
                indSweep = smooth((t - fwdAt) / (float) FWD_LEN[rs]);
                indFade = smooth((t - fwdAt) / 300f) * (1f - smooth((t - liftOutAt) / (float) LIFT_OUT_LEN));
            }
        } else if (intro) {
            indSweep = smooth((t - 400) / 1400f);
        }
        if (intro && !forging) updateFx(t, now, shown, rewind, minF);
        saber.on = false;
        if (forging) {
            saber.update(t, hourF * 30f, minF * 6f, secF * 6f);
            secA = saber.handA;
        }
        float nd = nightMs < 0 ? 0f : Math.min(0.1f, (now - nightMs) / 1000f);
        nightMs = now;
        if (nightLin != nightTarget) nightLin += clamp(nightTarget - nightLin, -nd / 1.6f, nd / 1.6f);
        float night = smooth(nightLin);

        realH = hourF * 30f;
        realM = minF * 6f;
        realS = secF * 6f;
        float hA = realH, mA = realM, sA = realS;        // asleep, the hands follow the sleep physics instead
        if (sleep.active()) {
            sleep.update(now);
            hA = sleep.angle(0, realH);
            mA = sleep.angle(1, realM);
            sA = sleep.angle(2, realS);
            secA = 1f;
        }
        trailK = 1f - sleep.amount;
        indFade *= 1f - sleep.amount;
        hang.layout(cx, cy, radius, height);
        hang.update(now, gauge.gx(), gauge.gy());

        band.place(cx, cy, radius, width, height);
        band.update(now, Worlds.is(theme) ? Worlds.look(theme) : theme);
        boolean bandOn = band.active();
        if (bandOn && !bandPrev) {                       // the bands take over: close the pendulum, flip and hanging numerals
            gauge.reset();
            hang.reset();
        }
        bandPrev = bandOn;

        drawBackground(c, night);
        worldMoving = worlds.step(theme, now);
        if (worlds.active()) worlds.env(c, now);

        if (lift > 0f) {
            dimPaint.setAlpha((int) (255 * lift));
            c.save();
            c.translate(cx, cy);
            c.drawRect(-cx, -cy, width - cx, height - cy, dimPaint);
            c.restore();
        }
        band.drawDim(c);
        if (forging) saber.drawLight(c, cx, cy);

        // Clock behind the subject. While lifted, a second copy with a glow and the rewind
        // effects fades in above the subject.
        float sg = sleep.glow(now);
        if (sg > 0.01f) {                                // a warm halo that breathes
            glowPaint.setAlpha((int) (255 * sg));
            drawGlow(c, 1f);
            glowPaint.setAlpha(255);
        }
        float behind = dialAlpha * (1f - (forging ? Math.max(gauge.lift, lift) : gauge.lift)) * sleep.dim(now) * band.clockAlpha;
        if (behind > 0.01f) {
            if (sleep.fixing()) drawRepairClock(c, hA, mA, sA, sec, scale, behind);
            else if (band.cut >= 0.999f) drawClock(c, hA, mA, sA, sec, scale, behind, false);
            else if (band.cut > 0.002f) drawClockCut(c, hA, mA, sA, sec, scale, behind, band.cut);
        }
        band.draw(c);
        if (scene != null && scene.subject != null) drawSubject(c, intro ? t : -1L, night);
        if (lift > 0f) {
            float r = radius * 2.3f;
            int sc = c.saveLayerAlpha(cx - r, cy - r, cx + r, cy + r, (int) (255 * lift));
            if (!forging) drawGlow(c, scale);
            drawFace(c, hA, mA, sA, sec, scale, now);
            c.restoreToCount(sc);
        }

        gauge.drawPendulum(c, now);
        if (stars && starBase >= 0 && !sleep.off() && !bandOn) drawStars(c, now);
    }

    /** Charging: the clock turns around on its vertical axis; the back shows the movement being serviced. */
    private void drawRepairClock(Canvas c, float hDeg, float mDeg, float sDeg, int sec, float scale, float alpha) {
        Repair rp = sleep.repair;
        float a = rp.angle() % 360f;
        if (a < 0f) a += 360f;
        boolean flat = a < 0.05f || a > 359.95f;
        if (flat && rp.wear() < 0.01f && rp.shine() < 0f) {
            drawClock(c, hDeg, mDeg, sDeg, sec, scale, alpha, false);
            return;
        }
        boolean back = a > 90f && a < 270f;
        float rot = a <= 90f ? a : (a < 270f ? a - 180f : a - 360f);
        float side = (float) Math.abs(Math.sin(Math.toRadians(a)));
        int sc = -1;
        float r2 = radius * 2.3f;
        if (alpha < 0.99f) sc = c.saveLayerAlpha(cx - r2, cy - r2, cx + r2, cy + r2, (int) (255 * alpha));
        if (side > 0.02f) {                                  // a soft shadow grows under the turning clock
            paint.setStyle(Paint.Style.FILL);
            for (int k = 3; k >= 1; k--) {
                paint.setColor(withAlpha(0x000000, (int) (38 * side)));
                c.drawCircle(cx + radius * 0.05f * side, cy + radius * 0.07f * side, radius * (1f + 0.05f * k) * scale, paint);
            }
        }
        c.save();
        camera.save();
        camera.setLocation(0f, 0f, -Math.max(8f, radius * 0.0445f));
        camera.rotateY(rot);
        camera.getMatrix(fm);
        camera.restore();
        fm.preTranslate(-cx, -cy);
        fm.postTranslate(cx, cy);
        c.concat(fm);
        float lf = rp.lift() * scale;
        c.scale(lf, lf, cx, cy);
        if (back) {
            rp.drawBack(c, cx, cy, radius);
        } else {
            drawClock(c, hDeg, mDeg, sDeg, sec, 1f, 1f, false);
            rp.drawWear(c, cx, cy, radius, rp.wear());
            rp.drawShine(c, cx, cy, radius, rp.shine());
        }
        if (side > 0.02f) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(0x000000, (int) (150 * side)));
            c.drawCircle(cx, cy, radius, paint);
        }
        c.restore();
        if (sc >= 0) c.restoreToCount(sc);
    }

    /**
     * The clock with a soft-edged circle closing around the hub: the hands are drawn in tip first, with no
     * snap. Used only while the bands arrive or the clock rebuilds, so the layer costs nothing in between.
     */
    private void drawClockCut(Canvas c, float hDeg, float mDeg, float sDeg, int sec, float scale,
                              float alpha, float cutK) {
        float r = radius * 2.3f;
        int sc = c.saveLayer(cx - r, cy - r, cx + r, cy + r, null);
        drawClock(c, hDeg, mDeg, sDeg, sec, scale, alpha, false);
        float k = Math.max(0.01f, radius * 1.2f * cutK / 72f);   // the gradient is solid out to 72% of its radius
        fx.setScale(k, k);
        fx.postTranslate(cx, cy);
        reveal.setLocalMatrix(fx);
        revealPaint.setShader(reveal);
        c.drawRect(cx - r, cy - r, cx + r, cy + r, revealPaint);
        c.restoreToCount(sc);
    }

    /** Per-frame state for the rewind effects: wedge length, lit ticks, numerals, landing pulse. */
    private void updateFx(long t, long now, long shown, float rewind, float minF) {
        float dt = lastFxMs >= 0 ? Math.min(0.1f, (now - lastFxMs) / 1000f) : 0f;
        // Minute-hand speed in degrees per second. Positive means clockwise (time moving forward).
        float speed = (dt > 0.001f && prevShown >= 0) ? (shown - prevShown) / 10000f / dt : 0f;
        lastFxMs = now;
        prevShown = shown;

        boolean wake = rs == 0 || rs == 4, ticks = rs == 2 || rs == 4;
        if (wake) fxWedge = clamp(speed * 0.08f, -140f, 140f);

        if (ticks) {
            float decay = (float) Math.exp(-3.2f * dt);
            for (int i = 0; i < 60; i++) lit[i] *= decay;
            int cur = (int) minF % 60;
            if (prevTick < 0) prevTick = cur;
            int dir = speed >= 0f ? 1 : -1;
            int steps = (((cur - prevTick) * dir) % 60 + 60) % 60;
            if (steps > 30) {
                lit[cur] = 1f;
            } else {
                for (int s = 0; s <= steps; s++) lit[(((prevTick + dir * s) % 60) + 60) % 60] = 1f;
            }
            prevTick = cur;
            fxNums = smooth((rewind - 0.85f) / 0.15f);
        }

        if (wake) {
            long landed = t - (fwdAt + FWD_LEN[rs]);
            if (landed >= 0 && landed < 700) fxPulse = landed / 700f;
        }
    }

    // ---------- themes and the night grade ----------

    void setTheme(int t, long now) {
        t = Math.max(0, Math.min(Themes.COUNT - 1, t));
        if (!themeInit) {                                // first read: no animation
            themeInit = true;
            theme = prevTheme = t;
            worlds.snap(t);
            nightLin = nightTarget = t == Themes.NOIR ? 1f : 0f;
            return;
        }
        if (t == theme) return;
        prevTheme = theme;
        theme = t;
        themeAt = now;
        nightTarget = t == Themes.NOIR ? 1f : 0f;
    }

    void cycleTheme(long now) {
        setTheme((theme + 1) % Themes.COUNT, now);
    }

    int theme() {
        return theme;
    }

    /** Double-tap target: the upper part of the cutout, where the head is. */
    boolean onSubjectTop(float x, float y) {
        if (scene == null || scene.subject == null) return false;
        Bitmap s = scene.subject;
        int px = Math.round(x - (subjX * width - s.getWidth() / 2f));
        int py = Math.round(y - (subjY * height - s.getHeight() / 2f));
        if (py < scene.top - 40 || py > scene.top + (scene.bottom - scene.top) * 0.30f) return false;
        for (int dy = -24; dy <= 24; dy += 24) {
            for (int dx = -24; dx <= 24; dx += 24) {
                int qx = px + dx, qy = py + dy;
                if (qx >= 0 && qy >= 0 && qx < s.getWidth() && qy < s.getHeight()
                        && (s.getPixel(qx, qy) >>> 24) > 40) return true;
            }
        }
        return false;
    }

    private Bitmap dialFor(int th) {
        Bitmap b = dials[th];
        if (b == null) {
            int size = (int) Math.ceil(radius * 2.1f) + 4;
            b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            if (th == 0) drawDial(new Canvas(b), size / 2f);
            else if (Worlds.is(th)) worlds.dial(th, new Canvas(b), size / 2f, radius);
            else Themes.dial(th, new Canvas(b), size / 2f, radius, paint);
            dials[th] = b;
        }
        return b;
    }

    /** Night grade spreads out from the clock like an eclipse; leaving Noir pulls it back in. */
    private void drawBackground(Canvas c, float night) {
        Bitmap bg = scene != null ? scene.bg : null;
        if (night <= 0.001f) {
            if (bg != null) c.drawBitmap(bg, 0f, 0f, bitmapPaint);
            else c.drawColor(BG);
            return;
        }
        if (night >= 0.999f) {
            drawGraded(c, bg);
        } else {
            if (bg != null) c.drawBitmap(bg, 0f, 0f, bitmapPaint);
            else c.drawColor(BG);
            int sc = c.saveLayer(0f, 0f, width, height, null);
            drawGraded(c, bg);
            float reach = (float) Math.hypot(Math.max(cx, width - cx), Math.max(cy, height - cy)) * 1.2f;
            float k = Math.max(0.01f, reach * night / 100f);
            fx.setScale(k, k);
            fx.postTranslate(cx, cy);
            reveal.setLocalMatrix(fx);
            revealPaint.setShader(reveal);
            c.drawRect(0f, 0f, width, height, revealPaint);
            c.restoreToCount(sc);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(radius * 0.05f);
            paint.setColor(withAlpha(0xBFD8FF, (int) (60 * (1f - night))));
            c.drawCircle(cx, cy, reach * night * 0.86f, paint);
            paint.setStrokeWidth(radius * 0.012f);
            paint.setColor(withAlpha(0xE6F0FF, (int) (170 * (1f - night))));
            c.drawCircle(cx, cy, reach * night * 0.86f, paint);
        }
        vignette.setAlpha((int) (255 * night));
        c.save();
        c.translate(width / 2f, height / 2f);
        c.drawRect(-width / 2f, -height / 2f, width / 2f, height / 2f, vignette);
        c.restore();
    }

    private void drawGraded(Canvas c, Bitmap bg) {
        if (bg == null) {
            c.drawColor(0xFF05070C);
            return;
        }
        bitmapPaint.setColorFilter(bgGrade);
        c.drawBitmap(bg, 0f, 0f, bitmapPaint);
        bitmapPaint.setColorFilter(null);
    }

    /** The cut-out picks up a little of the universe's light so it belongs to the scene. */
    private android.graphics.ColorFilter worldFilter() {
        int tint = worlds.tintColor();
        if (tint == 0) return null;
        if (tint != lastTint || tintFilter == null) {
            lastTint = tint;
            tintFilter = new PorterDuffColorFilter(tint, PorterDuff.Mode.SRC_ATOP);
        }
        return tintFilter;
    }

    private ColorMatrixColorFilter subjectFilter(float night) {
        if (night <= 0.001f) return null;
        if (night >= 0.999f) return subjGrade;
        cm.setSaturation(1f - 0.2f * night);             // in between: a new filter per frame, only while changing
        cm2.setScale(1f - 0.38f * night, 1f - 0.34f * night, 1f - 0.22f * night, 1f);
        cm.postConcat(cm2);
        return new ColorMatrixColorFilter(cm);
    }

    private void layout() {
        dirty = false;
        radius = Math.min(width * 0.21f * clockSize / 100f, width * 0.46f);
        cx = clockX * width;
        cy = clockY * height;

        if (radius != dialRadius) {              // dials are rebuilt lazily, one per theme, only when the size changes
            dialRadius = radius;
            release();
        }
        vignette.setShader(new RadialGradient(0f, 0f, Math.max(width, height) * 0.75f,
                new int[]{0x00000000, 0x66000000, 0xBB000000}, new float[]{0.35f, 0.7f, 1f}, Shader.TileMode.CLAMP));
        saber.layout(radius, width, height);
        worlds.layout(width, height, cx, cy, radius);

        // Soft halo and background vignette: gradients drawn around (0, 0) and moved with translate().
        glowPaint.setShader(new RadialGradient(0f, 0f, radius * 2f,
                new int[]{0x00FFC773, 0x66FFC773, 0x2AFFB35A, 0x00FFB35A},
                new float[]{0f, 0.45f, 0.72f, 1f}, Shader.TileMode.CLAMP));
        dimPaint.setShader(new RadialGradient(0f, 0f, Math.max(width, height) * 0.8f,
                new int[]{0x20000000, 0x55000000, 0xB8000000},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));

        float hourLen = radius * 0.52f, minLen = radius * 0.80f, hw = radius * 0.05f;
        hourPath.rewind();
        hourPath.moveTo(0, radius * 0.12f);
        hourPath.quadTo(hw * 1.8f, -hourLen * 0.35f, 0, -hourLen);
        hourPath.quadTo(-hw * 1.8f, -hourLen * 0.35f, 0, radius * 0.12f);
        hourPath.close();

        minutePath.rewind();
        float mw = radius * 0.016f, d = radius * 0.07f, dy = -minLen * 0.78f;
        minutePath.addRect(-mw, -minLen, mw, radius * 0.14f, Path.Direction.CW);
        minutePath.moveTo(0, dy - d);
        minutePath.lineTo(d * 0.55f, dy);
        minutePath.lineTo(0, dy + d);
        minutePath.lineTo(-d * 0.55f, dy);
        minutePath.close();
    }

    /** The clock in the current theme; during a theme change the new one grows out of the old one. */
    private void drawClock(Canvas c, float hDeg, float mDeg, float sDeg, int sec, float scale,
                           float alpha, boolean effects) {
        float p = themeAt < 0 ? 1f : clamp((frameNow - themeAt) / (float) themeDur(), 0f, 1f);
        worldBuild = Worlds.is(theme) ? p : 1f;
        if (p >= 1f) {
            drawOne(c, theme, hDeg, mDeg, sDeg, sec, scale, alpha, effects);
            return;
        }
        if (Worlds.is(theme)) {                              // a universe builds itself; the old clock just dissolves
            drawOne(c, prevTheme, hDeg, mDeg, sDeg, sec, scale * (1f + 0.05f * smooth(p)), alpha * (1f - smooth(p / 0.3f)), effects);
            drawOne(c, theme, hDeg, mDeg, sDeg, sec, scale, alpha, effects);
            return;
        }
        float e = smooth(p), reach = radius * 1.3f * e;
        drawOne(c, prevTheme, hDeg, mDeg, sDeg, sec, scale * (1f + 0.04f * e), alpha * (1f - smooth((p - 0.15f) / 0.7f)), effects);

        float r = radius * 2.3f;
        int sc = c.saveLayer(cx - r, cy - r, cx + r, cy + r, null);
        drawOne(c, theme, hDeg, mDeg, sDeg, sec, scale * (0.94f + 0.06f * e), alpha, effects);
        float k = Math.max(0.01f, reach / 100f);
        fx.setScale(k, k);
        fx.postTranslate(cx, cy);
        reveal.setLocalMatrix(fx);
        revealPaint.setShader(reveal);
        c.drawRect(cx - r, cy - r, cx + r, cy + r, revealPaint);
        c.restoreToCount(sc);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.05f);
        paint.setColor(withAlpha(GOLD, (int) (60 * (1f - p))));
        c.drawCircle(cx, cy, reach * 0.86f, paint);
        paint.setStrokeWidth(radius * 0.012f);
        paint.setColor(withAlpha(IVORY, (int) (200 * (1f - p))));
        c.drawCircle(cx, cy, reach * 0.86f, paint);
    }

    private void drawOne(Canvas c, int th, float hDeg, float mDeg, float sDeg, int sec, float scale,
                         float alpha, boolean effects) {
        int sc = -1;
        if (alpha < 1f) {
            float r = radius * 2.3f;
            sc = c.saveLayerAlpha(cx - r, cy - r, cx + r, cy + r, (int) (255 * alpha));
        }
        c.save();
        c.scale(scale, scale, cx, cy);

        boolean sab = effects && saber.on;                   // only the lifted copy plays the lightsaber intro
        int clipped = -1;
        if (sab && saber.wedge < 359.5f) {
            clipped = c.save();
            saber.clipWedge(c, cx, cy, radius * 1.1f);
        }
        Bitmap d = dialFor(th);
        if (Worlds.is(th)) bitmapPaint.setAlpha((int) (255 * Worlds.dialA(buildFor(th))));
        c.drawBitmap(d, cx - d.getWidth() / 2f, cy - d.getHeight() / 2f, bitmapPaint);
        bitmapPaint.setAlpha(255);
        if (gauge.indicator != 0 && indFade > 0.02f) gauge.drawIndicator(c, indFade, indSweep);
        if (effects) drawEffectsUnder(c, mDeg);
        if (Worlds.is(th)) {
            worlds.under(th, c, cx, cy, radius, buildFor(th), frameNow);
        } else if (th == 0) {
            if (secA > 0.02f && trailK > 0.02f) drawTrail(c, sec);
        } else if (!(th == 3 && hang.active())) {
            Themes.under(th, c, cx, cy, radius, hDeg, mDeg, textPaint);
        }
        if (clipped >= 0) c.restoreToCount(clipped);
        hang.draw(c, frameNow, paint, textPaint);

        if (sab) {
            saber.drawBlades(c, cx, cy, radius);
            if (saber.handA > 0.02f) drawThemedHands(c, th, hDeg, mDeg, sDeg, saber.handA);
        } else {
            drawThemedHands(c, th, hDeg, mDeg, sDeg, 1f);
        }
        if (effects && fxPulse >= 0f) drawPulse(c);
        c.restore();
        if (sc >= 0) c.restoreToCount(sc);
    }

    private float buildFor(int th) {
        return th == theme ? worldBuild : 1f;
    }

    private void drawThemedHands(Canvas c, int th, float hDeg, float mDeg, float sDeg, float a) {
        int sc = -1;
        if (a < 1f) {
            float r = radius * 1.1f;
            sc = c.saveLayerAlpha(cx - r, cy - r, cx + r, cy + r, (int) (255 * a));
        }
        if (th == 0) drawHands(c, hDeg, mDeg, sDeg);
        else if (Worlds.is(th)) worlds.hands(th, c, cx, cy, radius, hDeg, mDeg, sDeg, secA, buildFor(th), frameNow);
        else Themes.hands(th, c, cx, cy, radius, hDeg, mDeg, sDeg, secA, paint);
        if (sc >= 0) c.restoreToCount(sc);
    }

    /** Lit ticks, numerals, the luminous wedge and the ghost hands. Drawn above the dial, under the hands. */
    private void drawEffectsUnder(Canvas c, float minDeg) {
        if (rs == 2 || rs == 4) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 60; i++) {
                float l = lit[i];
                if (l < 0.03f) continue;
                boolean hr = i % 5 == 0;
                float rin = radius * (hr ? 0.80f : 0.90f), rout = radius * 0.94f;
                float x1 = cx + COS[i] * rin, y1 = cy + SIN[i] * rin;
                float x2 = cx + COS[i] * rout, y2 = cy + SIN[i] * rout;
                paint.setStrokeWidth(radius * (hr ? 0.075f : 0.05f));
                paint.setColor(withAlpha(AMBER, (int) (110 * l)));
                c.drawLine(x1, y1, x2, y2, paint);
                paint.setStrokeWidth(radius * (hr ? 0.04f : 0.022f));
                paint.setColor(withAlpha(GOLD, (int) (255 * l)));
                c.drawLine(x1, y1, x2, y2, paint);
            }
        }

        if (fxNums > 0.02f) {
            float size = radius * 0.16f;
            textPaint.setStyle(Paint.Style.FILL);
            textPaint.setTextSize(size);
            textPaint.setColor(withAlpha(IVORY, (int) (210 * fxNums)));
            for (int i = 1; i <= 12; i++) {
                int k = (i * 5) % 60;
                c.drawText(NUM[i - 1], cx + COS[k] * radius * 0.64f,
                        cy + SIN[k] * radius * 0.64f + size * 0.35f, textPaint);
            }
        }

        float w = Math.abs(fxWedge);
        if (w > 4f) {
            float r = radius * 0.84f, a0 = minDeg - 90f;
            wedgeRect.set(cx - r, cy - r, cx + r, cy + r);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(GOLD, 22));
            for (int k = 0; k < 6; k++) {
                float len = w * (1f - k / 6f);
                // The wedge trails behind the hand: counter-clockwise when time runs forward.
                if (fxWedge > 0f) c.drawArc(wedgeRect, a0 - len, len, true, paint);
                else c.drawArc(wedgeRect, a0, len, true, paint);
            }
            if (w > 8f) {
                float sgn = fxWedge > 0f ? 1f : -1f;
                hand(c, minutePath, minDeg - sgn * w * 0.33f, 0.024f, 0.30f);
                hand(c, minutePath, minDeg - sgn * w * 0.66f, 0.024f, 0.15f);
            }
        }
    }

    /** One soft ring leaves the dial when the clock lands on the real time. */
    private void drawPulse(Canvas c) {
        float p = fxPulse, e = 1f - (1f - p) * (1f - p);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(radius * 0.035f * (1f - p) + 1f);
        paint.setColor(withAlpha(GOLD, (int) (170 * (1f - p))));
        c.drawCircle(cx, cy, radius * (1f + 0.5f * e), paint);
    }

    /** The lifted clock's face: the dial, or after a triple tap the liquid back, turning in 3D. */
    private void drawFace(Canvas c, float hDeg, float mDeg, float sDeg, int sec, float scale, long now) {
        float a = gauge.angle;
        if (a < 0.4f) {
            drawClock(c, hDeg, mDeg, sDeg, sec, scale, 1f, true);
            return;
        }
        c.save();
        gauge.applyFlip(c);
        if (a <= 90f) drawClock(c, hDeg, mDeg, sDeg, sec, scale, 1f, true);
        else gauge.drawBack(c, now);
        gauge.drawShade(c);
        c.restore();
    }

    private void drawGlow(Canvas c, float scale) {
        c.save();
        c.translate(cx, cy);
        c.scale(scale, scale);
        c.drawCircle(0f, 0f, radius * 2f, glowPaint);
        c.restore();
    }

    /**
     * The subject never slides, so its edges stay put. Three entrances: settle (fade with a slight
     * zoom-out from the feet), bloom (soft circular reveal growing from the clock), sheen (fade in
     * with a diagonal band of light sweeping across).
     */
    private void drawSubject(Canvas c, long t, float night) {
        bitmapPaint.setColorFilter(night <= 0.001f ? worldFilter() : subjectFilter(night));
        drawSubjectRaw(c, t);
        bitmapPaint.setColorFilter(null);
    }

    private void drawSubjectRaw(Canvas c, long t) {
        Bitmap s = scene.subject;
        float left = subjX * width - s.getWidth() / 2f, top = subjY * height - s.getHeight() / 2f;
        if (t < 0 || t >= ENTER_MS) {
            c.drawBitmap(s, left, top, bitmapPaint);
            return;
        }

        float p = t / (float) ENTER_MS;
        float e = 1f - (1f - p) * (1f - p) * (1f - p);
        if (introStyle == 0) {
            c.save();
            float k = 1.04f - 0.04f * e;
            c.scale(k, k, subjX * width, top + s.getHeight());
            bitmapPaint.setAlpha((int) (255 * e));
            c.drawBitmap(s, left, top, bitmapPaint);
            bitmapPaint.setAlpha(255);
            c.restore();
            return;
        }

        int sc = c.saveLayer(0f, 0f, width, height, null);
        if (introStyle == 1) {
            c.drawBitmap(s, left, top, bitmapPaint);
            float reach = (float) Math.hypot(Math.max(cx, width - cx), Math.max(cy, height - cy)) * 1.2f;
            float k = Math.max(0.01f, reach * e / 100f);
            fx.setScale(k, k);
            fx.postTranslate(cx, cy);
            reveal.setLocalMatrix(fx);
            revealPaint.setShader(reveal);
            c.drawRect(0f, 0f, width, height, revealPaint);
        } else {
            bitmapPaint.setAlpha((int) (255 * Math.min(1f, p / 0.35f)));
            c.drawBitmap(s, left, top, bitmapPaint);
            bitmapPaint.setAlpha(255);
            float q = p * p * (3f - 2f * p);
            fx.setScale(width * 0.0045f, 1f);
            fx.postRotate(20f);
            fx.postTranslate(width * (-0.35f + 1.7f * q), height * 0.5f);
            sheen.setLocalMatrix(fx);
            sheenPaint.setShader(sheen);
            c.drawRect(0f, 0f, width, height, sheenPaint);
        }
        c.restoreToCount(sc);
    }

    private void drawDial(Canvas k, float c0) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(c0, c0, radius,
                new int[]{0x40FFFFFF, 0x1CFFFFFF, 0x66000000},
                new float[]{0f, 0.8f, 1f}, Shader.TileMode.CLAMP));
        k.drawCircle(c0, c0, radius, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.02f);
        paint.setColor(0x33000000);
        k.drawCircle(c0, c0, radius * 0.98f, paint);
        paint.setStrokeWidth(radius * 0.006f);
        paint.setColor(0x80FFFFFF);
        k.drawCircle(c0, c0, radius * 0.98f, paint);

        for (int i = 0; i < 60; i++) {
            boolean hour = i % 5 == 0;
            float rin = radius * (hour ? 0.80f : 0.90f), rout = radius * 0.94f;
            float x1 = c0 + COS[i] * rin, y1 = c0 + SIN[i] * rin;
            float x2 = c0 + COS[i] * rout, y2 = c0 + SIN[i] * rout;
            float w = radius * (hour ? 0.035f : 0.013f);
            paint.setStrokeWidth(w + radius * 0.02f);
            paint.setColor(0x55000000);
            k.drawLine(x1, y1, x2, y2, paint);
            paint.setStrokeWidth(w);
            paint.setColor(IVORY);
            k.drawLine(x1, y1, x2, y2, paint);
        }
    }

    private void drawTrail(Canvas c, int sec) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int t = 0; t < TRAIL; t++) {
            float f = 1f - t / (float) TRAIL;
            float a = f * f * secA * trailK;
            int i = (sec - t + 60) % 60;
            float rin = radius * (i % 5 == 0 ? 0.80f : 0.90f), rout = radius * 0.94f;
            float x1 = cx + COS[i] * rin, y1 = cy + SIN[i] * rin;
            float x2 = cx + COS[i] * rout, y2 = cy + SIN[i] * rout;

            paint.setStrokeWidth(radius * 0.05f * (0.5f + 0.5f * f));
            paint.setColor(withAlpha(AMBER, (int) (120 * a)));
            c.drawLine(x1, y1, x2, y2, paint);
            paint.setStrokeWidth(radius * 0.016f);
            paint.setColor(withAlpha(GOLD, (int) (255 * a)));
            c.drawLine(x1, y1, x2, y2, paint);
        }
    }

    private void drawHands(Canvas c, float hourDeg, float minuteDeg, float secDeg) {
        hand(c, hourPath, hourDeg, 0.03f, 1f);
        hand(c, minutePath, minuteDeg, 0.024f, 1f);

        if (secA > 0.02f) {
            c.save();
            c.translate(cx, cy);
            c.rotate(secDeg);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(radius * 0.05f);
            paint.setColor(withAlpha(GOLD, (int) (70 * secA)));
            c.drawLine(0, radius * 0.18f, 0, -radius * 0.9f, paint);
            paint.setStrokeWidth(radius * 0.012f);
            paint.setColor(withAlpha(GOLD, (int) (255 * secA)));
            c.drawLine(0, radius * 0.18f, 0, -radius * 0.9f, paint);
            paint.setStyle(Paint.Style.FILL);
            c.drawCircle(0, radius * 0.18f, radius * 0.035f, paint);
            c.restore();
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x80000000);
        c.drawCircle(cx, cy, radius * 0.065f, paint);
        paint.setColor(IVORY);
        c.drawCircle(cx, cy, radius * 0.05f, paint);
        paint.setColor(GOLD);
        c.drawCircle(cx, cy, radius * 0.018f, paint);
    }

    private void hand(Canvas c, Path p, float deg, float outline, float a) {
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(radius * outline);
        paint.setColor(withAlpha(0x000000, (int) (128 * a)));
        c.drawPath(p, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(IVORY, (int) (255 * a)));
        c.drawPath(p, paint);
        c.restore();
    }

    /** Three slow, bold stars leave the top centre for the bottom-left, bottom-right and bottom-centre. */
    private void drawStars(Canvas c, long now) {
        float x0 = width * 0.5f, y0 = -height * 0.02f;
        float[] tx = {-width * 0.03f, width * 1.03f, width * 0.5f};
        float ty = height * 1.03f;
        float bw = Math.max(3f, width * 0.0075f);

        for (int i = 0; i < 3; i++) {
            float t = (now - starBase - STAR_DELAY[i]) / (float) STAR_MS;
            if (t < 0f || t > 1f) continue;

            float e = t * t * (3f - 2f * t);
            float fade = t < 0.75f ? 1f : (1f - t) / 0.25f;
            float dx = tx[i] - x0, dy = ty - y0;
            float tail = Math.max(0f, e - 0.45f);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int k = 0; k < 6; k++) {
                float p0 = tail + (e - tail) * k / 6f;
                float p1 = tail + (e - tail) * (k + 1) / 6f;
                paint.setStrokeWidth(bw * (0.35f + 0.65f * (k + 1) / 6f));
                paint.setColor(withAlpha(STAR, (int) (255 * fade * (k + 1) / 6f)));
                c.drawLine(x0 + dx * p0, y0 + dy * p0, x0 + dx * p1, y0 + dy * p1, paint);
            }

            float hx = x0 + dx * e, hy = y0 + dy * e;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(STAR, (int) (90 * fade)));
            c.drawCircle(hx, hy, bw * 2.6f, paint);
            paint.setColor(withAlpha(0xFFFFFF, (int) (255 * fade)));
            c.drawCircle(hx, hy, bw, paint);
        }
    }

    // ---------- helpers ----------

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static float sine(float p) {
        return 0.5f - 0.5f * (float) Math.cos(Math.PI * clamp(p, 0f, 1f));
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
