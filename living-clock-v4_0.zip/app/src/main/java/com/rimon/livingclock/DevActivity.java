package com.rimon.livingclock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Developer More: the scenes engine. Reached only through the password in the main screen (not exported).
 * Rules are plain JSON; every edit and import goes through Scenes.parse, which validates and re-serialises.
 */
public class DevActivity extends Activity {

    private static final int BG = 0xFF0A0E16, CARD = 0xFF182030, EDGE = 0xFF2C3545, GOLD = 0xFFFFDC8A, MUTED = 0xFF9DA9BB;

    private SharedPreferences prefs;
    private LinearLayout list;
    private TextView live;
    private final Scenes probe = new Scenes();
    private String loaded = "";
    private final float[] sig = new float[Scenes.SIG.length];
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            String key = prefs.getString(Prefs.SCENES, "") + prefs.getBoolean(Prefs.SCENES_ON, false);
            if (!key.equals(loaded)) {                      // reload only on change so debounce timers keep counting
                loaded = key;
                probe.load(prefs);
            }
            Scenes.sample(DevActivity.this, ((android.media.AudioManager) getSystemService(AUDIO_SERVICE)).isMusicActive(), sig);
            probe.eval(sig, System.currentTimeMillis());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < sig.length; i++) sb.append(Scenes.SIG[i]).append(' ').append(Math.round(sig[i] * 10f) / 10f).append("   ");
            live.setText(sb + "\nactive: " + (probe.enabled() ? probe.active() : "engine is off"));
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Prefs.get(this);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(36), dp(18), dp(28));
        sv.addView(root);
        setContentView(sv);

        root.addView(label("Developer More", 22, Color.WHITE, true));
        root.addView(label("Scenes: when a condition is true, change the wallpaper. Higher priority wins; values can follow signals.", 12, MUTED, false));

        Switch on = new Switch(this);
        on.setText("Scenes engine");
        on.setTextColor(Color.WHITE);
        on.setChecked(prefs.getBoolean(Prefs.SCENES_ON, false));
        on.setOnCheckedChangeListener((v, c) -> prefs.edit().putBoolean(Prefs.SCENES_ON, c).apply());
        root.addView(on, lp(dp(14)));

        live = label("", 12, GOLD, false);
        live.setTypeface(Typeface.MONOSPACE);
        live.setPadding(dp(12), dp(10), dp(12), dp(10));
        live.setBackground(box());
        root.addView(live, lp(dp(10)));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, lp(dp(10)));

        root.addView(btn("Add preset", v -> addPreset()), lp(dp(12)));
        root.addView(btn("Add custom scene (JSON)", v -> edit(-1, "{\"name\":\"My scene\",\"pri\":50,\"when\":{\"sig\":\"battery\",\"op\":\"<\",\"v\":30},\"set\":{\"dim\":0.2}}")), lp(dp(8)));
        root.addView(btn("Export pack (share + copy)", v -> export()), lp(dp(8)));
        root.addView(btn("Import pack", v -> importPack()), lp(dp(8)));
        root.addView(btn("Reset to presets", v -> {
            prefs.edit().remove(Prefs.SCENES).apply();
            rebuild();
        }), lp(dp(8)));
        root.addView(label("Signals: music, charging, battery, saver, hour, weekday (1 = Sunday).\n"
                + "Set: pattern 0-4, exit 0-3, sleep 0-3, bands true/false, sens 0.3-2, dim 0-0.8, fps 15-60.\n"
                + "Conditions: all / any / not, ops > < = between, optional \"for\" seconds.", 11, MUTED, false), lp(dp(14)));
        rebuild();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresh);
    }

    // ---------- data ----------

    private List<Scenes.Scene> scenes() {
        try {
            return Scenes.parse(prefs.getString(Prefs.SCENES, Scenes.PRESETS));
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private void save(List<Scenes.Scene> l) {
        prefs.edit().putString(Prefs.SCENES, Scenes.text(l)).apply();
        rebuild();
    }

    private void rebuild() {
        list.removeAllViews();
        List<Scenes.Scene> l = scenes();
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            Scenes.Scene s = l.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(box());
            Switch sw = new Switch(this);
            sw.setText(s.name + "   (priority " + s.pri + ")");
            sw.setTextColor(Color.WHITE);
            sw.setChecked(s.on);
            sw.setOnCheckedChangeListener((v, c) -> {
                List<Scenes.Scene> cur = scenes();
                if (idx < cur.size()) {
                    cur.get(idx).on = c;
                    prefs.edit().putString(Prefs.SCENES, Scenes.text(cur)).apply();
                }
            });
            row.addView(sw);
            row.addView(label(s.summary(), 11, MUTED, false));
            LinearLayout bar = new LinearLayout(this);
            bar.addView(btn("Edit", v -> edit(idx, null)), new LinearLayout.LayoutParams(0, -2, 1f));
            bar.addView(btn("Delete", v -> {
                List<Scenes.Scene> cur = scenes();
                if (idx < cur.size() && cur.size() > 1) {
                    cur.remove(idx);
                    save(cur);
                }
            }), new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(bar);
            list.addView(row, lp(dp(8)));
        }
    }

    private void addPreset() {
        try {
            List<Scenes.Scene> presets = Scenes.parse(Scenes.PRESETS), cur = scenes();
            String[] names = new String[presets.size()];
            for (int i = 0; i < names.length; i++) names[i] = presets.get(i).name;
            new AlertDialog.Builder(this).setTitle("Add preset").setItems(names, (d, w) -> {
                if (cur.size() >= 12) {
                    toast("Twelve scenes is the limit");
                    return;
                }
                cur.add(presets.get(w));
                save(cur);
            }).show();
        } catch (Exception ignored) {
            // Presets are constants and always parse.
        }
    }

    private void edit(int idx, String starter) {
        List<Scenes.Scene> cur = scenes();
        String json;
        try {
            json = starter != null ? starter
                    : new org.json.JSONArray(Scenes.text(java.util.Collections.singletonList(cur.get(idx)))).getJSONObject(0).toString(2);
        } catch (Exception e) {
            return;
        }
        EditText in = new EditText(this);
        in.setText(json);
        in.setTypeface(Typeface.MONOSPACE);
        in.setTextSize(12);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        in.setGravity(Gravity.TOP);
        in.setMinLines(10);
        new AlertDialog.Builder(this).setTitle(idx < 0 ? "New scene" : "Edit scene").setView(in)
                .setPositiveButton("Save", (d, w) -> {
                    try {
                        List<Scenes.Scene> one = Scenes.parse("[" + in.getText() + "]");
                        if (idx >= 0) cur.set(idx, one.get(0));
                        else if (cur.size() < 12) cur.add(one.get(0));
                        save(cur);
                    } catch (Exception e) {
                        toast("Not saved: " + e.getMessage());
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    // ---------- packs ----------

    private void export() {
        String t = prefs.getString(Prefs.SCENES, Scenes.PRESETS);
        ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Living Clock pack", t));
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t);
        startActivity(Intent.createChooser(i, "Share scene pack"));
    }

    private void importPack() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        String pre = "";
        if (cm.hasPrimaryClip() && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (cs != null && cs.length() < 20000) pre = cs.toString();
        }
        EditText in = new EditText(this);
        in.setText(pre);
        in.setHint("Paste a pack");
        in.setTextSize(12);
        in.setMinLines(6);
        new AlertDialog.Builder(this).setTitle("Import pack").setView(in)
                .setPositiveButton("Preview", (d, w) -> {
                    try {
                        List<Scenes.Scene> got = Scenes.parse(in.getText().toString());
                        StringBuilder sb = new StringBuilder();
                        for (Scenes.Scene s : got) sb.append(s.name).append(": ").append(s.summary()).append('\n');
                        new AlertDialog.Builder(this).setTitle(got.size() + " scene(s) found").setMessage(sb.toString())
                                .setPositiveButton("Replace mine", (d2, w2) -> save(got))
                                .setNeutralButton("Add to mine", (d2, w2) -> {
                                    List<Scenes.Scene> cur = scenes();
                                    cur.addAll(got);
                                    save(cur.subList(0, Math.min(12, cur.size())));
                                })
                                .setNegativeButton("Cancel", null).show();
                    } catch (Exception e) {
                        toast("Invalid pack: " + e.getMessage());
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    // ---------- tiny view helpers ----------

    private TextView label(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(box());
        b.setOnClickListener(l);
        return b;
    }

    private GradientDrawable box() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setStroke(dp(1), EDGE);
        g.setCornerRadius(dp(12));
        return g;
    }

    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = top;
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }
}
