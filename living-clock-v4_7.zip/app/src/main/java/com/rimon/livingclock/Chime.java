package com.rimon.livingclock;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.SoundPool;
import android.os.Build;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/**
 * Plays the score of Director's Cut (see CutSound) on the system-sound stream, so it follows the ringer and the
 * system volume, stays silent in silent mode and is never mistaken for music by the bands.
 *
 * Nothing here touches the frame loop: the sounds are rendered once on a worker thread, the long ones are started
 * from a worker thread too, and the short clicks go through a SoundPool (instant, and playable at any speed,
 * which is how the clicks get heavier while the stack is being loaded).
 */
final class Chime {

    static final int ARM = 0, ENTER = 1, SLAM = 2, VANISH = 3;

    private static final long[][] TIMES = {
            {0, 14, 120, 30},                         // arm: a soft pulse, then the latch
            {0, 70, 60, 110},                         // enter: the clamp, then the drop
            {0, 40, 280, 120, 50, 60, 50, 36},        // slam: wait for the impact, then the hit and its echoes
            {0, 12}};                                 // vanish: the pen lifting
    private static final int[][] AMPS = {
            {0, 120, 0, 210},
            {0, 210, 0, 255},
            {0, 90, 0, 255, 0, 150, 0, 80},
            {0, 70}};

    private final Context app;
    private final Handler main;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final short[][] bank = new short[4][];
    private final List<AudioTrack> playing = new ArrayList<>();
    private SoundPool sp;
    private int detentId, lockId;
    private volatile boolean detentReady, lockReady, building, released;

    Chime(Context c, Handler main) {
        this.app = c.getApplicationContext();
        this.main = main;
    }

    /** Renders the sounds in the background so the first cue is instant. */
    void warm() {
        if (building || released || bank[0] != null) return;
        building = true;
        try {
            pool.execute(this::render);
        } catch (RejectedExecutionException e) {
            building = false;
        }
    }

    private void render() {
        try {
            short[] a = CutSound.arm(), e = CutSound.enter(), s = CutSound.slam(), v = CutSound.vanish();
            short[] d = CutSound.detent(), l = CutSound.lock();
            File fd = new File(app.getCacheDir(), "cut_detent.wav"), fl = new File(app.getCacheDir(), "cut_lock.wav");
            writeWav(fd, d);
            writeWav(fl, l);
            if (released) return;
            final SoundPool p = new SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(attrs())
                    .build();
            p.setOnLoadCompleteListener((pool1, id, status) -> {
                if (status != 0) return;
                if (id == detentId) detentReady = true;
                else if (id == lockId) lockReady = true;
            });
            detentId = p.load(fd.getAbsolutePath(), 1);
            lockId = p.load(fl.getAbsolutePath(), 1);
            main.post(() -> {
                building = false;
                if (released) {
                    p.release();
                    return;
                }
                sp = p;
                bank[ARM] = a;
                bank[ENTER] = e;
                bank[SLAM] = s;
                bank[VANISH] = v;
            });
        } catch (RuntimeException | OutOfMemoryError | IOException ex) {
            building = false;                                    // no sound this time; the picture still plays
        }
    }

    private static AudioAttributes attrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
    }

    /** A long cue. The track is built and started on the worker thread. */
    void play(int id) {
        if (released) return;
        buzz(TIMES[id], AMPS[id]);
        final short[] pcm = bank[id];
        if (pcm == null) {
            warm();
            return;
        }
        try {
            pool.execute(() -> start(pcm));
        } catch (RejectedExecutionException e) {
            // Shutting down.
        }
    }

    private void start(short[] pcm) {
        if (released) return;
        try {
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(CutSound.RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build();
            final AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(attrs())
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(pcm.length * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            if (track.write(pcm, 0, pcm.length) <= 0) {
                track.release();
                return;
            }
            synchronized (playing) {
                playing.add(track);
            }
            track.play();
            long ms = pcm.length / 2L * 1000L / CutSound.RATE + 300L;
            main.postDelayed(() -> {
                try {
                    pool.execute(() -> free(track));
                } catch (RejectedExecutionException e) {
                    free(track);
                }
            }, ms);
        } catch (RuntimeException e) {
            // No audio output right now: the picture still plays.
        }
    }

    private void free(AudioTrack t) {
        synchronized (playing) {
            if (!playing.remove(t)) return;
        }
        try {
            t.stop();
        } catch (RuntimeException ignored) {
            // Already stopped.
        }
        t.release();
    }

    /** One click. rate below 1 is lower and heavier; strength sets the loudness and the haptic. */
    void click(float rate, float strength) {
        SoundPool p = sp;
        if (released || p == null || !detentReady) return;
        float v = 0.35f + 0.65f * strength;
        p.play(detentId, v, v, 1, 0, Math.max(0.5f, Math.min(2f, rate)));
        tick(5 + (int) (9 * strength), 70 + (int) (185 * strength));
    }

    void lock() {
        SoundPool p = sp;
        if (released || p == null || !lockReady) return;
        p.play(lockId, 1f, 1f, 2, 0, 1f);
        buzz(new long[]{0, 60, 40, 34}, new int[]{0, 255, 0, 160});
    }

    /** Cut everything off at once (the kill switch or the sleep clock needs the screen). */
    void stopAll() {
        if (sp != null) sp.autoPause();
        List<AudioTrack> copy;
        synchronized (playing) {
            copy = new ArrayList<>(playing);
        }
        for (AudioTrack t : copy) {
            try {
                pool.execute(() -> free(t));
            } catch (RejectedExecutionException e) {
                free(t);
            }
        }
    }

    void release() {
        released = true;
        stopAll();
        if (sp != null) {
            sp.release();
            sp = null;
        }
        pool.shutdown();
    }

    @SuppressWarnings("deprecation")
    private void buzz(long[] times, int[] amps) {
        try {
            Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) {
                if (v.hasAmplitudeControl()) v.vibrate(VibrationEffect.createWaveform(times, amps, -1));
                else v.vibrate(VibrationEffect.createWaveform(times, -1));
            } else {
                v.vibrate(times, -1);
            }
        } catch (RuntimeException ignored) {
            // No vibrator permission or hardware.
        }
    }

    @SuppressWarnings("deprecation")
    private void tick(int ms, int amp) {
        try {
            Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, v.hasAmplitudeControl() ? Math.min(255, amp) : VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(ms);
        } catch (RuntimeException ignored) {
            // No vibrator permission or hardware.
        }
    }

    private static void writeWav(File f, short[] stereo) throws IOException {
        int dataLen = stereo.length * 2;
        ByteBuffer b = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN);
        b.put(new byte[]{'R', 'I', 'F', 'F'}).putInt(36 + dataLen).put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        b.putInt(16).putShort((short) 1).putShort((short) 2).putInt(CutSound.RATE).putInt(CutSound.RATE * 4)
                .putShort((short) 4).putShort((short) 16).put(new byte[]{'d', 'a', 't', 'a'}).putInt(dataLen);
        for (short s : stereo) b.putShort(s);
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write(b.array());
        }
    }
}
