package com.rimon.livingclock;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.Xfermode;

/**
 * Super 5: five elemental clocks, reached by triple-tapping the top of the cutout. The wallpaper is never replaced;
 * each clock lays a faint atmosphere over it (light, embers, stars, data, glints) and builds itself out of its own
 * element. Every one has its own formation, its own single-tap animation and its own way of coming apart, and the
 * way out of one feeds the way into the next (a ring of the new colour opens from the clock as the old one dies).
 *
 *   5 Inferno    a basalt dial split by living lava; a crown of flame licks the rim, embers rise. Forms from sparks
 *                spiralling in, the rim igniting clockwise, fissures spreading from the core, hands forged white-hot.
 *                tap = an eruption (flames surge, shockwaves, a fountain of sparks). out = it burns to ash.
 *   6 Nature     a moss-glass dial in a ring of bark, a living vine with leaves and blossoms, branch hands, a dew
 *                drop for the seconds. Forms from a seed: the dial grows, the vine climbs clockwise, flowers open.
 *                tap = a gust (leaves ripple, blossoms shed petals). out = the leaves turn and the wind takes them.
 *   7 Cosmos     a spiral galaxy turning inside a photon ring, stars for the hours, hands of light.
 *                Forms from a point of light that explodes and accretes into a galaxy, spinning down into place.
 *                tap = a supernova (core flash, shockwaves, a shooting star). out = it collapses into a singularity.
 *   8 Nexus      a living network: 31 nodes, 72 links, data pulses racing along them, the hands as bridges that light
 *                the nodes they point at. Forms node by node from the hub outward. tap = a signal floods the
 *                network ring by ring. out = the links snap, the nodes drift off and the grid glitches away.
 *   9 Obsidian   a volcanic-glass jewel cut into 60 facets, a polished rim and glass shard markers, blades of
 *                black glass. Forms from shards flying together and locking in with a flash, then a polish sweep.
 *                tap = light runs along the cracks from the core. out = it shatters.
 *
 * Cost: static art is drawn once into a cached bitmap; only what moves is drawn per frame (about 40 to 110 draw
 * calls). Nothing is allocated while drawing. Ambient motion runs at about 30 frames a second (15 on a low battery);
 * transitions follow the display.
 */
final class Supers {

    static final int FIRST = 5, N = 5;
    static final long BUILD_MS = 3800, EXIT_MS = 3000;
    static final String[] NAMES = {"Inferno", "Nature", "Cosmos", "Nexus", "Obsidian"};

    private static final int INF = 0, NAT = 1, COS = 2, NEX = 3, OBS = 4;
    private static final int[] LOOK = {3, 0, 1, 2, 4};                       // the band pattern each Super borrows
    private static final int[] TINT = {0xFF2A0600, 0xFF04200C, 0xFF070420, 0xFF021A24, 0xFF08060E};
    private static final float[] TINT_A = {0.30f, 0.26f, 0.32f, 0.28f, 0.34f};
    private static final int[] RIM = {0xFFFF7A1A, 0xFF7CE08A, 0xFFB9A4FF, 0xFF38E8FF, 0xFFB48CFF};
    private static final float TAU = 6.2831855f;

    // glow colours: index into halos[]
    private static final int H_FIRE = 0, H_HOT = 1, H_LEAF = 2, H_CYAN = 3, H_VIO = 4, H_WHITE = 5, H_PINK = 6;
    private static final int[] HC = {0xFFFF7A1A, 0xFFFFD27A, 0xFFB6FF7A, 0xFF38E8FF, 0xFFB48CFF, 0xFFFFFFFF, 0xFFFF4AD8};

    static boolean is(int th) {
        return th >= FIRST;
    }

    static int look(int th) {
        return LOOK[th - FIRST];
    }

    // ---------- state ----------

    private final float[] a = new float[N];
    private final boolean[] rising = new boolean[N];
    private long last = -1L;
    private int w, h;
    private float cx, cy, r, u;
    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG), gp = new Paint(Paint.ANTI_ALIAS_FLAG), bp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Xfermode add = new PorterDuffXfermode(PorterDuff.Mode.ADD);
    private final Path path = new Path(), tmp = new Path(), disc = new Path(), vSeg = new Path();
    private final PathMeasure pm = new PathMeasure();
    private final RectF rc = new RectF();
    private final Matrix mx = new Matrix();
    private final Bitmap[] cache = new Bitmap[N];
    private final Typeface condensed = Typeface.create("sans-serif-condensed", Typeface.BOLD), mono = Typeface.create("monospace", Typeface.BOLD);
    private final RadialGradient[] halos = new RadialGradient[HC.length];
    private final float[] buf = new float[640];

    // shared shaders
    private RadialGradient vignette, magmaDial, mossDial, cosmosDial, netDial, fireG, fireG2, petalP, petalW, petalIn, cosCore;
    private LinearGradient heatBlade, leafA, leafB, leafC, bandG, sheenG, glowBottom, rayG, beamH, beamM;
    private SweepGradient barkS, photonS, glassRim;

    // inferno
    private final Path crack = new Path();
    // nature
    private final Path vine = new Path(), leafP = new Path(), flowerP = new Path();
    private static final int LEAVES = 36;
    private final float[] lvA = new float[LEAVES], lvSize = new float[LEAVES], lvR = new float[LEAVES];
    // cosmos
    private final float[] twk = new float[48];
    // nexus
    private final float[] nx = new float[31], ny = new float[31];
    private final int[] nlv = new int[31], ea = new int[72], eb = new int[72], elv = new int[72];
    private final float[] est = new float[72];
    private static final float[] LV_NODE = {0.00f, 0.12f, 0.30f, 0.48f};
    // obsidian
    private final float[] ov = new float[74], fcx = new float[60], fcy = new float[60], fph = new float[60];
    private final int[] tri = new int[180], fcol = new int[60];
    private final LinearGradient[] fgrad = new LinearGradient[60];
    private final Path seam = new Path();

    Supers() {
        pt.setStrokeCap(Paint.Cap.ROUND);
        pt.setStrokeJoin(Paint.Join.ROUND);
    }

    boolean step(int theme, long now) {
        float dt = last < 0 ? 0f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        boolean moving = false;
        for (int i = 0; i < N; i++) {
            float target = theme == FIRST + i ? 1f : 0f;
            if (a[i] != target) {
                rising[i] = target > a[i];
                float rate = dt / (target > a[i] ? 2.6f : 2.0f);
                a[i] += Math.max(-rate, Math.min(rate, target - a[i]));
                moving |= a[i] != target;
            }
            if (a[i] == 0f && cache[i] != null && theme != FIRST + i) {      // free the bitmap once the clock has gone
                cache[i].recycle();
                cache[i] = null;
            }
        }
        return moving;
    }

    void snap(int theme) {
        for (int i = 0; i < N; i++) {
            a[i] = theme == FIRST + i ? 1f : 0f;
            rising[i] = false;
        }
    }

    boolean active() {
        for (int i = 0; i < N; i++) if (a[i] > 0.003f) return true;
        return false;
    }

    int tintColor() {
        int best = 0;
        for (int i = 1; i < N; i++) if (a[i] > a[best]) best = i;
        float e = smooth(a[best]);
        return e < 0.02f ? 0 : (RIM[best] & 0x00FFFFFF) | (((int) (e * 30f)) << 24);
    }

    void release() {
        for (int i = 0; i < N; i++) {
            if (cache[i] != null) cache[i].recycle();
            cache[i] = null;
        }
    }

    // ---------- layout ----------

    void layout(int width, int height, float clockX, float clockY, float radius) {
        boolean same = width == w && height == h && radius == r && vignette != null;
        w = width;
        h = height;
        cx = clockX;
        cy = clockY;
        r = radius;
        u = width / 1080f;
        disc.rewind();
        disc.addCircle(0f, 0f, r * 0.9f, Path.Direction.CW);
        if (same) return;
        release();
        Shader.TileMode cl = Shader.TileMode.CLAMP;
        float big = Math.max(w, h);
        vignette = new RadialGradient(0f, 0f, big * 0.75f, new int[]{0x00000000, 0x00000000, 0xA0000000}, new float[]{0f, 0.55f, 1f}, cl);
        for (int i = 0; i < HC.length; i++) {
            int col = HC[i] & 0x00FFFFFF;
            halos[i] = new RadialGradient(0f, 0f, 100f, new int[]{0xFF000000 | col, 0x73000000 | col, 0x1F000000 | col, col},
                    new float[]{0f, 0.25f, 0.6f, 1f}, cl);
        }
        bandG = new LinearGradient(0f, -100f, 0f, 100f, new int[]{0x0038E8FF, 0x3038E8FF, 0x0038E8FF}, new float[]{0f, 0.5f, 1f}, cl);
        sheenG = new LinearGradient(-100f, 0f, 100f, 0f, new int[]{0x00FFFFFF, 0x55E8EEFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, cl);
        glowBottom = new LinearGradient(0f, h * 0.52f, 0f, h, new int[]{0x00FF4A00, 0x40FF5A12, 0x99FF8A1E}, new float[]{0f, 0.6f, 1f}, cl);
        rayG = new LinearGradient(0f, 0f, 0f, h * 0.85f, new int[]{0x26FFF2B0, 0x00FFF2B0}, null, cl);
        initInferno(cl);
        initNature(cl);
        initCosmos(cl);
        initNexus(cl);
        initObsidian(cl);
    }

    private void initInferno(Shader.TileMode cl) {
        magmaDial = new RadialGradient(0f, 0f, r * 0.9f, new int[]{0xFF2A0A04, 0xFF140603, 0xFF080202}, new float[]{0f, 0.65f, 1f}, cl);
        float f = r * 1.3f;
        fireG = new RadialGradient(0f, 0f, f, new int[]{0xFFFFF0B0, 0xFFFFE9A0, 0xFFFF9A22, 0xFFE8421A, 0x00801008},
                new float[]{0f, 0.738f, 0.823f, 0.923f, 1f}, cl);
        fireG2 = new RadialGradient(0f, 0f, f, new int[]{0xFFFFFFE0, 0xFFFFF0B0, 0xFFFFD060, 0xFFFF8A2A, 0x00E8421A},
                new float[]{0f, 0.738f, 0.823f, 0.923f, 1f}, cl);
        heatBlade = new LinearGradient(0f, 0f, 0f, -r * 0.85f, new int[]{0xFF2A0A04, 0xFFE8431A, 0xFFFFC15A, 0xFFFFF4C8},
                new float[]{0f, 0.35f, 0.75f, 1f}, cl);
        crack.rewind();                                                         // fissures: ten main cracks with branches
        for (int m = 0; m < 10; m++) {
            float ang = m * 36f + (hash(m * 7 + 1) - 0.5f) * 20f, rad = r * 0.09f;
            crack.moveTo(px(rad, ang), py(rad, ang));
            for (int s = 0; s < 14; s++) {
                ang += (hash(m * 31 + s * 5 + 2) - 0.5f) * 26f;
                rad += r * (0.060f + 0.025f * hash(m * 17 + s * 3 + 5));
                if (rad > r * 0.9f) break;
                crack.lineTo(px(rad, ang), py(rad, ang));
                if (s > 1 && hash(m * 13 + s * 11 + 7) > 0.62f) {
                    float ba = ang + (hash(m * 3 + s) > 0.5f ? 1f : -1f) * (30f + 25f * hash(m + s * 19)), br = rad;
                    for (int q = 0; q < 3; q++) {
                        ba += (hash(m * 5 + s * 7 + q) - 0.5f) * 30f;
                        br += r * 0.05f;
                        if (br > r * 0.9f) break;
                        crack.lineTo(px(br, ba), py(br, ba));
                    }
                    crack.moveTo(px(rad, ang), py(rad, ang));
                }
            }
        }
    }

    private void initNature(Shader.TileMode cl) {
        mossDial = new RadialGradient(-r * 0.18f, -r * 0.22f, r * 1.05f, new int[]{0xFF2C5C34, 0xFF173A20, 0xFF0A1C10}, new float[]{0f, 0.65f, 1f}, cl);
        barkS = new SweepGradient(0f, 0f, new int[]{0xFF4A2E18, 0xFF7A5230, 0xFF4A2E18, 0xFF8A6038, 0xFF4A2E18}, null);
        leafA = new LinearGradient(-0.6f, 0f, 0.6f, 0f, new int[]{0xFF2E7A34, 0xFF2E7A34, 0xFF86D860, 0xFF86D860}, new float[]{0f, 0.47f, 0.53f, 1f}, cl);
        leafB = new LinearGradient(-0.6f, 0f, 0.6f, 0f, new int[]{0xFF1F5E2C, 0xFF1F5E2C, 0xFF58B24C, 0xFF58B24C}, new float[]{0f, 0.47f, 0.53f, 1f}, cl);
        leafC = new LinearGradient(-0.6f, 0f, 0.6f, 0f, new int[]{0xFFA4521A, 0xFFA4521A, 0xFFEAA83A, 0xFFEAA83A}, new float[]{0f, 0.47f, 0.53f, 1f}, cl);
        petalP = new RadialGradient(0f, 0f, 1f, new int[]{0xFFE8567F, 0xFFFFA6C0, 0xFFFFE6EE}, new float[]{0.05f, 0.55f, 1f}, cl);
        petalW = new RadialGradient(0f, 0f, 1f, new int[]{0xFFFFD35A, 0xFFFFF4C8, 0xFFFFFFF6}, new float[]{0.05f, 0.5f, 1f}, cl);
        petalIn = new RadialGradient(0f, 0f, 1f, new int[]{0xFFC8366A, 0xFFF0709A, 0xFFFFB6CC}, new float[]{0.05f, 0.55f, 1f}, cl);
        leafP.rewind();
        leafP.moveTo(0f, 0f);
        leafP.cubicTo(0.62f, -0.18f, 0.55f, -0.72f, 0f, -1f);
        leafP.cubicTo(-0.55f, -0.72f, -0.62f, -0.18f, 0f, 0f);
        tmp.rewind();
        tmp.moveTo(0f, 0f);
        tmp.cubicTo(0.46f, -0.22f, 0.44f, -0.92f, 0.06f, -1f);
        tmp.lineTo(0f, -0.93f);
        tmp.lineTo(-0.06f, -1f);
        tmp.cubicTo(-0.44f, -0.92f, -0.46f, -0.22f, 0f, 0f);
        flowerP.rewind();
        for (int i = 0; i < 5; i++) {
            mx.setRotate(i * 72f);
            flowerP.addPath(tmp, mx);
        }
        vine.rewind();
        for (int d = 0; d <= 360; d += 4) {
            float rr = vineR(d);
            if (d == 0) vine.moveTo(px(rr, d), py(rr, d));
            else vine.lineTo(px(rr, d), py(rr, d));
        }
        for (int k = 0; k < LEAVES; k++) {
            lvA[k] = k * 10f + (hash(k * 5 + 1) - 0.5f) * 5f;
            lvSize[k] = r * (0.075f + 0.04f * hash(k * 5 + 2));
            lvR[k] = hash(k * 5 + 3);
        }
    }

    private void initCosmos(Shader.TileMode cl) {
        cosmosDial = new RadialGradient(0f, 0f, r * 0.9f, new int[]{0xFF0B0A2A, 0xFF05051A, 0xFF010108}, new float[]{0f, 0.6f, 1f}, cl);
        cosCore = new RadialGradient(0f, 0f, r * 0.34f, new int[]{0xF2FFF4D8, 0x66FFC060, 0x00FFC060}, new float[]{0f, 0.35f, 1f}, cl);
        photonS = new SweepGradient(0f, 0f, new int[]{0x40B9A4FF, 0x40B9A4FF, 0xFFFFFFFF, 0xFFFFD27A, 0x40B9A4FF, 0x40B9A4FF},
                new float[]{0f, 0.50f, 0.76f, 0.82f, 0.95f, 1f});
        beamH = new LinearGradient(0f, 0f, 0f, -r * 0.5f, new int[]{0x00B48CFF, 0xB0B48CFF, 0xFFF0E6FF}, new float[]{0f, 0.5f, 1f}, cl);
        beamM = new LinearGradient(0f, 0f, 0f, -r * 0.82f, new int[]{0x0038E8FF, 0xA038E8FF, 0xFFE6FBFF}, new float[]{0f, 0.5f, 1f}, cl);
        for (int i = 0; i < 24; i++) {                                          // twinkling stars inside the dial
            float ang = hash(i * 3 + 41) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 42)) * r * 0.84f;
            twk[2 * i] = (float) Math.cos(ang) * rad;
            twk[2 * i + 1] = (float) Math.sin(ang) * rad;
        }
    }

    private void initNexus(Shader.TileMode cl) {
        netDial = new RadialGradient(0f, 0f, r * 0.9f, new int[]{0xFF06202C, 0xFF04121C, 0xFF030A12}, new float[]{0f, 0.6f, 1f}, cl);
        for (int k = 0; k < 12; k++) {
            nx[k] = px(r * 0.82f, k * 30f);
            ny[k] = py(r * 0.82f, k * 30f);
            nlv[k] = 3;
            nx[12 + k] = px(r * 0.56f, k * 30f + 15f);
            ny[12 + k] = py(r * 0.56f, k * 30f + 15f);
            nlv[12 + k] = 2;
        }
        for (int k = 0; k < 6; k++) {
            nx[24 + k] = px(r * 0.30f, k * 60f);
            ny[24 + k] = py(r * 0.30f, k * 60f);
            nlv[24 + k] = 1;
        }
        nx[30] = 0f;
        ny[30] = 0f;
        nlv[30] = 0;
        int e = 0;
        for (int k = 0; k < 12; k++) {
            e = edge(e, k, (k + 1) % 12);
            e = edge(e, 12 + k, k);
            e = edge(e, 12 + k, (k + 1) % 12);
            e = edge(e, 12 + k, 12 + (k + 1) % 12);
        }
        for (int j = 0; j < 6; j++) {
            e = edge(e, 24 + j, 12 + (2 * j + 11) % 12);
            e = edge(e, 24 + j, 12 + (2 * j) % 12);
            e = edge(e, 24 + j, 24 + (j + 1) % 6);
            e = edge(e, 30, 24 + j);
        }
    }

    private int edge(int e, int p, int q) {
        if (nlv[p] > nlv[q]) {
            int t = p;
            p = q;
            q = t;
        }
        ea[e] = p;
        eb[e] = q;
        int lv = nlv[q];
        elv[e] = lv;
        float s = LV_NODE[lv];
        est[e] = (nlv[p] != nlv[q] ? s - 0.06f : s + 0.08f) + 0.05f * hash(e * 5 + 3);
        return e + 1;
    }

    private void initObsidian(Shader.TileMode cl) {
        float[] rr = {0.30f, 0.60f, 0.89f};
        for (int k = 0; k < 3; k++) {
            for (int j = 0; j < 12; j++) {
                float ang = j * 30f + (k == 1 ? 15f : 0f) + (hash(k * 50 + j + 3) - 0.5f) * 7f;
                float rad = r * rr[k] * (1f + (hash(k * 70 + j + 9) - 0.5f) * 0.05f);
                ov[2 * (k * 12 + j)] = px(rad, ang);
                ov[2 * (k * 12 + j) + 1] = py(rad, ang);
            }
        }
        ov[72] = 0f;
        ov[73] = 0f;
        int t = 0;
        for (int j = 0; j < 12; j++) {
            tri[t++] = 36;
            tri[t++] = j;
            tri[t++] = (j + 1) % 12;
        }
        for (int s = 0; s < 2; s++) {
            int A = s == 0 ? 0 : 24, B = 12;
            for (int j = 0; j < 12; j++) {
                tri[t++] = A + j;
                tri[t++] = A + (j + 1) % 12;
                tri[t++] = B + j;
                tri[t++] = B + (j + 11) % 12;
                tri[t++] = B + j;
                tri[t++] = A + j;
            }
        }
        seam.rewind();
        float sz = r * 0.12f;
        for (int k = 0; k < 60; k++) {
            int i0 = tri[3 * k], i1 = tri[3 * k + 1], i2 = tri[3 * k + 2];
            float x0 = ov[2 * i0], y0 = ov[2 * i0 + 1], x1 = ov[2 * i1], y1 = ov[2 * i1 + 1], x2 = ov[2 * i2], y2 = ov[2 * i2 + 1];
            fcx[k] = (x0 + x1 + x2) / 3f;
            fcy[k] = (y0 + y1 + y2) / 3f;
            fph[k] = hash(k * 13 + 5);
            float nAng = hash(k * 7 + 1) * 360f;
            float lum = 0.5f + 0.5f * (float) Math.cos(Math.toRadians(nAng - 225f));
            int base = mix(0xFF07070E, 0xFF1E2034, lum * 0.85f);
            float tn = hash(k * 11 + 5);
            if (tn > 0.78f) base = mix(base, 0xFF1F5560, 0.45f);               // teal flecks, as in rainbow obsidian
            else if (tn > 0.62f) base = mix(base, 0xFF3F2670, 0.40f);
            else if (tn > 0.54f) base = mix(base, 0xFF6A4E1A, 0.35f);
            fcol[k] = base;
            fgrad[k] = new LinearGradient(fcx[k] + sz * 0.7f, fcy[k] + sz * 0.7f, fcx[k] - sz * 0.7f, fcy[k] - sz * 0.7f,
                    mix(base, 0xFF000000, 0.40f), mix(base, 0xFF5C6288, 0.35f + 0.35f * lum), cl);
            seam.moveTo(x0, y0);
            seam.lineTo(x1, y1);
            seam.lineTo(x2, y2);
            seam.close();
        }
        glassRim = new SweepGradient(0f, 0f, new int[]{0xFF05050A, 0xFF05050A, 0xFFCFD6FF, 0xFF05050A, 0xFF05050A, 0xFF8E96C8, 0xFF05050A, 0xFF05050A},
                new float[]{0f, 0.18f, 0.22f, 0.30f, 0.62f, 0.66f, 0.72f, 1f});
    }

    private float vineR(float deg) {
        return r * (0.915f + 0.010f * (float) Math.sin(Math.toRadians(deg * 6.0)));
    }

    // ---------- helpers ----------

    private static float hash(int n) {
        n = (n << 13) ^ n;
        return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483647f;
    }

    /** Time as a float that keeps its precision (the epoch in seconds does not). */
    private static float wf(double td) {
        return (float) (td % 10000.0);
    }

    private static float vn(float x, int seed) {
        int i = (int) Math.floor(x);
        float f = x - i, a0 = hash(i * 31 + seed), a1 = hash((i + 1) * 31 + seed);
        return a0 + (a1 - a0) * (f * f * (3f - 2f * f));
    }

    private static float smooth(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        return x * x * (3f - 2f * x);
    }

    private static float seg(float b, float from, float to) {
        return smooth((b - from) / (to - from));
    }

    private static float clamp01(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float outBack(float x) {
        x = clamp01(x);
        float v = x - 1f;
        return 1f + 2.2f * v * v * v + 1.2f * v * v;
    }

    private static float outCubic(float x) {
        x = clamp01(x);
        float v = 1f - x;
        return 1f - v * v * v;
    }

    private static float sn(double td, double period, double ph) {
        return (float) Math.sin(td * TAU / period + ph);
    }

    private static int al(int color, float f) {
        int v = (int) ((color >>> 24) * clamp01(f));
        return (color & 0x00FFFFFF) | (v << 24);
    }

    private static int mix(int c0, int c1, float t) {
        t = clamp01(t);
        int aa = (int) ((c0 >>> 24) + ((c1 >>> 24) - (c0 >>> 24)) * t);
        int rr = (int) (((c0 >> 16) & 255) + (((c1 >> 16) & 255) - ((c0 >> 16) & 255)) * t);
        int gg = (int) (((c0 >> 8) & 255) + (((c1 >> 8) & 255) - ((c0 >> 8) & 255)) * t);
        int bb = (int) ((c0 & 255) + ((c1 & 255) - (c0 & 255)) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }

    private static float px(float rr, float deg) {
        return (float) Math.sin(Math.toRadians(deg)) * rr;
    }

    private static float py(float rr, float deg) {
        return -(float) Math.cos(Math.toRadians(deg)) * rr;
    }

    private void stroke(float wid, int color, float alpha) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, wid));
        pt.setColor(al(color, alpha));
    }

    private void line(Canvas c, float x0, float y0, float x1, float y1, float wid, int color, float alpha) {
        if (alpha < 0.01f) return;
        stroke(wid, color, alpha);
        c.drawLine(x0, y0, x1, y1, pt);
    }

    private void dot(Canvas c, float x, float y, float rad, int color, float alpha) {
        if (alpha < 0.01f || rad <= 0f) return;
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(color, alpha));
        c.drawCircle(x, y, rad, pt);
    }

    private void ring(Canvas c, float x, float y, float rad, float wid, int color, float alpha) {
        if (alpha < 0.01f || rad <= 0f) return;
        stroke(wid, color, alpha);
        c.drawCircle(x, y, rad, pt);
    }

    private void arc(Canvas c, float rad, float start, float sweep, float wid, int color, float alpha) {
        if (alpha < 0.01f || sweep <= 0f) return;
        stroke(wid, color, alpha);
        rc.set(-rad, -rad, rad, rad);
        c.drawArc(rc, start, sweep, false, pt);
    }

    private void shaderRing(Canvas c, Shader s, float rad, float wid, float alpha) {
        pt.setShader(s);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(wid);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawCircle(0f, 0f, rad, pt);
        pt.setShader(null);
    }

    private void star4(Canvas c, float x, float y, float s, int color, float alpha) {
        line(c, x - s, y, x + s, y, s * 0.16f, color, alpha);
        line(c, x, y - s, x, y + s, s * 0.16f, color, alpha);
        dot(c, x, y, s * 0.18f, 0xFFFFFFFF, alpha);
    }

    /** A soft additive glow of one of the preset colours. */
    private void halo(Canvas c, int g, float x, float y, float rad, float alpha) {
        if (alpha < 0.01f || rad < 1f) return;
        float k = rad / 100f;
        mx.setScale(k, k);
        mx.postTranslate(x, y);
        halos[g].setLocalMatrix(mx);
        gp.setStyle(Paint.Style.FILL);
        gp.setShader(halos[g]);
        gp.setAlpha((int) (255 * clamp01(alpha)));
        gp.setXfermode(add);
        c.drawCircle(x, y, rad, gp);
        gp.setXfermode(null);
        gp.setShader(null);
        gp.setAlpha(255);
    }

    private void text(Canvas c, String s, float x, float y, float size, Typeface face, int color, float alpha) {
        if (alpha < 0.01f) return;
        pt.setStyle(Paint.Style.FILL);
        pt.setTypeface(face);
        pt.setTextAlign(Paint.Align.CENTER);
        pt.setTextSize(size);
        pt.setColor(al(color, alpha));
        c.drawText(s, x, y + size * 0.35f, pt);
        pt.setTypeface(Typeface.DEFAULT);
    }

    /** A blade pointing up: a kite with a short tail (right half only for the lit side of a glass blade). */
    private void kite(Path p, float len, float wid, float tail, boolean rightOnly) {
        p.rewind();
        p.moveTo(0f, -len);
        p.lineTo(wid, -len * 0.22f);
        p.lineTo(wid * 0.45f, tail);
        if (rightOnly) {
            p.lineTo(0f, tail);
        } else {
            p.lineTo(-wid * 0.45f, tail);
            p.lineTo(-wid, -len * 0.22f);
        }
        p.close();
    }

    private void blade(Canvas c, float deg, float len, float wid, float tail, Shader fill, int edge, float edgeA, float alpha) {
        kite(path, len, wid, tail, false);
        c.save();
        c.rotate(deg);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(fill);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawPath(path, pt);
        pt.setShader(null);
        stroke(r * 0.006f, edge, edgeA * alpha);
        c.drawPath(path, pt);
        c.restore();
    }

    private void tipOf(float[] out, float deg, float len) {
        out[0] = px(len, deg);
        out[1] = py(len, deg);
    }

    private final float[] tip = new float[2];

    // ---------- the overlay: light, tint, vignette and ambient life ----------

    void env(Canvas c, long now) {
        double td = now / 1000.0;
        float big = Math.max(w, h);
        for (int i = 0; i < N; i++) {
            if (a[i] < 0.004f) continue;
            float e = smooth(a[i]);
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(al(TINT[i], TINT_A[i] * e));
            c.drawRect(0f, 0f, w, h, gp);
            gp.setShader(vignette);
            gp.setAlpha((int) (255 * 0.5f * e));
            c.save();
            c.translate(w / 2f, h / 2f);
            c.drawCircle(0f, 0f, big, gp);
            c.restore();
            gp.setShader(null);
            gp.setAlpha(255);
            switch (i) {
                case INF: envInferno(c, td, e); break;
                case NAT: envNature(c, td, e); break;
                case COS: envCosmos(c, td, e); break;
                case NEX: envNexus(c, td, e); break;
                default: envObsidian(c, td, e); break;
            }
            // the world changes with the clock: a ring of the theme's colour opens from the clock as it forms, and
            // closes back into it as it leaves, so the end of one clock is the start of the next
            float aa = a[i];
            if (aa < 0.999f) {
                float rad, alpha;
                if (rising[i]) {
                    rad = big * 0.95f * outCubic(aa);
                    alpha = 0.55f * (1f - aa) * (1f - aa);
                } else {
                    rad = big * 0.95f * aa * aa;
                    alpha = 0.45f * 4f * aa * (1f - aa);
                }
                if (alpha > 0.01f && rad > 2f) {
                    c.save();
                    c.translate(cx, cy);
                    halo(c, i == INF ? H_FIRE : i == NAT ? H_LEAF : i == COS ? H_VIO : i == NEX ? H_CYAN : H_VIO, 0f, 0f, rad * 0.55f, alpha * 0.35f);
                    ring(c, 0f, 0f, rad, 5f * u + 14f * u * (1f - aa), RIM[i], alpha);
                    ring(c, 0f, 0f, rad, 1.6f * u, 0xFFFFFFFF, alpha * 0.8f);
                    c.restore();
                }
            }
        }
    }

    private void envInferno(Canvas c, double td, float e) {
        float fl = 0.62f + 0.22f * vn(wf(td) * 3.4f, 5) + 0.16f * vn(wf(td) * 8.1f, 9);
        gp.setShader(glowBottom);
        gp.setAlpha((int) (255 * clamp01(fl * e)));
        c.drawRect(0f, h * 0.52f, w, h, gp);
        gp.setShader(null);
        gp.setAlpha(255);
        for (int k = 0; k < 34; k++) {                                            // embers rising off the bottom
            float sp = 0.035f + 0.05f * hash(k * 5 + 3), ph = hash(k * 5 + 4);
            float t = (float) ((td * sp + ph) % 1.0);
            float x = hash(k * 5 + 1) * w + (float) Math.sin(td * (0.6 + hash(k) * 0.8) + k) * 40f * u * t;
            float y = h * (1.05f - 1.15f * t);
            float al = (float) Math.sin(Math.PI * t) * (0.5f + 0.5f * vn(wf(td) * 5f + k, 21));
            dot(c, x, y, (1.2f + 2.6f * hash(k * 5 + 2)) * u * (1f - 0.5f * t), t < 0.5f ? 0xFFFFC15A : 0xFFFF6A1A, al * e * 0.9f);
        }
    }

    private void envNature(Canvas c, double td, float e) {
        for (int b = 0; b < 3; b++) {                                             // light shafts through the canopy
            float x0 = w * (0.05f + 0.34f * b) + 0.03f * w * (float) Math.sin(td * 0.25 + b * 2.0);
            float shear = w * 0.28f, tw = w * 0.05f, bw = w * 0.16f;
            path.rewind();
            path.moveTo(x0 - tw, -h * 0.05f);
            path.lineTo(x0 + tw, -h * 0.05f);
            path.lineTo(x0 + bw + shear, h * 0.85f);
            path.lineTo(x0 - bw + shear, h * 0.85f);
            path.close();
            gp.setShader(rayG);
            gp.setAlpha((int) (255 * e * (0.55f + 0.45f * sn(td, 7 + b * 2, b * 1.7))));
            c.drawPath(path, gp);
        }
        gp.setShader(null);
        gp.setAlpha(255);
        for (int k = 0; k < 16; k++) {                                            // fireflies
            float x = hash(k * 7 + 1) * w + (float) Math.sin(td * (0.25 + 0.2 * hash(k)) + k * 3.0) * 70f * u;
            float y = h * (0.12f + 0.7f * hash(k * 7 + 2)) + (float) Math.cos(td * (0.2 + 0.15 * hash(k + 9)) + k) * 50f * u;
            float bl = (float) Math.pow(0.5 + 0.5 * Math.sin(td * (0.8 + 0.9 * hash(k * 7 + 3)) + k * 5.0), 3.0);
            halo(c, H_LEAF, x, y, 26f * u, bl * e * 0.8f);
            dot(c, x, y, 2.2f * u, 0xFFF4FFC8, bl * e);
        }
        for (int k = 0; k < 5; k++) {                                             // a few leaves drifting down
            float t = (float) ((td * (0.018 + 0.006 * k) + hash(k * 3 + 1)) % 1.0);
            float x = w * (hash(k * 3 + 2) * 0.8f + 0.1f) + (float) Math.sin(td * 0.9 + k * 2.0) * 60f * u + t * 120f * u;
            float y = h * (-0.05f + 1.1f * t);
            c.save();
            c.translate(x, y);
            c.rotate((float) ((td * 40.0 * (k % 2 == 0 ? 1 : -1)) % 360.0) + k * 70f);
            c.scale(22f * u, 22f * u);
            pt.setStyle(Paint.Style.FILL);
            pt.setShader(k % 2 == 0 ? leafB : leafC);
            pt.setColor(al(0xFFFFFFFF, 0.8f * e));
            c.drawPath(leafP, pt);
            pt.setShader(null);
            c.restore();
        }
    }

    private void envCosmos(Canvas c, double td, float e) {
        halo(c, H_VIO, w * (0.22f + 0.03f * (float) Math.sin(td * 0.05)), h * 0.26f, w * 0.75f, 0.11f * e);
        halo(c, H_CYAN, w * 0.88f, h * (0.72f + 0.02f * (float) Math.cos(td * 0.04)), w * 0.62f, 0.07f * e);
        for (int tier = 0; tier < 3; tier++) {                                    // stars in three brightnesses
            int n = 0;
            for (int k = tier; k < 72; k += 3) {
                buf[n++] = hash(k * 5 + 1) * w;
                buf[n++] = hash(k * 5 + 2) * h;
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth((1.6f + tier * 0.9f) * u);
            pt.setColor(al(tier == 2 ? 0xFFFFF4D8 : 0xFFDCE6FF, e * (0.35f + 0.4f * (0.5f + 0.5f * sn(td, 2.4 + tier * 1.1, tier * 2.1)))));
            c.drawPoints(buf, 0, n, pt);
        }
        float cyc = (float) (td % 9.0), sl = 0.9f;                                // a shooting star every nine seconds
        if (cyc < sl) {
            float t = cyc / sl, hx = w * (0.85f - 0.55f * t), hy = h * (0.08f + 0.22f * t);
            for (int q = 0; q < 5; q++) {
                float t0 = Math.max(0f, t - q * 0.025f), t1 = Math.max(0f, t - (q + 1) * 0.025f);
                line(c, w * (0.85f - 0.55f * t0), h * (0.08f + 0.22f * t0), w * (0.85f - 0.55f * t1), h * (0.08f + 0.22f * t1),
                        (3.4f - q * 0.5f) * u, 0xFFE6F0FF, e * (1f - q * 0.2f) * (float) Math.sin(Math.PI * t));
            }
            dot(c, hx, hy, 3.2f * u, 0xFFFFFFFF, e * (float) Math.sin(Math.PI * t));
        }
    }

    private void envNexus(Canvas c, double td, float e) {
        float bandH = h * 0.07f, yc = (float) ((td * 0.06) % 1.3) * h - h * 0.15f;
        mx.setScale(1f, bandH / 100f);
        mx.postTranslate(0f, yc);
        bandG.setLocalMatrix(mx);
        gp.setShader(bandG);
        gp.setAlpha((int) (255 * e));
        c.drawRect(0f, yc - bandH, w, yc + bandH, gp);
        gp.setShader(null);
        gp.setAlpha(255);
        int n = 0;
        for (int k = 0; k < 26; k++) {                                            // data packets falling down fixed lanes
            float lane = (float) (Math.floor(hash(k * 5 + 1) * 24.0) + 0.5) / 24f * w;
            float t = (float) ((td * (0.05 + 0.09 * hash(k * 5 + 2)) + hash(k * 5 + 3)) % 1.0);
            float y = h * (1.1f * t - 0.05f), len = (14f + 40f * hash(k * 5 + 4)) * u;
            buf[n++] = lane;
            buf[n++] = y - len;
            buf[n++] = lane;
            buf[n++] = y;
        }
        stroke(1.6f * u, 0xFF38E8FF, e * 0.30f);
        c.drawLines(buf, 0, n, pt);
        n = 0;
        for (int k = 0; k < 26; k++) {
            buf[n++] = buf[4 * k + 2];
            buf[n++] = buf[4 * k + 3];
        }
        stroke(4.2f * u, 0xFFBFFBFF, e * 0.7f);
        c.drawPoints(buf, 0, n, pt);
    }

    private void envObsidian(Canvas c, double td, float e) {
        float t = (float) ((td % 12.0) / 4.5);                                    // a slow band of light crosses the glass
        if (t < 1f) {
            float s = smooth(t);
            mx.setScale(w * 0.0016f, h * 0.0045f);
            mx.postRotate(28f);
            mx.postTranslate(-w * 0.3f + w * 1.6f * s, h * (0.1f + 0.8f * s));
            sheenG.setLocalMatrix(mx);
            gp.setShader(sheenG);
            gp.setAlpha((int) (255 * 0.35f * e * (float) Math.sin(Math.PI * t)));
            c.drawRect(0f, 0f, w, h, gp);
            gp.setShader(null);
            gp.setAlpha(255);
        }
        for (int k = 0; k < 6; k++) {                                             // glints on the glass
            float cyc = (float) ((td * (0.16 + 0.05 * hash(k + 3)) + hash(k * 3 + 1)) % 1.0);
            float al = (float) Math.pow(Math.max(0.0, Math.sin(Math.PI * cyc * 1.0)), 14.0) * e * 0.85f;
            if (al > 0.02f) star4(c, hash(k * 7 + 1) * w, hash(k * 7 + 2) * h, (10f + 10f * hash(k + 5)) * u, 0xFFCFD6FF, al);
        }
    }

    // ---------- cache ----------

    void prepare(int th) {
        int i = th - FIRST;
        if (cache[i] != null || r <= 0f) return;
        float ext = 1.12f;
        int bw = (int) Math.ceil(2f * ext * r) + 4;
        cache[i] = Bitmap.createBitmap(bw, bw, Bitmap.Config.ARGB_8888);
        Canvas k = new Canvas(cache[i]);
        k.translate(ext * r + 2f, ext * r + 2f);
        pt.setShader(null);
        switch (i) {
            case INF: infernoArt(k); break;
            case NAT: natureArt(k); break;
            case COS: cosmosArt(k); break;
            case NEX: nexusArt(k); break;
            default: obsidianArt(k); break;
        }
    }

    private void drawCache(Canvas c, int i, float alpha) {
        prepare(FIRST + i);
        if (cache[i] == null || alpha < 0.01f) return;
        float ext = 1.12f;
        bp.setAlpha((int) (255 * clamp01(alpha)));
        c.drawBitmap(cache[i], -ext * r - 2f, -ext * r - 2f, bp);
        bp.setAlpha(255);
    }

    // ---------- drawing one clock ----------

    /**
     * b is how much of the clock has formed (0..1), x how far it has come apart (0..1), tapT seconds since the last
     * tap (negative when none). Everything is drawn in a frame centred on the clock.
     */
    void draw(int th, Canvas c, float hDeg, float mDeg, float sDeg, float sa, float b, float x, float tapT, long now) {
        double td = now / 1000.0;
        int i = th - FIRST;
        float alpha = 1f - seg(x, 0.5f, 1f);
        float k = seg(b, 0.78f, 1f);
        c.save();
        c.translate(cx, cy);
        int sc = -1;
        if (alpha < 0.99f && alpha > 0.01f) sc = c.saveLayerAlpha(-r * 2.7f, -r * 2.7f, r * 2.7f, r * 2.7f, (int) (255 * alpha));
        if (alpha > 0.01f) {
            switch (i) {
                case INF: inferno(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, k); break;
                case NAT: nature(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, k); break;
                case COS: cosmos(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, k); break;
                case NEX: nexus(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, k); break;
                default: obsidian(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, k); break;
            }
        }
        if (sc >= 0) c.restoreToCount(sc);
        if (x > 0f) {                                                            // what flies off leaves the clock's own layer
            switch (i) {
                case INF: infernoAsh(c, x, td); break;
                case NAT: natureWind(c, x, td); break;
                case COS: cosmosSink(c, x, td); break;
                default: break;
            }
        }
        c.restore();
    }

    // =====================================================================================================
    // 5  Inferno
    // =====================================================================================================

    private void infernoArt(Canvas c) {
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(magmaDial);
        c.drawCircle(0f, 0f, r * 0.93f, pt);
        pt.setShader(null);
        for (int i = 0; i < 160; i++) {                                         // the grain of cooled basalt
            float ang = hash(i * 3 + 1) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 2)) * r * 0.88f;
            dot(c, (float) Math.cos(ang) * rad, (float) Math.sin(ang) * rad, r * (0.003f + 0.004f * hash(i + 7)), i % 3 == 0 ? 0xFFFF6A1A : 0xFF000000, i % 3 == 0 ? 0.10f : 0.35f);
        }
        stroke(r * 0.10f, 0xFF1C0C08, 1f);                                      // the forged iron rim
        c.drawCircle(0f, 0f, r * 0.95f, pt);
        ring(c, 0f, 0f, r * 0.995f, r * 0.006f, 0xFFFFB070, 0.35f);
        ring(c, 0f, 0f, r * 0.905f, r * 0.012f, 0xFF050202, 1f);
        ring(c, 0f, 0f, r * 0.893f, r * 0.008f, 0xFFFF6A1A, 0.55f);
        for (int i = 0; i < 60; i++) {
            if (i % 5 == 0) continue;
            dot(c, px(r * 0.84f, i * 6f), py(r * 0.84f, i * 6f), r * 0.006f, 0xFFFF8A1E, 0.55f);
        }
        for (int i = 0; i < 12; i++) {                                          // forged diamonds for the hours
            boolean q = i % 3 == 0;
            float hh = r * (q ? 0.075f : 0.048f), ww = r * (q ? 0.030f : 0.020f), rr = r * 0.80f;
            c.save();
            c.rotate(i * 30f);
            path.rewind();
            path.moveTo(0f, -rr - hh);
            path.lineTo(ww, -rr);
            path.lineTo(0f, -rr + hh);
            path.lineTo(-ww, -rr);
            path.close();
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(0xFF3A1208);
            c.drawPath(path, pt);
            stroke(r * 0.006f, 0xFFFF9A22, 0.9f);
            c.drawPath(path, pt);
            line(c, 0f, -rr - hh * 0.6f, 0f, -rr + hh * 0.5f, r * 0.007f, 0xFFFFE9A0, q ? 0.95f : 0.7f);
            c.restore();
        }
        String[] q = {"12", "3", "6", "9"};
        for (int i = 0; i < 4; i++) {
            float tx = px(r * 0.62f, i * 90f), ty = py(r * 0.62f, i * 90f);
            text(c, q[i], tx + r * 0.012f, ty + r * 0.016f, r * 0.19f, condensed, 0xFF000000, 0.8f);
            text(c, q[i], tx, ty, r * 0.19f, condensed, 0xFFFFB04A, 0.95f);
        }
        stroke(r * 0.02f, 0xFFFFFFFF, 0.06f);                                   // reflections on the dial
        rc.set(-r * 0.78f, -r * 0.78f, r * 0.78f, r * 0.78f);
        c.drawArc(rc, 200f, 70f, false, pt);
    }

    private void flames(Canvas c, double td, float b, float life, float surge) {
        float[] sc = {1f, 0.64f, 0.34f}, off = {0f, 0.5f, 0.25f}, alp = {0.93f, 0.88f, 0.75f};
        for (int layer = 0; layer < 3; layer++) {
            path.rewind();
            int n = 36;
            float step = 360f / n, base = r * 0.93f;
            for (int i = 0; i < n; i++) {
                float th = (i + off[layer]) * step;
                float ign = seg(b, 0.14f + 0.30f * i / n, 0.40f + 0.30f * i / n);
                if (ign <= 0.002f || life <= 0.002f) continue;
                float nz = 0.55f * vn(wf(td) * 2.6f + i * 0.83f, 11 + layer) + 0.45f * vn(wf(td) * 6.3f + i * 1.7f, 29 + layer);
                float hgt = (0.10f + 0.26f * nz) * sc[layer] * (1f + surge) * ign * life;
                float lean = (nz - 0.5f) * 14f + 4f * (float) Math.sin(td * 2.0 + i * 0.9);
                float hh = r * hgt, tipR = r * 0.93f + hh, wd = step * 1.6f;
                float tA = th + lean, bl = th - wd * 0.5f, br = th + wd * 0.5f;
                float r1 = base + hh * 0.22f, r2 = base + hh * 0.62f;
                path.moveTo(px(base, bl), py(base, bl));
                path.cubicTo(px(r1, bl - wd * 0.10f), py(r1, bl - wd * 0.10f), px(r2, tA - wd * 0.26f + lean * 0.3f), py(r2, tA - wd * 0.26f + lean * 0.3f), px(tipR, tA), py(tipR, tA));
                path.cubicTo(px(r2, tA + wd * 0.26f + lean * 0.3f), py(r2, tA + wd * 0.26f + lean * 0.3f), px(r1, br + wd * 0.10f), py(r1, br + wd * 0.10f), px(base, br), py(base, br));
                path.close();
            }
            pt.setShader(layer == 0 ? fireG : fireG2);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFFFFFFF, alp[layer]));
            if (layer > 0) pt.setXfermode(add);
            c.drawPath(path, pt);
            pt.setXfermode(null);
            pt.setShader(null);
        }
    }

    private void inferno(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float life = 1f - seg(x, 0f, 0.5f);
        float surge = tap >= 0f ? 1.1f * (float) Math.exp(-2.6 * tap) : 0f;
        float heat = 0.8f + 0.2f * sn(td, 2.3, 0) + surge * 0.8f;
        float lit = seg(b, 0.10f, 0.50f) * life;
        halo(c, H_FIRE, 0f, 0f, r * 1.55f, 0.30f * heat * lit);
        if (b < 0.5f) {                                                         // sparks spiral in and gather on the rim
            halo(c, H_HOT, 0f, 0f, r * (0.10f + 0.5f * seg(b, 0f, 0.3f)), 0.55f * (1f - seg(b, 0.2f, 0.45f)));
            for (int i = 0; i < 70; i++) {
                float hs = hash(i * 3 + 1), p = seg(b, 0.0f + 0.28f * hs, 0.40f + 0.25f * hs);
                if (p <= 0f || p >= 1f) continue;
                float p0 = Math.max(0f, p - 0.07f), ang = hash(i * 3 + 2) * 360f, ra = 0.6f + 0.8f * hash(i * 3 + 3);
                float a1 = ang + (1f - p) * 140f, r1 = r * (0.95f + (1f - p) * 1.3f * ra);
                float a0 = ang + (1f - p0) * 140f, r0 = r * (0.95f + (1f - p0) * 1.3f * ra);
                float al = (float) Math.sin(Math.PI * p);
                line(c, px(r0, a0), py(r0, a0), px(r1, a1), py(r1, a1), r * (0.008f + 0.008f * hs), 0xFFFF7A1A, 0.8f * al);
                halo(c, H_FIRE, px(r1, a1), py(r1, a1), r * 0.06f, 0.5f * al);
                dot(c, px(r1, a1), py(r1, a1), r * (0.012f + 0.012f * hs), mix(0xFFFF8A1E, 0xFFFFF0B0, p), al);
            }
        }
        flames(c, td, b, life, surge);
        float built = seg(b, 0.30f, 0.62f) * (1f - seg(x, 0.30f, 0.75f));
        drawCache(c, INF, built);
        float spread = seg(b, 0.16f, 0.60f), xf = seg(x, 0f, 0.35f);
        float crackA = spread * (1f - seg(x, 0.55f, 0.9f));
        if (crackA > 0.01f) {                                                   // living lava spreads from the core
            c.save();
            tmp.rewind();
            tmp.addCircle(0f, 0f, r * 0.93f * Math.max(spread, 0.02f), Path.Direction.CW);
            c.clipPath(tmp);
            float pulse = 0.65f + 0.25f * sn(td, 3.1, 0) + 0.4f * surge + 0.9f * xf;
            float wd = 1f + 0.8f * xf;
            stroke(r * 0.034f * wd, 0xFFFF3A00, 0.22f * pulse * crackA);
            c.drawPath(crack, pt);
            stroke(r * 0.013f * wd, 0xFFFF8A1E, 0.85f * crackA * Math.min(1f, pulse + 0.2f));
            c.drawPath(crack, pt);
            stroke(r * 0.0045f * wd, mix(0xFFFFE9A0, 0xFFFFFFFF, xf), 0.95f * crackA);
            c.drawPath(crack, pt);
            c.restore();
        }
        if (built > 0.3f) {
            for (int i = 0; i < 4; i++) halo(c, H_FIRE, px(r * 0.62f, i * 90f), py(r * 0.62f, i * 90f), r * 0.22f, 0.28f * heat * built);
        }
        embers(c, td, b, life, tap);
        if (tap >= 0f && tap < 2.4f) {                                          // the eruption: shockwaves and a fountain of sparks
            for (int q = 0; q < 3; q++) {
                float t = clamp01((tap - q * 0.16f) / 1.3f);
                if (t > 0f && t < 1f) {
                    float rad = r * (0.9f + 1.15f * outCubic(t));
                    ring(c, 0f, 0f, rad, r * (0.05f * (1f - t) + 0.006f), q == 0 ? 0xFFFFE9A0 : 0xFFFF7A1A, 0.75f * (1f - t));
                }
            }
            halo(c, H_HOT, 0f, 0f, r * (0.5f + 0.5f * tap), 0.5f * (float) Math.exp(-3.0 * tap));
            if (tap < 1.8f) {
                for (int i = 0; i < 36; i++) {
                    float hs = hash(i * 5 + 1), th = i * 10f + 4f * hash(i), v = r * (1.0f + 1.5f * hash(i * 5 + 2)), t = tap;
                    float ox = px(r * 0.96f, th), oy = py(r * 0.96f, th);
                    float vx = px(1f, th) * v, vy = py(1f, th) * v - r * 0.9f;
                    float sx = ox + vx * t, sy = oy + vy * t + 0.5f * r * 2.6f * t * t;
                    halo(c, H_FIRE, sx, sy, r * 0.07f, 0.5f * (1f - t / 1.8f));
                    dot(c, sx, sy, r * (0.014f + 0.018f * hs) * (1f - t / 2.4f), mix(0xFFFFE9A0, 0xFFFF4A12, t / 1.8f), 1f - t / 1.8f);
                }
            }
        }
        if (k > 0.01f && x < 0.7f) {
            float hk = smooth(k), hot = 1f - 0.35f * seg(x, 0f, 0.5f);
            blade(c, hD, r * 0.52f * hk, r * 0.060f, r * 0.12f, heatBlade, 0xFFFF9A22, 0.85f, k);
            blade(c, mD, r * 0.82f * hk, r * 0.042f, r * 0.14f, heatBlade, 0xFFFF9A22, 0.85f, k);
            tipOf(tip, mD, r * 0.82f * hk);
            halo(c, H_HOT, tip[0], tip[1], r * 0.12f, 0.55f * heat * k * hot);
            tipOf(tip, hD, r * 0.52f * hk);
            halo(c, H_FIRE, tip[0], tip[1], r * 0.12f, 0.45f * heat * k * hot);
            if (sa > 0.02f) {
                c.save();
                c.rotate(sD);
                line(c, 0f, r * 0.16f, 0f, -r * 0.88f * hk, r * 0.008f, 0xFFFF8A1E, 0.95f * sa * k);
                dot(c, 0f, -r * 0.88f * hk, r * 0.018f, 0xFFFFE9A0, sa * k);
                c.restore();
            }
            dot(c, 0f, 0f, r * 0.052f, 0xFF1A0A06, k);
            ring(c, 0f, 0f, r * 0.052f, r * 0.012f, 0xFFFF8A1E, k);
            halo(c, H_HOT, 0f, 0f, r * 0.22f, 0.5f * heat * k * life);
        }
    }

    private void embers(Canvas c, double td, float b, float life, float tap) {
        float on = seg(b, 0.30f, 0.80f) * life;
        if (on < 0.01f) return;
        for (int i = 0; i < 26; i++) {
            float sp = 0.16f + 0.22f * hash(i * 5 + 1), t = (float) ((td * sp + hash(i * 5 + 2)) % 1.0);
            float th = hash(i * 5 + 3) * 360f;
            float ex = px(r * 0.98f, th) + (float) Math.sin(td * 1.3 + i * 2.0) * r * 0.06f * t;
            float ey = py(r * 0.98f, th) - r * 1.1f * t;
            float al = (float) Math.pow(Math.sin(Math.PI * t), 0.7) * on;
            dot(c, ex, ey, r * 0.011f * (1f - 0.6f * t), mix(0xFFFFD27A, 0xFFFF5A12, t), al);
            if (i < 6) halo(c, H_FIRE, ex, ey, r * 0.07f, al * 0.4f);
        }
    }

    private void infernoAsh(Canvas c, float x, double td) {
        for (int i = 0; i < 110; i++) {                                          // the dial crumbles to ash and glowing flakes
            float hs = hash(i * 7 + 1), dl = 0.18f * hash(i * 7 + 2) + 0.05f;
            float t = clamp01((x - dl) / (1f - dl));
            if (t <= 0f) continue;
            float rho = (float) Math.sqrt(hash(i * 7 + 3)) * r * 0.88f, ang = hash(i * 7 + 4) * 360f;
            float ox = px(rho, ang), oy = py(rho, ang);
            float sx = ox + px(1f, ang) * r * (0.35f + 0.9f * hs) * t + (float) Math.sin(t * 9.0 + i) * r * 0.05f * t;
            float sy = oy + py(1f, ang) * r * (0.35f + 0.9f * hs) * t - r * 1.7f * t * t;
            float al = seg(x, 0.06f, 0.22f) * (1f - smooth((t - 0.45f) / 0.55f));
            dot(c, sx, sy, r * (0.016f + 0.030f * hash(i * 7 + 5)) * (1f - 0.5f * t), mix(0xFFFF8A1E, 0xFF5A4A44, t * 1.6f), al);
        }
        halo(c, H_FIRE, 0f, 0f, r * 1.5f, 0.28f * (1f - x) * seg(x, 0f, 0.2f));
    }

    // =====================================================================================================
    // 6  Nature
    // =====================================================================================================

    private void natureArt(Canvas c) {
        shaderRing(c, barkS, r * 0.93f, r * 0.14f, 1f);                         // a ring of bark with its growth rings
        float[] gr = {0.88f, 0.915f, 0.95f, 0.975f};
        for (int i = 0; i < 4; i++) ring(c, 0f, 0f, r * gr[i], r * 0.003f, 0xFF2A1808, 0.35f);
        ring(c, 0f, 0f, r * 0.995f, r * 0.004f, 0xFFB88A58, 0.5f);
        for (int i = 0; i < 14; i++) {                                          // moss on the bark
            float ang = hash(i * 5 + 1) * 360f, rad = r * (0.90f + 0.07f * hash(i * 5 + 2));
            dot(c, px(rad, ang), py(rad, ang), r * (0.03f + 0.02f * hash(i * 5 + 3)), 0xFF4A8A3A, 0.45f);
        }
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(mossDial);
        c.drawCircle(0f, 0f, r * 0.86f, pt);
        pt.setShader(null);
        float[] tr = {0.15f, 0.27f, 0.40f, 0.52f, 0.64f, 0.75f};
        for (int i = 0; i < tr.length; i++) ring(c, -r * 0.01f * i, r * 0.008f * i, r * tr[i], r * 0.004f, 0xFFFFFFFF, 0.05f);
        for (int i = 0; i < 70; i++) {                                          // dew on the glass
            float ang = hash(i * 3 + 1) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 2)) * r * 0.82f;
            dot(c, (float) Math.cos(ang) * rad, (float) Math.sin(ang) * rad, r * (0.003f + 0.004f * hash(i + 3)), 0xFFFFFFFF, 0.10f);
        }
        for (int i = 0; i < 60; i++) {
            if (i % 5 == 0) continue;
            dot(c, px(r * 0.80f, i * 6f), py(r * 0.80f, i * 6f), r * 0.005f, 0xFFC8F0B0, 0.35f);
        }
        ring(c, 0f, 0f, r * 0.845f, r * 0.03f, 0xFF000000, 0.30f);
        stroke(r * 0.02f, 0xFFFFFFFF, 0.07f);
        rc.set(-r * 0.76f, -r * 0.76f, r * 0.76f, r * 0.76f);
        c.drawArc(rc, 195f, 90f, false, pt);
    }

    private void leaf(Canvas c, float x, float y, float deg, float sz, Shader s, float alpha) {
        if (alpha < 0.01f || sz < 0.5f) return;
        c.save();
        c.translate(x, y);
        c.rotate(deg);
        c.scale(sz, sz);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(s);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawPath(leafP, pt);
        pt.setShader(null);
        c.restore();
    }

    private void flower(Canvas c, float x, float y, float deg, float sz, boolean daisy, float alpha) {
        if (alpha < 0.01f || sz < 0.5f) return;
        c.save();
        c.translate(x, y);
        c.rotate(deg);
        c.scale(sz, sz);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(daisy ? petalW : petalP);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawPath(flowerP, pt);
        c.rotate(36f);
        c.scale(0.62f, 0.62f);
        pt.setShader(daisy ? petalP : petalIn);
        c.drawPath(flowerP, pt);
        pt.setShader(null);
        pt.setColor(al(0xFFFFC93A, alpha));
        c.drawCircle(0f, 0f, 0.26f, pt);
        pt.setColor(al(0xFF8A4B14, alpha * 0.7f));
        c.drawCircle(0.05f, 0.04f, 0.09f, pt);
        c.restore();
    }

    private void branch(Canvas c, float deg, float len, float wid, int twigs, float leafSz, float grow, float wither, float alpha, double td, int seed) {
        if (grow < 0.01f) return;
        float L = len * grow;
        c.save();
        c.rotate(deg + 1.2f * sn(td, 5.5 + seed, seed));
        line(c, 0f, r * 0.07f, 0f, -L, wid * 1.4f, 0xFF2A1A0C, alpha);
        line(c, 0f, r * 0.06f, 0f, -L, wid, 0xFF7A5430, alpha);
        line(c, -wid * 0.2f, 0f, -wid * 0.2f, -L * 0.97f, wid * 0.32f, 0xFFC09060, alpha * 0.8f);
        Shader ls = wither > 0.25f ? leafC : leafB;
        for (int t = 0; t < twigs; t++) {
            float f = 0.30f + 0.55f * t / Math.max(1, twigs - 1);
            float side = t % 2 == 0 ? 1f : -1f, ty = -L * f, tl = leafSz * 1.7f * smooth(grow * 1.2f - f * 0.2f);
            float ang = side * 48f, tx = px(tl, ang) , tyy = ty + py(tl, ang);
            line(c, 0f, ty, tx, tyy, wid * 0.45f, 0xFF7A5430, alpha);
            leaf(c, tx, tyy, ang + side * 8f + 3f * sn(td, 3 + t, t + seed), leafSz * smooth(grow * 1.3f - f * 0.3f), t % 2 == 0 ? leafA : ls, alpha);
        }
        leaf(c, 0f, -L, 2f * sn(td, 4, seed), leafSz * 1.25f * smooth(grow), leafA, alpha);
        c.restore();
    }

    private void nature(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float grow = seg(b, 0.20f, 0.78f), wither = seg(x, 0f, 0.6f);
        float dialRev = seg(b, 0.04f, 0.40f), da = 1f - seg(x, 0.35f, 0.9f);
        if (b < 0.55f) {                                                        // a seed wakes in the middle
            float sg = 1f - seg(b, 0.32f, 0.55f);
            halo(c, H_LEAF, 0f, 0f, r * (0.05f + 0.34f * seg(b, 0f, 0.35f)), 0.85f * sg * (0.7f + 0.3f * sn(td, 1.2, 0)));
            dot(c, 0f, 0f, r * 0.02f * (1f - seg(b, 0.2f, 0.4f)), 0xFFF4FFC8, sg);
        }
        if (dialRev > 0.002f) {                                                 // the dial grows outward from the seed
            c.save();
            tmp.rewind();
            tmp.addCircle(0f, 0f, r * 1.06f * outCubic(dialRev), Path.Direction.CW);
            c.clipPath(tmp);
            drawCache(c, NAT, da);
            c.restore();
        }
        float vineA = da;
        int stem = mix(0xFF3E7A34, 0xFF8A6A2A, wither);
        if (grow > 0.003f) {                                                    // the vine climbs clockwise from twelve
            Path vp = vine;
            if (grow < 1f) {
                pm.setPath(vine, false);
                vSeg.rewind();
                pm.getSegment(0f, pm.getLength() * grow, vSeg, true);
                vp = vSeg;
            }
            stroke(r * 0.020f, 0xFF1A3A14, vineA);
            c.drawPath(vp, pt);
            stroke(r * 0.015f, stem, vineA);
            c.drawPath(vp, pt);
            stroke(r * 0.0045f, mix(0xFF9BE07A, 0xFFD8B050, wither), 0.8f * vineA);
            c.drawPath(vp, pt);
            if (grow < 1f) {                                                    // the growing tip glows
                float ta = grow * 360f;
                halo(c, H_LEAF, px(vineR(ta), ta), py(vineR(ta), ta), r * 0.14f, 0.8f);
                dot(c, px(vineR(ta), ta), py(vineR(ta), ta), r * 0.014f, 0xFFF4FFC8, 1f);
            }
        }
        for (int i = 0; i < LEAVES; i++) {                                      // leaves unfurl as the vine passes, shed in the wind
            float thk = lvA[i], lg = outBack((grow * 360f - thk) / 36f);
            float dly = 0.05f + 0.40f * hash(i * 9 + 4), t = clamp01((x - dly) / (0.95f - dly));
            if (lg <= 0.01f || t >= 1f) continue;
            float gust = tap >= 0f ? 22f * (float) Math.exp(-1.6 * tap) * (float) Math.sin(tap * 8.0 - thk * 0.045) : 0f;
            float sway = 5f * sn(td, 3.2 + 0.1 * (i % 5), i * 0.9) + 3f * (vn(wf(td) * 0.7f + i, 3) - 0.5f) + gust;
            float vr = vineR(thk), vx = px(vr, thk), vy = py(vr, thk);
            float dir = (i % 2 == 0 ? thk + 38f : thk + 142f) + sway;
            float ox = 0f, oy = 0f, spin = 0f;
            if (t > 0f) {
                ox = r * (0.2f + 2.6f * t * t) * (0.6f + 0.8f * lvR[i]);
                oy = -r * 0.5f * t + r * 0.35f * (float) Math.sin(t * 7.0 + i) * t;
                spin = t * 260f * (lvR[i] - 0.5f);
            }
            boolean turned = x > 0.12f + 0.3f * hash(i * 9 + 6);
            leaf(c, vx + ox, vy + oy, dir + spin, lvSize[i] * Math.min(lg, 1.15f) * (1f - 0.3f * t), turned ? leafC : (i % 2 == 0 ? leafA : leafB), (1f - seg(t, 0.55f, 1f)) * vineA);
        }
        for (int q = 0; q < 12; q++) {                                          // blossoms open as the vine reaches them
            float ang = q * 30f;
            boolean daisy = q % 3 == 0;
            float bloom = outBack((grow * 360f - ang) / 36f - 0.15f);
            float dl = 0.30f + 0.40f * hash(q * 5 + 2), t = clamp01((x - dl) / (0.95f - dl));
            if (bloom <= 0.01f || t >= 1f) continue;
            float pulse = 1f + 0.05f * sn(td, 4, q) + (tap >= 0f ? 0.28f * (float) Math.exp(-2.2 * tap) * (float) Math.sin(tap * 14.0 - q * 0.5) : 0f);
            float vr = vineR(ang), fx = px(vr, ang), fy = py(vr, ang);
            if (t > 0f) {
                fx += r * (0.3f + 3f * t * t) * (0.7f + 0.6f * hash(q * 5 + 3));
                fy += -r * 0.6f * t + r * 0.4f * (float) Math.sin(t * 6.0 + q) * t;
            }
            flower(c, fx, fy, ang + 12f * sn(td, 5, q) + t * 300f, r * (daisy ? 0.105f : 0.072f) * Math.min(bloom, 1.2f) * pulse, daisy, (1f - seg(t, 0.7f, 1f)) * vineA);
        }
        if (tap >= 0f && tap < 2.6f) {                                          // the gust shakes petals loose
            for (int i = 0; i < 48; i++) {
                int q = i / 4;
                float t = clamp01((tap - 0.05f * (i % 4)) / 2.3f);
                if (t <= 0f || t >= 1f) continue;
                float ang = q * 30f, vr = vineR(ang);
                float sx = px(vr, ang) + r * (0.25f + 1.5f * hash(i * 3 + 1)) * t + (float) Math.sin(t * 8.0 + i) * r * 0.06f * t;
                float sy = py(vr, ang) - r * 0.35f * t * (0.5f + hash(i * 3 + 2)) + r * 0.9f * t * t;
                c.save();
                c.translate(sx, sy);
                c.rotate(i * 47f + t * 400f);
                c.scale(r * 0.035f, r * 0.035f);
                pt.setStyle(Paint.Style.FILL);
                pt.setShader(q % 3 == 0 ? petalW : petalP);
                pt.setColor(al(0xFFFFFFFF, (1f - t) * seg(t, 0f, 0.1f)));
                c.drawPath(leafP, pt);
                pt.setShader(null);
                c.restore();
            }
            float ge = (float) Math.exp(-2.0 * tap);
            halo(c, H_LEAF, 0f, 0f, r * (0.6f + 0.5f * tap), 0.35f * ge);
        }
        if (k > 0.01f) {                                                        // branch hands with leaves, a dew drop for the seconds
            float hk = outCubic(k);
            branch(c, hD, r * 0.50f, r * 0.050f, 2, r * 0.085f, hk, wither, k * da, td, 1);
            branch(c, mD, r * 0.80f, r * 0.027f, 3, r * 0.065f, hk, wither, k * da, td, 2);
            if (sa > 0.02f) {
                c.save();
                c.rotate(sD);
                line(c, 0f, r * 0.14f, 0f, -r * 0.86f * hk, r * 0.008f, 0xFF9BE07A, 0.9f * sa * k * da);
                halo(c, H_LEAF, 0f, -r * 0.86f * hk, r * 0.10f, 0.35f * sa * k * da);
                dot(c, 0f, -r * 0.86f * hk, r * 0.030f, 0xFFD6FFF0, 0.85f * sa * k * da);
                dot(c, -r * 0.009f, -r * 0.86f * hk - r * 0.010f, r * 0.010f, 0xFFFFFFFF, sa * k * da);
                c.restore();
            }
            dot(c, 0f, 0f, r * 0.048f, 0xFF5A3C20, k * da);
            dot(c, 0f, 0f, r * 0.028f, 0xFF9BE07A, k * da);
            dot(c, -r * 0.008f, -r * 0.008f, r * 0.010f, 0xFFF4FFC8, k * da);
        }
    }

    private void natureWind(Canvas c, float x, double td) {
        for (int i = 0; i < 18; i++) {                                          // a few extra leaves ride the wind across the screen
            float dl = 0.05f + 0.4f * hash(i * 5 + 1), t = clamp01((x - dl) / (1f - dl));
            if (t <= 0f) continue;
            float ang = hash(i * 5 + 2) * 360f, rad = r * (0.7f + 0.2f * hash(i * 5 + 3));
            float sx = px(rad, ang) + r * (0.5f + 3.2f * hash(i * 5 + 4)) * t * t;
            float sy = py(rad, ang) - r * 0.9f * t + r * 0.5f * (float) Math.sin(t * 6.0 + i) * t;
            leaf(c, sx, sy, ang + t * 420f * (hash(i) - 0.5f), r * (0.05f + 0.04f * hash(i * 5 + 5)), i % 3 == 0 ? leafA : leafC, 1f - seg(t, 0.5f, 1f));
        }
    }

    // =====================================================================================================
    // 7  Cosmos
    // =====================================================================================================

    private void cosmosArt(Canvas c) {
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(cosmosDial);
        c.drawCircle(0f, 0f, r * 0.9f, pt);
        pt.setShader(null);
        c.save();
        c.clipPath(disc);
        for (int i = 0; i < 170; i++) {                                         // background stars
            float ang = hash(i * 3 + 11) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 12)) * r * 0.9f;
            dot(c, (float) Math.cos(ang) * rad, (float) Math.sin(ang) * rad, r * (0.002f + 0.004f * hash(i + 13)), 0xFFFFFFFF, 0.3f + 0.6f * hash(i * 3 + 14));
        }
        for (int i = 0; i < 3400; i++) {                                        // three spiral arms of dust and stars
            float rho = 0.04f + 0.84f * (float) Math.pow(hash(i * 5 + 1), 0.7);
            float th = (i % 3) * (TAU / 3f) + 5.2f * rho + (hash(i * 5 + 2) - 0.5f) * (0.9f * (1f - rho) + 0.28f);
            float sx = (float) Math.cos(th) * rho * r, sy = (float) Math.sin(th) * rho * r;
            int col = rho < 0.3f ? mix(0xFFFFE3B0, 0xFFC79BFF, rho / 0.3f) : mix(0xFFC79BFF, 0xFF6C8CFF, (rho - 0.3f) / 0.6f);
            dot(c, sx, sy, r * (0.003f + 0.006f * hash(i * 5 + 3)), col, (0.25f + 0.55f * hash(i * 5 + 4)) * (1f - 0.5f * rho));
        }
        for (int i = 0; i < 380; i++) {                                         // dust lanes
            float rho = 0.10f + 0.74f * hash(i * 5 + 21);
            float th = (i % 3) * (TAU / 3f) + 5.2f * rho + 0.22f * (1f - rho) + 0.1f;
            dot(c, (float) Math.cos(th) * rho * r, (float) Math.sin(th) * rho * r, r * (0.008f + 0.012f * hash(i * 5 + 22)), 0xFF03030C, 0.30f);
        }
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(cosCore);
        c.drawCircle(0f, 0f, r * 0.34f, pt);
        pt.setShader(null);
        c.restore();
        float[] orb = {0.30f, 0.55f, 0.78f};
        for (int i = 0; i < 3; i++) ring(c, 0f, 0f, r * orb[i], r * 0.003f, 0xFFB9A4FF, 0.10f);
    }

    private void cosmos(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float sc = 1f - 0.94f * x * x;
        float gS = 0.04f + 0.96f * outCubic(seg(b, 0.05f, 0.62f)), gA = seg(b, 0.04f, 0.30f);
        float spinIn = 1f - seg(b, 0.05f, 0.75f);
        float tapSpin = tap >= 0f ? 140f * (1f - (float) Math.exp(-1.6 * tap)) : 0f;
        float rot = (float) ((td * 2.2) % 360.0) + 480f * spinIn * spinIn + 900f * x * x + tapSpin;
        if (b < 0.14f) {                                                        // a point of light, then it breaks open
            float p = b / 0.14f;
            halo(c, H_WHITE, 0f, 0f, r * (0.05f + 0.5f * p), 0.9f * (float) Math.sin(Math.PI * Math.min(1f, p * 1.1f)));
        }
        if (b < 0.58f) {                                                        // stardust falls in and gathers into arms
            for (int i = 0; i < 90; i++) {
                float hs = hash(i * 3 + 1), p = seg(b, 0.02f + 0.25f * hs, 0.40f + 0.25f * hs);
                if (p <= 0f || p >= 1f) continue;
                float ang = hash(i * 3 + 2) * 360f + (1f - p) * 220f, rad = r * (0.30f + (1f - p) * (1.5f - 0.3f * hash(i * 3 + 3)) + 0.6f * p);
                dot(c, px(Math.min(rad, r * 1.9f), ang), py(Math.min(rad, r * 1.9f), ang), r * (0.006f + 0.008f * hs), mix(0xFFB9A4FF, 0xFFFFF4D8, p), (float) Math.sin(Math.PI * p));
            }
        }
        c.save();
        c.scale(sc, sc);
        if (gA > 0.01f) {
            c.save();
            c.rotate(rot);
            c.scale(gS, gS);
            drawCache(c, COS, gA);
            c.restore();
        }
        float ig = seg(b, 0.35f, 0.65f);                                        // the photon ring ignites
        if (ig > 0.01f) {
            float wob = 1f + 0.02f * (1f - ig);
            ring(c, 0f, 0f, r * 0.95f * wob, r * 0.10f, 0xFF07061C, ig);
            ring(c, 0f, 0f, r * 0.995f * wob, r * 0.006f, 0xFF9A8CFF, 0.5f * ig);
            ring(c, 0f, 0f, r * 0.90f, r * 0.004f, 0xFF6A5CC8, 0.6f * ig);
            mx.setRotate((float) ((td * 40.0) % 360.0) + 360f * (1f - ig));
            photonS.setLocalMatrix(mx);
            shaderRing(c, photonS, r * 0.915f, r * 0.05f, 0.18f * ig);
            shaderRing(c, photonS, r * 0.915f, r * 0.012f, ig);
        }
        float tw = 1f;
        if (gA > 0.5f) {                                                        // a few stars twinkle on the dial
            for (int i = 0; i < 24; i++) {
                float al = (0.35f + 0.65f * (0.5f + 0.5f * sn(td, 1.6 + 2.0 * hash(i + 3), i * 1.7))) * gA * tw;
                dot(c, twk[2 * i] * gS, twk[2 * i + 1] * gS, r * (0.004f + 0.004f * hash(i + 9)), 0xFFFFFFFF, al);
            }
        }
        float mk = seg(b, 0.55f, 0.85f);
        if (mk > 0.01f) {                                                       // twelve stars for the hours
            int n = 0;
            for (int i = 0; i < 60; i++) {
                if (i % 5 == 0) continue;
                buf[n++] = px(r * 0.80f, i * 6f);
                buf[n++] = py(r * 0.80f, i * 6f);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(r * 0.011f);
            pt.setColor(al(0xFFDCD2FF, 0.5f * mk));
            c.drawPoints(buf, 0, n, pt);
            for (int i = 0; i < 12; i++) {
                boolean q = i % 3 == 0;
                float ms = clamp01((mk * 1.4f - 0.4f * i / 12f)), s = r * (q ? 0.062f : 0.036f) * outBack(ms);
                float mxp = px(r * 0.80f, i * 30f), myp = py(r * 0.80f, i * 30f);
                float twinkle = 0.75f + 0.25f * sn(td, 2.0 + 0.2 * i, i);
                if (q) halo(c, H_VIO, mxp, myp, s * 3.4f, 0.55f * twinkle * mk);
                star4(c, mxp, myp, s, q ? 0xFFFFE9B0 : 0xFFDCD2FF, twinkle * mk);
            }
        }
        if (tap >= 0f && tap < 3f) {                                            // supernova: flash, shockwaves and a shooting star
            halo(c, H_WHITE, 0f, 0f, r * (0.35f + 0.5f * tap), 0.9f * (float) Math.exp(-3.2 * tap));
            for (int q = 0; q < 3; q++) {
                float t = clamp01((tap - q * 0.2f) / 1.6f);
                if (t > 0f && t < 1f) ring(c, 0f, 0f, r * (0.1f + 1.25f * outCubic(t)), r * (0.045f * (1f - t) + 0.005f), q == 0 ? 0xFFFFFFFF : (q == 1 ? 0xFFB48CFF : 0xFF38E8FF), 0.8f * (1f - t));
            }
            if (tap < 1.1f) {
                float t = tap / 1.1f;
                float hx = -0.95f * r + 1.9f * r * t, hy = -0.8f * r + 1.6f * r * t, fa = (float) Math.sin(Math.PI * t);
                for (int q = 0; q < 6; q++) {
                    float t0 = Math.max(0f, t - q * 0.035f), t1 = Math.max(0f, t - (q + 1) * 0.035f);
                    line(c, -0.95f * r + 1.9f * r * t0, -0.8f * r + 1.6f * r * t0, -0.95f * r + 1.9f * r * t1, -0.8f * r + 1.6f * r * t1, r * (0.018f - q * 0.002f), 0xFFE6F0FF, fa * (1f - q * 0.16f));
                }
                halo(c, H_WHITE, hx, hy, r * 0.12f, fa * 0.8f);
                dot(c, hx, hy, r * 0.014f, 0xFFFFFFFF, fa);
            }
        }
        if (k > 0.01f) {                                                        // hands of light
            float hk = smooth(k);
            halo(c, H_VIO, 0f, 0f, r * 0.22f, 0.45f * k);
            lightBeam(c, hD, r * 0.50f * hk, r * 0.050f, beamH, H_VIO, k);
            lightBeam(c, mD, r * 0.82f * hk, r * 0.034f, beamM, H_CYAN, k);
            if (sa > 0.02f) {                                                   // a small comet circles the photon ring
                float a1 = sa * k;
                for (int q = 0; q < 4; q++) arc(c, r * 0.915f, sD - 90f - 9f * (q + 1), 9f, r * (0.016f - q * 0.003f), 0xFFFFD27A, a1 * (0.7f - q * 0.16f));
                float hx = px(r * 0.915f, sD), hy = py(r * 0.915f, sD);
                halo(c, H_HOT, hx, hy, r * 0.10f, 0.7f * a1);
                dot(c, hx, hy, r * 0.016f, 0xFFFFFFFF, a1);
            }
            dot(c, 0f, 0f, r * 0.030f, 0xFFFFF4D8, k);
        }
        c.restore();
    }

    private void lightBeam(Canvas c, float deg, float len, float wid, Shader s, int glow, float alpha) {
        c.save();
        c.rotate(deg);
        path.rewind();
        path.moveTo(0f, -len);
        path.lineTo(wid, -len * 0.04f);
        path.lineTo(0f, r * 0.10f);
        path.lineTo(-wid, -len * 0.04f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(s);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawPath(path, pt);
        pt.setShader(null);
        line(c, 0f, -len * 0.12f, 0f, -len, r * 0.006f, 0xFFFFFFFF, 0.8f * alpha);
        halo(c, glow, 0f, -len, r * 0.13f, 0.7f * alpha);
        star4(c, 0f, -len, r * 0.045f, 0xFFFFFFFF, alpha);
        c.restore();
    }

    private void cosmosSink(Canvas c, float x, double td) {
        for (int i = 0; i < 70; i++) {                                          // everything is drawn into the singularity
            float dl = 0.5f * hash(i * 5 + 1), p = clamp01((x - dl) / (1f - dl));
            if (p <= 0f || p >= 1f) continue;
            float ang = hash(i * 5 + 2) * 360f + p * 300f, rad = r * (0.15f + 1.0f * hash(i * 5 + 3)) * (1f - p) * (1f - p);
            dot(c, px(rad, ang), py(rad, ang), r * (0.006f + 0.007f * hash(i * 5 + 4)), 0xFFDCD2FF, (float) Math.sin(Math.PI * p));
        }
        float fl = seg(x, 0.62f, 0.85f);
        if (fl > 0.01f) halo(c, H_WHITE, 0f, 0f, r * (0.15f + 0.6f * fl), (float) Math.sin(Math.PI * seg(x, 0.62f, 1f)));
    }

    // =====================================================================================================
    // 8  Nexus
    // =====================================================================================================

    private void nexusArt(Canvas c) {
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(netDial);
        c.drawCircle(0f, 0f, r * 0.9f, pt);
        pt.setShader(null);
        c.save();                                                               // a faint hex grid
        c.clipPath(disc);
        path.rewind();
        float s = r * 0.13f, hh = s * 0.866f;
        for (int row = -9; row <= 9; row++) {
            for (int col = -9; col <= 9; col++) {
                float hx = col * s * 1.5f, hy = row * hh * 2f + (col & 1) * hh;
                if (hx * hx + hy * hy > r * r * 1.05f) continue;
                for (int e = 0; e < 3; e++) {
                    float a0 = e * 60f, a1 = a0 + 60f;
                    path.moveTo(hx + (float) Math.cos(Math.toRadians(a0)) * s, hy + (float) Math.sin(Math.toRadians(a0)) * s);
                    path.lineTo(hx + (float) Math.cos(Math.toRadians(a1)) * s, hy + (float) Math.sin(Math.toRadians(a1)) * s);
                }
            }
        }
        stroke(r * 0.003f, 0xFF38E8FF, 0.07f);
        c.drawPath(path, pt);
        c.restore();
        ring(c, 0f, 0f, r * 0.95f, r * 0.10f, 0xFF04121C, 1f);                  // the bezel
        ring(c, 0f, 0f, r * 0.995f, r * 0.005f, 0xFF7AB8C8, 0.45f);
        ring(c, 0f, 0f, r * 0.90f, r * 0.004f, 0xFF38E8FF, 0.45f);
        for (int i = 0; i < 60; i++) {
            float in = i % 5 == 0 ? 0.925f : 0.945f;
            line(c, px(r * in, i * 6f), py(r * in, i * 6f), px(r * 0.985f, i * 6f), py(r * 0.985f, i * 6f), r * (i % 5 == 0 ? 0.007f : 0.003f), 0xFF38E8FF, i % 5 == 0 ? 0.7f : 0.3f);
        }
        stroke(r * 0.02f, 0xFFFFFFFF, 0.05f);
        rc.set(-r * 0.78f, -r * 0.78f, r * 0.78f, r * 0.78f);
        c.drawArc(rc, 195f, 80f, false, pt);
    }

    private float nodeGrow(int n, float b, float x) {
        int lv = nlv[n];
        float g = outBack((b - LV_NODE[lv]) / 0.14f);
        float t = clamp01((x - 0.42f * (3 - lv) / 3f) / 0.5f);
        return g * (1f - smooth(t));
    }

    private void nexus(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float built = seg(b, 0f, 0.35f), da = 1f - seg(x, 0.45f, 0.9f);
        if (built > 0.01f) {
            if (x > 0.12f) {                                                    // a glitch: the grid slips in horizontal slices
                float gl = (float) Math.sin(Math.PI * seg(x, 0.12f, 0.9f));
                for (int s = 0; s < 8; s++) {
                    float dx = r * 0.30f * (hash(s * 13 + (int) (x * 16f)) - 0.5f) * gl;
                    c.save();
                    c.clipRect(-r * 1.2f, -r * 1.2f + s * r * 0.3f, r * 1.2f, -r * 1.2f + (s + 1) * r * 0.3f);
                    c.translate(dx, 0f);
                    drawCache(c, NEX, built * da);
                    c.restore();
                }
            } else {
                drawCache(c, NEX, built);
            }
        }
        float sweep = seg(b, 0.45f, 0.85f);                                     // the inner rim traces itself clockwise
        if (sweep < 1f && sweep > 0.01f) arc(c, r * 0.90f, -90f, 360f * sweep, r * 0.012f, 0xFF38E8FF, 0.9f * da);
        float edgeA = 0.42f * da;
        int n = 0;
        for (int e = 0; e < 72; e++) {                                          // the links grow outward, and snap on the way out
            float g = clamp01((b - est[e]) / 0.16f);
            g = smooth(g) * (1f - smooth((x - (0.05f + 0.35f * hash(e * 3 + 1))) / 0.35f));
            if (g <= 0.002f) continue;
            int p = ea[e], q = eb[e];
            buf[n++] = nx[p];
            buf[n++] = ny[p];
            buf[n++] = nx[p] + (nx[q] - nx[p]) * g;
            buf[n++] = ny[p] + (ny[q] - ny[p]) * g;
        }
        if (n > 0) {
            stroke(r * 0.014f, 0xFF38E8FF, 0.07f * da);
            c.drawLines(buf, 0, n, pt);
            stroke(r * 0.0048f, 0xFF38E8FF, edgeA);
            c.drawLines(buf, 0, n, pt);
        }
        float wave = tap >= 0f ? tap * 0.62f * r * 1.4f : -1f;                  // the signal front, in px from the hub
        float ph = (float) ((td % 7.0) / 7.0);                                  // a quiet wave from the hub every seven seconds
        float quiet = ph < 0.5f ? ph * 2f * r * 1.0f : -1f;
        if (wave >= 0f || quiet >= 0f) {
            for (int e = 0; e < 72; e++) {
                float mxm = (nx[ea[e]] + nx[eb[e]]) * 0.5f, mym = (ny[ea[e]] + ny[eb[e]]) * 0.5f;
                float dist = (float) Math.sqrt(mxm * mxm + mym * mym), lit = 0f;
                if (wave >= 0f) lit = Math.max(lit, (float) Math.exp(-Math.pow((dist - wave) / (r * 0.12f), 2.0)) * (1f - clamp01(tap / 2.6f)));
                if (quiet >= 0f) lit = Math.max(lit, 0.35f * (float) Math.exp(-Math.pow((dist - quiet) / (r * 0.10f), 2.0)) * (1f - ph * 2f));
                if (lit > 0.04f && b > 0.95f && x < 0.05f) line(c, nx[ea[e]], ny[ea[e]], nx[eb[e]], ny[eb[e]], r * 0.010f, 0xFFBFFBFF, lit * da);
            }
        }
        for (int i = 0; i < 31; i++) {                                          // nodes
            float g = nodeGrow(i, b, x);
            if (g <= 0.01f) continue;
            float off = 1f;
            if (x > 0f && nlv[i] > 0) off = 1f + 0.5f * x * x * (0.5f + hash(i + 5));
            float sz = r * (nlv[i] == 3 ? 0.018f : nlv[i] == 2 ? 0.022f : nlv[i] == 1 ? 0.028f : 0.046f) * g;
            float nxp = nx[i] * off, nyp = ny[i] * off, lit = 0f;
            if (wave >= 0f) {
                float dist = (float) Math.sqrt(nx[i] * nx[i] + ny[i] * ny[i]);
                lit = (float) Math.exp(-Math.pow((dist - wave) / (r * 0.12f), 2.0)) * (1f - clamp01(tap / 2.6f));
            }
            if (quiet >= 0f) {
                float dist = (float) Math.sqrt(nx[i] * nx[i] + ny[i] * ny[i]);
                lit = Math.max(lit, 0.45f * (float) Math.exp(-Math.pow((dist - quiet) / (r * 0.10f), 2.0)) * (1f - ph * 2f));
            }
            if (lit > 0.05f) halo(c, H_CYAN, nxp, nyp, r * 0.13f, lit * da);
            dot(c, nxp, nyp, sz * 1.6f, 0xFF04121C, da);
            dot(c, nxp, nyp, sz, mix(0xFF7AEFFF, 0xFFFFFFFF, lit), da);
        }
        if (b > 0.9f) {
            for (int i = 0; i < 12; i += 3) ring(c, nx[i], ny[i], r * 0.04f, r * 0.006f, 0xFF38E8FF, 0.8f * da * seg(b, 0.9f, 1f));
            for (int j = 0; j < 10; j++) {                                      // data pulses racing along the links
                float per = 2.0f + 1.8f * hash(j * 3 + 1);
                double tt = td / per + hash(j * 3 + 2);
                int cyc = (int) Math.floor(tt);
                float f = (float) (tt - cyc);
                int e = (int) (hash(cyc * 17 + j * 131) * 72f) % 72;
                boolean fw = hash(cyc * 7 + j) > 0.5f;
                float f0 = fw ? f : 1f - f, f1 = fw ? Math.max(0f, f - 0.14f) : Math.min(1f, 1f - f + 0.14f);
                float p0x = nx[ea[e]] + (nx[eb[e]] - nx[ea[e]]) * f0, p0y = ny[ea[e]] + (ny[eb[e]] - ny[ea[e]]) * f0;
                float p1x = nx[ea[e]] + (nx[eb[e]] - nx[ea[e]]) * f1, p1y = ny[ea[e]] + (ny[eb[e]] - ny[ea[e]]) * f1;
                float al = (float) Math.sin(Math.PI * f) * da * seg(b, 0.9f, 1f);
                line(c, p1x, p1y, p0x, p0y, r * 0.008f, 0xFF9AF4FF, 0.6f * al);
                halo(c, H_CYAN, p0x, p0y, r * 0.05f, 0.7f * al);
                dot(c, p0x, p0y, r * 0.009f, 0xFFFFFFFF, al);
            }
        }
        if (k > 0.01f && x < 0.6f) {                                            // hands are bridges that light the nodes they point at
            float hk = smooth(k), ka = k * (1f - seg(x, 0f, 0.5f));
            int nh = ((int) Math.round(((hD - 15f) % 360f + 360f) % 360f / 30f)) % 12, nm = ((int) Math.round(((mD % 360f) + 360f) % 360f / 30f)) % 12;
            float hl = r * 0.50f * hk, ml = r * 0.82f * hk;
            tipOf(tip, hD, hl);
            float hx = tip[0], hy = tip[1];
            line(c, 0f, 0f, hx, hy, r * 0.034f, 0xFF38E8FF, 0.16f * ka);
            line(c, 0f, 0f, hx, hy, r * 0.016f, 0xFF7AEFFF, 0.95f * ka);
            line(c, 0f, 0f, hx, hy, r * 0.006f, 0xFFFFFFFF, ka);
            line(c, hx, hy, nx[12 + nh], ny[12 + nh], r * 0.005f, 0xFF9AF4FF, 0.75f * ka);
            halo(c, H_CYAN, nx[12 + nh], ny[12 + nh], r * 0.16f, 0.75f * ka);
            dot(c, nx[12 + nh], ny[12 + nh], r * 0.026f, 0xFFFFFFFF, ka);
            tipOf(tip, mD, ml);
            float mxp = tip[0], myp = tip[1];
            line(c, 0f, 0f, mxp, myp, r * 0.026f, 0xFF38E8FF, 0.14f * ka);
            line(c, 0f, 0f, mxp, myp, r * 0.011f, 0xFF38E8FF, 0.95f * ka);
            line(c, 0f, 0f, mxp, myp, r * 0.004f, 0xFFFFFFFF, ka);
            line(c, mxp, myp, nx[nm], ny[nm], r * 0.005f, 0xFF9AF4FF, 0.75f * ka);
            halo(c, H_CYAN, nx[nm], ny[nm], r * 0.16f, 0.75f * ka);
            dot(c, nx[nm], ny[nm], r * 0.026f, 0xFFFFFFFF, ka);
            c.save();                                                           // hand tips are small diamonds
            c.translate(hx, hy);
            c.rotate(hD + 45f);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFFFFFFF, ka));
            c.drawRect(-r * 0.022f, -r * 0.022f, r * 0.022f, r * 0.022f, pt);
            c.restore();
            c.save();
            c.translate(mxp, myp);
            c.rotate(mD + 45f);
            pt.setColor(al(0xFFBFFBFF, ka));
            c.drawRect(-r * 0.017f, -r * 0.017f, r * 0.017f, r * 0.017f, pt);
            c.restore();
            if (sa > 0.02f) {                                                   // a magenta pulse runs round the bezel
                float a1 = sa * ka;
                for (int q = 0; q < 4; q++) arc(c, r * 0.93f, sD - 90f - 7f * (q + 1), 7f, r * (0.018f - q * 0.003f), 0xFFFF4AD8, a1 * (0.75f - q * 0.17f));
                float sx = px(r * 0.93f, sD), sy = py(r * 0.93f, sD);
                halo(c, H_PINK, sx, sy, r * 0.10f, 0.75f * a1);
                dot(c, sx, sy, r * 0.016f, 0xFFFFFFFF, a1);
            }
            halo(c, H_CYAN, 0f, 0f, r * 0.20f, 0.5f * ka * (0.8f + 0.2f * sn(td, 2.0, 0)));
        }
    }

    // =====================================================================================================
    // 9  Obsidian
    // =====================================================================================================

    private void facet(Canvas c, int k, float ox, float oy, float rot, float alpha, float flash) {
        if (alpha < 0.01f) return;
        int i0 = tri[3 * k], i1 = tri[3 * k + 1], i2 = tri[3 * k + 2];
        c.save();
        c.translate(ox + fcx[k], oy + fcy[k]);
        c.rotate(rot);
        c.translate(-fcx[k], -fcy[k]);
        path.rewind();
        path.moveTo(ov[2 * i0], ov[2 * i0 + 1]);
        path.lineTo(ov[2 * i1], ov[2 * i1 + 1]);
        path.lineTo(ov[2 * i2], ov[2 * i2 + 1]);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(fgrad[k]);
        pt.setColor(al(0xFFFFFFFF, alpha));
        c.drawPath(path, pt);
        pt.setShader(null);
        stroke(r * 0.005f, 0xFFAEB8FF, 0.38f * alpha);
        c.drawPath(path, pt);
        if (flash > 0.01f) {
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFFFFFFF, 0.55f * flash * alpha));
            c.drawPath(path, pt);
        }
        c.restore();
    }

    private void obsRim(Canvas c, float alpha, float scale) {
        c.save();
        c.scale(scale, scale);
        shaderRing(c, glassRim, r * 0.945f, r * 0.11f, alpha);
        ring(c, 0f, 0f, r * 0.89f, r * 0.004f, 0xFF8A93C8, 0.55f * alpha);
        ring(c, 0f, 0f, r * 0.998f, r * 0.004f, 0xFFD8DEFF, 0.35f * alpha);
        c.restore();
    }

    private void obsMarkers(Canvas c, float grow, float alpha) {
        if (grow < 0.01f) return;
        for (int i = 0; i < 12; i++) {
            boolean q = i % 3 == 0;
            float ww = r * (q ? 0.022f : 0.013f), top = r * (0.80f + (q ? 0.085f : 0.06f) * grow), bot = r * (0.80f - (q ? 0.085f : 0.06f) * grow), mid = r * 0.80f;
            c.save();
            c.rotate(i * 30f);
            path.rewind();
            path.moveTo(0f, -top);
            path.lineTo(ww, -mid);
            path.lineTo(0f, -bot);
            path.lineTo(-ww, -mid);
            path.close();
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFE6EAFF, 0.95f * alpha));
            c.drawPath(path, pt);
            path.rewind();
            path.moveTo(0f, -top);
            path.lineTo(ww, -mid);
            path.lineTo(0f, -bot);
            path.close();
            pt.setColor(al(0xFF8C94C8, 0.65f * alpha));
            c.drawPath(path, pt);
            c.restore();
        }
    }

    private void obsidianArt(Canvas c) {
        for (int k = 0; k < 60; k++) facet(c, k, 0f, 0f, 0f, 1f, 0f);
        obsRim(c, 1f, 1f);
        obsMarkers(c, 1f, 1f);
    }

    private void obsidian(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        boolean whole = b >= 1f && x <= 0f;
        if (whole) {
            drawCache(c, OBS, 1f);
        } else {
            for (int i = 0; i < 60; i++) {
                float ox = 0f, oy = 0f, rot = 0f, al = 1f, fl = 0f;
                float s = 0.05f + 0.40f * fph[i], p = outCubic((b - s) / 0.35f);
                if (p < 1f) {                                                   // shards fly together and lock in with a flash
                    float ang = (float) Math.atan2(fcy[i], fcx[i]) + (fph[i] - 0.5f) * 1.2f;
                    float d = r * 1.7f * (1f - p);
                    ox = (float) Math.cos(ang) * d;
                    oy = (float) Math.sin(ang) * d;
                    rot = (1f - p) * 160f * (fph[i] - 0.5f);
                    al = seg(p, 0f, 0.3f);
                }
                float lp = clamp01((b - s - 0.30f) / 0.12f);
                if (lp > 0f && lp < 1f) fl = (float) Math.sin(Math.PI * lp);
                if (x > 0f) {                                                   // and the same, run backwards with gravity, to shatter
                    float t = clamp01((x - 0.28f * fph[i]) / 0.72f);
                    if (t > 0f) {
                        float ang = (float) Math.atan2(fcy[i], fcx[i]) + (fph[i] - 0.5f) * 0.8f;
                        ox = (float) Math.cos(ang) * r * 2.2f * t * t;
                        oy = (float) Math.sin(ang) * r * 2.2f * t * t + r * 1.6f * t * t;
                        rot = t * (fph[i] > 0.5f ? 220f : -220f) * (0.4f + fph[i]);
                        al = 1f - seg(t, 0.45f, 1f);
                    }
                }
                facet(c, i, ox, oy, rot, al, fl);
            }
            float rimA = seg(b, 0.40f, 0.70f) * (1f - seg(x, 0f, 0.35f));
            obsRim(c, rimA, 1f + 0.12f * (1f - seg(b, 0.4f, 0.7f)) + 0.14f * seg(x, 0f, 0.5f));
            obsMarkers(c, seg(b, 0.60f, 0.85f), 1f - seg(x, 0f, 0.3f));
            if (x > 0f && x < 0.25f) {                                          // the glass cracks with light before it goes
                float f = (float) Math.sin(Math.PI * x / 0.25f);
                stroke(r * 0.006f, 0xFFFFFFFF, 0.9f * f);
                pt.setXfermode(add);
                c.drawPath(seam, pt);
                pt.setXfermode(null);
                halo(c, H_VIO, 0f, 0f, r * 1.2f, 0.4f * f);
            }
        }
        if (b > 0.75f && b < 1f) {                                              // the polish sweep that finishes the build
            sweep(c, seg(b, 0.75f, 1f), 0.9f);
        } else if (whole && x <= 0f) {
            float t = (float) ((td % 8.0) / 1.5);
            if (t < 1f) sweep(c, t, 0.7f);
            for (int q = 0; q < 2; q++) {                                       // a couple of facets catch the light
                double cy2 = td / 1.4 + q * 0.5;
                int n = (int) Math.floor(cy2);
                float f = (float) (cy2 - n), flash = (float) Math.pow(Math.sin(Math.PI * f), 6.0) * 0.35f;
                int fk = (int) (hash(n * 5 + q * 31) * 60f) % 60;
                if (flash > 0.02f) facetGlint(c, fk, flash);
            }
            halo(c, H_VIO, 0f, 0f, r * 0.30f, 0.20f + 0.08f * sn(td, 4.0, 0));
        }
        if (tap >= 0f && tap < 2.6f) {                                          // light runs along the cracks from the core
            float f0 = tap * r * 0.62f, f1 = f0 + r * 0.30f, fa = 1f - clamp01(tap / 2.4f);
            if (f0 < r * 1.0f) {
                c.save();
                tmp.rewind();
                tmp.addCircle(0f, 0f, Math.min(f1, r), Path.Direction.CW);
                tmp.addCircle(0f, 0f, Math.min(f0, r), Path.Direction.CCW);
                c.clipPath(tmp);
                stroke(r * 0.016f, 0xFFB48CFF, 0.55f * fa);
                pt.setXfermode(add);
                c.drawPath(seam, pt);
                stroke(r * 0.005f, 0xFFFFFFFF, 0.95f * fa);
                c.drawPath(seam, pt);
                pt.setXfermode(null);
                c.restore();
            }
            ring(c, 0f, 0f, r * (0.1f + 1.1f * outCubic(clamp01(tap / 1.6f))), r * 0.008f, 0xFFE0E6FF, 0.7f * (1f - clamp01(tap / 1.6f)));
            for (int q = 0; q < 8; q++) {
                float t = clamp01((tap - 0.05f * q) / 0.9f), gl = (float) Math.sin(Math.PI * t);
                int fk = (q * 7 + 3) % 60;
                if (gl > 0.02f) star4(c, fcx[fk], fcy[fk], r * 0.06f * gl, 0xFFE0E6FF, gl);
            }
        }
        if (k > 0.01f && x < 0.3f) {                                            // blades of black glass
            float hk = smooth(k), ha = k * (1f - seg(x, 0f, 0.25f));
            glassBlade(c, hD, r * 0.52f * hk, r * 0.058f, r * 0.12f, ha);
            glassBlade(c, mD, r * 0.82f * hk, r * 0.040f, r * 0.14f, ha);
            tipOf(tip, mD, r * 0.82f * hk);
            halo(c, H_VIO, tip[0], tip[1], r * 0.10f, 0.35f * ha);
            if (sa > 0.02f) {
                c.save();
                c.rotate(sD);
                line(c, 0f, r * 0.16f, 0f, -r * 0.88f * hk, r * 0.006f, 0xFFE0E6FF, 0.9f * sa * ha);
                dot(c, 0f, -r * 0.88f * hk, r * 0.014f, 0xFFFFFFFF, sa * ha);
                c.restore();
            }
            dot(c, 0f, 0f, r * 0.048f, 0xFF0A0A12, ha);
            ring(c, 0f, 0f, r * 0.048f, r * 0.008f, 0xFFB8C2FF, 0.9f * ha);
            dot(c, 0f, 0f, r * 0.014f, 0xFFE0E6FF, ha);
        }
    }

    private void glassBlade(Canvas c, float deg, float len, float wid, float tail, float alpha) {
        c.save();
        c.rotate(deg);
        kite(path, len, wid + r * 0.006f, tail + r * 0.006f, false);
        c.translate(r * 0.010f, r * 0.014f);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0x77000000, alpha));
        c.drawPath(path, pt);
        c.translate(-r * 0.010f, -r * 0.014f);
        kite(path, len, wid, tail, false);
        pt.setColor(al(0xFF1A1C30, alpha));
        c.drawPath(path, pt);
        kite(path, len, wid, tail, true);
        pt.setColor(al(0xFF5A6090, alpha));
        c.drawPath(path, pt);
        kite(path, len, wid, tail, false);
        stroke(r * 0.016f, 0xFFB48CFF, 0.30f * alpha);
        pt.setXfermode(add);
        c.drawPath(path, pt);
        pt.setXfermode(null);
        stroke(r * 0.007f, 0xFFE6EAFF, 1f * alpha);
        c.drawPath(path, pt);
        line(c, wid * 0.30f, -len * 0.80f, wid * 0.42f, -len * 0.30f, r * 0.004f, 0xFFFFFFFF, 0.6f * alpha);
        c.restore();
    }

    private void sweep(Canvas c, float t, float alpha) {
        c.save();
        c.clipPath(disc);
        mx.setScale(r * 0.0035f, 1f);
        mx.postRotate(24f);
        mx.postTranslate(-r * 1.1f + r * 2.2f * smooth(t), 0f);
        sheenG.setLocalMatrix(mx);
        gp.setShader(sheenG);
        gp.setStyle(Paint.Style.FILL);
        gp.setAlpha((int) (255 * alpha));
        gp.setXfermode(add);
        c.drawRect(-r * 1.2f, -r * 1.2f, r * 1.2f, r * 1.2f, gp);
        gp.setXfermode(null);
        gp.setShader(null);
        gp.setAlpha(255);
        c.restore();
    }

    private void facetGlint(Canvas c, int k, float alpha) {
        int i0 = tri[3 * k], i1 = tri[3 * k + 1], i2 = tri[3 * k + 2];
        path.rewind();
        path.moveTo(ov[2 * i0], ov[2 * i0 + 1]);
        path.lineTo(ov[2 * i1], ov[2 * i1 + 1]);
        path.lineTo(ov[2 * i2], ov[2 * i2 + 1]);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFFD8DEFF, alpha));
        pt.setXfermode(add);
        c.drawPath(path, pt);
        pt.setXfermode(null);
    }
}
