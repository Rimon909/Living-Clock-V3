package com.rimon.livingclock;

import java.util.Random;

/**
 * The score of Director's Cut, synthesised sample by sample. No Android classes in here, so it can be run and
 * measured anywhere. Weight is the whole idea: sub-bass, mechanical clicks, dark drones, a pen on paper.
 * There is deliberately nothing bright or sparkling in it.
 *
 * arm    : a reactor spooling up and a heavy latch.
 * enter  : the teardown. A clamp releases, the weight drops, servos whine down, a dark drone settles.
 * detent : one click of a mechanism; played at lower rates it gets heavier.
 * lock   : the load locks.
 * slam   : the assembly. Plates close, a beat of nothing, then the impact at 0.36 s.
 * vanish : a pen writes the signature, lifts, and everything sinks away.
 *
 * Output is interleaved stereo, 16 bit, RATE Hz.
 */
final class CutSound {

    static final int RATE = 44100;

    private static final double TAU = Math.PI * 2.0;

    private CutSound() {}

    // ================= the scores =================

    /** Four taps on the clock: a reactor spooling up, ending in a heavy latch. */
    static short[] arm() {
        int n = (int) (RATE * 1.2f);
        float[] bass = new float[n], air = new float[n];
        Random r = new Random(5);
        kick(bass, 0.00f, 0.55f, 96f, 44f, 0.14f, r);
        riserSaw(air, 0.02f, 0.58f, 0.20f, 55f, 165f);
        riserNoise(air, 0.05f, 0.52f, 0.10f, 400f, 2400f, r);
        tick(air, 0.62f, 0.55f, r);
        tom(bass, 0.62f, 0.50f, 98f, 0.16f);
        metal(air, 0.62f, 0.20f, 0.7f);
        return mix(bass, air, 0.85f, 0.30f, 1.0f, 0.78f);
    }

    /** The teardown: a clamp releases, the weight drops, the servos whine down, a dark drone settles. */
    static short[] enter() {
        int n = (int) (RATE * 3.8f);
        float[] bass = new float[n], air = new float[n];
        Random r = new Random(11);
        kick(bass, 0.00f, 1.00f, 95f, 36f, 0.30f, r);
        sub(bass, 0.04f, 0.85f, 72f, 30f, 0.90f, 2.4f);
        metal(air, 0.00f, 0.55f, 0.8f);
        noiseHit(air, 0.00f, 0.55f, r);
        noiseFall(air, 0.10f, 0.65f, 0.20f, 7000f, 1500f, r);            // pressure released
        sweepSaw(air, 0.18f, 0.85f, 0.13f, 900f, 170f);                  // servo whine falling
        float[] ratchet = {0.56f, 0.65f, 0.79f, 1.02f};
        for (int i = 0; i < ratchet.length; i++) {
            tick(air, ratchet[i], 0.34f, r);
            tom(bass, ratchet[i], 0.26f, 70f + 9f * i, 0.09f);
        }
        float[] chord = {55f, 82.41f, 110f};                             // A1 E2 A2: low and dark
        pad(air, 0.30f, 3.4f, 0.24f, chord, 0.55f);
        return mix(bass, air, 0.70f, 0.30f, 1.15f, 0.95f);
    }

    /** One click of a mechanism. Played at different rates: higher is lighter, lower is heavier. */
    static short[] detent() {
        int n = (int) (RATE * 0.26f);
        float[] bass = new float[n], air = new float[n];
        Random r = new Random(3);
        kick(bass, 0f, 0.60f, 150f, 70f, 0.045f, r);
        tom(bass, 0f, 0.35f, 128f, 0.05f);
        tick(air, 0f, 0.55f, r);
        metal(air, 0f, 0.07f, 1.4f);
        return mix(bass, air, 0.9f, 0.10f, 1.0f, 0.42f);
    }

    /** The load locks: a clank with a dull ring and a thud under it. */
    static short[] lock() {
        int n = (int) (RATE * 1.5f);
        float[] bass = new float[n], air = new float[n];
        Random r = new Random(17);
        kick(bass, 0f, 1.0f, 112f, 40f, 0.26f, r);
        tom(bass, 0.01f, 0.45f, 82f, 0.22f);
        metal(air, 0f, 0.65f, 0.75f);
        metal(air, 0.05f, 0.35f, 0.55f);
        noiseHit(air, 0f, 0.45f, r);
        return mix(bass, air, 0.85f, 0.25f, 1.1f, 0.8f);
    }

    /** The assembly: plates close, a beat of nothing, then the impact. The impact lands at 0.36 s. */
    static short[] slam() {
        int n = (int) (RATE * 4.4f);
        float[] bass = new float[n], air = new float[n];
        Random r = new Random(29);
        float hit = 0.36f;
        riserNoise(air, 0f, 0.33f, 0.32f, 300f, 2600f, r);
        riserSaw(air, 0f, 0.33f, 0.22f, 55f, 130f);
        float[] plate = {0.08f, 0.16f, 0.23f, 0.29f};
        for (int i = 0; i < plate.length; i++) {
            tick(air, plate[i], 0.30f, r);
            tom(bass, plate[i], 0.30f, 64f + 10f * i, 0.07f);
        }
        kick(bass, hit, 1.15f, 120f, 32f, 0.40f, r);
        sub(bass, hit, 1.00f, 80f, 27f, 1.25f, 3.8f);
        braam(bass, hit, 0.90f, 41f, 3.4f);
        noiseHit(air, hit, 1.00f, r);
        metal(air, hit, 0.60f, 1.0f);
        metal(air, hit + 0.05f, 0.38f, 0.7f);
        tom(bass, hit + 0.04f, 0.50f, 61f, 0.30f);
        float[] chord = {55f, 82.41f, 110f, 164.81f};                    // dark, no sparkle
        pad(air, hit + 0.14f, 3.7f, 0.24f, chord, 0.60f);
        return mix(bass, air, 0.70f, 0.40f, 1.25f, 1.0f);
    }

    /** The vanish: a pen writing, the lift of the pen, then everything sinking away. Lasts 5.6 s. */
    static short[] vanish() {
        int n = (int) (RATE * 5.6f);
        float[] bass = new float[n], air = new float[n];
        Random r = new Random(41);
        float[] chord = {55f, 82.41f, 110f};
        pad(air, 0.0f, 4.2f, 0.20f, chord, 0.55f);
        penScratch(air, 0.25f, 2.0f, 0.11f, r);
        tom(bass, 2.28f, 0.30f, 196f, 0.05f);                             // the pen lifts
        tick(air, 2.28f, 0.30f, r);
        noiseFall(air, 2.55f, 2.4f, 0.10f, 3600f, 260f, r);
        tapeStop(air, 3.0f, 2.2f, 0.18f, chord);
        sub(bass, 2.9f, 0.20f, 46f, 26f, 1.2f, 2.6f);
        return mix(bass, air, 0.75f, 0.35f, 1.0f, 0.8f);
    }

    // ================= instruments =================

    /** A kick drum: a sine that falls fast from f0 to f1, plus a few milliseconds of click. */
    private static void kick(float[] out, float at, float amp, float f0, float f1, float decay, Random r) {
        int s = (int) (at * RATE);
        double ph = 0.0;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > decay * 7f) break;
            double f = f1 + (f0 - f1) * Math.exp(-t / 0.028);
            ph += TAU * f / RATE;
            float env = (float) Math.exp(-t / decay) * Math.min(1f, t / 0.0014f);
            float v = (float) Math.sin(ph) * env;
            if (t < 0.004f) v += 0.45f * (r.nextFloat() * 2f - 1f) * (1f - t / 0.004f);
            out[s + i] += amp * v;
        }
    }

    /** A low tom: a sine with a short pitch drop. */
    private static void tom(float[] out, float at, float amp, float f, float decay) {
        int s = (int) (at * RATE);
        double ph = 0.0;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > decay * 6f) break;
            double fr = f * (1.0 + 0.35 * Math.exp(-t / 0.04));
            ph += TAU * fr / RATE;
            out[s + i] += amp * (float) (Math.sin(ph) * Math.exp(-t / decay) * Math.min(1f, t / 0.004f));
        }
    }

    /** Deep boom: pitch falls from f0 to f1, long tail. */
    private static void sub(float[] out, float at, float amp, float f0, float f1, float decay, float len) {
        int s = (int) (at * RATE);
        double ph = 0.0;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > len) break;
            double f = f1 + (f0 - f1) * Math.exp(-t / 0.22);
            ph += TAU * f / RATE;
            float env = (float) Math.exp(-t / decay) * Math.min(1f, t / 0.006f);
            out[s + i] += amp * env * (float) Math.sin(ph);
        }
    }

    /** A tiny noise click, differenced so it has no low end. */
    private static void tick(float[] out, float at, float amp, Random r) {
        int s = (int) (at * RATE);
        float prev = 0f;
        for (int i = 0; s + i < out.length && i < RATE / 90; i++) {
            float t = i / (float) RATE;
            float nz = r.nextFloat() * 2f - 1f;
            float hp = nz - prev;
            prev = nz;
            out[s + i] += amp * 0.5f * hp * (float) Math.exp(-t / 0.0022);
        }
    }

    /** Air that climbs: band-passed noise whose centre rises, swelling as it goes. */
    private static void riserNoise(float[] out, float at, float len, float amp, float f0, float f1, Random r) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        float low = 0f, band = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double fc = f0 * Math.pow(f1 / f0, p);
            float f = (float) (2.0 * Math.sin(Math.PI * fc / RATE));
            float x = r.nextFloat() * 2f - 1f;
            low += f * band;
            float high = x - low - 0.55f * band;
            band += f * high;
            float env = (float) Math.pow(p, 1.7) * Math.min(1f, (n - i) / (RATE * 0.012f));
            out[s + i] += amp * 1.6f * env * band;
        }
    }

    /** A saw that glides up while its filter opens: the rising tone under the countdown. */
    private static void riserSaw(float[] out, float at, float len, float amp, float f0, float f1) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        double ph = 0.0;
        float lp = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double f = f0 * Math.pow(f1 / f0, p);
            ph += f / RATE;
            ph -= Math.floor(ph);
            float saw = (float) (2.0 * ph - 1.0);
            float fc = 500f + 3200f * p;
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (saw - lp);
            float env = (float) Math.pow(p, 1.4) * Math.min(1f, (n - i) / (RATE * 0.012f));
            out[s + i] += amp * env * lp;
        }
    }

    /** The burst at the hit: dark noise whose brightness collapses, so it feels like a wall falling over. */
    private static void noiseHit(float[] out, float at, float amp, Random r) {
        int s = (int) (at * RATE);
        float lp = 0f;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > 1.8f) break;
            float k = 0.55f * (float) Math.exp(-t / 0.16) + 0.012f;
            lp += k * ((r.nextFloat() * 2f - 1f) - lp);
            out[s + i] += amp * 1.5f * lp * (float) Math.exp(-t / 0.34) * Math.min(1f, t / 0.0015f);
        }
    }

    /** Inharmonic partials that ring after the hit, like struck metal. */
    private static void metal(float[] out, float at, float amp, float fmul) {
        float[] f = {187.3f, 262.7f, 391.9f, 611.3f, 917.7f, 1403f};
        float[] g = {0.50f, 0.42f, 0.30f, 0.20f, 0.12f, 0.07f};
        int s = (int) (at * RATE);
        for (int p = 0; p < f.length; p++) {
            double w = TAU * f[p] * fmul / RATE;
            float tau = 1.1f / (1f + 0.35f * p);
            for (int i = 0; s + i < out.length; i++) {
                float t = i / (float) RATE;
                if (t > tau * 6f) break;
                out[s + i] += amp * g[p] * (float) (Math.sin(w * i) * Math.exp(-t / tau) * Math.min(1f, t / 0.002f));
            }
        }
    }

    /**
     * The "braam": three detuned saws and a sub octave, pushed hard through a soft clipper, with a filter that
     * opens after the hit and closes again. Pitch starts a little sharp and settles.
     */
    private static void braam(float[] out, float at, float amp, float f, float len) {
        int s = (int) (at * RATE);
        double p0 = 0, p1 = 0, p2 = 0, p3 = 0;
        float lp = 0f;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > len) break;
            double fr = f * (1.0 + 0.22 * Math.exp(-t / 0.07));
            p0 += fr * 0.994 / RATE;
            p1 += fr / RATE;
            p2 += fr * 1.006 / RATE;
            p3 += fr * 0.5 / RATE;
            p0 -= Math.floor(p0);
            p1 -= Math.floor(p1);
            p2 -= Math.floor(p2);
            p3 -= Math.floor(p3);
            float x = (float) ((2 * p0 - 1) + (2 * p1 - 1) + (2 * p2 - 1)) / 3f * 0.9f + (float) Math.sin(TAU * p3) * 0.7f;
            x = (float) Math.tanh(x * 3.6f);
            double open = Math.exp(-Math.pow((t - 0.28) / 0.34, 2));
            float fc = (float) (200.0 + 1500.0 * open);
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (x - lp);
            float env = Math.min(1f, t / 0.01f) * (float) Math.exp(-t / 0.95f) * Math.min(1f, (len - t) / 0.3f);
            out[s + i] += amp * env * lp;
        }
    }

    /** A wide pad: three detuned saws per note, a filter that slowly opens, a slow attack and a long release. */
    private static void pad(float[] out, float at, float len, float amp, float[] notes, float cut) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        float[] det = {0.9962f, 1.0f, 1.0038f};
        double[] ph = new double[notes.length * 3];
        for (int i = 0; i < ph.length; i++) ph[i] = (i * 0.37) % 1.0;
        float lp = 0f, lp2 = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float t = i / (float) RATE;
            float sum = 0f;
            for (int v = 0; v < notes.length; v++) {
                for (int d = 0; d < 3; d++) {
                    int idx = v * 3 + d;
                    ph[idx] += notes[v] * det[d] / RATE;
                    ph[idx] -= Math.floor(ph[idx]);
                    sum += (float) (2.0 * ph[idx] - 1.0);
                }
            }
            sum /= ph.length;
            float up = Math.min(1f, t / 1.6f);
            float fc = (520f + 1700f * up * up) * cut;
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (sum - lp);
            lp2 += k * (lp - lp2);                                    // two poles: warm, no fizz
            float att = Math.min(1f, t / 0.55f);
            att *= att;
            float rel = Math.min(1f, (len - t) / 1.4f);
            out[s + i] += amp * 3.0f * att * rel * lp2;
        }
    }

    /** A struck-glass note: inharmonic partials, the high ones dying faster, a slightly detuned twin for shimmer. */
    private static void glass(float[] out, float at, float freq, float amp, float tau) {
        int s = (int) (at * RATE);
        float[] ratio = {1f, 2.0f, 2.76f, 5.4f};
        float[] gain = {1f, 0.34f, 0.20f, 0.08f};
        for (int p = 0; p < ratio.length; p++) {
            float f = freq * ratio[p];
            if (f > RATE * 0.42f) continue;
            float decay = tau / (1f + 0.7f * p);
            double w = TAU * f / RATE, w2 = TAU * f * 1.0032 / RATE;
            for (int i = 0; s + i < out.length; i++) {
                float t = i / (float) RATE;
                if (t > decay * 8f) break;
                float env = (float) Math.exp(-t / decay) * Math.min(1f, t / 0.004f);
                out[s + i] += amp * gain[p] * env * (float) (Math.sin(w * i) + 0.45 * Math.sin(w2 * i));
            }
        }
    }

    /** A saw gliding between two pitches through a closing or opening filter. */
    private static void sweepSaw(float[] out, float at, float len, float amp, float f0, float f1) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        double ph = 0.0;
        float lp = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double f = f0 * Math.pow(f1 / f0, p);
            ph += f / RATE;
            ph -= Math.floor(ph);
            float saw = (float) (2.0 * ph - 1.0);
            float fc = (float) (1400.0 * Math.pow(0.25, p));
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (saw - lp);
            float env = (float) Math.sin(Math.PI * Math.min(1f, p * 1.0f)) ;
            out[s + i] += amp * env * lp;
        }
    }

    /** Pen on paper: filtered noise whose level follows the strokes of a signature. */
    private static void penScratch(float[] out, float at, float len, float amp, Random r) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        float low = 0f, band = 0f;
        float f = (float) (2.0 * Math.sin(Math.PI * 3200.0 / RATE));
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n, t = i / (float) RATE;
            float stroke = 0.5f + 0.5f * (float) Math.sin(TAU * (2.6 * t + 0.4 * Math.sin(TAU * 0.9 * t)));
            float env = (0.25f + 0.75f * stroke * stroke) * Math.min(1f, p * 20f) * Math.min(1f, (1f - p) * 20f);
            float x = r.nextFloat() * 2f - 1f;
            low += f * band;
            float high = x - low - 0.45f * band;
            band += f * high;
            out[s + i] += amp * env * band;
        }
    }

    private static void sweepSine(float[] out, float at, float len, float amp, float f0, float f1) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        double ph = 0.0;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            ph += TAU * (f0 * Math.pow(f1 / f0, p)) / RATE;
            float env = (float) Math.sin(Math.PI * Math.pow(p, 0.8));
            out[s + i] += amp * env * (float) Math.sin(ph);
        }
    }

    /** The pad being dragged down by a stopping tape: pitch and level fall together. */
    private static void tapeStop(float[] out, float at, float len, float amp, float[] notes) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        double[] ph = new double[notes.length];
        float lp = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double speed = Math.pow(1.0 - p, 1.8);
            float sum = 0f;
            for (int v = 0; v < notes.length; v++) {
                ph[v] += notes[v] * speed / RATE;
                ph[v] -= Math.floor(ph[v]);
                sum += (float) (2.0 * ph[v] - 1.0);
            }
            sum /= notes.length;
            float fc = (float) (180.0 + 1500.0 * speed);
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (sum - lp);
            out[s + i] += amp * 2.4f * (float) Math.pow(1.0 - p, 1.2) * lp;
        }
    }

    private static void noiseFall(float[] out, float at, float len, float amp, float f0, float f1, Random r) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        float low = 0f, band = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double fc = f0 * Math.pow(f1 / f0, p);
            float f = (float) (2.0 * Math.sin(Math.PI * Math.min(fc, 6000.0) / RATE));
            float x = r.nextFloat() * 2f - 1f;
            low += f * band;
            float high = x - low - 0.6f * band;
            band += f * high;
            out[s + i] += amp * 1.5f * (float) Math.pow(1.0 - p, 1.6) * Math.min(1f, p / 0.03f) * band;
        }
    }

    // ================= room and mix =================

    /** A small stereo room: four damped combs and two all-pass filters per side. */
    private static void room(float[] in, float[] outL, float[] outR) {
        int[] dl = {1307, 1637, 1811, 1931}, dr = {1337, 1667, 1847, 1973};
        side(in, outL, dl, 556);
        side(in, outR, dr, 579);
    }

    private static void side(float[] in, float[] out, int[] delays, int apDelay) {
        float fb = 0.90f, damp = 0.35f;
        float[][] buf = new float[delays.length][];
        int[] pos = new int[delays.length];
        float[] store = new float[delays.length];
        for (int c = 0; c < delays.length; c++) buf[c] = new float[delays[c]];
        float[] ap1 = new float[apDelay], ap2 = new float[apDelay * 4 / 5];
        int a1 = 0, a2 = 0;
        for (int i = 0; i < in.length; i++) {
            float x = in[i] * 0.18f, sum = 0f;
            for (int c = 0; c < delays.length; c++) {
                float y = buf[c][pos[c]];
                store[c] = y * (1f - damp) + store[c] * damp;
                buf[c][pos[c]] = x + store[c] * fb;
                if (++pos[c] >= delays[c]) pos[c] = 0;
                sum += y;
            }
            float z = sum * 0.5f;
            float b = ap1[a1];
            float o = -z + b;
            ap1[a1] = z + b * 0.5f;
            if (++a1 >= ap1.length) a1 = 0;
            float b2 = ap2[a2];
            float o2 = -o + b2;
            ap2[a2] = o + b2 * 0.5f;
            if (++a2 >= ap2.length) a2 = 0;
            out[i] = o2;
        }
    }

    /** Dry bass + air with its room, a touch of width, a soft ceiling, a short fade, 16-bit stereo. */
    private static short[] mix(float[] bass, float[] air, float airDry, float roomAmt, float drive, float level) {
        int n = bass.length;
        float[] rl = new float[n], rr = new float[n];
        room(air, rl, rr);
        int haas = (int) (RATE * 0.011f);
        float[] l = new float[n], r = new float[n];
        float peak = 1e-6f;
        for (int i = 0; i < n; i++) {
            float aL = air[i], aR = i >= haas ? air[i - haas] : 0f;
            l[i] = bass[i] + airDry * aL + roomAmt * rl[i];
            r[i] = bass[i] + airDry * aR + roomAmt * rr[i];
            peak = Math.max(peak, Math.max(Math.abs(l[i]), Math.abs(r[i])));
        }
        float g = drive / peak;
        int fade = (int) (RATE * 0.22f), head = (int) (RATE * 0.002f);
        short[] pcm = new short[n * 2];
        for (int i = 0; i < n; i++) {
            float f = 1f;
            if (n - i < fade) f = (n - i) / (float) fade;
            if (i < head) f *= i / (float) head;
            float vl = (float) Math.tanh(l[i] * g * 1.15f) * 0.9f * f * level;
            float vr = (float) Math.tanh(r[i] * g * 1.15f) * 0.9f * f * level;
            pcm[2 * i] = (short) Math.round(vl * 32767f);
            pcm[2 * i + 1] = (short) Math.round(vr * 32767f);
        }
        return pcm;
    }
}
