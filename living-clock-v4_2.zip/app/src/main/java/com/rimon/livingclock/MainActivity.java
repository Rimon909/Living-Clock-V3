package com.rimon.livingclock;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputFilter;
import android.text.InputType;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_BG = 1, REQ_SUBJ = 2;
    private static final String[] REWIND_NAMES = {"Luminous wake + spring landing", "Mechanical ticking snap",
            "Dial ticks light up", "Quick and subtle", "Wake + ticks combined", "Lightsaber forge"};
    private static final String[] BAND_NAMES = {"Unwind (swirling cascade)", "Drop and bounce", "Implode and burst",
            "Wave slide from the centre", "Card flip", "Random each time"};
    private static final String[] PATTERN_NAMES = {"Follow the clock theme", "Sunburst (rays around the dial)",
            "Mirror ribbon (aurora)", "LED matrix (peak dots)", "Liquid wave (water and droplets)"};
    private static final String[] EXIT_NAMES = {"Transformer (plates ratchet home)", "Comet gather (spiral and shockwave)",
            "Card fan (stack, then fan out)", "Random each time"};
    private static final String[] INDICATOR_NAMES = {"Off", "Rim arc", "Lit ticks", "Tiny percentage",
            "Intro-only arc", "Arc + percentage"};
    private static final int BG = 0xFF0A0E16, CARD = 0xFF182030, EDGE = 0xFF2C3545;
    private static final int GOLD = 0xFFFFDC8A, MUTED = 0xFF9DA9BB, WHITE = 0xFFFFFFFF;

    private interface IntSink {
        void accept(int v);
    }

    private SharedPreferences prefs;
    private Preview preview;
    private TextView status;
    private Button subjectMode, clockMode, killButton, devButton;
    private TextView killStatus;
    private LinearLayout card;
    private LinearLayout modes;
    private Button applyButton;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = Prefs.get(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column();
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("LIVING CLOCK", 24, WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        root.addView(text("Time, with depth.", 12, MUTED));

        LinearLayout killCard = column();
        killCard.setPadding(dp(16), dp(12), dp(16), dp(14));
        killCard.setBackground(rounded(CARD, EDGE));
        killStatus = text("", 12, MUTED);
        killButton = button("", v -> onKillClicked());
        killCard.addView(text("Kill switch", 14, WHITE));
        killCard.addView(killStatus, matchWrap(dp(4)));
        killCard.addView(killButton, matchWrap(dp(8)));
        root.addView(killCard, matchWrap(dp(14)));
        devButton = button("Developer More", v -> openDeveloper());
        root.addView(devButton, matchWrap(dp(10)));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int sw = Math.min(dm.widthPixels, dm.heightPixels);
        int sh = Math.max(dm.widthPixels, dm.heightPixels);
        int ph = dp(460);
        int pw = ph * sw / sh;

        preview = new Preview(this);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(pw, ph);
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        plp.topMargin = dp(18);
        root.addView(preview, plp);

        status = text("Drag the subject or the clock on the preview.", 12, MUTED);
        status.setGravity(Gravity.CENTER);
        root.addView(status, matchWrap(dp(10)));

        modes = row();
        subjectMode = button("Move subject", v -> setDragSubject(true));
        clockMode = button("Move clock", v -> setDragSubject(false));
        modes.addView(subjectMode, weight());
        modes.addView(clockMode, weight());
        root.addView(modes, matchWrap(dp(14)));

        card = column();
        card.setPadding(dp(16), dp(14), dp(16), dp(16));
        card.setBackground(rounded(CARD, EDGE));
        root.addView(card, matchWrap(dp(14)));

        card.addView(button("Choose background photo", v -> pick(REQ_BG)), matchWrap(0));
        card.addView(button("Choose subject photo", v -> pick(REQ_SUBJ)), matchWrap(dp(10)));

        card.addView(slider("Subject size", 50, 160,
                        Math.round(prefs.getFloat(Prefs.SUBJ_SCALE, 1f) * 100),
                        v -> { },
                        v -> {
                            prefs.edit().putFloat(Prefs.SUBJ_SCALE, v / 100f).apply();
                            Prefs.bump(this);
                            preview.rebuild();
                        }),
                matchWrap(dp(14)));

        card.addView(slider("Clock size", 60, 160,
                        prefs.getInt(Prefs.CLOCK_SIZE, 100),
                        v -> preview.setClockSize(v),
                        v -> prefs.edit().putInt(Prefs.CLOCK_SIZE, v).apply()),
                matchWrap(dp(14)));

        Switch stars = new Switch(this);
        stars.setText("Shooting stars each minute");
        stars.setTextColor(WHITE);
        stars.setChecked(prefs.getBoolean(Prefs.STARS, true));
        stars.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean(Prefs.STARS, on).apply();
            preview.setStars(on);
        });
        card.addView(stars, matchWrap(dp(14)));
        card.addView(button("Test shooting stars", v -> preview.spawnStars()), matchWrap(dp(8)));
        card.addView(button("Preview intro", v -> preview.playIntro()), matchWrap(dp(8)));
        card.addView(text("Hanging numerals (one tap on the clock)", 13, WHITE), matchWrap(dp(14)));
        RadioGroup numeralGroup = new RadioGroup(this);
        for (int i = 0; i < Hang.NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(4000 + i);
            rb.setText(Hang.NAMES[i]);
            rb.setTextColor(WHITE);
            numeralGroup.addView(rb);
        }
        numeralGroup.check(4000 + prefs.getInt(Prefs.NUMERALS, 0));
        numeralGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.NUMERALS, id - 4000).apply();
            preview.setNumerals(id - 4000);
        });
        card.addView(numeralGroup, matchWrap(0));
        card.addView(button("Test hanging numerals (tap again to drop)", v -> preview.toggleNumerals()), matchWrap(dp(8)));

        card.addView(text("While charging", 13, WHITE), matchWrap(dp(14)));
        RadioGroup sleepGroup = new RadioGroup(this);
        String[] sleepNames = {"Off", "Settle (hands swing down)", "Breathing (slow dim)", "Repair (turns around and mends itself)"};
        for (int i = 0; i < sleepNames.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(5000 + i);
            rb.setText(sleepNames[i]);
            rb.setTextColor(WHITE);
            sleepGroup.addView(rb);
        }
        sleepGroup.check(5000 + prefs.getInt(Prefs.SLEEP, 3));
        sleepGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.SLEEP, id - 5000).apply();
            preview.setSleepStyle(id - 5000);
        });
        card.addView(sleepGroup, matchWrap(0));
        card.addView(button("Test charging (30 s demo, tap again to unplug)", v -> preview.toggleSleep()), matchWrap(dp(8)));

        Switch introSwitch = new Switch(this);
        introSwitch.setText("Play intro when waking");
        introSwitch.setTextColor(WHITE);
        introSwitch.setChecked(prefs.getBoolean(Prefs.INTRO, true));
        introSwitch.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean(Prefs.INTRO, on).apply();
            preview.setIntro(on);
        });
        card.addView(introSwitch, matchWrap(dp(14)));

        card.addView(text("Intro animation", 13, WHITE), matchWrap(dp(4)));
        RadioGroup rewindGroup = new RadioGroup(this);
        for (int i = 0; i < REWIND_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(REWIND_NAMES[i]);
            rb.setTextColor(WHITE);
            rewindGroup.addView(rb);
        }
        rewindGroup.check(1000 + prefs.getInt(Prefs.REWIND, 0));
        rewindGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.REWIND, id - 1000).apply();
            preview.setRewind(id - 1000);
        });
        card.addView(rewindGroup, matchWrap(0));

        card.addView(text("Clock theme (double tap the top of the cutout to change)", 13, WHITE), matchWrap(dp(14)));
        card.addView(text("Triple tap the top of the cutout to switch between the ordinary themes and the Super 5.", 11, MUTED), matchWrap(dp(2)));
        RadioGroup themeGroup = new RadioGroup(this);
        for (int i = 0; i < Themes.NAMES.length; i++) {
            if (i == Supers.FIRST) {
                TextView sup = text("SUPER 5  (luxury clocks: triple tap to unlock, tap a clock to play it)", 12, GOLD);
                sup.setPadding(0, dp(12), 0, dp(4));
                themeGroup.addView(sup);
            }
            RadioButton rb = new RadioButton(this);
            rb.setId(3000 + i);
            rb.setText(Themes.NAMES[i]);
            rb.setTextColor(WHITE);
            themeGroup.addView(rb);
        }
        themeGroup.check(3000 + (prefs.getBoolean(Prefs.SUPER, false) ? prefs.getInt(Prefs.SUPER_THEME, Supers.FIRST) : prefs.getInt(Prefs.THEME, 0)));
        themeGroup.setOnCheckedChangeListener((g, id) -> {
            int t = id - 3000;
            SharedPreferences.Editor ed = prefs.edit();
            if (Supers.is(t)) ed.putBoolean(Prefs.SUPER, true).putInt(Prefs.SUPER_THEME, t);
            else ed.putBoolean(Prefs.SUPER, false).putInt(Prefs.THEME, t);
            ed.apply();
            preview.setTheme(t);
        });
        card.addView(themeGroup, matchWrap(0));

        Switch bandSwitch = new Switch(this);
        bandSwitch.setText("Music bands while music plays");
        bandSwitch.setTextColor(WHITE);
        bandSwitch.setChecked(prefs.getBoolean(Prefs.BAND, true));
        bandSwitch.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean(Prefs.BAND, on).apply();
            preview.reloadBands();
        });
        card.addView(bandSwitch, matchWrap(dp(14)));
        card.addView(text("The clock becomes twelve band members in the style of your clock theme, the background dims,"
                + " and when the music stops the clock rebuilds itself.", 12, MUTED), matchWrap(dp(4)));

        Switch realSwitch = new Switch(this);
        realSwitch.setText("Real audio sync (needs microphone permission; nothing is recorded). Off = built-in groove");
        realSwitch.setTextColor(WHITE);
        realSwitch.setChecked(prefs.getBoolean(Prefs.BAND_REAL, true));
        realSwitch.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean(Prefs.BAND_REAL, on).apply();
            preview.reloadBands();
            if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
            }
        });
        card.addView(realSwitch, matchWrap(dp(10)));

        card.addView(text("Music band entrance", 13, WHITE), matchWrap(dp(10)));
        RadioGroup bandGroup = new RadioGroup(this);
        for (int i = 0; i < BAND_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(6000 + i);
            rb.setText(BAND_NAMES[i]);
            rb.setTextColor(WHITE);
            bandGroup.addView(rb);
        }
        bandGroup.check(6000 + prefs.getInt(Prefs.BAND_ENTER, 5));
        bandGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.BAND_ENTER, id - 6000).apply();
            preview.reloadBands();
        });
        card.addView(bandGroup, matchWrap(0));
        card.addView(text("Band pattern", 13, WHITE), matchWrap(dp(14)));
        RadioGroup patGroup = new RadioGroup(this);
        for (int i = 0; i < PATTERN_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(7000 + i);
            rb.setText(PATTERN_NAMES[i]);
            rb.setTextColor(WHITE);
            patGroup.addView(rb);
        }
        patGroup.check(7000 + prefs.getInt(Prefs.BAND_STYLE, 0));
        patGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.BAND_STYLE, id - 7000).apply();
            preview.reloadBands();
        });
        card.addView(patGroup, matchWrap(0));

        card.addView(text("Clock rebuild when the music stops", 13, WHITE), matchWrap(dp(14)));
        RadioGroup exitGroup = new RadioGroup(this);
        for (int i = 0; i < EXIT_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(8000 + i);
            rb.setText(EXIT_NAMES[i]);
            rb.setTextColor(WHITE);
            exitGroup.addView(rb);
        }
        exitGroup.check(8000 + prefs.getInt(Prefs.BAND_EXIT, 3));
        exitGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.BAND_EXIT, id - 8000).apply();
            preview.reloadBands();
        });
        card.addView(exitGroup, matchWrap(0));
        card.addView(button("Test music bands (tap again to rebuild the clock)", v -> preview.toggleBands()), matchWrap(dp(8)));

        card.addView(text("Battery indicator", 13, WHITE), matchWrap(dp(14)));
        RadioGroup indicatorGroup = new RadioGroup(this);
        for (int i = 0; i < INDICATOR_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(2000 + i);
            rb.setText(INDICATOR_NAMES[i]);
            rb.setTextColor(WHITE);
            indicatorGroup.addView(rb);
        }
        indicatorGroup.check(2000 + prefs.getInt(Prefs.INDICATOR, 1));
        indicatorGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.INDICATOR, id - 2000).apply();
            preview.setIndicator(id - 2000);
        });
        card.addView(indicatorGroup, matchWrap(0));
        card.addView(button("Test pendulum (double tap centre)", v -> preview.togglePendulum()), matchWrap(dp(10)));
        card.addView(button("Test flip (triple tap)", v -> preview.toggleFlip()), matchWrap(dp(8)));

        Button apply = button("Set as live wallpaper", v -> applyWallpaper());
        applyButton = apply;
        apply.setBackground(rounded(GOLD, GOLD));
        apply.setTextColor(BG);
        root.addView(apply, matchWrap(dp(16)));

        setDragSubject(true);
        refreshKill();
        askAudio();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshKill();
        preview.setActive(!Kill.isOn(this));
    }

    /** The bands need the microphone permission to read the music's spectrum (nothing is recorded). */
    private void askAudio() {
        if (Kill.isOn(this) || !prefs.getBoolean(Prefs.BAND, true) || !prefs.getBoolean(Prefs.BAND_REAL, true)) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        preview.reloadBands();
        Prefs.bump(this);
    }

    // ---------- kill switch ----------

    private void onKillClicked() {
        if (Kill.isOn(this)) {
            long wait = Kill.lockedFor(this);
            if (wait > 0L) {
                toast("Too many tries. Wait " + (wait / 1000 + 1) + " s.");
                return;
            }
            EditText in = new EditText(this);
            in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            in.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
            in.setHint("Password");
            new AlertDialog.Builder(this)
                    .setTitle("Turn Living Clock back on")
                    .setView(in)
                    .setPositiveButton("Turn on", (d, w) -> {
                        if (Kill.release(this, in.getText().toString())) {
                            toast("Living Clock is on");
                            refreshKill();
                            preview.setActive(true);
                            askAudio();
                        } else {
                            toast(Kill.lockedFor(this) > 0L ? "Too many tries. Locked for a minute." : "Wrong password");
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Stop everything?")
                    .setMessage("The wallpaper freezes to one still picture and every sensor, listener and timer stops. "
                            + "Turning it on again needs the password.")
                    .setPositiveButton("Stop", (d, w) -> {
                        Kill.engage(this);
                        preview.setActive(false);
                        refreshKill();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    /** Developer More opens only after the same password as the kill switch. */
    private void openDeveloper() {
        long wait = Kill.lockedFor(this);
        if (wait > 0L) {
            toast("Too many tries. Wait " + (wait / 1000 + 1) + " s.");
            return;
        }
        EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        in.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        in.setHint("Password");
        new AlertDialog.Builder(this)
                .setTitle("Developer More")
                .setView(in)
                .setPositiveButton("Enter", (d, w) -> {
                    if (Kill.verify(this, in.getText().toString())) startActivity(new Intent(this, DevActivity.class));
                    else toast(Kill.lockedFor(this) > 0L ? "Too many tries. Locked for a minute." : "Wrong password");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshKill() {
        boolean on = Kill.isOn(this);
        killStatus.setText(on ? "Everything is stopped. Settings are locked until you turn the app back on."
                : "Running. The kill switch stops the wallpaper, sensors, audio listener and timers at once.");
        killButton.setText(on ? "Turn on (password)" : "Kill everything");
        killButton.setTextColor(on ? GOLD : 0xFFFF7A6B);
        lock(card, !on);
        lock(modes, !on);
        lock(applyButton, !on);
        lock(devButton, !on);
        preview.setKilled(on);
    }

    private void lock(View v, boolean enabled) {
        v.setAlpha(enabled ? 1f : 0.4f);
        setEnabledDeep(v, enabled);
    }

    private void setEnabledDeep(View v, boolean enabled) {
        v.setEnabled(enabled);
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) setEnabledDeep(g.getChildAt(i), enabled);
        }
    }

    @Override
    protected void onPause() {
        preview.setActive(false);
        super.onPause();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        status.setText("Working…");
        if (req == REQ_BG) Assets.importBackground(this, uri, this::finishImport);
        else if (req == REQ_SUBJ) Assets.importSubject(this, uri, this::finishImport);
    }

    private void finishImport(boolean ok, String message) {
        status.setText(message);
        if (ok) preview.load();
    }

    private void pick(int req) {
        startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), req);
    }

    private void setDragSubject(boolean subject) {
        preview.setDragSubject(subject);
        subjectMode.setTextColor(subject ? GOLD : MUTED);
        clockMode.setTextColor(subject ? MUTED : GOLD);
    }

    private void applyWallpaper() {
        try {
            startActivity(new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            new ComponentName(this, LivingClockService.class)));
        } catch (Exception e) {
            toast("Couldn't open the wallpaper picker.");
        }
    }

    // ---------- live preview ----------

    /** Same renderer and scene as the wallpaper, at the phone's aspect ratio. Dragging edits positions live. */
    private final class Preview extends View {

        private final Renderer renderer = new Renderer();
        private final Tilt tilt = new Tilt(MainActivity.this, new Handler(Looper.getMainLooper()),
                (ax, ay, az) -> renderer.gauge.setGravity(ax, ay));
        private Scene scene;
        private int generation;
        private boolean active, dragSubject = true, dragging, stopped;
        private float downX, downY, baseX, baseY;

        Preview(Context c) {
            super(c);
            renderer.band.attach(c);
            renderer.sleep.repair.demo = true;      // the charging test runs a 30 second demo
            renderer.readConfig(prefs);
        }

        void setKilled(boolean on) {
            stopped = on;
            renderer.setKilled(on);
            if (on) tilt.stop();
            invalidate();
        }

        void setActive(boolean on) {
            active = on;
            if (on) {
                invalidate();
            } else {
                tilt.stop();
                renderer.closeGauge();
                renderer.setSleeping(false, System.currentTimeMillis(), true);
            }
        }

        void setDragSubject(boolean on) {
            dragSubject = on;
        }

        void setClockSize(int pct) {
            renderer.setClockSize(pct);
            invalidate();
        }

        void setStars(boolean on) {
            renderer.setStars(on);
            invalidate();
        }

        void spawnStars() {
            renderer.spawnStars(System.currentTimeMillis());
            invalidate();
        }

        void playIntro() {
            renderer.playIntro(System.currentTimeMillis(), true);
            invalidate();
        }

        void toggleBands() {
            if (stopped) return;
            renderer.band.setDemo(!renderer.band.demo(), System.currentTimeMillis());
            invalidate();
        }

        void reloadBands() {
            renderer.readConfig(prefs);
            invalidate();
        }

        void toggleNumerals() {
            renderer.tapNumerals(System.currentTimeMillis());
            invalidate();
        }

        void setNumerals(int preset) {
            renderer.hang.preset = preset;
            invalidate();
        }

        void setSleepStyle(int style) {
            renderer.setSleepStyle(style);
            invalidate();
        }

        void toggleSleep() {
            renderer.setSleeping(!renderer.sleeping(), System.currentTimeMillis(), false);
            invalidate();
        }

        void setIntro(boolean on) {
            renderer.setIntro(on);
        }

        void setIndicator(int style) {
            renderer.gauge.indicator = style;
            invalidate();
        }

        void setTheme(int theme) {
            renderer.setMode(Supers.is(theme) ? prefs.getInt(Prefs.THEME, 0) : theme, Supers.is(theme), theme, System.currentTimeMillis());
            invalidate();
        }

        void togglePendulum() {
            renderer.gauge.togglePendulum(System.currentTimeMillis());
            invalidate();
        }

        void toggleFlip() {
            renderer.gauge.toggleFlip(System.currentTimeMillis());
            invalidate();
        }

        /** Picks a rewind style and plays it right away. */
        void setRewind(int style) {
            renderer.setRewind(style);
            renderer.playIntro(System.currentTimeMillis(), true);
            invalidate();
        }

        void load() {
            renderer.readConfig(prefs);
            rebuild();
        }

        void rebuild() {
            if (getWidth() <= 0) return;
            final int gen = ++generation;
            Scene.buildAsync(getContext(), getWidth(), getHeight(),
                    prefs.getFloat(Prefs.SUBJ_SCALE, 1f), built -> {
                        if (gen != generation) {
                            built.recycle();
                            return;
                        }
                        Scene old = scene;
                        scene = built;
                        renderer.setScene(built);
                        if (old != null) old.recycle();
                        invalidate();
                    });
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            renderer.setSize(w, h);
            rebuild();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            long now = System.currentTimeMillis();
            renderer.draw(canvas, now);
            if (renderer.gauge.due) renderer.gauge.readFrom(getContext());
            boolean need = active && renderer.sensing();
            if (need != tilt.running()) {
                if (need) tilt.start();
                else tilt.stop();
            }
            if (!active || stopped) return;
            if (renderer.animating(now)) postInvalidateOnAnimation();
            else postInvalidateDelayed(renderer.delay(now));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    downX = e.getX();
                    downY = e.getY();
                    baseX = dragSubject ? renderer.subjX() : renderer.clockX();
                    baseY = dragSubject ? renderer.subjY() : renderer.clockY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!dragging) return true;
                    float x = baseX + (e.getX() - downX) / getWidth();
                    float y = baseY + (e.getY() - downY) / getHeight();
                    if (dragSubject) renderer.setSubject(x, y);
                    else renderer.setClock(x, y);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (dragging) {
                        dragging = false;
                        SharedPreferences.Editor ed = prefs.edit();
                        if (dragSubject) {
                            ed.putFloat(Prefs.SUBJ_X, renderer.subjX()).putFloat(Prefs.SUBJ_Y, renderer.subjY());
                        } else {
                            ed.putFloat(Prefs.CLOCK_X, renderer.clockX()).putFloat(Prefs.CLOCK_Y, renderer.clockY());
                        }
                        ed.apply();
                    }
                    return true;
            }
            return super.onTouchEvent(e);
        }
    }

    // ---------- view helpers ----------

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextColor(WHITE);
        b.setBackground(rounded(CARD, EDGE));
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout slider(String label, int min, int max, int value, IntSink live, IntSink done) {
        LinearLayout box = column();
        TextView t = text(label + "  " + value, 13, WHITE);
        box.addView(t);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = p + min;
                t.setText(label + "  " + v);
                if (fromUser) live.accept(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                done.accept(s.getProgress() + min);
            }
        });
        box.addView(bar);
        return box;
    }

    private GradientDrawable rounded(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(16));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout.LayoutParams matchWrap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = top;
        return lp;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
