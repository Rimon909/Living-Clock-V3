package com.rimon.livingclock;

import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * Four clock themes beside the classic glass one. All are translucent so they sit on any photo.
 *   1 Orbit             hands become bodies on orbits: a ringed planet, a moon, a comet (orbital dials)
 *   2 Rings             hands become arcs that grow around the dial (arc-sweep displays)
 *   3 Kinetic numerals  the numerals swell where the hands point (jumping-hour numerals, kinetic type)
 *   4 Noir              smoked-glass dial, slim dauphine blades, crimson accent; also darkens the wallpaper
 * Static art is drawn once into a cached bitmap; only the hands and the numerals are drawn per frame.
 */
final class Themes {

    static final int COUNT = 10, NOIR = 4;   // 5 to 9 are the Super 5, see Supers
    static final String[] NAMES = {"Classic glass", "Orbit", "Rings", "Kinetic numerals", "Noir",
            "Super 5 · Heritage Pocket", "Super 5 · Grand Pendulum", "Super 5 · Tourbillon", "Super 5 · Celestial Orrery", "Super 5 · Imperial Egg"};

    private static final int IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A, CRIMSON = 0xFFD94452;
    private static final String[] NUM = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
    private static final Path P = new Path(), Q = new Path();
    private static final RectF R = new RectF();

    private Themes() { }

    // ---------- static art, drawn once ----------

    static void dial(int th, Canvas k, float c0, float r, Paint p) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(c0, c0, r,
                th == NOIR ? new int[]{0xB0141A24, 0xC80A0E15, 0xE6000000} : new int[]{0x26FFFFFF, 0x10FFFFFF, 0x4D000000},
                new float[]{0f, 0.75f, 1f}, Shader.TileMode.CLAMP));
        k.drawCircle(c0, c0, r, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(r * 0.006f);
        p.setColor(0x70FFFFFF);
        k.drawCircle(c0, c0, r * 0.98f, p);

        if (th == 1) orbitDial(k, c0, r, p);
        else if (th == 2) ringsDial(k, c0, r, p);
        else if (th == 3) typeDial(k, c0, r, p);
        else noirDial(k, c0, r, p);
    }

    private static void orbitDial(Canvas k, float c0, float r, Paint p) {
        p.setPathEffect(new DashPathEffect(new float[]{r * 0.012f, r * 0.03f}, 0f));
        p.setStrokeWidth(r * 0.006f);
        p.setColor(0x66FFFFFF);
        k.drawCircle(c0, c0, r * 0.46f, p);
        k.drawCircle(c0, c0, r * 0.78f, p);
        p.setPathEffect(null);
        p.setStrokeWidth(r * 0.004f);
        p.setColor(0x30FFFFFF);
        k.drawCircle(c0, c0, r * 0.93f, p);

        p.setStyle(Paint.Style.FILL);
        p.setColor(withA(IVORY, 0xC0));
        for (int i = 0; i < 12; i++) {
            float rr = r * 0.93f;
            k.drawCircle(c0 + Renderer.COS[i * 5] * rr, c0 + Renderer.SIN[i * 5] * rr, r * (i % 3 == 0 ? 0.022f : 0.012f), p);
        }
        p.setShader(new RadialGradient(c0, c0, r * 0.16f, new int[]{0xFFFFE9B0, 0x66FFC060, 0x00FFC060},
                new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        k.drawCircle(c0, c0, r * 0.16f, p);
        p.setShader(null);
    }

    private static void ringsDial(Canvas k, float c0, float r, Paint p) {
        p.setStrokeWidth(r * 0.10f);
        p.setColor(0x22FFFFFF);
        k.drawCircle(c0, c0, r * 0.86f, p);
        k.drawCircle(c0, c0, r * 0.68f, p);
        k.drawCircle(c0, c0, r * 0.50f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x96FFF4E2);
        for (int i = 0; i < 12; i++) {
            k.drawCircle(c0 + Renderer.COS[i * 5] * r * 0.945f, c0 + Renderer.SIN[i * 5] * r * 0.945f, r * 0.013f, p);
        }
    }

    private static void typeDial(Canvas k, float c0, float r, Paint p) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 60; i++) {
            boolean q = i % 5 == 0;
            p.setColor(withA(IVORY, q ? 0xB0 : 0x70));
            k.drawCircle(c0 + Renderer.COS[i] * r * 0.935f, c0 + Renderer.SIN[i] * r * 0.935f, r * (q ? 0.013f : 0.006f), p);
        }
    }

    private static void noirDial(Canvas k, float c0, float r, Paint p) {
        for (int i = 1; i < 60; i++) {                  // the crimson marker replaces the 12 o'clock tick
            boolean hr = i % 5 == 0;
            float rin = r * (hr ? 0.82f : 0.90f), rout = r * 0.95f;
            p.setStrokeWidth(r * (hr ? 0.018f : 0.007f));
            p.setColor(hr ? 0xF0F2F4FA : 0xA0F2F4FA);
            k.drawLine(c0 + Renderer.COS[i] * rin, c0 + Renderer.SIN[i] * rin,
                    c0 + Renderer.COS[i] * rout, c0 + Renderer.SIN[i] * rout, p);
        }
        P.rewind();
        P.moveTo(c0, c0 - r * 0.80f);
        P.lineTo(c0 - r * 0.04f, c0 - r * 0.95f);
        P.lineTo(c0 + r * 0.04f, c0 - r * 0.95f);
        P.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(CRIMSON);
        k.drawPath(P, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.004f);
        p.setColor(0x24FFFFFF);
        k.drawCircle(c0, c0, r * 0.70f, p);
    }

    // ---------- per-frame parts under the hands ----------

    /** Kinetic numerals: each numeral swells and brightens as the hour or minute hand comes near. */
    static void under(int th, Canvas c, float cx, float cy, float r, float hDeg, float mDeg, Paint t) {
        if (th != 3) return;
        t.setStyle(Paint.Style.FILL);
        for (int i = 1; i <= 12; i++) {
            float ang = i * 30f;
            float dh = diff(ang, hDeg), dm = diff(ang, mDeg);
            float hf = (float) Math.exp(-(dh * dh) / 400f), mf = (float) Math.exp(-(dm * dm) / 196f);
            float f = Math.max(hf, mf * 0.8f);
            float size = r * 0.105f * (1f + 0.85f * hf + 0.45f * mf);
            t.setTextSize(size);
            t.setFakeBoldText(hf > 0.5f);
            t.setColor(hf > 0.5f ? withA(GOLD, 255) : withA(IVORY, (int) (120 + 135 * f)));
            int k = (i * 5) % 60;
            c.drawText(NUM[i - 1], cx + Renderer.COS[k] * r * 0.74f, cy + Renderer.SIN[k] * r * 0.74f + size * 0.35f, t);
        }
        t.setFakeBoldText(false);
    }

    // ---------- hands ----------

    static void hands(int th, Canvas c, float cx, float cy, float r, float h, float m, float s, float sa, Paint p) {
        if (th == 1) orbitHands(c, cx, cy, r, h, m, s, sa, p);
        else if (th == 2) ringsHands(c, cx, cy, r, h, m, s, sa, p);
        else if (th == 3) typeHands(c, cx, cy, r, h, m, s, sa, p);
        else noirHands(c, cx, cy, r, h, m, s, sa, p);
    }

    private static void orbitHands(Canvas c, float cx, float cy, float r, float h, float m, float s, float sa, Paint p) {
        float hx = px(cx, r * 0.46f, h), hy = py(cy, r * 0.46f, h);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(r * 0.005f);
        p.setColor(0x44FFFFFF);
        c.drawLine(cx, cy, hx, hy, p);

        p.setStyle(Paint.Style.FILL);                                   // planet with a ring
        p.setColor(0x40FFC27A);
        c.drawCircle(hx, hy, r * 0.16f, p);
        p.setColor(0xFFFFC27A);
        c.drawCircle(hx, hy, r * 0.07f, p);
        p.setColor(0x99FFF4E2);
        c.drawCircle(hx - r * 0.02f, hy - r * 0.02f, r * 0.03f, p);
        c.save();
        c.translate(hx, hy);
        c.rotate(-20f);
        R.set(-r * 0.115f, -r * 0.032f, r * 0.115f, r * 0.032f);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.008f);
        p.setColor(0xB0FFF4E2);
        c.drawOval(R, p);
        c.restore();

        float mx = px(cx, r * 0.78f, m), my = py(cy, r * 0.78f, m);     // moon
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x40D9ECFF);
        c.drawCircle(mx, my, r * 0.11f, p);
        p.setColor(0xFFD9ECFF);
        c.drawCircle(mx, my, r * 0.048f, p);
        p.setColor(0x99FFFFFF);
        c.drawCircle(mx - r * 0.014f, my - r * 0.014f, r * 0.02f, p);

        if (sa > 0.02f) {                                               // comet with a tail along the rim
            for (int k = 8; k >= 0; k--) {
                float a = s - k * 4f;
                p.setColor(withA(0xFFFFE9B0, (int) (230 * sa * (1f - k / 9f))));
                c.drawCircle(px(cx, r * 0.93f, a), py(cy, r * 0.93f, a), r * (k == 0 ? 0.026f : 0.018f * (1f - k * 0.08f)), p);
            }
            p.setColor(withA(0xFFFFE9B0, (int) (70 * sa)));
            c.drawCircle(px(cx, r * 0.93f, s), py(cy, r * 0.93f, s), r * 0.07f, p);
        }
    }

    private static void ringsHands(Canvas c, float cx, float cy, float r, float h, float m, float s, float sa, Paint p) {
        ring(c, cx, cy, r * 0.50f, r * 0.10f, h, 0xFF6FE3D0, 1f, p);
        ring(c, cx, cy, r * 0.68f, r * 0.10f, m, 0xFFFF8FA3, 1f, p);
        ring(c, cx, cy, r * 0.86f, r * 0.10f, s, 0xFFFFD27A, sa, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(IVORY);
        c.drawCircle(cx, cy, r * 0.02f, p);
    }

    private static void ring(Canvas c, float cx, float cy, float rr, float w, float deg, int col, float a, Paint p) {
        if (a <= 0.02f) return;
        R.set(cx - rr, cy - rr, cx + rr, cy + rr);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        if (deg > 1f) {
            p.setStrokeWidth(w * 1.5f);
            p.setColor(withA(col, (int) (45 * a)));
            c.drawArc(R, -90f, deg, false, p);
            p.setStrokeWidth(w * 0.9f);
            p.setColor(withA(col, (int) (235 * a)));
            c.drawArc(R, -90f, deg, false, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(withA(0xFFFFFF, (int) (240 * a)));
        c.drawCircle(px(cx, rr, deg), py(cy, rr, deg), w * 0.28f, p);
    }

    private static void typeHands(Canvas c, float cx, float cy, float r, float h, float m, float s, float sa, Paint p) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        float mx = px(cx, r * 0.56f, m), my = py(cy, r * 0.56f, m);     // minute needle ending in a small ring
        p.setStrokeWidth(r * 0.014f);
        p.setColor(0xF0FFF4E2);
        c.drawLine(cx, cy, mx, my, p);
        p.setStrokeWidth(r * 0.012f);
        c.drawCircle(mx, my, r * 0.03f, p);

        float hx = px(cx, r * 0.30f, h), hy = py(cy, r * 0.30f, h);     // short hour stub
        p.setStrokeWidth(r * 0.09f);
        p.setColor(withA(GOLD, 50));
        c.drawLine(cx, cy, hx, hy, p);
        p.setStrokeWidth(r * 0.045f);
        p.setColor(withA(GOLD, 235));
        c.drawLine(cx, cy, hx, hy, p);

        if (sa > 0.02f) {                                               // seconds dot with a short trail
            p.setStyle(Paint.Style.FILL);
            for (int k = 5; k >= 1; k--) {
                p.setColor(withA(GOLD, (int) (140 * sa * (1f - k / 6f))));
                c.drawCircle(px(cx, r * 0.935f, s - k * 6f), py(cy, r * 0.935f, s - k * 6f), r * 0.012f, p);
            }
            p.setColor(withA(GOLD, (int) (70 * sa)));
            c.drawCircle(px(cx, r * 0.935f, s), py(cy, r * 0.935f, s), r * 0.06f, p);
            p.setColor(withA(GOLD, (int) (255 * sa)));
            c.drawCircle(px(cx, r * 0.935f, s), py(cy, r * 0.935f, s), r * 0.022f, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x80000000);
        c.drawCircle(cx, cy, r * 0.045f, p);
        p.setColor(IVORY);
        c.drawCircle(cx, cy, r * 0.032f, p);
    }

    private static void noirHands(Canvas c, float cx, float cy, float r, float h, float m, float s, float sa, Paint p) {
        kite(c, cx, cy, r, h, r * 0.52f, r * 0.042f, r * 0.10f, p);
        kite(c, cx, cy, r, m, r * 0.80f, r * 0.030f, r * 0.12f, p);
        if (sa > 0.02f) {
            c.save();
            c.translate(cx, cy);
            c.rotate(s);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(r * 0.008f);
            p.setColor(withA(CRIMSON, (int) (255 * sa)));
            c.drawLine(0f, r * 0.2f, 0f, -r * 0.9f, p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(0f, r * 0.2f, r * 0.03f, p);
            c.restore();
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF0B0F17);
        c.drawCircle(cx, cy, r * 0.055f, p);
        p.setColor(CRIMSON);
        c.drawCircle(cx, cy, r * 0.03f, p);
    }

    /** A slim dauphine blade: two facets, a lighter left and a darker right, like a polished hand. */
    private static void kite(Canvas c, float cx, float cy, float r, float deg, float len, float hw, float tail, Paint p) {
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        P.rewind();
        P.moveTo(0f, tail);
        P.lineTo(hw, -len * 0.22f);
        P.lineTo(0f, -len);
        P.lineTo(-hw, -len * 0.22f);
        P.close();
        Q.rewind();
        Q.moveTo(0f, tail);
        Q.lineTo(hw, -len * 0.22f);
        Q.lineTo(0f, -len);
        Q.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF2F4FA);
        c.drawPath(P, p);
        p.setColor(0x33000000);
        c.drawPath(Q, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.008f);
        p.setColor(0x99000000);
        c.drawPath(P, p);
        c.restore();
    }

    // ---------- helpers ----------

    private static float px(float cx, float rr, float deg) {
        return cx + (float) Math.sin(Math.toRadians(deg)) * rr;
    }

    private static float py(float cy, float rr, float deg) {
        return cy - (float) Math.cos(Math.toRadians(deg)) * rr;
    }

    private static float diff(float a, float b) {
        float d = Math.abs(a - b) % 360f;
        return d > 180f ? 360f - d : d;
    }

    private static int withA(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }
}
