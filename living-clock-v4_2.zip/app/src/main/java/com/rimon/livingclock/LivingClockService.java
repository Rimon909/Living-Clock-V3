package com.rimon.livingclock;

import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.media.AudioManager;
import android.media.AudioPlaybackConfiguration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;

import java.util.List;

/**
 * Live wallpaper. Idle: one draw a second. During the intro, falling numbers, shooting stars and the
 * battery gauge it follows the display refresh through Choreographer, then returns to idle. The
 * accelerometer is on only while the pendulum or the flipped clock is showing.
 *
 * Kill switch: when it is on, every receiver, sensor, listener and timer is released and the wallpaper shows one
 * still frame until the app turns it back on.
 * Music: the bands follow real sound only. A paused or muted signal sends them home; while they wait, a short
 * listener (a fraction of a second every few seconds) wakes them when sound returns.
 *
 * Taps on the clock: 1 = numbers, 2 in the centre = pendulum, 3 = flip. A tap on the pendulum pokes it.
 */
public class LivingClockService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new ClockEngine();
    }

    private final class ClockEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {

        private final long tapGap = 300L;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Choreographer choreographer = Choreographer.getInstance();
        private final Renderer renderer = new Renderer();
        private final Tilt tilt = new Tilt(LivingClockService.this, handler,
                (ax, ay, az) -> renderer.gauge.setGravity(ax, ay));
        private final Runnable tick = this::frame;
        private final Choreographer.FrameCallback vsync = t -> frame();

        private int taps, kind;
        private long lastTapMs;
        private float tapX, tapY;
        private boolean touchSeen;

        private AudioManager audio;
        private Object musicCb;                  // AudioManager.AudioPlaybackCallback, API 26+
        private boolean musicOn, rateLocked;
        private long lastMusicPoll;
        private boolean killed, probing, volumeOn, sceneDirty = true;
        private final Scenes scenes = new Scenes();
        private final float[] sig = new float[Scenes.SIG.length];
        private long sceneAt;
        private int lockedCap;
        private final Beat.Probe probe = new Beat.Probe();

        private final Runnable probeOpen = new Runnable() {
            @Override
            public void run() {
                if (killed || !visible || !renderer.band.needsProbe()) {
                    probing = false;
                    return;
                }
                if (probe.open(LivingClockService.this)) handler.postDelayed(probeRead, 240);
                else handler.postDelayed(this, 4000);
            }
        };

        private final Runnable probeRead = () -> {
            boolean heard = probe.audible();
            probe.close();
            if (killed || !ClockEngine.this.visible) {
                probing = false;
            } else if (heard) {
                probing = false;
                renderer.band.sound();
                schedule(0);
            } else if (renderer.band.needsProbe()) {
                handler.postDelayed(probeOpen, 2500);
            } else {
                probing = false;
            }
        };

        private final BroadcastReceiver volumeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!killed && visible && renderer.band.needsProbe()) {   // volume moved: check at once if sound is back
                    handler.removeCallbacks(probeOpen);
                    handler.postDelayed(probeOpen, 300);
                    probing = true;
                }
            }
        };

        private final Runnable resolveTaps = () -> {
            int n = taps;
            taps = 0;
            long now = System.currentTimeMillis();
            if (kind == 2) {                                   // two taps on the top of the cutout: the next theme of this mode
                if (n == 2) {
                    renderer.cycleTheme(now);
                    saveMode();
                }
                schedule(0);
                return;
            }
            if (n == 1 && Supers.is(renderer.theme())) {         // one tap on a Super clock: its own animation
                renderer.tapSuper(now);
                schedule(0);
                return;
            }
            if (n == 2 && renderer.inCenter(tapX, tapY)) renderer.gauge.togglePendulum(now);
            else if (renderer.gauge.flipped()) {
                renderer.gauge.touched(now);
                renderer.gauge.slosh();
            } else renderer.tapNumerals(now);
            schedule(0);
        };

        private final BroadcastReceiver wakeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                long now = System.currentTimeMillis();
                String a = intent.getAction();
                if (Intent.ACTION_POWER_CONNECTED.equals(a)) renderer.setSleeping(true, now, !visible);
                else if (Intent.ACTION_POWER_DISCONNECTED.equals(a)) renderer.setSleeping(false, now, !visible);
                else renderer.playIntro(now, false);
                schedule(0);
            }
        };

        private SharedPreferences prefs;
        private Scene scene;
        private boolean visible, ready, destroyed, receiverOn;
        private int width, height, generation, imageVersion;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
            prefs = Prefs.get(LivingClockService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            imageVersion = prefs.getInt(Prefs.IMG, 0);
            renderer.band.attach(LivingClockService.this);
            renderer.readConfig(prefs);
            killed = prefs.getBoolean(Prefs.KILL, false);
            scenes.load(prefs);
            renderer.setKilled(killed);
            if (!killed) registerReceivers();
        }

        private void registerReceivers() {
            if (receiverOn) return;
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            filter.addAction(Intent.ACTION_POWER_CONNECTED);
            filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
            LivingClockService.this.registerReceiver(wakeReceiver, filter);
            receiverOn = true;
            if (!volumeOn) {
                LivingClockService.this.registerReceiver(volumeReceiver, new IntentFilter("android.media.VOLUME_CHANGED_ACTION"));
                volumeOn = true;
            }
        }

        private void unregisterReceivers() {
            if (receiverOn) {
                try {
                    LivingClockService.this.unregisterReceiver(wakeReceiver);
                } catch (IllegalArgumentException ignored) {
                    // Already unregistered.
                }
                receiverOn = false;
            }
            if (volumeOn) {
                try {
                    LivingClockService.this.unregisterReceiver(volumeReceiver);
                } catch (IllegalArgumentException ignored) {
                    // Already unregistered.
                }
                volumeOn = false;
            }
        }

        /** Everything stops: sensors, audio, listeners, timers. One still frame stays on screen. */
        private void shutdown() {
            stop();
            handler.removeCallbacks(resolveTaps);
            handler.removeCallbacks(probeOpen);
            handler.removeCallbacks(probeRead);
            probe.close();
            probing = false;
            taps = 0;
            tilt.stop();
            stopMusicWatch();
            musicOn = false;
            lockRate(false);
            unregisterReceivers();
            renderer.setKilled(true);
            if (ready && !destroyed) drawFrame(System.currentTimeMillis());
        }

        private void startup() {
            renderer.setKilled(false);
            registerReceivers();
            if (visible) resume();
            else if (ready) drawFrame(System.currentTimeMillis());
        }

        private void resume() {
            startMusicWatch();
            renderer.gauge.readFrom(LivingClockService.this);
            renderer.setSleeping(renderer.gauge.plugged, System.currentTimeMillis(), true);
            checkMusic();
            renderer.playIntro(System.currentTimeMillis(), false);
            schedule(0);
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (killed) {
                if (visible && ready) drawFrame(System.currentTimeMillis());
                return;
            }
            if (visible) {
                resume();
            } else {
                handler.removeCallbacks(probeOpen);
                handler.removeCallbacks(probeRead);
                probe.close();
                probing = false;
                stopMusicWatch();
                musicOn = false;
                lockRate(false);
                stop();
                tilt.stop();
                renderer.closeGauge();
                handler.removeCallbacks(resolveTaps);
                taps = 0;
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            ready = w > 0 && h > 0;
            if (!ready) return;
            if (killed) {
                if (w != width || h != height || scene == null) {
                    width = w;
                    height = h;
                    renderer.setSize(w, h);
                    rebuild();
                } else {
                    drawFrame(System.currentTimeMillis());
                }
                return;
            }
            if (w == width && h == height && scene != null) {
                schedule(0);
                return;
            }
            width = w;
            height = h;
            renderer.setSize(w, h);
            rebuild();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            ready = false;
            stop();
            tilt.stop();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            destroyed = true;
            stop();
            tilt.stop();
            handler.removeCallbacks(resolveTaps);
            stopMusicWatch();
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            handler.removeCallbacks(probeOpen);
            handler.removeCallbacks(probeRead);
            probe.close();
            unregisterReceivers();
            renderer.release();
            if (scene != null) scene.recycle();
            scene = null;
            super.onDestroy();
        }

        // ---------- touch ----------

        /** Full touch events, when the launcher forwards them: poke or drag the pendulum, else count taps. */
        @Override
        public void onTouchEvent(MotionEvent e) {
            touchSeen = true;
            if (killed || renderer.asleep()) return;
            long now = System.currentTimeMillis();
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                if (renderer.gauge.touch(0, e.getX(), e.getY(), now)) schedule(0);
                else tap(e.getX(), e.getY());
            } else if (action == MotionEvent.ACTION_MOVE) {
                renderer.gauge.touch(1, e.getX(), e.getY(), now);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                renderer.gauge.touch(2, e.getX(), e.getY(), now);
            }
        }

        /** Most launchers forward taps on empty home-screen areas as this command. */
        @Override
        public Bundle onCommand(String action, int x, int y, int z, Bundle extras, boolean resultRequested) {
            if (!killed && !touchSeen && WallpaperManager.COMMAND_TAP.equals(action)) tap(x, y);
            return null;
        }

        private void saveMode() {
            SharedPreferences.Editor ed = prefs.edit();
            renderer.saveMode(ed);
            ed.apply();
        }

        private void tap(float x, float y) {
            if (renderer.asleep() || renderer.band.active()) return;   // the bands own the clock while music plays
            long now = System.currentTimeMillis();
            if (renderer.gauge.pokeAt(x, y, now)) {
                schedule(0);
                return;
            }
            int k = renderer.onClock(x, y) ? 1 : (renderer.onSubjectTop(x, y) ? 2 : 0);
            if (k == 0) {
                taps = 0;
                kind = 0;
                return;
            }
            taps = (k == kind && now - lastTapMs <= tapGap) ? taps + 1 : 1;
            kind = k;
            lastTapMs = now;
            tapX = x;
            tapY = y;
            handler.removeCallbacks(resolveTaps);
            if (k == 2) {                       // top of the cutout: two taps = next theme, three taps = into or out of the Super 5
                if (taps >= 3) {
                    taps = 0;
                    renderer.toggleSuper(now);
                    saveMode();
                    schedule(0);
                } else if (taps == 2) {
                    handler.postDelayed(resolveTaps, tapGap);   // wait a moment in case a third tap follows
                }
                return;
            }
            if (taps >= 3) {
                taps = 0;
                renderer.hang.dismiss(now);
                renderer.gauge.toggleFlip(now);
                schedule(0);
            } else {
                handler.postDelayed(resolveTaps, tapGap);
            }
        }

        // ---------- settings and scene ----------

        @Override
        public void onSharedPreferenceChanged(SharedPreferences p, String key) {
            if (Prefs.SCENES.equals(key) || Prefs.SCENES_ON.equals(key)) {
                scenes.load(p);
                sceneDirty = true;
                if (!killed) schedule(0);
                return;
            }
            if (Prefs.KILL.equals(key) || p.getBoolean(Prefs.KILL, false) != killed) {
                boolean k = p.getBoolean(Prefs.KILL, false);
                if (k != killed) {
                    killed = k;
                    if (k) shutdown();
                    else startup();
                    return;
                }
            }
            renderer.readConfig(p);
            int v = p.getInt(Prefs.IMG, 0);
            if (v != imageVersion) {
                imageVersion = v;
                rebuild();
            } else {
                schedule(0);
            }
        }

        private void rebuild() {
            if (!ready || destroyed) return;
            final int gen = ++generation;
            Scene.buildAsync(LivingClockService.this, width, height,
                    prefs.getFloat(Prefs.SUBJ_SCALE, 1f), built -> {
                        if (destroyed || gen != generation) {
                            built.recycle();
                            return;
                        }
                        Scene old = scene;
                        scene = built;
                        renderer.setScene(built);
                        if (old != null) old.recycle();
                        if (killed) drawFrame(System.currentTimeMillis());
                        else schedule(0);
                    });
        }

        // ---------- music ----------

        /** Event driven from Android 8 on: nothing wakes while no audio starts or stops. */
        private void startMusicWatch() {
            if (audio == null) audio = (AudioManager) LivingClockService.this.getSystemService(Context.AUDIO_SERVICE);
            if (audio == null || musicCb != null || Build.VERSION.SDK_INT < 26) return;
            AudioManager.AudioPlaybackCallback cb = new AudioManager.AudioPlaybackCallback() {
                @Override
                public void onPlaybackConfigChanged(List<AudioPlaybackConfiguration> configs) {
                    checkMusic();
                }
            };
            audio.registerAudioPlaybackCallback(cb, handler);
            musicCb = cb;
        }

        private void stopMusicWatch() {
            if (Build.VERSION.SDK_INT >= 26 && musicCb != null && audio != null) {
                audio.unregisterAudioPlaybackCallback((AudioManager.AudioPlaybackCallback) musicCb);
            }
            musicCb = null;
        }

        private void checkMusic() {
            if (audio == null || !visible || destroyed || killed) return;
            boolean on = !renderer.asleep() && audio.isMusicActive();
            if (on == musicOn) return;
            musicOn = on;
            renderer.band.setMusic(on);
            sceneDirty = true;
            if (!on) {
                handler.removeCallbacks(probeOpen);
                handler.removeCallbacks(probeRead);
                probe.close();
                probing = false;
            }
            schedule(0);
        }

        /** While the bands play, ask the display for a steady 60 Hz: smooth, and cheaper than 120 Hz. */
        private void lockRate(boolean on) {
            rateLocked = on;
            lockedCap = renderer.fpsCap;
            if (Build.VERSION.SDK_INT < 30) return;
            try {
                getSurfaceHolder().getSurface().setFrameRate(on ? (renderer.fpsCap > 0 ? renderer.fpsCap : 60f) : 0f,
                        on ? Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE : Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
            } catch (RuntimeException ignored) {
                // The surface can vanish mid-call.
            }
        }

        // ---------- frame loop ----------

        private void stop() {
            handler.removeCallbacks(tick);
            choreographer.removeFrameCallback(vsync);
        }

        private void schedule(long delayMs) {
            stop();
            if (visible && ready && !destroyed && !killed) handler.postDelayed(tick, delayMs);
        }

        private void frame() {
            if (!visible || !ready || destroyed || killed) return;
            long wall = System.currentTimeMillis();
            drawFrame(wall);
            if (!probing && renderer.band.needsProbe()) {      // sound may come back: listen briefly every few seconds
                probing = true;
                handler.postDelayed(probeOpen, 1500);
            }

            if (Build.VERSION.SDK_INT < 26 && System.currentTimeMillis() - lastMusicPoll >= 1000) {
                lastMusicPoll = System.currentTimeMillis();     // no playback callback before Android 8: look once a second
                checkMusic();
            }
            if (sceneDirty || (scenes.enabled() && wall - sceneAt >= 500L)) {   // scenes: about twice a second, only when on
                sceneAt = wall;
                sceneDirty = false;
                Scenes.sample(LivingClockService.this, musicOn, sig);
                renderer.applyScene(scenes.eval(sig, wall));
            }
            boolean bandOn = renderer.band.active();
            if (bandOn != rateLocked || (bandOn && lockedCap != renderer.fpsCap)) lockRate(bandOn);

            if (renderer.gauge.due) {
                sceneDirty = true;
                renderer.gauge.readFrom(LivingClockService.this);
                renderer.setSleeping(renderer.gauge.plugged, System.currentTimeMillis(), true);
            }
            boolean need = renderer.sensing();
            if (need != tilt.running()) {
                if (need) tilt.start();
                else tilt.stop();
            }

            long now = System.currentTimeMillis();
            int cap = renderer.fpsCap;
            if (renderer.animating(now)) {
                if (cap > 0) handler.postDelayed(tick, Math.max(1L, 1000L / cap - (now - wall)));   // governor: capped rate
                else choreographer.postFrameCallback(vsync);
            } else {
                handler.postDelayed(tick, renderer.delay(now));
            }
        }

        private void drawFrame(long now) {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) canvas = holder.lockHardwareCanvas();
                if (canvas == null) canvas = holder.lockCanvas();
                if (canvas != null) renderer.draw(canvas, now);
            } catch (RuntimeException ignored) {
                // The surface can vanish mid-frame during rotation or lock-screen changes.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (RuntimeException ignored) {
                        // Surface no longer valid.
                    }
                }
            }
        }
    }
}
