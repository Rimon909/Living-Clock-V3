package com.rimon.livingclock;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;

/**
 * Super 5: five premium clocks, reached by triple-tapping the top of the cutout. The wallpaper is never
 * replaced; each clock only lays a faint tint over it. Every one has working parts, its own single-tap animation
 * and its own way in and out.
 *
 *   5 Heritage Pocket   a bronze wall clock on a hanging loop: glass dome, gold numerals, a spoked ring and a
 *                       working gear train; tap = the crown chimes (loop swings, rings ripple, gears spin up);
 *                       in = it drops on its loop and bounces, out = it lifts away
 *   6 Grand Pendulum    a walnut cabinet with a swinging pendulum, a working escapement and brass weights;
 *                       tap = the hour strikes (the pendulum is kicked and leaves ghost trails);
 *                       in = the doors swing open, out = they close
 *   7 Tourbillon        an open-worked dial: bridges, a gear train and a cage that turns once a minute;
 *                       tap = winding (the cage spins up trailing gold, screws glint);
 *                       in = the parts fly in and mesh, out = an exploded view
 *   8 Celestial Orrery  a midnight dial with a star map that turns with the day, a sun and a moon on their rings and
 *                       a true moon phase; tap = a shooting star and the sky spins;
 *                       in = the sky unfolds from the centre, out = it spirals closed
 *   9 Imperial Egg      an enamel and gold egg with a jewelled dial; tap = the lid lifts and a golden bird sings;
 *                       in = the egg turns to face you, out = it turns away
 *
 * Cost: static art is drawn once into a cached bitmap; only what moves is drawn per frame (about 35 to 70 draw
 * calls). Ambient motion runs at about 24 frames a second (12 on a low battery); transitions follow the display.
 */
final class Supers {

    static final int FIRST = 5, N = 5;
    static final long BUILD_MS = 3800, EXIT_MS = 3000;
    static final String[] NAMES = {"Heritage Pocket", "Grand Pendulum", "Tourbillon", "Celestial Orrery", "Imperial Egg"};

    private static final int[] LOOK = {3, 2, 4, 1, 0};                       // the band pattern each Super borrows
    private static final int[] TINT = {0xFF2A1E12, 0xFF1E1208, 0xFF0A1220, 0xFF060B24, 0xFF1A0A18};
    private static final float[] TINT_A = {0.22f, 0.24f, 0.26f, 0.30f, 0.24f};
    private static final int[] RIM = {0xFFE0B25A, 0xFFD8A83E, 0xFFE8B49A, 0xFFB9C8FF, 0xFFFFD27A};
    private static final float[][] EXT = {{1.2f, 1.2f, 1.7f, 1.2f}, {1.35f, 1.35f, 1.5f, 3.1f}, {1.2f, 1.2f, 1.2f, 1.2f},
            {1.2f, 1.2f, 1.2f, 1.2f}, {1.1f, 1.1f, 1.45f, 1.65f}};           // cache extents in r: left, right, top, bottom
    private static final float TAU = 6.2831855f;
    private static final int GOLD = 0xFFE0B25A, GOLD_L = 0xFFF3D78A, GOLD_D = 0xFF8A5E1E, IVORY = 0xFFFFF4E2;
    private static final long MOON_EPOCH = 947182440000L;                    // a new moon: 2000-01-06 18:14 UTC
    private static final double SYNODIC = 29.530588853 * 86400000.0;

    static boolean is(int th) {
        return th >= FIRST;
    }

    static int look(int th) {
        return LOOK[th - FIRST];
    }

    // ---------- state ----------

    private final float[] a = new float[N];
    private long last = -1L;
    private int w, h;
    private float cx, cy, r, u;
    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG), gp = new Paint(Paint.ANTI_ALIAS_FLAG), bp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Path path = new Path(), tmp = new Path(), disc = new Path(), egg = new Path(), moon = new Path();
    private final RectF rc = new RectF(), rc2 = new RectF();
    private final Rect src = new Rect();
    private final Matrix mx = new Matrix();
    private final Bitmap[] cache = new Bitmap[N];
    private final Typeface condensed = Typeface.create("sans-serif-condensed", Typeface.BOLD), serif = Typeface.create("serif", Typeface.BOLD);
    private RadialGradient vignette, heritDial, navyDial, ivoryDial, rubyEgg, bobG;
    private SweepGradient bronze, goldS, roseS, silverS;
    private LinearGradient walnut, velvet, sheen;
    private Path gBig, gSmall, gEsc, gBarrel, gB, gC, spring;
    private final float[] phase = new float[6], buf = new float[512], star = new float[400], flick = new float[48], cpts = new float[40];
    private static final int[][] GROUPS = {{0, 7}, {7, 12}, {12, 16}};
    private static final float[] CON = {                                     // three little constellations: x, y pairs in -1..1
            -0.9f, 0.1f, -0.6f, 0.0f, -0.3f, 0.1f, 0.0f, 0.3f, 0.35f, 0.25f, 0.6f, 0.55f, 0.9f, 0.5f,
            -0.7f, -0.5f, -0.35f, -0.2f, 0f, -0.55f, 0.35f, -0.25f, 0.7f, -0.6f,
            -0.2f, 0.9f, 0.0f, 0.55f, 0.15f, 0.8f, 0.4f, 0.5f};
    private final char[] txt = {'1', '2'};

    Supers() {
        pt.setStrokeCap(Paint.Cap.ROUND);
        pt.setStrokeJoin(Paint.Join.ROUND);
    }

    boolean step(int theme, long now) {
        float dt = last < 0 ? 0f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        boolean moving = false;
        for (int i = 0; i < N; i++) {
            float target = theme == FIRST + i ? 1f : 0f;
            if (a[i] != target) {
                float rate = dt / (target > a[i] ? 2.4f : 2.0f);
                a[i] += Math.max(-rate, Math.min(rate, target - a[i]));
                moving |= a[i] != target;
            }
            if (a[i] == 0f && cache[i] != null && theme != FIRST + i) {      // free the bitmap once the clock has gone
                cache[i].recycle();
                cache[i] = null;
            }
        }
        return moving;
    }

    void snap(int theme) {
        for (int i = 0; i < N; i++) a[i] = theme == FIRST + i ? 1f : 0f;
    }

    boolean active() {
        for (int i = 0; i < N; i++) if (a[i] > 0.003f) return true;
        return false;
    }

    int tintColor() {
        int best = 0;
        for (int i = 1; i < N; i++) if (a[i] > a[best]) best = i;
        float e = smooth(a[best]);
        return e < 0.02f ? 0 : (RIM[best] & 0x00FFFFFF) | (((int) (e * 30f)) << 24);
    }

    void release() {
        for (int i = 0; i < N; i++) {
            if (cache[i] != null) cache[i].recycle();
            cache[i] = null;
        }
    }

    // ---------- layout ----------

    void layout(int width, int height, float clockX, float clockY, float radius) {
        boolean same = width == w && height == h && radius == r && vignette != null;
        w = width;
        h = height;
        cx = clockX;
        cy = clockY;
        r = radius;
        u = width / 1080f;
        disc.rewind();
        disc.addCircle(0f, 0f, r * 0.9f, Path.Direction.CW);
        if (same) return;
        release();
        Shader.TileMode cl = Shader.TileMode.CLAMP;
        float big = Math.max(w, h);
        vignette = new RadialGradient(0f, 0f, big * 0.75f, new int[]{0x00000000, 0x00000000, 0xA0000000}, new float[]{0f, 0.55f, 1f}, cl);
        heritDial = new RadialGradient(0f, 0f, r * 0.87f, new int[]{0xFF3A383F, 0xFF242329, 0xFF141318}, new float[]{0f, 0.6f, 1f}, cl);
        navyDial = new RadialGradient(0f, 0f, r * 0.9f, new int[]{0xFF1B2A5E, 0xFF0B1230, 0xFF03050F}, new float[]{0f, 0.6f, 1f}, cl);
        ivoryDial = new RadialGradient(0f, 0f, r * 0.72f, new int[]{0xFFFFF9EC, 0xFFF0E2C6, 0xFFD9C6A0}, new float[]{0f, 0.7f, 1f}, cl);
        rubyEgg = new RadialGradient(-r * 0.3f, -r * 0.5f, r * 1.7f, new int[]{0xFFA21F44, 0xFF5A0C24, 0xFF22040F}, new float[]{0f, 0.55f, 1f}, cl);
        bobG = new RadialGradient(-r * 0.07f, -r * 0.07f, r * 0.3f, new int[]{0xFFFFEDB0, 0xFFD8A83E, 0xFF8A5E1E}, new float[]{0f, 0.55f, 1f}, cl);
        bronze = new SweepGradient(0f, 0f, new int[]{0xFF5A3A1F, 0xFFD39A58, 0xFF7A4A24, 0xFFE8B070, 0xFF5A3A1F, 0xFFB57A3E, 0xFF6B4423, 0xFFD9A263, 0xFF5A3A1F}, null);
        goldS = new SweepGradient(0f, 0f, new int[]{0xFF8A5E1E, 0xFFF3D78A, 0xFFC99A3E, 0xFFFFE9A8, 0xFF8A5E1E, 0xFFE0B25A, 0xFF9A6A24, 0xFFF3D78A, 0xFF8A5E1E}, null);
        roseS = new SweepGradient(0f, 0f, new int[]{0xFF8A5040, 0xFFF0B8A0, 0xFFB87060, 0xFFFFD6C0, 0xFF8A5040, 0xFFE0A088, 0xFF9A6050, 0xFFF0B8A0, 0xFF8A5040}, null);
        silverS = new SweepGradient(0f, 0f, new int[]{0xFF7A8296, 0xFFE8EEFF, 0xFF9AA4BA, 0xFFFFFFFF, 0xFF7A8296, 0xFFD0D8EE, 0xFF8A94AC, 0xFFE8EEFF, 0xFF7A8296}, null);
        walnut = new LinearGradient(-r * 1.3f, 0f, r * 1.3f, 0f, new int[]{0xFF2A140A, 0xFF5A3217, 0xFF3A1E0E, 0xFF5A3217, 0xFF2A140A}, new float[]{0f, 0.25f, 0.5f, 0.75f, 1f}, cl);
        velvet = new LinearGradient(-r * 0.8f, 0f, r * 0.8f, 0f, new int[]{0xFF1A0C0C, 0xFF341A14, 0xFF1A0C0C}, new float[]{0f, 0.5f, 1f}, cl);
        sheen = new LinearGradient(-100f, 0f, 100f, 0f, new int[]{0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, cl);
        gBig = gear(r * 0.17f, 24);
        gSmall = gear(r * 0.075f, 12);
        gEsc = gear(r * 0.11f, 15);
        gBarrel = gear(r * 0.27f, 30);
        gB = gear(r * 0.15f, 17);
        gC = gear(r * 0.11f, 13);
        spring = new Path();
        for (float t = 0f; t < TAU * 6f; t += 0.25f) {
            float rr = r * (0.012f + 0.085f * t / (TAU * 6f));
            if (t == 0f) spring.moveTo(rr, 0f);
            else spring.lineTo((float) Math.cos(t) * rr, (float) Math.sin(t) * rr);
        }
        egg.rewind();                                                          // an egg: a little narrower at the top
        for (int i = 0; i <= 72; i++) {
            float t = i * TAU / 72f, ex = 0.98f * r * (float) Math.sin(t) * (1f - 0.16f * (float) Math.cos(t)), ey = -1.30f * r * (float) Math.cos(t);
            if (i == 0) egg.moveTo(ex, ey);
            else egg.lineTo(ex, ey);
        }
        egg.close();
        phase[0] = mesh(0f, 24, 12, 150f);                                     // meshing teeth: the small gears of the heritage clock
        phase[1] = mesh(0f, 24, 12, -30f);
        phase[2] = mesh(0f, 30, 17, 12f);                                      // tourbillon train: barrel, third wheel, fourth wheel
        phase[3] = mesh(phase[2], 17, 13, 60f);
        for (int i = 0; i < 48; i++) flick[i] = hash(i * 7 + 3);
        for (int i = 0; i < 200; i++) {                                        // star dust for the celestial dial
            float ang = hash(i * 3 + 1) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 2)) * r * 0.86f;
            star[2 * i] = (float) Math.cos(ang) * rad;
            star[2 * i + 1] = (float) Math.sin(ang) * rad;
        }
    }

    /** Phase for a gear that meshes with another: tA, tB are tooth counts and theta the direction from A to B. */
    private static float mesh(float a0, int tA, int tB, float theta) {
        return theta + 180f - 180f / tB + ((float) tA / tB) * (theta - a0);
    }

    private Path gear(float rr, int teeth) {
        Path p = new Path();
        float pitch = TAU * rr / teeth, ro = rr + pitch * 0.34f, rd = rr - pitch * 0.40f;
        double da = TAU / teeth;
        boolean first = true;
        for (int i = 0; i < teeth; i++) {
            double ang = i * da;
            double[] aa = {ang - da * 0.28, ang - da * 0.15, ang + da * 0.15, ang + da * 0.28};
            float[] rs = {rd, ro, ro, rd};
            for (int k = 0; k < 4; k++) {
                float x = (float) Math.cos(aa[k]) * rs[k], y = (float) Math.sin(aa[k]) * rs[k];
                if (first) {
                    p.moveTo(x, y);
                    first = false;
                } else {
                    p.lineTo(x, y);
                }
            }
        }
        p.close();
        return p;
    }

    // ---------- helpers ----------

    private static float hash(int n) {
        n = (n << 13) ^ n;
        return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483647f;
    }

    private static float smooth(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        return x * x * (3f - 2f * x);
    }

    private static float seg(float b, float from, float to) {
        return smooth((b - from) / (to - from));
    }

    private static float clamp01(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float outBack(float x) {
        x = clamp01(x);
        float v = x - 1f;
        return 1f + 2.7f * v * v * v + 1.7f * v * v;
    }

    private static float sn(double td, double period, double ph) {
        return (float) Math.sin(td * TAU / period + ph);
    }

    private static int al(int color, float f) {
        int v = (int) ((color >>> 24) * clamp01(f));
        return (color & 0x00FFFFFF) | (v << 24);
    }

    private static float px(float rr, float deg) {
        return (float) Math.sin(Math.toRadians(deg)) * rr;
    }

    private static float py(float rr, float deg) {
        return -(float) Math.cos(Math.toRadians(deg)) * rr;
    }

    private void stroke(Canvas c, float wid, int color, float alpha) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, wid));
        pt.setColor(al(color, alpha));
    }

    private void line(Canvas c, float x0, float y0, float x1, float y1, float wid, int color, float alpha) {
        stroke(c, wid, color, alpha);
        c.drawLine(x0, y0, x1, y1, pt);
    }

    private void dot(Canvas c, float x, float y, float rad, int color, float alpha) {
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(color, alpha));
        c.drawCircle(x, y, rad, pt);
    }

    private void ring(Canvas c, float x, float y, float rad, float wid, int color, float alpha) {
        stroke(c, wid, color, alpha);
        c.drawCircle(x, y, rad, pt);
    }

    private void star4(Canvas c, float x, float y, float s, int color, float alpha) {
        line(c, x - s, y, x + s, y, s * 0.14f, color, alpha);
        line(c, x, y - s, x, y + s, s * 0.14f, color, alpha);
        dot(c, x, y, s * 0.16f, 0xFFFFFFFF, alpha);
    }

    private void shaderRing(Canvas c, Shader s, float rad, float wid) {
        pt.setShader(s);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(wid);
        pt.setColor(0xFFFFFFFF);
        c.drawCircle(0f, 0f, rad, pt);
        pt.setShader(null);
    }

    private void text(Canvas c, String s, float x, float y, float size, Typeface face, float scaleX, int color, float alpha) {
        pt.setStyle(Paint.Style.FILL);
        pt.setTypeface(face);
        pt.setTextAlign(Paint.Align.CENTER);
        pt.setTextSize(size);
        pt.setTextScaleX(scaleX);
        pt.setColor(al(color, alpha));
        c.drawText(s, x, y + size * 0.35f, pt);
        pt.setTextScaleX(1f);
        pt.setTypeface(Typeface.DEFAULT);
    }

    /** Numerals with a little depth: a shadow, a dark edge, the gold face and a highlight. */
    private void numeral(Canvas c, String s, float x, float y, float size, Typeface face, float scaleX, float alpha) {
        text(c, s, x + size * 0.07f, y + size * 0.09f, size, face, scaleX, 0xAA000000, alpha);
        text(c, s, x + size * 0.035f, y + size * 0.045f, size, face, scaleX, GOLD_D, alpha);
        text(c, s, x, y, size, face, scaleX, GOLD, alpha);
        text(c, s, x - size * 0.02f, y - size * 0.02f, size, face, scaleX, 0x88FFF2C8, alpha * 0.8f);
    }

    private void gearAt(Canvas c, Path g, float x, float y, float ang, int fill, int edge, float alpha) {
        c.save();
        c.translate(x, y);
        c.rotate(ang);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(fill, alpha));
        c.drawPath(g, pt);
        stroke(c, r * 0.006f, edge, alpha);
        c.drawPath(g, pt);
        c.restore();
    }

    /** A leaf-shaped hand pointing up, drawn in a rotated frame at the origin. */
    private void leaf(Path p, float len, float wid, float tail) {
        p.rewind();
        p.moveTo(0f, -len);
        p.quadTo(wid * 0.9f, -len * 0.78f, wid, -len * 0.55f);
        p.quadTo(wid * 0.95f, -len * 0.40f, wid * 0.28f, -len * 0.30f);
        p.lineTo(wid * 0.30f, tail * 0.2f);
        p.lineTo(-wid * 0.30f, tail * 0.2f);
        p.lineTo(-wid * 0.28f, -len * 0.30f);
        p.quadTo(-wid * 0.95f, -len * 0.40f, -wid, -len * 0.55f);
        p.quadTo(-wid * 0.9f, -len * 0.78f, 0f, -len);
        p.close();
    }

    private void solidHand(Canvas c, float deg, float len, float wid, float tail, float alpha) {
        c.save();
        c.rotate(deg);
        leaf(path, len, wid, r * tail);
        c.save();
        c.translate(r * 0.012f, r * 0.016f);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0x66000000, alpha));
        c.drawPath(path, pt);
        c.restore();
        pt.setColor(al(GOLD, alpha));
        c.drawPath(path, pt);
        stroke(c, r * 0.006f, GOLD_D, alpha);
        c.drawPath(path, pt);
        line(c, -wid * 0.18f, -len * 0.92f, -wid * 0.22f, -len * 0.34f, r * 0.006f, 0xFFFFF2C8, 0.7f * alpha);
        line(c, 0f, 0f, 0f, r * tail, r * 0.012f, GOLD, alpha);
        ring(c, 0f, r * tail, r * 0.04f, r * 0.012f, GOLD, alpha);
        dot(c, 0f, r * tail, r * 0.014f, GOLD_D, alpha);
        c.restore();
    }

    private void skeletonHand(Canvas c, float deg, float len, float wid, int color, float alpha) {
        c.save();
        c.rotate(deg);
        leaf(path, len, wid, r * 0.06f);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0x33000000, alpha));
        c.drawPath(path, pt);
        stroke(c, r * 0.009f, color, alpha);
        c.drawPath(path, pt);
        line(c, 0f, -len * 0.50f, 0f, -len * 0.84f, r * 0.012f, 0xFFB8FFD8, 0.9f * alpha);
        line(c, 0f, 0f, 0f, r * 0.10f, r * 0.012f, color, alpha);
        c.restore();
    }

    private void thinHand(Canvas c, float deg, float len, float tail, int color, float alpha) {
        c.save();
        c.rotate(deg);
        line(c, 0f, r * tail, 0f, -len, r * 0.008f, color, alpha);
        ring(c, 0f, r * tail, r * 0.026f, r * 0.007f, color, alpha);
        dot(c, 0f, -len, r * 0.012f, color, alpha);
        c.restore();
    }

    // ---------- the overlay: a faint tint, a vignette and a few motes ----------

    void env(Canvas c, long now) {
        double td = now / 1000.0;
        for (int i = 0; i < N; i++) {
            if (a[i] < 0.004f) continue;
            float e = smooth(a[i]);
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(al(TINT[i], TINT_A[i] * e));
            c.drawRect(0f, 0f, w, h, gp);
            gp.setShader(vignette);
            gp.setAlpha((int) (255 * 0.5f * e));
            c.save();
            c.translate(w / 2f, h / 2f);
            c.drawCircle(0f, 0f, Math.max(w, h), gp);
            c.restore();
            gp.setShader(null);
            gp.setAlpha(255);
            if (i == 3 || i == 4) {                                              // a few twinkles or gold motes, nothing more
                int n = i == 3 ? 28 : 16;
                for (int k = 0; k < n; k++) {
                    buf[2 * k] = hash(k * 5 + 1) * w;
                    buf[2 * k + 1] = i == 3 ? hash(k * 5 + 2) * h * 0.5f
                            : h - (float) (((td * (12 + 18 * hash(k * 5 + 3))) + hash(k * 5 + 4) * h) % (h + 40f)) * u + 20f;
                }
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth((i == 3 ? 3f : 4f) * u);
                pt.setColor(al(i == 3 ? 0xFFDCE6FF : GOLD_L, e * (i == 3 ? 0.45f + 0.35f * sn(td, 3, 0) : 0.55f)));
                c.drawPoints(buf, 0, 2 * n, pt);
            }
        }
    }

    // ---------- cache ----------

    void prepare(int th) {
        int i = th - FIRST;
        if (cache[i] != null || r <= 0f) return;
        float[] e = EXT[i];
        int bw = (int) Math.ceil((e[0] + e[1]) * r) + 4, bh = (int) Math.ceil((e[2] + e[3]) * r) + 4;
        cache[i] = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas k = new Canvas(cache[i]);
        k.translate(e[0] * r + 2f, e[2] * r + 2f);
        art(th, k, 1f);
    }

    private void drawCache(Canvas c, int th, float alpha) {
        prepare(th);
        float[] e = EXT[th - FIRST];
        bp.setAlpha((int) (255 * clamp01(alpha)));
        c.drawBitmap(cache[th - FIRST], -e[0] * r - 2f, -e[2] * r - 2f, bp);
        bp.setAlpha(255);
    }

    // ---------- drawing one clock ----------

    /**
     * b is how much of the clock has built (0..1), x how far it has left (0..1), tapT seconds since the last tap
     * (negative when none). Everything is drawn in a frame centred on the clock.
     */
    void draw(int th, Canvas c, float hDeg, float mDeg, float sDeg, float sa, float b, float x, float tapT, long now) {
        double td = now / 1000.0;
        float alpha = 1f - seg(x, 0.40f, 1f);
        if (alpha < 0.01f) return;
        int sc = -1;
        if (alpha < 0.99f) sc = c.saveLayerAlpha(cx - r * 2.7f, cy - r * 2.2f, cx + r * 2.7f, cy + r * 3.6f, (int) (255 * alpha));
        c.save();
        c.translate(cx, cy);
        float handK = seg(b, 0.78f, 1f);
        if (th == 5) heritage(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, handK);
        else if (th == 6) pendulum(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, handK);
        else if (th == 7) tourbillon(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, handK);
        else if (th == 8) celestial(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, handK);
        else imperial(c, hDeg, mDeg, sDeg, sa, b, x, tapT, td, handK);
        c.restore();
        if (sc >= 0) c.restoreToCount(sc);
    }

    private void art(int th, Canvas c, float b) {
        pt.setShader(null);
        if (th == 5) heritageArt(c, b);
        else if (th == 6) pendulumArt(c);
        else if (th == 7) tourbillonArt(c);
        else if (th == 8) celestialArt(c);
        else imperialArt(c);
    }

    // =====================================================================================================
    // 5  Heritage Pocket
    // =====================================================================================================

    private void heritageArt(Canvas c, float b) {
        shaderRing(c, bronze, r * 0.95f, r * 0.10f);                          // the double bronze case
        ring(c, 0f, 0f, r * 0.995f, r * 0.006f, 0xFFFFE0B0, 0.45f);
        ring(c, 0f, 0f, r * 0.89f, r * 0.014f, 0xFF2A1A0E, 1f);
        ring(c, 0f, 0f, r * 0.875f, r * 0.010f, 0xFFE8C080, 0.8f);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(heritDial);
        c.drawCircle(0f, 0f, r * 0.865f, pt);
        pt.setShader(null);
        for (int i = 0; i < 150; i++) {                                        // the grain of the dial
            float ang = hash(i * 3 + 1) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 2)) * r * 0.85f;
            dot(c, (float) Math.cos(ang) * rad, (float) Math.sin(ang) * rad, r * 0.004f, i % 2 == 0 ? 0xFFFFFFFF : 0xFF000000, 0.10f);
        }
        for (int i = 1; i <= 12; i++) numeral(c, Integer.toString(i), px(r * 0.765f, i * 30f), py(r * 0.765f, i * 30f), r * 0.215f, condensed, 0.72f, 1f);
        ring(c, 0f, 0f, r * 0.50f, r * 0.018f, GOLD, 1f);                       // the inner ring and its spokes
        ring(c, 0f, 0f, r * 0.475f, r * 0.004f, 0xFF0C0B0E, 0.8f);
        int n = 0;
        for (int i = 0; i < 60; i++) {
            float in = i % 5 == 0 ? 0.20f : 0.235f;
            buf[n++] = px(r * in, i * 6f);
            buf[n++] = py(r * in, i * 6f);
            buf[n++] = px(r * 0.47f, i * 6f);
            buf[n++] = py(r * 0.47f, i * 6f);
        }
        stroke(c, r * 0.0035f, GOLD, 0.6f);
        c.drawLines(buf, 0, n, pt);
        dot(c, 0f, 0f, r * 0.21f, 0xFF1A191D, 1f);
        stroke(c, r * 0.02f, 0xFFFFFFFF, 0.08f);                                // reflections on the glass dome
        rc.set(-r * 0.80f, -r * 0.80f, r * 0.80f, r * 0.80f);
        c.drawArc(rc, 195f, 90f, false, pt);
        stroke(c, r * 0.05f, 0xFFFFFFFF, 0.05f);
        rc.set(-r * 0.70f, -r * 0.70f, r * 0.70f, r * 0.70f);
        c.drawArc(rc, 200f, 70f, false, pt);
    }

    private void heritage(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float drop = b >= 0.5f ? 0f : (float) (Math.exp(-6.0 * b / 0.5) * Math.cos(8.0 * b / 0.5));
        float lift = x * x * 2.3f * r;
        c.save();
        c.translate(0f, -1.7f * r * drop - lift);
        c.rotate(px(1f, x * 14f) * 3f, 0f, -r * 1.0f);
        float intro = seg(b, 0f, 0.12f);
        if (intro < 0.99f) c.saveLayerAlpha(-r * 1.3f, -r * 1.8f, r * 1.3f, r * 1.3f, (int) (255 * intro));
        drawCache(c, 5, 1f);

        float swing = (tap >= 0f ? 9f * (float) (Math.exp(-1.4 * tap) * Math.sin(7.0 * tap)) : 0f)
                + (b < 0.7f ? 6f * (float) (Math.exp(-2.0 * b) * Math.sin(9.0 * b)) : 0f) + 0.6f * sn(td, 6, 0);
        c.save();                                                              // the crown and the hanging loop swing as one
        c.rotate(swing, 0f, -r * 1.0f);
        path.rewind();
        path.moveTo(-r * 0.075f, -r * 1.0f);
        path.lineTo(r * 0.075f, -r * 1.0f);
        path.lineTo(r * 0.045f, -r * 1.10f);
        path.lineTo(-r * 0.045f, -r * 1.10f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(0xFFB86F3A);
        c.drawPath(path, pt);
        line(c, -r * 0.03f, -r * 1.01f, -r * 0.02f, -r * 1.09f, r * 0.012f, 0xFFFFC890, 0.8f);
        ring(c, 0f, -r * 1.37f, r * 0.27f, r * 0.045f, 0xFF9A5A2C, 1f);
        rc.set(-r * 0.27f, -r * 1.64f, r * 0.27f, -r * 1.10f);
        stroke(c, r * 0.012f, 0xFFFFD7A0, 0.8f);
        c.drawArc(rc, 200f, 70f, false, pt);
        c.restore();

        float spin = (float) (td * 9.0) + (tap >= 0f && tap < 2.2f ? 540f * (1f - (float) Math.pow(1f - tap / 2.2f, 3.0)) : 0f)
                + (1f - seg(b, 0.35f, 0.8f)) * 400f;                          // the gear train: everything turns together
        float ga = seg(b, 0.4f, 0.75f);
        float pos = r * 0.245f;
        for (int s = 0; s < 2; s++) {
            float th = s == 0 ? 150f : -30f;
            gearAt(c, gSmall, (float) Math.cos(Math.toRadians(th)) * pos, (float) Math.sin(Math.toRadians(th)) * pos,
                    phase[s] - spin * 2f, 0xFF3A2A22, 0xFFB98A4A, ga);
        }
        gearAt(c, gBig, 0f, 0f, spin, 0xFF3A2A22, 0xFFC99A58, ga);
        for (int q = 0; q < 4; q++) dot(c, px(r * 0.095f, q * 90f + spin), py(r * 0.095f, q * 90f + spin), r * 0.042f, 0xFF1A191D, ga);
        ring(c, 0f, 0f, r * 0.045f, r * 0.012f, GOLD, ga);

        if (tap >= 0f && tap < 2.4f) {                                         // the chime: rings of gold light leave the centre
            for (int q = 0; q < 3; q++) {
                float t = clamp01((tap - q * 0.25f) / 1.5f);
                if (t > 0f && t < 1f) ring(c, 0f, 0f, r * (0.15f + 0.75f * smooth(t)), r * 0.02f * (1f - t) + 1f, GOLD_L, 0.8f * (1f - t));
            }
        }
        float sw = tap >= 0f && tap < 1.4f ? tap / 1.4f : (float) ((td % 9.0) / 1.3);       // a sheen sweeps across the glass
        if (sw >= 0f && sw < 1f) {
            c.save();
            c.clipPath(disc);
            mx.setScale(r * 0.0045f, 1f);
            mx.postRotate(24f);
            mx.postTranslate(-r * 1.1f + r * 2.2f * smooth(sw), 0f);
            sheen.setLocalMatrix(mx);
            gp.setShader(sheen);
            gp.setStyle(Paint.Style.FILL);
            c.drawRect(-r * 1.2f, -r * 1.2f, r * 1.2f, r * 1.2f, gp);
            gp.setShader(null);
            c.restore();
        }
        if (k > 0.01f) {
            float spinIn = (1f - k) * -360f;
            solidHand(c, hD + spinIn, r * 0.46f * k, r * 0.052f, 0.13f, k);
            solidHand(c, mD + spinIn, r * 0.78f * k, r * 0.040f, 0.16f, k);
            if (sa > 0.02f) thinHand(c, sD, r * 0.86f * k, 0.15f, GOLD_L, sa * k);
            dot(c, 0f, 0f, r * 0.022f, GOLD_D, k);
            dot(c, 0f, 0f, r * 0.012f, GOLD_L, k);
        }
        if (intro < 0.99f) c.restore();
        c.restore();
    }

    // =====================================================================================================
    // 6  Grand Pendulum
    // =====================================================================================================

    private void pendulumArt(Canvas c) {
        rc.set(-r * 1.22f, -r * 1.28f, r * 1.22f, r * 3.0f);                   // the walnut case
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(walnut);
        c.drawRoundRect(rc, r * 0.32f, r * 0.32f, pt);
        pt.setShader(null);
        for (int i = 0; i < 40; i++) {                                         // grain
            float gx = (hash(i * 3 + 1) * 2f - 1f) * r * 1.15f, gy = -r * 1.1f + hash(i * 3 + 2) * r * 4.0f;
            line(c, gx, gy, gx + (hash(i) - 0.5f) * r * 0.05f, gy + r * (0.2f + hash(i * 3 + 3) * 0.6f), r * 0.006f, 0xFF000000, 0.12f);
        }
        stroke(c, r * 0.014f, GOLD, 0.85f);
        rc.set(-r * 1.16f, -r * 1.22f, r * 1.16f, r * 2.94f);
        c.drawRoundRect(rc, r * 0.28f, r * 0.28f, pt);
        dot(c, 0f, -r * 1.36f, r * 0.05f, GOLD, 1f);                           // finial
        path.rewind();
        path.moveTo(0f, -r * 1.46f);
        path.lineTo(r * 0.06f, -r * 1.36f);
        path.lineTo(0f, -r * 1.26f);
        path.lineTo(-r * 0.06f, -r * 1.36f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(GOLD_L);
        c.drawPath(path, pt);
        shaderRing(c, goldS, r * 0.96f, r * 0.09f);                             // the dial: a gold bezel, a navy face
        ring(c, 0f, 0f, r * 0.90f, r * 0.012f, 0xFF2A1A0E, 1f);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(navyDial);
        c.drawCircle(0f, 0f, r * 0.895f, pt);
        pt.setShader(null);
        int n = 0;
        for (int i = 0; i < 60; i++) {
            float in = i % 5 == 0 ? 0.80f : 0.84f;
            buf[n++] = px(r * in, i * 6f);
            buf[n++] = py(r * in, i * 6f);
            buf[n++] = px(r * 0.865f, i * 6f);
            buf[n++] = py(r * 0.865f, i * 6f);
        }
        stroke(c, r * 0.006f, IVORY, 0.85f);
        c.drawLines(buf, 0, n, pt);
        String[] rom = {"XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI"};
        for (int i = 0; i < 12; i++) numeral(c, rom[i], px(r * 0.67f, i * 30f), py(r * 0.67f, i * 30f), r * 0.14f, serif, 1f, 1f);
        rc.set(-r * 0.80f, r * 1.22f, r * 0.80f, r * 2.80f);                    // the pendulum window
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(velvet);
        c.drawRoundRect(rc, r * 0.12f, r * 0.12f, pt);
        pt.setShader(null);
        stroke(c, r * 0.018f, GOLD, 1f);
        c.drawRoundRect(rc, r * 0.12f, r * 0.12f, pt);
        stroke(c, r * 0.006f, GOLD_L, 0.7f);
        rc.set(-r * 0.76f, r * 1.26f, r * 0.76f, r * 2.76f);
        c.drawRoundRect(rc, r * 0.10f, r * 0.10f, pt);
        for (int sd = -1; sd <= 1; sd += 2) {                                   // two brass weights on chains
            float wx = sd * r * 0.55f;
            stroke(c, r * 0.008f, GOLD, 0.9f);
            for (float yy = r * 1.28f; yy < r * 1.90f; yy += r * 0.045f) c.drawPoint(wx, yy, pt);
            rc.set(wx - r * 0.11f, r * 1.95f, wx + r * 0.11f, r * 2.45f);
            pt.setStyle(Paint.Style.FILL);
            pt.setShader(null);
            pt.setColor(GOLD);
            c.drawRoundRect(rc, r * 0.05f, r * 0.05f, pt);
            line(c, wx - r * 0.06f, r * 1.99f, wx - r * 0.06f, r * 2.40f, r * 0.02f, 0xFFFFF2C8, 0.6f);
            line(c, wx + r * 0.07f, r * 1.99f, wx + r * 0.07f, r * 2.40f, r * 0.02f, GOLD_D, 0.7f);
        }
        path.rewind();                                                          // a reflection across the glass
        path.moveTo(-r * 0.70f, r * 1.30f);
        path.lineTo(-r * 0.30f, r * 1.30f);
        path.lineTo(r * 0.30f, r * 2.70f);
        path.lineTo(-r * 0.10f, r * 2.70f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(0x10FFFFFF);
        c.drawPath(path, pt);
        rc.set(-r * 0.34f, r * 2.84f, r * 0.34f, r * 2.94f);
        pt.setColor(GOLD_D);
        c.drawRoundRect(rc, r * 0.03f, r * 0.03f, pt);
    }

    private void pendulum(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float reveal = seg(b, 0f, 0.34f), open = seg(b, 0.18f, 0.58f) * (1f - seg(x, 0.25f, 0.85f)), amp = seg(b, 0.45f, 0.95f) * (1f - seg(x, 0f, 0.35f));
        c.save();
        c.translate(0f, r * 0.5f * x);
        c.clipRect(-r * 1.4f, -r * 1.6f, r * 1.4f, -r * 1.6f + r * 4.8f * reveal);
        drawCache(c, 6, 1f);
        float boost = tap >= 0f ? 16f * (float) Math.exp(-tap / 2.2) : 0f;
        float period = 2.0f, t = (float) (td % 60.0);
        float theta = (7.5f * amp + boost) * (float) Math.sin(TAU * t / period);
        float a2 = amp * 12f * (float) Math.sin(TAU * t / period + 1.57f);
        float steps = (float) Math.floor(t) + smooth((t - (float) Math.floor(t)) * 4f);    // the escape wheel steps once a second
        gearAt(c, gEsc, 0f, r * 0.50f, steps * 24f, 0xFF8A5E1E, GOLD_L, 1f);
        c.save();                                                               // the anchor rocks with the pendulum
        c.translate(0f, r * 0.38f);
        c.rotate(-a2);
        path.rewind();
        path.moveTo(-r * 0.15f, r * 0.20f);
        path.quadTo(-r * 0.17f, 0f, 0f, -r * 0.03f);
        path.quadTo(r * 0.17f, 0f, r * 0.15f, r * 0.20f);
        stroke(c, r * 0.022f, GOLD, 1f);
        c.drawPath(path, pt);
        c.restore();
        float pivotY = r * 1.30f, len = r * 1.30f;
        if (tap >= 0f && tap < 3f) {                                            // ghost trails while it is kicked
            for (int g = 3; g >= 1; g--) {
                float tg = t - g * 0.06f, th2 = (7.5f * amp + boost) * (float) Math.sin(TAU * tg / period);
                dot(c, -(float) Math.sin(Math.toRadians(th2)) * len, pivotY + (float) Math.cos(Math.toRadians(th2)) * len, r * 0.22f, GOLD, 0.16f / g);
            }
        }
        c.save();
        c.translate(0f, pivotY);
        c.rotate(theta);
        line(c, 0f, 0f, 0f, len, r * 0.022f, GOLD_D, 1f);
        line(c, -r * 0.005f, 0f, -r * 0.005f, len, r * 0.008f, GOLD_L, 0.8f);
        c.translate(0f, len);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(bobG);
        c.drawCircle(0f, 0f, r * 0.22f, pt);
        pt.setShader(null);
        ring(c, 0f, 0f, r * 0.17f, r * 0.014f, GOLD_D, 0.8f);
        dot(c, -r * 0.07f, -r * 0.07f, r * 0.05f, 0xFFFFFFFF, 0.35f);
        if (tap >= 0f && tap < 2.2f) ring(c, 0f, 0f, r * (0.22f + 0.5f * clamp01(tap / 2.2f)), r * 0.02f, GOLD_L, 0.7f * (1f - tap / 2.2f));
        c.restore();
        if (k > 0.01f) {
            float spinIn = (1f - k) * -180f;
            breguet(c, hD + spinIn, r * 0.46f * k, r * 0.07f, k);
            breguet(c, mD + spinIn, r * 0.76f * k, r * 0.05f, k);
            if (sa > 0.02f) thinHand(c, sD, r * 0.80f * k, 0.14f, 0xFFE8EEFF, sa * k);
            dot(c, 0f, 0f, r * 0.03f, GOLD, k);
            dot(c, 0f, 0f, r * 0.014f, GOLD_D, k);
        }
        if (open < 0.999f) {                                                   // the cabinet doors, swinging open and shut
            float lw = r * 1.22f * (1f - open);
            for (int sd = -1; sd <= 1; sd += 2) {
                float x0 = sd < 0 ? -r * 1.22f : r * 1.22f - lw, x1 = sd < 0 ? -r * 1.22f + lw : r * 1.22f;
                rc.set(x0, -r * 1.28f, x1, r * 3.0f);
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(0xFF3A1E0E);
                c.drawRoundRect(rc, r * 0.1f, r * 0.1f, pt);
                stroke(c, r * 0.014f, GOLD, 0.9f);
                rc.set(x0 + r * 0.05f, -r * 1.22f, x1 - r * 0.05f, r * 2.94f);
                c.drawRoundRect(rc, r * 0.08f, r * 0.08f, pt);
                dot(c, sd < 0 ? x1 - r * 0.1f : x0 + r * 0.1f, r * 0.9f, r * 0.04f * (1f - open), GOLD_L, 1f);
            }
        }
        c.restore();
    }

    /** A Breguet hand: a slim shaft with a hollow moon near the tip. */
    private void breguet(Canvas c, float deg, float len, float moon, float alpha) {
        c.save();
        c.rotate(deg);
        line(c, r * 0.012f, r * 0.014f, r * 0.012f, -len, r * 0.016f, 0xFF000000, 0.35f * alpha);
        line(c, 0f, r * 0.10f, 0f, -len * 0.90f, r * 0.020f, GOLD, alpha);
        ring(c, 0f, -len * 0.74f, moon * 0.7f, r * 0.012f, GOLD, alpha);
        path.rewind();
        path.moveTo(0f, -len);
        path.lineTo(r * 0.018f, -len * 0.90f);
        path.lineTo(-r * 0.018f, -len * 0.90f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(GOLD_L, alpha));
        c.drawPath(path, pt);
        c.restore();
    }

    // =====================================================================================================
    // 7  Tourbillon
    // =====================================================================================================

    private void tourbillonArt(Canvas c) {
        shaderRing(c, roseS, r * 0.95f, r * 0.10f);
        ring(c, 0f, 0f, r * 0.995f, r * 0.006f, 0xFFFFE0D0, 0.5f);
        ring(c, 0f, 0f, r * 0.885f, r * 0.012f, 0xFF3A2018, 1f);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(0x8A0C1018);
        c.drawCircle(0f, 0f, r * 0.88f, pt);
        for (int i = 0; i < 60; i++) {
            float in = i % 5 == 0 ? 0.80f : 0.84f;
            line(c, px(r * in, i * 6f), py(r * in, i * 6f), px(r * 0.865f, i * 6f), py(r * 0.865f, i * 6f), r * 0.004f, 0xFFF0C8B4, 0.7f);
        }
        for (int i = 0; i < 12; i++) {                                         // applied batons with a lume dot
            float deg = i * 30f;
            line(c, px(r * 0.66f, deg), py(r * 0.66f, deg), px(r * 0.77f, deg), py(r * 0.77f, deg), r * (i % 3 == 0 ? 0.035f : 0.022f), 0xFFF0B8A0, 1f);
            dot(c, px(r * 0.715f, deg), py(r * 0.715f, deg), r * 0.009f, 0xFFB8FFD8, 1f);
        }
    }

    /** How present a part is: it assembles from outside on the way in and scatters on the way out. */
    private float part(int k, float b, float x) {
        return seg(b, 0.05f + 0.07f * k, 0.50f + 0.07f * k) * (1f - seg(x, 0.02f * k, 0.70f + 0.02f * k));
    }

    private void bridge(Canvas c, int k, float rad, float from, float sweep, float p, double td, float sparkle) {
        float mid = from + sweep / 2f, off = (1f - p) * r * 0.9f;
        c.save();
        c.translate(px(off, mid), py(off, mid));
        rc.set(-rad, -rad, rad, rad);
        stroke(c, r * 0.14f, 0xFF4A2A20, p);
        c.drawArc(rc, from - 90f, sweep, false, pt);
        stroke(c, r * 0.12f, 0xFFB87868, p);
        c.drawArc(rc, from - 90f, sweep, false, pt);
        stroke(c, r * 0.028f, 0xFFFFD6C0, 0.8f * p);
        rc.set(-rad - r * 0.03f, -rad - r * 0.03f, rad + r * 0.03f, rad + r * 0.03f);
        c.drawArc(rc, from - 90f, sweep, false, pt);
        for (int e = 0; e < 2; e++) {                                           // a screw at each end, glinting now and then
            float deg = from + e * sweep;
            float sx = px(rad, deg), sy = py(rad, deg);
            dot(c, sx, sy, r * 0.032f, 0xFF3A2018, p);
            dot(c, sx, sy, r * 0.024f, 0xFFD0D8E0, p);
            line(c, sx - r * 0.018f, sy - r * 0.01f, sx + r * 0.018f, sy + r * 0.01f, r * 0.006f, 0xFF3A2018, p);
            float gl = Math.max(sparkle, Math.max(0f, sn(td, 7.0, k * 2.0 + e * 1.1) - 0.93f) * 14f);
            if (gl > 0.05f) star4(c, sx, sy, r * 0.06f * Math.min(1f, gl), 0xFFFFFFFF, Math.min(1f, gl));
        }
        c.restore();
    }

    private void tourbillon(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float plate = seg(b, 0f, 0.40f) * (1f - seg(x, 0.3f, 0.9f));
        drawCache(c, 7, plate);
        float spark = tap >= 0f && tap < 2.6f ? (float) Math.sin(Math.PI * clamp01(tap / 2.6f)) : 0f;
        float wind = tap >= 0f && tap < 2.4f ? 1f - (float) Math.pow(1f - tap / 2.4f, 3.0) : (tap >= 0f ? 1f : 0f);
        float base = (float) (td * 3.0) + wind * 720f;

        float p0 = part(0, b, x), p1 = part(1, b, x), p2 = part(2, b, x), p3 = part(3, b, x), p4 = part(4, b, x), p5 = part(5, b, x);
        bridge(c, 0, r * 0.62f, -50f, 110f, p0, td, spark);
        bridge(c, 1, r * 0.56f, 105f, 80f, p1, td, spark);
        bridge(c, 2, r * 0.58f, 215f, 90f, p2, td, spark);

        float ax = -r * 0.34f, ay = -r * 0.14f;                                  // the going train: barrel, third wheel, fourth wheel
        float bxp = ax + r * 0.42f * (float) Math.cos(Math.toRadians(12)), byp = ay + r * 0.42f * (float) Math.sin(Math.toRadians(12));
        float cxp = bxp + r * 0.26f * (float) Math.cos(Math.toRadians(60)), cyp = byp + r * 0.26f * (float) Math.sin(Math.toRadians(60));
        partGear(c, gBarrel, ax, ay, base, 0xFFB87868, p3, 3f);
        partGear(c, gB, bxp, byp, phase[2] - base * 30f / 17f, 0xFFD8A090, p4, 4f);
        partGear(c, gC, cxp, cyp, phase[3] + base * 30f / 13f, 0xFFB87868, p5, 5f);
        c.save();                                                               // the mainspring inside the barrel
        c.translate(ax, ay);
        c.rotate(base);
        stroke(c, r * 0.005f, 0xFFFFD6C0, 0.8f * p3);
        c.scale(2.6f, 2.6f);
        c.drawPath(spring, pt);
        c.restore();

        float tp = part(6, b, x), off = (1f - tp) * r * 0.9f;                    // the tourbillon cage, turning once a minute
        c.save();
        c.translate(0f, r * 0.52f + off);
        float cage = (float) (td * 6.0) + wind * 1080f, bal = (1.5f + 0.4f * spark) * 140f * (float) Math.sin(TAU * 1.6 * td);
        if (spark > 0.02f) {                                                    // the gold light that trails the spinning cage
            for (int g = 1; g <= 6; g++) {
                rc.set(-r * 0.21f, -r * 0.21f, r * 0.21f, r * 0.21f);
                stroke(c, r * 0.02f, GOLD_L, 0.5f * spark * (1f - g / 7f));
                c.drawArc(rc, cage - g * 14f, 10f, false, pt);
            }
        }
        c.rotate(cage);
        ring(c, 0f, 0f, r * 0.20f, r * 0.024f, 0xFFD8A090, tp);
        for (int q = 0; q < 3; q++) line(c, 0f, 0f, px(r * 0.20f, q * 120f), py(r * 0.20f, q * 120f), r * 0.02f, 0xFFD8A090, tp);
        c.save();
        c.rotate(bal - cage);                                                   // the balance wheel keeps its own beat
        ring(c, 0f, 0f, r * 0.115f, r * 0.014f, GOLD_L, tp);
        for (int q = 0; q < 2; q++) line(c, px(r * 0.115f, q * 90f), py(r * 0.115f, q * 90f), -px(r * 0.115f, q * 90f), -py(r * 0.115f, q * 90f), r * 0.01f, GOLD_L, tp);
        stroke(c, r * 0.003f, 0xFFB7C0CC, 0.9f * tp);
        c.drawPath(spring, pt);
        c.restore();
        dot(c, 0f, 0f, r * 0.02f, 0xFFD0384A, tp);
        c.restore();

        for (int j = 0; j < 5; j++) {                                           // rubies at the pivots light up in turn
            float jx = j == 0 ? ax : j == 1 ? bxp : j == 2 ? cxp : j == 3 ? 0f : r * 0.30f, jy = j == 0 ? ay : j == 1 ? byp : j == 2 ? cyp : j == 3 ? r * 0.52f + (1f - tp) * r * 0.9f : -r * 0.42f;
            float lit = seg(b, 0.55f + 0.06f * j, 0.7f + 0.06f * j) * (1f - seg(x, 0f, 0.4f));
            dot(c, jx, jy, r * 0.026f, 0xFFD8A040, lit);
            dot(c, jx, jy, r * 0.017f, 0xFFE0304A, lit);
            dot(c, jx - r * 0.005f, jy - r * 0.005f, r * 0.005f, 0xFFFFFFFF, 0.8f * lit);
        }
        if (k > 0.01f) {
            float spinIn = (1f - k) * -270f;
            skeletonHand(c, hD + spinIn, r * 0.46f * k, r * 0.048f, 0xFFF0B8A0, k);
            skeletonHand(c, mD + spinIn, r * 0.78f * k, r * 0.036f, 0xFFF0B8A0, k);
            if (sa > 0.02f) line(c, 0f, r * 0.10f, px(r * 0.86f * k, sD), py(r * 0.86f * k, sD), r * 0.006f, 0xFFFFFFFF, 0.9f * sa * k);
            if (sa > 0.02f) line(c, 0f, 0f, px(r * 0.10f, sD + 180f), py(r * 0.10f, sD + 180f), r * 0.012f, 0xFFD0384A, sa * k);
            dot(c, 0f, 0f, r * 0.022f, 0xFFF0B8A0, k);
        }
    }

    private void partGear(Canvas c, Path g, float gx, float gy, float ang, int fill, float p, float dir) {
        if (p < 0.01f) return;
        float off = (1f - p) * r * 0.9f, dd = dir * 72f;
        gearAt(c, g, gx + px(off, dd), gy + py(off, dd), ang + (1f - p) * 360f, fill, 0xFFFFE0D0, p);
        dot(c, gx + px(off, dd), gy + py(off, dd), r * 0.018f, 0xFF1A0E0C, p);
    }

    // =====================================================================================================
    // 8  Celestial Orrery
    // =====================================================================================================

    private void celestialArt(Canvas c) {
        shaderRing(c, silverS, r * 0.95f, r * 0.10f);
        ring(c, 0f, 0f, r * 0.995f, r * 0.006f, 0xFFFFFFFF, 0.5f);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(navyDial);
        c.drawCircle(0f, 0f, r * 0.89f, pt);
        pt.setShader(null);
        for (int i = 0; i < 200; i++) {                                        // star dust
            float al = 0.15f + 0.6f * hash(i * 7 + 5);
            dot(c, star[2 * i], star[2 * i + 1], r * (0.004f + 0.004f * hash(i * 7 + 6)), 0xFFDCE6FF, al);
        }
        for (int i = 0; i < 60; i++) {
            float in = i % 5 == 0 ? 0.80f : 0.84f;
            line(c, px(r * in, i * 6f), py(r * in, i * 6f), px(r * 0.865f, i * 6f), py(r * 0.865f, i * 6f), r * 0.004f, 0xFFDCE6FF, 0.7f);
        }
        for (int i = 0; i < 12; i++) star4(c, px(r * 0.745f, i * 30f), py(r * 0.745f, i * 30f), r * (i % 3 == 0 ? 0.05f : 0.032f), 0xFFE8EEFF, 1f);
        ring(c, 0f, 0f, r * 0.64f, r * 0.006f, 0xFFB9C8FF, 0.7f);              // the ring the sun and the moon follow
        ring(c, 0f, 0f, r * 0.60f, r * 0.003f, 0xFFB9C8FF, 0.5f);
        for (int i = 0; i < 12; i++) dot(c, px(r * 0.62f, i * 30f + 15f), py(r * 0.62f, i * 30f + 15f), r * 0.010f, 0xFFE8EEFF, 0.9f);
    }

    /** The moon phase as a path in a frame centred on the moon: lit part only. */
    private void moonPhase(float rad, float phase01) {
        boolean waning = phase01 > 0.5f;
        float p = waning ? 1f - phase01 : phase01, k = (float) Math.cos(p * TAU);
        moon.rewind();
        rc2.set(-rad, -rad, rad, rad);
        moon.arcTo(rc2, -90f, 180f);
        float ex = rad * Math.abs(k);
        rc.set(-Math.max(ex, 0.001f), -rad, Math.max(ex, 0.001f), rad);
        moon.arcTo(rc, 90f, k > 0f ? -180f : 180f);
        moon.close();
        if (waning) {
            mx.setScale(-1f, 1f);
            moon.transform(mx);
        }
    }

    private void celestial(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float e = seg(b, 0.05f, 0.60f), spin = (1f - e) * 540f;
        c.save();
        c.rotate(-(1f - e) * 60f + x * 160f);
        float sc2 = 0.85f + 0.15f * e - 0.5f * x * x;
        c.scale(sc2, sc2);
        tmp.rewind();                                                            // the sky unfolds from the centre
        tmp.addCircle(0f, 0f, r * (0.10f + 1.02f * e), Path.Direction.CW);
        c.save();
        c.clipPath(tmp);
        drawCache(c, 8, 1f);
        c.restore();

        long ms = System.currentTimeMillis();
        java.util.Calendar cal = CAL;
        cal.setTimeInMillis(ms);
        float day = (cal.get(java.util.Calendar.HOUR_OF_DAY) * 60f + cal.get(java.util.Calendar.MINUTE) + cal.get(java.util.Calendar.SECOND) / 60f) / 1440f;
        float tapSpin = tap >= 0f && tap < 3f ? 360f * (1f - (float) Math.pow(1f - tap / 3f, 3.0)) : 0f;
        float rot = day * 360f + spin + tapSpin;                                 // the star map turns once a day (and spins on a tap)
        float co = (float) Math.cos(Math.toRadians(rot)), si = (float) Math.sin(Math.toRadians(rot));
        float sk = r * 0.26f * seg(b, 0.25f, 0.75f);
        int nl = 0, np = 0;
        for (int g = 0; g < 3; g++) {
            float gx = (g == 0 ? -0.18f : g == 1 ? 0.28f : 0.02f) * r * 1.2f, gy = (g == 0 ? -0.02f : g == 1 ? -0.33f : 0.33f) * r;
            for (int i = GROUPS[g][0]; i < GROUPS[g][1]; i++) {
                float qx = gx + CON[2 * i] * sk, qy = gy + CON[2 * i + 1] * sk;
                float rx = qx * co - qy * si, ry = qx * si + qy * co;
                cpts[2 * np] = rx;
                cpts[2 * np + 1] = ry;
                np++;
                if (i > GROUPS[g][0]) {
                    buf[nl++] = cpts[2 * (np - 2)];
                    buf[nl++] = cpts[2 * (np - 2) + 1];
                    buf[nl++] = rx;
                    buf[nl++] = ry;
                }
            }
        }
        stroke(c, r * 0.004f, 0xFFB9C8FF, 0.45f * e);
        c.drawLines(buf, 0, nl, pt);
        stroke(c, r * 0.016f, 0xFFFFFFFF, e * (0.7f + 0.3f * sn(td, 2.5, 0) + (tap >= 0f && tap < 1.5f ? 0.3f : 0f)));
        c.drawPoints(cpts, 0, 2 * np, pt);

        float sunA = (day * 24f - 12f) / 24f * 360f;                             // sun and moon on their ring, noon at the top
        float orb = seg(b, 0.55f, 0.85f);
        dot(c, px(r * 0.64f, sunA), py(r * 0.64f, sunA), r * 0.075f, 0xFFFFC857, 0.25f * orb);
        dot(c, px(r * 0.64f, sunA), py(r * 0.64f, sunA), r * 0.04f, 0xFFFFE9A8, orb);
        float phase01 = (float) (((ms - MOON_EPOCH) % (long) SYNODIC) / SYNODIC);
        float moonA = sunA + 180f;
        dot(c, px(r * 0.64f, moonA), py(r * 0.64f, moonA), r * 0.034f, 0xFFE8EEFF, orb);
        c.save();                                                                // the moon phase window
        c.translate(0f, r * 0.34f);
        float mw = r * 0.15f * seg(b, 0.45f, 0.8f);
        dot(c, 0f, 0f, mw * 1.35f, 0xFF0A0F28, 1f);
        ring(c, 0f, 0f, mw * 1.35f, r * 0.012f, 0xFFB9C8FF, 0.9f);
        dot(c, 0f, 0f, mw, 0xFF1E2848, 1f);
        if (mw > 1f) {
            moonPhase(mw, phase01);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(0xFFF0F2FA);
            c.drawPath(moon, pt);
            if (tap >= 0f && tap < 2.5f) dot(c, 0f, 0f, mw * 1.7f, 0xFFB9C8FF, 0.25f * (float) Math.sin(Math.PI * tap / 2.5f));
        }
        c.restore();
        float ss = tap >= 0f ? tap / 1.1f : (float) ((td % 15.0) / 1.1);       // a shooting star
        if (ss >= 0f && ss < 1f) {
            float sx0 = -r * 0.8f + ss * r * 1.5f, sy0 = -r * 0.7f + ss * r * 0.9f;
            line(c, sx0, sy0, sx0 - r * 0.28f, sy0 - r * 0.17f, r * 0.012f, 0xFFFFFFFF, 1f - ss);
            dot(c, sx0, sy0, r * 0.014f, 0xFFFFFFFF, 1f - ss);
        }
        if (k > 0.01f) {
            float spinIn = (1f - k) * -240f;
            dauphine(c, hD + spinIn, r * 0.46f * k, r * 0.052f, GOLD_L, k);
            dauphine(c, mD + spinIn, r * 0.78f * k, r * 0.040f, 0xFFE8EEFF, k);
            if (sa > 0.02f) {
                thinHand(c, sD, r * 0.84f * k, 0.12f, 0xFFB9C8FF, sa * k);
                star4(c, px(r * 0.84f * k, sD), py(r * 0.84f * k, sD), r * 0.03f, 0xFFFFFFFF, sa * k);
            }
            dot(c, 0f, 0f, r * 0.026f, GOLD, k);
            dot(c, 0f, 0f, r * 0.012f, 0xFFFFFFFF, k);
        }
        c.restore();
    }

    private static final java.util.Calendar CAL = java.util.Calendar.getInstance();

    private void dauphine(Canvas c, float deg, float len, float wid, int color, float alpha) {
        c.save();
        c.rotate(deg);
        path.rewind();
        path.moveTo(0f, -len);
        path.lineTo(wid, -len * 0.30f);
        path.lineTo(0f, r * 0.10f);
        path.lineTo(-wid, -len * 0.30f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0x66000000, alpha));
        c.save();
        c.translate(r * 0.012f, r * 0.016f);
        c.drawPath(path, pt);
        c.restore();
        pt.setColor(al(color, alpha));
        c.drawPath(path, pt);
        path.rewind();
        path.moveTo(0f, -len * 0.92f);
        path.lineTo(0f, r * 0.04f);
        path.lineTo(-wid * 0.9f, -len * 0.30f);
        path.close();
        pt.setColor(al(0x55000000, alpha));
        c.drawPath(path, pt);
        line(c, 0f, -len * 0.55f, 0f, -len * 0.85f, r * 0.012f, 0xFFB8FFD8, 0.8f * alpha);
        c.restore();
    }

    // =====================================================================================================
    // 9  Imperial Egg
    // =====================================================================================================

    private void imperialArt(Canvas c) {
        pt.setStyle(Paint.Style.FILL);                                         // the pedestal
        pt.setShader(goldS);
        c.drawOval(rcSet(-r * 0.58f, r * 1.28f, r * 0.58f, r * 1.50f), pt);
        path.rewind();
        path.moveTo(-r * 0.20f, r * 1.22f);
        path.lineTo(r * 0.20f, r * 1.22f);
        path.lineTo(r * 0.34f, r * 1.40f);
        path.lineTo(-r * 0.34f, r * 1.40f);
        path.close();
        c.drawPath(path, pt);
        pt.setShader(null);
        stroke(c, r * 0.008f, GOLD_D, 1f);
        c.drawOval(rcSet(-r * 0.58f, r * 1.28f, r * 0.58f, r * 1.50f), pt);

        pt.setStyle(Paint.Style.FILL);                                         // the enamel body with guilloche engraving
        pt.setShader(rubyEgg);
        c.drawPath(egg, pt);
        pt.setShader(null);
        c.save();
        c.clipPath(egg);
        int n = 0;
        for (int i = 0; i < 72; i++) {
            buf[n++] = px(r * 0.74f, i * 5f);
            buf[n++] = py(r * 0.74f, i * 5f);
            buf[n++] = px(r * 1.5f, i * 5f);
            buf[n++] = py(r * 1.5f, i * 5f);
        }
        stroke(c, r * 0.003f, GOLD_L, 0.16f);
        c.drawLines(buf, 0, n, pt);
        for (int q = 1; q <= 4; q++) {                                           // echoing outlines
            c.save();
            float kk = 0.78f + 0.055f * q;
            c.scale(kk, kk);
            stroke(c, r * 0.004f / kk, GOLD_L, 0.20f);
            c.drawPath(egg, pt);
            c.restore();
        }
        for (int m = 1; m <= 5; m++) {                                           // gold meridians
            for (int sd = -1; sd <= 1; sd += 2) {
                path.rewind();
                for (int i = 0; i <= 36; i++) {
                    float t = i * 3.14159f / 36f, ex = sd * 0.98f * r * (float) Math.sin(t) * (1f - 0.16f * (float) Math.cos(t)) * m / 6f, ey = -1.30f * r * (float) Math.cos(t);
                    if (i == 0) path.moveTo(ex, ey);
                    else path.lineTo(ex, ey);
                }
                stroke(c, r * 0.004f, GOLD, 0.30f);
                c.drawPath(path, pt);
            }
        }
        c.restore();
        pt.setShader(goldS);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(r * 0.034f);
        c.drawPath(egg, pt);
        pt.setShader(null);
        stroke(c, r * 0.006f, 0xFF3A1008, 0.8f);
        c.save();
        c.scale(0.985f, 0.985f);
        c.drawPath(egg, pt);
        c.restore();

        float seam = -r * 0.98f;                                                // the seam of the lid, with pearls
        path.rewind();
        path.moveTo(-r * 0.567f, seam);
        path.quadTo(0f, seam + r * 0.10f, r * 0.567f, seam);
        stroke(c, r * 0.03f, GOLD, 1f);
        c.drawPath(path, pt);
        for (int i = 0; i < 9; i++) {
            float t = i / 8f, ex = -r * 0.52f + t * r * 1.04f, ey = seam + r * 0.05f * (1f - (2f * t - 1f) * (2f * t - 1f)) * 1.0f + r * 0.0f;
            dot(c, ex, ey + r * 0.022f, r * 0.014f, 0xFFF4EDE2, 1f);
        }
        pt.setStyle(Paint.Style.FILL);                                          // the dial
        ring(c, 0f, 0f, r * 0.745f, r * 0.05f, GOLD, 1f);
        ring(c, 0f, 0f, r * 0.775f, r * 0.006f, GOLD_L, 0.9f);
        pt.setStyle(Paint.Style.FILL);
        pt.setShader(ivoryDial);
        c.drawCircle(0f, 0f, r * 0.72f, pt);
        pt.setShader(null);
        for (int i = 0; i < 60; i++) {
            float in = i % 5 == 0 ? 0.62f : 0.655f;
            line(c, px(r * in, i * 6f), py(r * in, i * 6f), px(r * 0.69f, i * 6f), py(r * 0.69f, i * 6f), r * 0.004f, 0xFF3A2410, 0.8f);
        }
        String[] rom = {"XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI"};
        for (int i = 0; i < 12; i++) text(c, rom[i], px(r * 0.50f, i * 30f), py(r * 0.50f, i * 30f), r * 0.11f, serif, 1f, 0xFF3A2410, 1f);
        for (int i = 0; i < 12; i++) {                                          // twelve gems around the dial
            float deg = i * 30f;
            boolean big = i % 3 == 0;
            dot(c, px(r * 0.86f, deg), py(r * 0.86f, deg), r * (big ? 0.042f : 0.028f), big ? 0xFF1FBF7F : 0xFFF4EDE2, 1f);
            dot(c, px(r * 0.86f, deg) - r * 0.01f, py(r * 0.86f, deg) - r * 0.01f, r * (big ? 0.014f : 0.009f), 0xFFFFFFFF, 0.8f);
        }
    }

    private RectF rcSet(float l, float t, float rr, float bb) {
        rc.set(l, t, rr, bb);
        return rc;
    }

    private void imperial(Canvas c, float hD, float mD, float sD, float sa, float b, float x, float tap, double td, float k) {
        float turn = seg(b, 0.02f, 0.56f), away = x;
        float sx = Math.max(0.03f, (float) Math.sin(turn * Math.PI / 2.0)) * Math.max(0.03f, (float) Math.cos(away * Math.PI / 2.0));
        c.save();
        c.scale(sx, 1f - 0.12f * away);                                          // the egg turns to face you, and away again
        float open = tap >= 0f && tap < 4.2f ? (tap < 0.5f ? smooth(tap / 0.5f) : (tap < 3.5f ? 1f : 1f - smooth((tap - 3.5f) / 0.7f))) : 0f;
        float seam = -r * 0.98f;
        if (open < 0.01f) {
            drawCache(c, 9, 1f);
        } else {
            float[] e = EXT[4];
            int cut = (int) ((e[2] * r + 2f) + seam) + 2;                         // the lid is the top slice of the cached picture
            prepare(9);
            Bitmap bm = cache[4];
            float left = -e[0] * r - 2f, top = -e[2] * r - 2f;
            c.save();
            c.clipRect(left, seam, left + bm.getWidth(), top + bm.getHeight());
            c.drawBitmap(bm, left, top, bp);
            c.restore();
            pt.setStyle(Paint.Style.FILL);                                          // the hollow, lit from inside
            pt.setColor(al(0xFF2A0610, 1f));
            c.drawOval(rcSet(-r * 0.55f, seam - r * 0.07f * open, r * 0.55f, seam + r * 0.09f), pt);
            dot(c, 0f, seam, r * 0.45f * open, GOLD_L, 0.18f * open);
            c.save();
            c.translate(r * 0.5f, seam);                                            // the lid lifts and tilts on its hinge
            c.rotate(-16f * open);
            c.translate(-r * 0.5f, -seam - r * 0.34f * open);
            src.set(0, 0, bm.getWidth(), cut);
            rc.set(left, top, left + bm.getWidth(), top + cut);
            c.drawBitmap(bm, src, rc, bp);
            c.restore();
            bird(c, seam, tap, td);
        }
        float sw = (float) ((td % 8.0) / 1.2);                                    // the guilloche catches the light
        if (sw >= 0f && sw < 1f) {
            c.save();
            c.clipPath(egg);
            mx.setScale(r * 0.004f, 1f);
            mx.postRotate(24f);
            mx.postTranslate(-r * 1.1f + r * 2.2f * smooth(sw), 0f);
            sheen.setLocalMatrix(mx);
            gp.setShader(sheen);
            gp.setStyle(Paint.Style.FILL);
            c.drawRect(-r * 1.2f, -r * 1.5f, r * 1.2f, r * 1.5f, gp);
            gp.setShader(null);
            c.restore();
        }
        for (int i = 0; i < 12; i++) {                                            // a wave of twinkles runs around the gems
            float tw = Math.max(0f, sn(td, 4.0, -i * 0.52)) * seg(b, 0.5f, 0.8f);
            if (tw > 0.6f) star4(c, px(r * 0.86f, i * 30f), py(r * 0.86f, i * 30f), r * 0.07f * tw, 0xFFFFFFFF, tw);
        }
        if (b > 0.5f && b < 0.78f) {                                              // gold dust as the egg arrives
            float q = (b - 0.5f) / 0.28f;
            for (int i = 0; i < 10; i++) star4(c, px(r * (0.4f + 0.9f * q), i * 36f), py(r * (0.4f + 1.1f * q), i * 36f), r * 0.03f * (1f - q), GOLD_L, 1f - q);
        }
        if (k > 0.01f) {
            float spinIn = (1f - k) * -300f;
            pomme(c, hD + spinIn, r * 0.42f * k, k);
            pomme(c, mD + spinIn, r * 0.66f * k, k);
            if (sa > 0.02f) {
                line(c, px(r * 0.10f, sD + 180f), py(r * 0.10f, sD + 180f), px(r * 0.70f * k, sD), py(r * 0.70f * k, sD), r * 0.006f, 0xFFB02030, sa * k);
                dot(c, px(r * 0.10f, sD + 180f), py(r * 0.10f, sD + 180f), r * 0.016f, 0xFFD0384A, sa * k);
            }
            dot(c, 0f, 0f, r * 0.026f, GOLD, k);
            dot(c, 0f, 0f, r * 0.012f, 0xFF3A2410, k);
        }
        c.restore();
    }

    /** A Louis XV style hand: a slim shaft with a ring ("pomme") near the tip. */
    private void pomme(Canvas c, float deg, float len, float alpha) {
        c.save();
        c.rotate(deg);
        line(c, r * 0.010f, r * 0.014f, r * 0.010f, -len, r * 0.018f, 0xFF000000, 0.30f * alpha);
        line(c, 0f, r * 0.10f, 0f, -len * 0.92f, r * 0.020f, 0xFF3A2410, alpha);
        line(c, 0f, r * 0.10f, 0f, -len * 0.92f, r * 0.012f, GOLD, alpha);
        ring(c, 0f, -len * 0.64f, r * 0.040f, r * 0.012f, GOLD, alpha);
        ring(c, 0f, -len * 0.64f, r * 0.040f, r * 0.003f, 0xFF3A2410, alpha);
        path.rewind();
        path.moveTo(0f, -len);
        path.lineTo(r * 0.022f, -len * 0.90f);
        path.lineTo(-r * 0.022f, -len * 0.90f);
        path.close();
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(GOLD, alpha));
        c.drawPath(path, pt);
        c.restore();
    }

    /** The golden songbird that rises out of the egg and sings, with notes floating away. */
    private void bird(Canvas c, float seam, float tap, double td) {
        float rise = outBack(clamp01((tap - 0.35f) / 0.7f)) * (1f - smooth((tap - 3.2f) / 0.5f));
        if (rise < 0.02f) return;
        float bob = 2f * u * (float) Math.sin(td * 9.0), by = seam - r * 0.22f * rise + bob, tilt = 6f * (float) Math.sin(td * 5.0);
        float beak = tap > 0.9f && tap < 3.2f ? Math.max(0f, (float) Math.sin(td * 14.0)) : 0f;
        c.save();
        c.translate(0f, by);
        c.rotate(tilt);
        c.scale(rise, rise);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(GOLD);
        c.drawOval(rcSet(-r * 0.15f, -r * 0.08f, r * 0.13f, r * 0.10f), pt);          // body
        path.rewind();
        path.moveTo(-r * 0.12f, 0f);                                                     // tail
        path.lineTo(-r * 0.30f, -r * 0.07f + r * 0.02f * (float) Math.sin(td * 10.0));
        path.lineTo(-r * 0.30f, r * 0.05f);
        path.close();
        pt.setColor(GOLD_D);
        c.drawPath(path, pt);
        pt.setColor(GOLD_L);
        c.drawCircle(r * 0.12f, -r * 0.09f, r * 0.07f, pt);                              // head
        path.rewind();
        path.moveTo(r * 0.18f, -r * 0.11f - r * 0.025f * beak);
        path.lineTo(r * 0.27f, -r * 0.09f);
        path.lineTo(r * 0.18f, -r * 0.075f + r * 0.02f * beak);
        path.close();
        pt.setColor(0xFFE8602A);
        c.drawPath(path, pt);
        dot(c, r * 0.135f, -r * 0.10f, r * 0.012f, 0xFF1A0A08, 1f);
        stroke(c, r * 0.012f, GOLD_D, 0.9f);
        rc.set(-r * 0.10f, -r * 0.06f, r * 0.06f, r * 0.07f);
        c.drawArc(rc, 200f, 140f, false, pt);                                             // wing
        c.restore();
        for (int i = 0; i < 3; i++) {                                                     // notes drifting up and away
            float t = clamp01((tap - 1.0f - i * 0.7f) / 1.8f);
            if (t <= 0f || t >= 1f || tap > 3.6f) continue;
            float nx = (i - 1) * r * 0.22f + r * 0.08f * (float) Math.sin(t * 6.0 + i), ny = seam - r * (0.35f + 0.5f * t), na = (float) Math.sin(Math.PI * t);
            dot(c, nx, ny, r * 0.022f, GOLD_L, na);
            line(c, nx + r * 0.02f, ny, nx + r * 0.02f, ny - r * 0.09f, r * 0.007f, GOLD_L, na);
            line(c, nx + r * 0.02f, ny - r * 0.09f, nx + r * 0.05f, ny - r * 0.06f, r * 0.007f, GOLD_L, na);
        }
    }
}
