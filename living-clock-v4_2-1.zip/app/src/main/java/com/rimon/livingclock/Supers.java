package com.rimon.livingclock;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;

import java.util.Calendar;

/**
 * Super 5: five luxury mechanisms, reached by triple-tapping the top of the cutout. Double tap steps through
 * them in a loop; triple tap goes back to the ordinary themes. The wallpaper photo is never replaced: each
 * Super only lays a light tint, a vignette and a little ambient motion over it.
 *
 *   5 Brass Pocket Watch     bronze case with bow and crown, raised gold numerals, a spoked gold ring and a
 *                            working gear train that ticks once a second. Tap: wind the crown, the gears
 *                            whirr and the power reserve (battery) sweeps round the rim.
 *   6 Grand Pendulum         a regulator with Roman numerals, a sun medallion, a bell and a real pendulum
 *                            swinging in a glass case below the dial. Tap: it chimes the hour.
 *   7 Tourbillon             an open-worked movement: a tourbillon cage turns once a minute, a balance wheel
 *                            beats, a barrel and a gear train drive it. Tap: a date window opens and rolls.
 *   8 Celestial Observatory  a night dial with the real moon phase, an armillary of turning rings, and a sun
 *                            and moon on the day track. Tap: constellations light up and the phase is read out.
 *   9 Royal Diamond          engine-turned emerald dial, baguette diamonds, a gem-set bezel. Tap: the stones
 *                            flash in a wave and the time is written in words.
 *
 * Every Super builds itself piece by piece and takes itself apart in reverse when it leaves; each has its own
 * backdrop effect for the jump in and out.
 *
 * Cost: the static art of each clock is drawn once into a cached dial; only what moves is drawn per frame, with
 * reused paths and paints and no allocation. Ambient motion runs at about 24 frames a second (12 on a low
 * battery), transitions and taps follow the display.
 */
final class Supers {

    static final int FIRST = 5, N = 5;
    static final long BUILD_MS = 4200, EXIT_MS = 3000;
    static final String[] NAMES = {"Brass Pocket Watch", "Grand Pendulum", "Tourbillon", "Celestial Observatory", "Royal Diamond"};

    private static final int[] LOOK = {5, 6, 2, 1, 8};                      // the band pattern each Super borrows
    private static final int[] TINT = {0xFF2A1608, 0xFF1C0A0C, 0xFF0A1424, 0xFF070A24, 0xFF031610};
    private static final int[] RIM = {0xFFFFB35A, 0xFFFF9A55, 0xFF9CC8FF, 0xFF9AA8FF, 0xFF7CFFD2};
    private static final float[] TINT_A = {0.30f, 0.34f, 0.32f, 0.40f, 0.34f};
    private static final long[] TAP_LEN = {4200L, 0L, 5200L, 5600L, 4600L};   // 0 = decided at the tap (the chime)
    private static final float TAU = 6.2831855f;

    private static final int GOLD_D = 0xFF8A6420, GOLD_M = 0xFFD2A547, GOLD_L = 0xFFF3D585, GOLD_H = 0xFFFFF2C2;
    private static final int BRZ_D = 0xFF2E1B0E, BRZ_M = 0xFF8B5A2B, BRZ_L = 0xFFCB8F52, COPPER = 0xFFB4693A;
    private static final int ROSE_D = 0xFF8A4F46, ROSE_M = 0xFFD99A86, ROSE_L = 0xFFF6CDBA;
    private static final int STEEL = 0xFFB8C4D4, INK = 0xFF0C0D10, RUBY = 0xFFE0314B;
    private static final int EMER_D = 0xFF03231A, EMER_M = 0xFF0B6B4C, EMER_L = 0xFF2FC79A;

    private static final Typeface COND = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private static final Typeface SERIF = Typeface.create("serif", Typeface.NORMAL);
    private static final Typeface SERIF_B = Typeface.create("serif", Typeface.BOLD);
    private static final Typeface SERIF_I = Typeface.create("serif", Typeface.ITALIC);
    private static final Typeface SANS = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private static final String[] NUM = {"12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"};
    private static final String[] ROMAN = {"XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI"};
    private static final String[] DAYS = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
    private static final String[] HOUR_WORD = {"Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven"};

    static boolean is(int th) {
        return th >= FIRST;
    }

    static int look(int th) {
        return LOOK[th - FIRST];
    }

    /** The cached dial is a square bitmap; the pocket watch needs room above for its bow and crown. */
    static int dialSize(int th, float radius) {
        return (int) Math.ceil(radius * (th == FIRST ? 3.3f : 2.2f)) + 4;
    }

    // ---------- state ----------

    private final float[] a = new float[N];
    private final long[] tapAt = {-1L, -1L, -1L, -1L, -1L};
    private long last = -1L, tapLen6 = 0L;
    private int w, h;
    private float cx, cy, r, u;
    private boolean built;
    private int pct = 60, pctShown = -1;
    private String pctLabel = "60%";
    private boolean charging;

    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG), gp = new Paint(Paint.ANTI_ALIAS_FLAG),
            sp = new Paint(Paint.ANTI_ALIAS_FLAG), tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path(), path2 = new Path(), disc = new Path();
    private final RectF rc = new RectF();
    private final Calendar cal = Calendar.getInstance();
    private RadialGradient vignette, glare;
    private final float[] dust = new float[48 * 3], speck = new float[160 * 2], star = new float[120 * 3];
    private final float[] buf = new float[512], pts = new float[128];

    // tap-time facts
    private int tapHour, tapMin, tapDay, tapWd;
    private String words = "", moonName = "", moonLine = "", dayStr = "1", prevStr = "31";
    private long tzStamp = -1L, tzOff;

    Supers() {
        pt.setStrokeCap(Paint.Cap.ROUND);
        pt.setStrokeJoin(Paint.Join.ROUND);
        sp.setStrokeCap(Paint.Cap.ROUND);
        sp.setStrokeJoin(Paint.Join.ROUND);
    }

    /** Each Super's presence moves slowly toward its target. True while any is moving. */
    boolean step(int theme, long now) {
        float dt = last < 0 ? 0f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        boolean moving = false;
        for (int i = 0; i < N; i++) {
            float target = theme == FIRST + i ? 1f : 0f;
            if (a[i] == target) continue;
            float rate = dt / (target > a[i] ? 2.4f : 2.0f);
            a[i] += Math.max(-rate, Math.min(rate, target - a[i]));
            moving |= a[i] != target;
        }
        return moving;
    }

    void snap(int theme) {
        for (int i = 0; i < N; i++) a[i] = theme == FIRST + i ? 1f : 0f;
    }

    boolean active() {
        for (int i = 0; i < N; i++) if (a[i] > 0.003f) return true;
        return false;
    }

    /** The phone's charge, for the power reserve and the jewels. */
    void power(int percent, boolean isCharging) {
        pct = Math.max(0, Math.min(100, percent));
        charging = isCharging;
        if (pct != pctShown) {
            pctShown = pct;
            pctLabel = pct + "%";
        }
    }

    /** A little of the Super's light for the cut-out subject, so it belongs to the scene. */
    int tintColor() {
        int best = 0;
        for (int i = 1; i < N; i++) if (a[i] > a[best]) best = i;
        float e = smooth(a[best]);
        return e < 0.02f ? 0 : (RIM[best] & 0x00FFFFFF) | (((int) (e * 34f)) << 24);
    }

    // ---------- taps ----------

    /** One tap on a Super's clock: its own function and its own animation. */
    void tap(int th, long now) {
        int i = th - FIRST;
        if (i < 0 || i >= N) return;
        cal.setTimeInMillis(now);
        tapHour = cal.get(Calendar.HOUR);
        if (tapHour == 0) tapHour = 12;
        tapMin = cal.get(Calendar.MINUTE);
        tapDay = cal.get(Calendar.DAY_OF_MONTH);
        tapWd = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (i == 1) tapLen6 = 900L + 640L * tapHour + 1400L;
        if (i == 2) {
            dayStr = Integer.toString(tapDay);
            prevStr = Integer.toString(tapDay == 1 ? 31 : tapDay - 1);
        }
        if (i == 3) moonRead(now);
        if (i == 4) wordsOf(tapHour % 12, tapMin);
        tapAt[i] = now;
    }

    /** Seconds since the tap, or -1 when none is playing. */
    private float tk(int th, long now) {
        int i = th - FIRST;
        if (tapAt[i] < 0L) return -1f;
        long len = i == 1 ? tapLen6 : TAP_LEN[i];
        long e = now - tapAt[i];
        if (e < 0L || e > len) return -1f;
        return e / 1000f;
    }

    /** True while a tap animation plays, so frames follow the display. */
    boolean busy(long now) {
        for (int i = 0; i < N; i++) if (tk(FIRST + i, now) >= 0f) return true;
        return false;
    }

    // ---------- helpers ----------

    private static float hash(int n) {
        n = (n << 13) ^ n;
        return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483647f;
    }

    private static float smooth(float x) {
        x = x < 0f ? 0f : (x > 1f ? 1f : x);
        return x * x * (3f - 2f * x);
    }

    private static float seg(float b, float from, float to) {
        return smooth((b - from) / (to - from));
    }

    private static float clamp01(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float outBack(float x) {
        x = clamp01(x);
        float v = x - 1f;
        return 1f + 2.2f * v * v * v + 1.2f * v * v;
    }

    private static float outCubic(float x) {
        x = clamp01(x);
        float v = 1f - x;
        return 1f - v * v * v;
    }

    private static float sn(double td, double period, double phase) {
        return (float) Math.sin(td * TAU / period + phase);
    }

    private static float drift(double td, double speed, float mod) {
        float v = (float) ((td * speed) % mod);
        return v < 0f ? v + mod : v;
    }

    /** A step of a ratchet: n clicks across 0..1. */
    private static float ratchet(float x, int n) {
        x = clamp01(x);
        float v = x * n, i = (float) Math.floor(v);
        return (i + smooth((v - i) * 1.8f)) / n;
    }

    private static int al(int color, float f) {
        int v = (int) ((color >>> 24) * (f < 0f ? 0f : (f > 1f ? 1f : f)));
        return (color & 0x00FFFFFF) | (v << 24);
    }

    private static float hx(float c0, float rr, float deg) {
        return c0 + (float) Math.sin(Math.toRadians(deg)) * rr;
    }

    private static float hy(float c0, float rr, float deg) {
        return c0 - (float) Math.cos(Math.toRadians(deg)) * rr;
    }

    private static float sinD(float deg) {
        return (float) Math.sin(Math.toRadians(deg));
    }

    private static float cosD(float deg) {
        return (float) Math.cos(Math.toRadians(deg));
    }

    /** Fraction of the day in local time, 0 at midnight. */
    private float dayFrac(long now) {
        if (tzStamp < 0L || now - tzStamp > 60_000L) {
            cal.setTimeInMillis(now);
            tzOff = cal.get(Calendar.ZONE_OFFSET) + cal.get(Calendar.DST_OFFSET);
            tzStamp = now;
        }
        return (float) (((now + tzOff) % 86_400_000L) / 86_400_000.0);
    }

    private void blob(Canvas c, RadialGradient g, float x, float y, float rad, float alpha) {
        gp.setStyle(Paint.Style.FILL);
        gp.setShader(g);
        gp.setAlpha((int) (255 * clamp01(alpha)));
        c.save();
        c.translate(x, y);
        c.drawCircle(0f, 0f, rad, gp);
        c.restore();
        gp.setShader(null);
        gp.setAlpha(255);
    }

    private void line(Canvas c, float x0, float y0, float x1, float y1, float wid, int color, float alpha) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, wid));
        pt.setColor(al(color, alpha));
        c.drawLine(x0, y0, x1, y1, pt);
    }

    private void dot(Canvas c, float x, float y, float rad, int color, float alpha) {
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(color, alpha));
        c.drawCircle(x, y, rad, pt);
    }

    private void ring(Canvas c, float x, float y, float rad, float wid, int color, float alpha) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, wid));
        pt.setColor(al(color, alpha));
        c.drawCircle(x, y, rad, pt);
    }

    /** An arc about the origin; degrees run clockwise from 12 o'clock. */
    private void arc(Canvas c, float rad, float from, float sweep, float wid, int color, float alpha) {
        if (sweep == 0f) return;
        rc.set(-rad, -rad, rad, rad);
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, wid));
        pt.setColor(al(color, alpha));
        c.drawArc(rc, from - 90f, sweep, false, pt);
    }

    private void fillPath(Canvas c, Path p, int color, float alpha) {
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(color, alpha));
        c.drawPath(p, pt);
    }

    private void strokePath(Canvas c, Path p, float wid, int color, float alpha) {
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, wid));
        pt.setColor(al(color, alpha));
        c.drawPath(p, pt);
    }

    private void star4(Canvas c, float x, float y, float s, int color, float alpha) {
        line(c, x - s, y, x + s, y, s * 0.14f, color, alpha);
        line(c, x, y - s, x, y + s, s * 0.14f, color, alpha);
        dot(c, x, y, s * 0.16f, 0xFFFFFFFF, alpha);
    }

    /** Text about (x, y): a baseline-centred string with the given face and size. Fill is a colour or, if sh != null, a shader. */
    private void text(Canvas c, String s, float x, float y, float size, Typeface face, int color, float alpha, Shader sh) {
        tp.setStyle(Paint.Style.FILL);
        tp.setTypeface(face);
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTextSize(size);
        tp.setColor(al(color, alpha));
        tp.setShader(sh);
        c.drawText(s, x, y, tp);
        tp.setShader(null);
    }

    /** A gear outline about the origin, tooth 0 at 12 o'clock. Holes are added by the caller with even-odd fill. */
    private static void gear(Path p, int n, float rTip, float rRoot) {
        p.rewind();
        float pitch = 360f / n;
        for (int i = 0; i < n; i++) {
            float ctr = i * pitch;
            float[] ang = {ctr - 0.30f * pitch, ctr - 0.15f * pitch, ctr + 0.15f * pitch, ctr + 0.30f * pitch, ctr + 0.5f * pitch};
            float[] rad = {rRoot, rTip, rTip, rRoot, rRoot};
            for (int k = 0; k < 5; k++) {
                float x = hx(0f, rad[k], ang[k]), y = hy(0f, rad[k], ang[k]);
                if (i == 0 && k == 0) p.moveTo(x, y);
                else p.lineTo(x, y);
            }
        }
        p.close();
    }

    /** Angle of a gear that meshes with the driver (tooth pitch pA, angle rotA) towards direction phi. */
    private static float meshAngle(float phi, float rotA, float pA, float pB) {
        return phi + 180f - pB * (0.5f - (phi - rotA) / pA);
    }

    /** One step a second, like an escapement: the angle of the driving wheel with tooth pitch 'pitch'. */
    private static float tickAngle(double td, float pitch, int teeth) {
        long k = (long) Math.floor(td);
        float f = (float) (td - k);
        return pitch * ((k % teeth) + smooth(f / 0.22f));
    }

    // ---------- layout ----------

    private RadialGradient haloGold, haloBlue;
    private final float[] warp = new float[56 * 3], stars = new float[240];

    void layout(int width, int height, float clockX, float clockY, float radius) {
        boolean same = built && width == w && height == h && radius == r;
        w = width;
        h = height;
        cx = clockX;
        cy = clockY;
        r = radius;
        u = width / 1080f;
        if (!same) {
            built = true;
            Shader.TileMode cl = Shader.TileMode.CLAMP;
            float big = Math.max(w, h);
            vignette = new RadialGradient(0f, 0f, big * 0.75f, new int[]{0x00000000, 0x00000000, 0xB0000000}, new float[]{0f, 0.55f, 1f}, cl);
            glare = new RadialGradient(0f, 0f, w * 0.8f, new int[]{0x66FFD08A, 0x22FFB35A, 0x00FFB35A}, new float[]{0f, 0.55f, 1f}, cl);
            haloGold = new RadialGradient(0f, 0f, r * 2.6f, new int[]{0x66FFC878, 0x30FFA848, 0x00FFA848}, new float[]{0f, 0.5f, 1f}, cl);
            haloBlue = new RadialGradient(0f, 0f, r * 2.6f, new int[]{0x66C8DCFF, 0x306A7CFF, 0x006A7CFF}, new float[]{0f, 0.5f, 1f}, cl);
            for (int i = 0; i < 48; i++) {
                dust[3 * i] = hash(i * 3 + 1) * w;
                dust[3 * i + 1] = 14f + hash(i * 3 + 2) * 26f;
                dust[3 * i + 2] = hash(i * 3 + 3) * h;
            }
            for (int i = 0; i < 120; i++) {                                    // sky stars: three twinkle groups of forty
                stars[2 * i] = hash(i * 5 + 11) * w;
                stars[2 * i + 1] = hash(i * 5 + 12) * h;
            }
            for (int i = 0; i < 56; i++) {                                     // warp streaks: angle, delay, length
                warp[3 * i] = hash(i * 7 + 21) * 360f;
                warp[3 * i + 1] = hash(i * 7 + 22) * 0.5f;
                warp[3 * i + 2] = 0.4f + hash(i * 7 + 23) * 0.8f;
            }
            for (int i = 0; i < 160; i++) {                                    // fine grain inside a dial, as polar points
                float ang = hash(i * 3 + 41) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 42)) * 0.92f;
                speck[2 * i] = (float) Math.cos(ang) * rad;
                speck[2 * i + 1] = (float) Math.sin(ang) * rad;
            }
            for (int i = 0; i < 120; i++) {                                    // dial stars as polar points: x, y, size
                float ang = hash(i * 3 + 61) * TAU, rad = (float) Math.sqrt(hash(i * 3 + 62)) * 0.93f;
                star[3 * i] = (float) Math.cos(ang) * rad;
                star[3 * i + 1] = (float) Math.sin(ang) * rad;
                star[3 * i + 2] = 0.4f + hash(i * 3 + 63);
            }
            buildWatch();
            buildPendulum();
            buildTourbillon();
            buildCelestial();
            buildDiamond();
        }
        disc.rewind();
        disc.addCircle(cx, cy, r * 0.97f, Path.Direction.CW);
    }

    // ---------- the backdrop: a tint, a vignette and a little ambient life ----------

    void env(Canvas c, long now) {
        double td = now / 1000.0;
        for (int i = 0; i < N; i++) {
            if (a[i] < 0.004f) continue;
            float e = smooth(a[i]);
            gp.setStyle(Paint.Style.FILL);
            gp.setColor(al(TINT[i], TINT_A[i] * e));
            c.drawRect(0f, 0f, w, h, gp);
            blob(c, vignette, w / 2f, h / 2f, Math.max(w, h), 0.55f * e);
            if (i == 0) {
                blob(c, haloGold, cx, cy, r * 2.6f, 0.55f * e);
                motes(c, td, e, 40, 0xFFFFD79A, 0.55f, 1f, 3.5f);
            } else if (i == 1) {
                blob(c, haloGold, cx, cy, r * 2.6f, e * (0.40f + 0.08f * sn(td, 3.1, 0)));
                motes(c, td, e, 30, 0xFFFFC890, 0.40f, 0.6f, 3f);
            } else if (i == 2) {
                blob(c, haloBlue, cx, cy, r * 2.6f, 0.38f * e);
                motes(c, td, e, 26, 0xFFCFE2FF, 0.34f, 0.8f, 2.6f);
            } else if (i == 3) {
                skyAmbient(c, td, e);
            } else {
                blob(c, haloGold, cx, cy, r * 2.6f, 0.30f * e);
                glints(c, td, e);
            }
        }
    }

    /** Dust motes rising slowly from below. */
    private void motes(Canvas c, double td, float e, int n, int color, float alpha, float speed, float size) {
        for (int i = 0; i < n; i++) {
            float y = h - drift(td * speed + dust[3 * i + 2], (10f + dust[3 * i + 1]) * u, h + 60f) + 30f;
            buf[2 * i] = dust[3 * i] + 22f * u * (float) Math.sin(td * 0.45 + i * 1.3);
            buf[2 * i + 1] = y;
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(size * u);
        pt.setColor(al(color, alpha * e));
        c.drawPoints(buf, 0, 2 * n, pt);
    }

    /** Twinkling stars over the whole screen and now and then a shooting star. */
    private void skyAmbient(Canvas c, double td, float e) {
        pt.setStyle(Paint.Style.STROKE);
        for (int g = 0; g < 3; g++) {
            float tw = 0.30f + 0.70f * (0.5f + 0.5f * sn(td, 2.6 + g * 1.3, g * 2.1));
            pt.setStrokeWidth((2.2f + g * 0.9f) * u);
            pt.setColor(al(g == 1 ? 0xFFFFE8B0 : 0xFFDCE6FF, 0.85f * tw * e));
            c.drawPoints(stars, g * 80, 80, pt);
        }
        double per = 7.0;
        long n = (long) Math.floor(td / per);
        float t = (float) ((td - n * per) / 1.1);                                       // each shot lasts 1.1 s
        if (t < 1f) {
            float x0 = hash((int) n * 3 + 1) * w * 0.7f + w * 0.3f, y0 = hash((int) n * 3 + 2) * h * 0.35f;
            float dx = -w * 0.34f, dy = h * 0.12f, hd = smooth(t);
            float fade = (float) Math.sin(Math.PI * t);
            for (int k = 0; k < 6; k++) {
                float f0 = hd - k * 0.045f;
                if (f0 < 0f) break;
                dot(c, x0 + dx * f0, y0 + dy * f0, (3.4f - k * 0.45f) * u, k == 0 ? 0xFFFFFFFF : 0xFFBFD0FF, (0.9f - k * 0.13f) * fade * e);
            }
        }
    }

    /** Little glints of light that come and go like light on cut stones. */
    private void glints(Canvas c, double td, float e) {
        for (int k = 0; k < 6; k++) {
            double ph = td / 3.4 + k * 0.37;
            long n = (long) Math.floor(ph);
            float f = (float) (ph - n), al2 = (float) Math.sin(Math.PI * f);
            al2 *= al2;
            if (al2 < 0.03f) continue;
            float x = hash((int) n * 11 + k * 5 + 1) * w, y = hash((int) n * 11 + k * 5 + 2) * h;
            star4(c, x, y, (10f + 16f * al2) * u, 0xFFEFFFF8, 0.85f * al2 * e);
        }
    }

    // ---------- the jump: a door into another space, different for each Super ----------

    /** q runs 0..1 and the door is shut at 0.5; behind it the old clock comes apart and the new one begins. */
    void portal(Canvas c, int th, float q, long now) {
        if (q <= 0f || q >= 1f) return;
        double td = now / 1000.0;
        float f = (float) Math.sin(Math.PI * q);                              // 0 open, 1 closed, 0 open
        float diag = (float) Math.hypot(w, h);
        gp.setStyle(Paint.Style.FILL);
        pt.setStyle(Paint.Style.FILL);
        if (th == FIRST) {                                                    // brass gear rings roll out from the dial
            gp.setColor(al(0xFF1A0E05, 0.60f * f));
            c.drawRect(0f, 0f, w, h, gp);
            for (int k = 0; k < 3; k++) {
                float e = clamp01(q * 1.45f - k * 0.17f);
                if (e <= 0f || e >= 1f) continue;
                float rad = diag * 0.72f * outCubic(e), fade = (float) Math.sin(Math.PI * e);
                float spin = (k % 2 == 0 ? 1f : -1f) * q * 70f + k * 5f;
                int n = 0;
                for (int i = 0; i < 36; i++) {
                    float ang = spin + i * 10f;
                    buf[n++] = hx(cx, rad, ang);
                    buf[n++] = hy(cy, rad, ang);
                    buf[n++] = hx(cx, rad + 30f * u + 12f * u * k, ang);
                    buf[n++] = hy(cy, rad + 30f * u + 12f * u * k, ang);
                }
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeCap(Paint.Cap.BUTT);
                pt.setStrokeWidth(Math.max(3f, 6.28f * rad / 72f * 0.55f));
                pt.setColor(al(k == 1 ? BRZ_L : GOLD_M, 0.80f * fade));
                c.drawLines(buf, 0, n, pt);
                pt.setStrokeCap(Paint.Cap.ROUND);
                ring(c, cx, cy, rad, 5f * u, GOLD_H, 0.85f * fade);
                ring(c, cx, cy, rad - 4f * u, 2f * u, BRZ_D, 0.7f * fade);
            }
            blob(c, haloGold, cx, cy, r * 2.6f, f * f);
        } else if (th == FIRST + 1) {                                         // velvet curtains with a gold fringe, and a chime ring
            float cl = smooth(clamp01(f * 1.12f)), half = w * 0.5f * cl;
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFF3A0B16, 0.94f));
            c.drawRect(0f, 0f, half, h, pt);
            c.drawRect(w - half, 0f, w, h, pt);
            for (int side = 0; side < 2; side++) {
                int n = 0;
                for (int k = 0; k < 10; k++) {
                    float x = half * (k + 0.5f) / 10f;
                    x += (float) Math.sin(td * 1.7 + k) * 5f * u * cl;
                    float xx = side == 0 ? x : w - x;
                    buf[n++] = xx;
                    buf[n++] = 0f;
                    buf[n++] = xx;
                    buf[n++] = h;
                }
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeCap(Paint.Cap.BUTT);
                pt.setStrokeWidth(Math.max(2f, half / 10f * 0.38f));
                pt.setColor(al(side == 0 ? 0xFF6A1428 : 0xFF2A0610, 0.55f));
                c.drawLines(buf, 0, n, pt);
                pt.setStrokeCap(Paint.Cap.ROUND);
            }
            if (cl > 0.02f) {
                line(c, half, 0f, half, h, 8f * u, GOLD_M, 0.95f);
                line(c, w - half, 0f, w - half, h, 8f * u, GOLD_M, 0.95f);
                int n = 0;
                for (int k = 0; k < 22; k++) {
                    buf[n++] = half;
                    buf[n++] = h * (k + 0.5f) / 22f;
                    buf[n++] = w - half;
                    buf[n++] = h * (k + 0.5f) / 22f;
                }
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(11f * u);
                pt.setColor(al(GOLD_L, 0.9f));
                c.drawPoints(buf, 0, n, pt);
            }
            for (int k = 0; k < 2; k++) {
                float e = clamp01(q * 1.5f - 0.15f - k * 0.2f);
                if (e <= 0f || e >= 1f) continue;
                ring(c, cx, cy, diag * 0.6f * outCubic(e), 6f * u, GOLD_L, 0.7f * (float) Math.sin(Math.PI * e));
            }
        } else if (th == FIRST + 2) {                                         // an eight-bladed aperture closes on the dial
            float ap = Math.max(diag * 0.05f, diag * 0.66f * (1f - smooth(f * 1.05f))), twist = (1f - f) * 55f;
            for (int k = 0; k < 8; k++) {
                c.save();
                c.translate(cx, cy);
                c.rotate(k * 45f + twist);
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(k % 2 == 0 ? 0xFF151A22 : 0xFF1B212B, 0.93f));
                c.drawRect(ap, -diag * 1.2f, ap + diag * 1.4f, diag * 1.2f, pt);
                line(c, ap, -ap * 0.42f, ap, ap * 0.42f, 4f * u, ROSE_L, 0.9f * f);
                c.restore();
            }
            ring(c, cx, cy, ap * 0.5f, 3f * u, ROSE_L, 0.4f * f);
        } else if (th == FIRST + 3) {                                         // a jump through the stars: streaks fly out of the clock
            gp.setColor(al(0xFF070A2A, 0.62f * f));
            c.drawRect(0f, 0f, w, h, gp);
            int n = 0;
            for (int i = 0; i < 56; i++) {
                float t = clamp01(q * 1.55f - warp[3 * i + 1]);
                if (t <= 0f || t >= 1f) continue;
                float head = diag * 0.85f * t * t, len = diag * 0.22f * f * warp[3 * i + 2] + 14f * u;
                float ang = warp[3 * i];
                buf[n++] = hx(cx, Math.max(0f, head - len), ang);
                buf[n++] = hy(cy, Math.max(0f, head - len), ang);
                buf[n++] = hx(cx, head, ang);
                buf[n++] = hy(cy, head, ang);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(5f * u);
            pt.setColor(al(0xFF8FA4FF, 0.35f));
            c.drawLines(buf, 0, n, pt);
            pt.setStrokeWidth(2f * u);
            pt.setColor(al(0xFFFFFFFF, 0.9f));
            c.drawLines(buf, 0, n, pt);
            blob(c, haloBlue, cx, cy, r * 2.6f, f * f);
        } else {                                                              // facets of a cut stone open from the clock
            gp.setColor(al(0xFF021410, 0.55f * f));
            c.drawRect(0f, 0f, w, h, gp);
            float reach = diag * 0.95f * outCubic(clamp01(q * 1.3f)), rot = q * 45f;
            for (int k = 0; k < 16; k++) {
                float ang = rot + k * 22.5f;
                path.rewind();
                path.moveTo(cx, cy);
                path.lineTo(hx(cx, reach, ang - 11.25f), hy(cy, reach, ang - 11.25f));
                path.lineTo(hx(cx, reach, ang + 11.25f), hy(cy, reach, ang + 11.25f));
                path.close();
                fillPath(c, path, k % 2 == 0 ? 0xFFFFFFFF : 0xFF7CFFD2, 0.20f * f);
            }
            int n = 0;
            for (int k = 0; k < 16; k++) {
                float ang = rot + k * 22.5f - 11.25f;
                buf[n++] = hx(cx, r * 0.9f, ang);
                buf[n++] = hy(cy, r * 0.9f, ang);
                buf[n++] = hx(cx, reach, ang);
                buf[n++] = hy(cy, reach, ang);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(2.5f * u);
            pt.setColor(al(0xFFEFFFF8, 0.8f * f));
            c.drawLines(buf, 0, n, pt);
            ring(c, cx, cy, reach * 0.98f, 4f * u, 0xFFFFFFFF, 0.6f * f);
            blob(c, haloGold, cx, cy, r * 2.6f, f * 0.8f);
        }
    }

    // ---------- the clocks: static art (cached) and the animated parts under the hands ----------

    /** How much of the cached dial is showing: it takes over from the animated build at the end. */
    static float dialA(float b) {
        return b >= 1f ? 1f : smooth((b - 0.8f) / 0.2f);
    }

    void dial(int th, Canvas k, float c0, float rad) {
        k.save();
        k.translate(c0 - cx, c0 - cy);
        art(th, k, 1f);
        k.restore();
    }

    void under(int th, Canvas c, float b, long now) {
        double td = now / 1000.0;
        float da = dialA(b);
        if (da < 0.999f) {
            float ext = r * 1.7f;
            int sc = c.saveLayerAlpha(cx - ext, cy - ext, cx + ext, cy + ext, (int) (255 * (1f - da)));
            art(th, c, b);
            c.restoreToCount(sc);
        }
        live(th, c, b, td, now);
    }

    private void art(int th, Canvas c, float b) {
        pt.setShader(null);
        pt.setTypeface(Typeface.DEFAULT);
        if (th == 5) watchArt(c, b);
        else if (th == 6) pendArt(c, b);
        else if (th == 7) tourArt(c, b);
        else if (th == 8) celArt(c, b);
        else diaArt(c, b);
    }

    /** What moves under the hands, scaled by how much of the clock has built. */
    private void live(int th, Canvas c, float b, double td, long now) {
        if (th == 5) watchLive(c, b, td, now);
        else if (th == 6) pendLive(c, b, td, now);
        else if (th == 7) tourLive(c, b, td, now);
        else if (th == 8) celLive(c, b, td, now);
        else diaLive(c, b, td, now);
    }

    // ---------- hands ----------

    void hands(int th, Canvas c, float hDeg, float mDeg, float sDeg, float sa, float b, long now) {
        float k = seg(b, 0.78f, 1f);                                                   // hands extend at the very end of the build
        if (k < 0.01f) return;
        double td = now / 1000.0;
        if (th == 5) watchHands(c, hDeg, mDeg, sDeg, sa, k, td, now);
        else if (th == 6) pendHands(c, hDeg, mDeg, sDeg, sa, k, td, now);
        else if (th == 7) tourHands(c, hDeg, mDeg, sDeg, sa, k, td, now);
        else if (th == 8) celHands(c, hDeg, mDeg, sDeg, sa, k, td, now);
        else diaHands(c, hDeg, mDeg, sDeg, sa, k, td, now);
    }

    // =====================================================================================================
    // 5  Brass Pocket Watch
    // =====================================================================================================

    private final Path gearA = new Path(), gearB = new Path(), gearC = new Path(), wHour = new Path(), wMin = new Path(),
            wCrown = new Path(), wSpiral = new Path(), wBolt = new Path();
    private SweepGradient wRim;
    private LinearGradient wNum, wGoldV;
    private RadialGradient wPlate, wWell;

    private void buildWatch() {
        float R = r;
        gear(gearA, 20, R * 0.217f, R * 0.182f);
        gearA.setFillType(Path.FillType.EVEN_ODD);
        gearA.addCircle(0f, 0f, R * 0.034f, Path.Direction.CW);
        for (int k = 0; k < 4; k++) gearA.addCircle(hx(0f, R * 0.118f, 45f + k * 90f), hy(0f, R * 0.118f, 45f + k * 90f), R * 0.040f, Path.Direction.CW);
        gear(gearB, 10, R * 0.117f, R * 0.082f);
        gearB.setFillType(Path.FillType.EVEN_ODD);
        for (int k = 0; k < 3; k++) gearB.addCircle(hx(0f, R * 0.052f, k * 120f), hy(0f, R * 0.052f, k * 120f), R * 0.016f, Path.Direction.CW);
        gear(gearC, 12, R * 0.137f, R * 0.102f);
        gearC.setFillType(Path.FillType.EVEN_ODD);
        for (int k = 0; k < 4; k++) gearC.addCircle(hx(0f, R * 0.066f, 45f + k * 90f), hy(0f, R * 0.066f, 45f + k * 90f), R * 0.019f, Path.Direction.CW);

        wHour.rewind();                                                        // a leaf hand, hollowed
        wHour.setFillType(Path.FillType.EVEN_ODD);
        wHour.moveTo(0f, -0.50f * R);
        wHour.cubicTo(0.016f * R, -0.42f * R, 0.060f * R, -0.36f * R, 0.058f * R, -0.27f * R);
        wHour.cubicTo(0.056f * R, -0.20f * R, 0.020f * R, -0.17f * R, 0.016f * R, -0.10f * R);
        wHour.lineTo(0.016f * R, 0.03f * R);
        wHour.cubicTo(0.044f * R, 0.05f * R, 0.044f * R, 0.12f * R, 0f, 0.13f * R);
        wHour.cubicTo(-0.044f * R, 0.12f * R, -0.044f * R, 0.05f * R, -0.016f * R, 0.03f * R);
        wHour.lineTo(-0.016f * R, -0.10f * R);
        wHour.cubicTo(-0.020f * R, -0.17f * R, -0.056f * R, -0.20f * R, -0.058f * R, -0.27f * R);
        wHour.cubicTo(-0.060f * R, -0.36f * R, -0.016f * R, -0.42f * R, 0f, -0.50f * R);
        wHour.close();
        rc.set(-0.020f * R, -0.37f * R, 0.020f * R, -0.20f * R);
        wHour.addOval(rc, Path.Direction.CW);

        wMin.rewind();                                                         // a long hand with a spade
        wMin.setFillType(Path.FillType.EVEN_ODD);
        wMin.moveTo(0f, -0.80f * R);
        wMin.cubicTo(0.012f * R, -0.72f * R, 0.046f * R, -0.66f * R, 0.044f * R, -0.56f * R);
        wMin.cubicTo(0.042f * R, -0.50f * R, 0.012f * R, -0.46f * R, 0.012f * R, -0.40f * R);
        wMin.lineTo(0.012f * R, 0.03f * R);
        wMin.cubicTo(0.040f * R, 0.05f * R, 0.040f * R, 0.13f * R, 0f, 0.14f * R);
        wMin.cubicTo(-0.040f * R, 0.13f * R, -0.040f * R, 0.05f * R, -0.012f * R, 0.03f * R);
        wMin.lineTo(-0.012f * R, -0.40f * R);
        wMin.cubicTo(-0.012f * R, -0.46f * R, -0.042f * R, -0.50f * R, -0.044f * R, -0.56f * R);
        wMin.cubicTo(-0.046f * R, -0.66f * R, -0.012f * R, -0.72f * R, 0f, -0.80f * R);
        wMin.close();
        rc.set(-0.014f * R, -0.65f * R, 0.014f * R, -0.52f * R);
        wMin.addOval(rc, Path.Direction.CW);

        wCrown.rewind();                                                       // the cup-shaped crown
        wCrown.moveTo(-0.098f * R, -1.19f * R);
        wCrown.lineTo(0.098f * R, -1.19f * R);
        wCrown.quadTo(0.080f * R, -1.11f * R, 0.056f * R, -1.075f * R);
        wCrown.lineTo(-0.056f * R, -1.075f * R);
        wCrown.quadTo(-0.080f * R, -1.11f * R, -0.098f * R, -1.19f * R);
        wCrown.close();

        wSpiral.rewind();                                                      // a hairspring
        for (int i = 0; i <= 72; i++) {
            float ang = i * 15f, rad = R * (0.012f + 0.062f * i / 72f);
            if (i == 0) wSpiral.moveTo(hx(0f, rad, ang), hy(0f, rad, ang));
            else wSpiral.lineTo(hx(0f, rad, ang), hy(0f, rad, ang));
        }

        wBolt.rewind();
        wBolt.moveTo(0.012f * R, -0.050f * R);
        wBolt.lineTo(-0.026f * R, 0.008f * R);
        wBolt.lineTo(-0.002f * R, 0.008f * R);
        wBolt.lineTo(-0.012f * R, 0.050f * R);
        wBolt.lineTo(0.026f * R, -0.010f * R);
        wBolt.lineTo(0.002f * R, -0.010f * R);
        wBolt.close();

        wRim = new SweepGradient(0f, 0f, new int[]{0xFF5A3418, 0xFFE0AA70, 0xFF7A4A24, 0xFF33200F, 0xFFB67A44, 0xFF6B4020, 0xFFE0AA70, 0xFF5A3418},
                new float[]{0f, 0.10f, 0.26f, 0.44f, 0.62f, 0.76f, 0.90f, 1f});
        wNum = new LinearGradient(0f, -0.12f * R, 0f, 0.12f * R, new int[]{GOLD_H, GOLD_M, GOLD_D}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        wGoldV = new LinearGradient(0f, -0.55f * R, 0f, 0.55f * R, new int[]{GOLD_L, GOLD_D, GOLD_M}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        wPlate = new RadialGradient(0f, 0f, 0.93f * R, new int[]{0xFF403D38, 0xFF2B2A27, 0xFF161513}, new float[]{0f, 0.62f, 1f}, Shader.TileMode.CLAMP);
        wWell = new RadialGradient(0f, 0f, 0.52f * R, new int[]{0x66000000, 0x33000000, 0x00000000}, new float[]{0f, 0.7f, 1f}, Shader.TileMode.CLAMP);
    }

    private static float windEnv(float t) {
        return seg(t, 0f, 0.3f) * (1f - seg(t, 2.6f, 3.8f));
    }

    private void watchArt(Canvas c, float b) {
        c.save();
        c.translate(cx, cy);
        float R = r;

        // the bow and crown drop in from above and settle with a little bounce
        float bowA = seg(b, 0f, 0.08f), bowT = outBack(seg(b, 0.02f, 0.25f));
        c.save();
        c.translate(0f, -(1f - bowT) * R * 0.75f);
        ring(c, 0f, -1.31f * R, 0.19f * R, 0.040f * R, 0xFF7A4326, bowA);
        c.save();
        c.translate(0f, -1.31f * R);
        arc(c, 0.19f * R, 285f, 70f, 0.016f * R, 0xFFE9B27A, 0.9f * bowA);
        arc(c, 0.19f * R, 105f, 60f, 0.012f * R, 0xFF2A160A, 0.7f * bowA);
        c.restore();
        fillPath(c, wCrown, 0xFFA85A32, bowA);
        strokePath(c, wCrown, 0.008f * R, 0xFF3A1D0C, bowA);
        line(c, -0.070f * R, -1.17f * R, -0.042f * R, -1.090f * R, 0.014f * R, 0xFFF0B98A, 0.7f * bowA);
        pt.setStyle(Paint.Style.FILL);
        pt.setColor(al(0xFF4A2A14, bowA));
        c.drawRect(-0.080f * R, -1.075f * R, 0.080f * R, -1.025f * R, pt);
        line(c, -0.080f * R, -1.062f * R, 0.080f * R, -1.062f * R, 0.008f * R, 0xFFC98A4B, 0.8f * bowA);
        c.restore();

        // the case: a bronze ring that sweeps round, then its thin edge lines
        float rimT = seg(b, 0.04f, 0.30f);
        if (rimT > 0.002f) {
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.BUTT);
            sp.setStrokeWidth(0.115f * R);
            sp.setShader(wRim);
            sp.setColor(0xFFFFFFFF);
            rc.set(-0.99f * R, -0.99f * R, 0.99f * R, 0.99f * R);
            c.drawArc(rc, -90f, 360f * rimT, false, sp);
            sp.setShader(null);
            sp.setStrokeCap(Paint.Cap.ROUND);
            ring(c, 0f, 0f, 1.047f * R, 0.007f * R, 0xFF1A0E06, rimT);
            ring(c, 0f, 0f, 0.936f * R, 0.010f * R, 0xFFF0C890, 0.8f * rimT);
            ring(c, 0f, 0f, 0.99f * R, 0.004f * R, 0xFFFFE4C0, 0.35f * rimT);
        }

        // the dial plate with a fine grain
        float plateT = seg(b, 0.14f, 0.40f);
        if (plateT > 0.002f) {
            sp.setStyle(Paint.Style.FILL);
            sp.setShader(wPlate);
            sp.setColor(al(0xFFFFFFFF, plateT));
            c.drawCircle(0f, 0f, 0.925f * R * (0.86f + 0.14f * plateT), sp);
            sp.setShader(null);
            for (int i = 0; i < 160; i++) {
                buf[2 * i] = speck[2 * i] * R;
                buf[2 * i + 1] = speck[2 * i + 1] * R;
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1.2f, 0.010f * R));
            pt.setColor(al(0xFFFFFFFF, 0.09f * plateT));
            c.drawPoints(buf, 0, 320, pt);
            sp.setStyle(Paint.Style.FILL);
            sp.setShader(wWell);
            sp.setColor(al(0xFFFFFFFF, plateT));
            c.drawCircle(0f, 0f, 0.52f * R, sp);
            sp.setShader(null);
            ring(c, 0f, 0f, 0.915f * R, 0.012f * R, 0xFFFFFFFF, 0.14f * plateT);
        }

        // raised gold numerals rise one after another, starting at 12
        float size = 0.30f * R, base = 0.108f * R;
        for (int i = 0; i < 12; i++) {
            float t0 = 0.30f + i * 0.022f, ai = seg(b, t0, t0 + 0.14f);
            if (ai < 0.01f) continue;
            float nx = hx(0f, 0.750f * R, i * 30f), ny = hy(0f, 0.750f * R, i * 30f), sc = 0.6f + 0.4f * outBack(ai);
            c.save();
            c.translate(nx, ny);
            c.scale(sc, sc);
            c.rotate((1f - ai) * (i % 2 == 0 ? 14f : -14f));
            text(c, NUM[i], 0.014f * R, base + 0.018f * R, size, COND, 0xFF000000, 0.55f * ai, null);
            text(c, NUM[i], -0.005f * R, base - 0.006f * R, size, COND, GOLD_H, 0.60f * ai, null);
            text(c, NUM[i], 0f, base, size, COND, 0xFFFFFFFF, ai, wNum);
            c.restore();
        }

        // the gold ring, then its spokes grow out of the centre one after another
        float ringT = seg(b, 0.46f, 0.64f);
        if (ringT > 0.002f) {
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.BUTT);
            sp.setStrokeWidth(0.016f * R);
            sp.setShader(wGoldV);
            sp.setColor(0xFFFFFFFF);
            rc.set(-0.52f * R, -0.52f * R, 0.52f * R, 0.52f * R);
            c.drawArc(rc, -90f, 360f * ringT, false, sp);
            sp.setShader(null);
            sp.setStrokeCap(Paint.Cap.ROUND);
            ring(c, 0f, 0f, 0.527f * R, 0.004f * R, GOLD_H, 0.55f * ringT);
        }
        int n = 0, m = 0;
        for (int i = 0; i < 60; i++) {
            float si = seg(b, 0.50f + i * 0.003f, 0.66f + i * 0.003f);
            if (si < 0.01f) continue;
            boolean major = i % 5 == 0;
            float out = (major ? 0.535f : 0.505f) * R, ra = 0.205f * R, rb = ra + (out - ra) * si, ang = i * 6f;
            float sx = sinD(ang), sy = -cosD(ang);
            if (major) {
                buf[256 + m++] = sx * ra;
                buf[256 + m++] = sy * ra;
                buf[256 + m++] = sx * rb;
                buf[256 + m++] = sy * rb;
            } else {
                buf[n++] = sx * ra;
                buf[n++] = sy * ra;
                buf[n++] = sx * rb;
                buf[n++] = sy * rb;
            }
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, 0.0045f * R));
        pt.setColor(al(GOLD_M, 0.80f));
        c.drawLines(buf, 0, n, pt);
        pt.setStrokeWidth(Math.max(1.4f, 0.008f * R));
        pt.setColor(al(GOLD_L, 0.95f));
        c.drawLines(buf, 256, m, pt);
        c.restore();
    }

    private void watchLive(Canvas c, float b, double td, long now) {
        float ga = seg(b, 0.54f, 0.76f);
        float tk = tk(FIRST, now);
        float wind = tk < 0f ? 0f : windEnv(tk);
        float R = r;
        c.save();
        c.translate(cx, cy);

        // a light runs round the spokes; while winding there are three of them, and faster
        float ringT = seg(b, 0.52f, 0.68f);
        if (ringT > 0.05f) {
            int heads = wind > 0.02f ? 3 : 1;
            float speed = 36f + 220f * wind;
            for (int hd = 0; hd < heads; hd++) {
                float head = (float) ((td * speed + hd * 120f) % 360.0);
                int i0 = (int) (head / 6f);
                for (int k = -3; k <= 3; k++) {
                    int i = ((i0 + k) % 60 + 60) % 60;
                    float fl = 1f - Math.abs(k) / 4f;
                    float sx = sinD(i * 6f), sy = -cosD(i * 6f);
                    line(c, sx * 0.205f * R, sy * 0.205f * R, sx * 0.505f * R, sy * 0.505f * R, 0.008f * R, GOLD_H, 0.85f * fl * ringT);
                }
            }
        }

        if (ga > 0.01f) {
            float fly = 1f - seg(b, 0.54f, 0.86f);
            float extra = tk < 0f ? 0f : 720f * outCubic(tk / 2.6f);
            float rotA = tickAngle(td, 18f, 20) + extra + fly * fly * 540f;
            float sc = outBack(seg(b, 0.54f, 0.76f));

            dot(c, 0.010f * R, 0.014f * R, 0.226f * R * sc, 0xFF000000, 0.35f * ga);
            drawWatchGear(c, gearA, 0f, 0f, rotA, sc, ga, 0xFF2F261D, 0xFF8A6A3C, 0);

            float bx = hx(0f, 0.30f * R, 125f), by = hy(0f, 0.30f * R, 125f);
            drawWatchGear(c, gearB, bx, by, meshAngle(125f, rotA, 18f, 36f), sc, ga, GOLD_M, GOLD_D, 1);
            float gx = hx(0f, 0.32f * R, 305f), gy = hy(0f, 0.32f * R, 305f);
            drawWatchGear(c, gearC, gx, gy, meshAngle(305f, rotA, 18f, 30f), sc, ga, BRZ_M, 0xFF3A2010, 2);

            // the balance wheel beats once a second, its hairspring breathing with it
            float osc = (38f + 22f * wind) * sn(td, 1.0, 0.0);
            float wx = hx(0f, 0.36f * R, 215f), wy = hy(0f, 0.36f * R, 215f);
            c.save();
            c.translate(wx, wy);
            c.scale(sc, sc);
            dot(c, 0.006f * R, 0.010f * R, 0.100f * R, 0xFF000000, 0.28f * ga);
            c.rotate(osc);
            float breathe = 1f + 0.10f * (float) Math.sin(Math.toRadians(osc * 2.2));
            c.save();
            c.scale(breathe, breathe);
            strokePath(c, wSpiral, 0.0045f * R, 0xFF9FC0E8, 0.9f * ga);
            c.restore();
            ring(c, 0f, 0f, 0.092f * R, 0.015f * R, GOLD_M, ga);
            ring(c, 0f, 0f, 0.100f * R, 0.004f * R, GOLD_H, 0.6f * ga);
            line(c, -0.090f * R, 0f, 0.090f * R, 0f, 0.010f * R, GOLD_D, ga);
            line(c, 0f, -0.090f * R, 0f, 0.090f * R, 0.010f * R, GOLD_D, ga);
            for (int k = 0; k < 6; k++) dot(c, hx(0f, 0.092f * R, k * 60f), hy(0f, 0.092f * R, k * 60f), 0.011f * R, GOLD_H, ga);
            dot(c, 0f, 0f, 0.016f * R, RUBY, ga);
            c.restore();

            // sparks where the teeth bite while the watch is being wound
            if (tk >= 0f && tk < 1.8f) {
                float fa = (1f - seg(tk, 0.5f, 1.8f)) * (0.5f + 0.5f * (float) Math.sin(tk * 44f));
                star4(c, hx(0f, 0.20f * R, 125f), hy(0f, 0.20f * R, 125f), 0.040f * R, GOLD_H, fa);
                star4(c, hx(0f, 0.20f * R, 305f), hy(0f, 0.20f * R, 305f), 0.034f * R, GOLD_H, fa);
            }
        }

        // the crown: a ring of light for each turn of the winding
        if (tk >= 0f && tk < 2.8f) {
            for (int k = 0; k < 3; k++) {
                float f = (tk - k * 0.34f) / 0.9f;
                if (f <= 0f || f >= 1f) continue;
                ring(c, 0f, -1.12f * R, (0.10f + 0.30f * f) * R, 0.016f * R * (1f - f), GOLD_H, 0.9f * (1f - f));
            }
            dot(c, 0f, -1.13f * R, 0.11f * R, GOLD_H, 0.30f * wind * (0.5f + 0.5f * (float) Math.sin(tk * 30f)));
        }

        // the power reserve: the battery as a gold arc round the rim, with its figure on a small plaque
        if (tk >= 0f) {
            float env = seg(tk, 0f, 0.35f) * (1f - seg(tk, 3.3f, 4.1f));
            if (env > 0.01f) {
                float fill = seg(tk, 0.35f, 2.0f), val = 270f * pct / 100f * fill;
                int col = pct <= 15 && !charging ? 0xFFFF6A5A : GOLD_L;
                arc(c, 0.895f * R, -135f, 270f, 0.026f * R, 0xFF000000, 0.55f * env);
                arc(c, 0.895f * R, -135f, 270f, 0.004f * R, GOLD_M, 0.5f * env);
                arc(c, 0.895f * R, -135f, val, 0.020f * R, col, env);
                int n = 0;
                for (int k = 0; k <= 10; k++) {
                    float ang = -135f + 27f * k;
                    buf[n++] = hx(0f, 0.868f * R, ang);
                    buf[n++] = hy(0f, 0.868f * R, ang);
                    buf[n++] = hx(0f, 0.922f * R, ang);
                    buf[n++] = hy(0f, 0.922f * R, ang);
                }
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(Math.max(1f, 0.005f * R));
                pt.setColor(al(GOLD_H, 0.7f * env));
                c.drawLines(buf, 0, n, pt);
                float ea = -135f + val;
                dot(c, hx(0f, 0.895f * R, ea), hy(0f, 0.895f * R, ea), 0.026f * R, 0xFFFFFFFF, env);
                dot(c, hx(0f, 0.895f * R, ea), hy(0f, 0.895f * R, ea), 0.050f * R, GOLD_H, 0.35f * env);
                rc.set(-0.17f * R, -0.395f * R, 0.17f * R, -0.265f * R);
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(0xFF140E08, 0.88f * env));
                c.drawRoundRect(rc, 0.04f * R, 0.04f * R, pt);
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(Math.max(1f, 0.008f * R));
                pt.setColor(al(GOLD_M, env));
                c.drawRoundRect(rc, 0.04f * R, 0.04f * R, pt);
                if (charging) {
                    c.save();
                    c.translate(-0.115f * R, -0.330f * R);
                    fillPath(c, wBolt, GOLD_H, env);
                    c.restore();
                }
                text(c, pctLabel, charging ? 0.02f * R : 0f, -0.296f * R, 0.098f * R, COND, GOLD_L, env, null);
            }
        }
        c.restore();
    }

    /** One wheel of the gear train: body, edge, details that turn with it, and a highlight that does not. */
    private void drawWatchGear(Canvas c, Path g, float x, float y, float rot, float sc, float al, int body, int edge, int kind) {
        float R = r;
        c.save();
        c.translate(x, y);
        c.scale(sc, sc);
        c.save();
        c.rotate(rot);
        fillPath(c, g, body, al);
        strokePath(c, g, 0.006f * R, edge, al);
        if (kind == 0) {
            ring(c, 0f, 0f, 0.158f * R, 0.008f * R, 0xFF6C5230, al);
            ring(c, 0f, 0f, 0.086f * R, 0.006f * R, 0xFF160F08, al);
            for (int k = 0; k < 4; k++) dot(c, hx(0f, 0.060f * R, k * 90f), hy(0f, 0.060f * R, k * 90f), 0.044f * R, GOLD_M, al);
            for (int k = 0; k < 4; k++) dot(c, hx(0f, 0.060f * R, k * 90f), hy(0f, 0.060f * R, k * 90f), 0.020f * R, GOLD_L, al);
            dot(c, 0f, 0f, 0.052f * R, GOLD_D, al);
        } else if (kind == 1) {
            ring(c, 0f, 0f, 0.070f * R, 0.005f * R, 0xFF7A5A18, al);
            dot(c, 0f, 0f, 0.026f * R, RUBY, al);
            dot(c, -0.008f * R, -0.008f * R, 0.008f * R, 0xFFFFC0C8, 0.8f * al);
        } else {
            ring(c, 0f, 0f, 0.090f * R, 0.005f * R, 0xFF5A3A1E, al);
            dot(c, 0f, 0f, 0.032f * R, GOLD_D, al);
            dot(c, 0f, 0f, 0.014f * R, GOLD_H, al);
        }
        c.restore();
        arc(c, kind == 0 ? 0.20f * R : (kind == 1 ? 0.105f * R : 0.125f * R), 285f, 46f, 0.010f * R, 0xFFFFF0C8, 0.38f * al);
        c.restore();
    }

    private void watchHands(Canvas c, float hDeg, float mDeg, float sDeg, float sa, float k, double td, long now) {
        float R = r;
        for (int pass = 0; pass < 2; pass++) {
            float ox = pass == 0 ? 0.013f * R : 0f, oy = pass == 0 ? 0.020f * R : 0f;
            for (int hnd = 0; hnd < 2; hnd++) {
                c.save();
                c.translate(cx + ox, cy + oy);
                c.rotate(hnd == 0 ? hDeg : mDeg);
                c.scale(k, k);
                Path p = hnd == 0 ? wHour : wMin;
                if (pass == 0) {
                    fillPath(c, p, 0xFF000000, 0.36f * k);
                } else {
                    fillPath(c, p, GOLD_M, k);
                    strokePath(c, p, 0.006f * R, 0xFF5A3C10, k);
                    float len = hnd == 0 ? 0.455f : 0.74f;
                    line(c, 0f, -len * R, 0f, -(hnd == 0 ? 0.37f : 0.66f) * R, 0.008f * R, GOLD_H, 0.9f * k);
                    line(c, 0f, -(hnd == 0 ? 0.19f : 0.50f) * R, 0f, -0.05f * R, 0.008f * R, GOLD_H, 0.75f * k);
                    line(c, 0.020f * R, -(hnd == 0 ? 0.30f : 0.55f) * R, 0.026f * R, -(hnd == 0 ? 0.25f : 0.50f) * R, 0.005f * R, GOLD_D, 0.7f * k);
                }
                c.restore();
            }
        }
        if (sa > 0.02f) {                                                    // the seconds hand, slim, with a ring and a counterweight
            c.save();
            c.translate(cx, cy);
            c.rotate(sDeg);
            c.scale(k, k);
            line(c, 0f, 0.16f * R, 0f, -0.86f * R, 0.007f * R, 0xFFE8B25A, sa * k);
            ring(c, 0f, 0.15f * R, 0.030f * R, 0.008f * R, 0xFFE8B25A, sa * k);
            dot(c, 0f, 0.20f * R, 0.020f * R, 0xFFE8B25A, sa * k);
            dot(c, 0f, -0.76f * R, 0.014f * R, 0xFFE8B25A, sa * k);
            c.restore();
        }
        dot(c, cx, cy, 0.050f * R, 0xFF2E1B0E, k);
        dot(c, cx, cy, 0.036f * R, GOLD_M, k);
        dot(c, cx, cy, 0.022f * R, GOLD_L, k);
        dot(c, cx - 0.006f * R, cy - 0.008f * R, 0.008f * R, 0xFFFFFFFF, 0.8f * k);
        // the glass dome: bright arcs at the upper left and now and then a glint sweeping across
        float vis = seg(k, 0f, 1f);
        arc(c, cx, cy, 0.86f * R, 210f, 70f, 0.050f * R, 0xFFFFFFFF, 0.075f * vis);
        arc(c, cx, cy, 0.79f * R, 222f, 42f, 0.018f * R, 0xFFFFFFFF, 0.13f * vis);
        arc(c, cx, cy, 0.93f * R, 120f, 36f, 0.012f * R, 0xFFFFFFFF, 0.09f * vis);
        float g = (float) ((td % 11.0) / 1.5);
        if (g < 1f && vis > 0.5f) {
            c.save();
            c.clipPath(disc);
            c.translate(cx, cy);
            c.rotate(28f);
            float gx = (-1.3f + 2.6f * smooth(g)) * R, fa = (float) Math.sin(Math.PI * g);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFFFFFFF, 0.07f * fa));
            c.drawRect(gx - 0.22f * R, -1.3f * R, gx + 0.22f * R, 1.3f * R, pt);
            pt.setColor(al(0xFFFFFFFF, 0.13f * fa));
            c.drawRect(gx - 0.07f * R, -1.3f * R, gx + 0.07f * R, 1.3f * R, pt);
            c.restore();
        }
    }

    /** An arc about (x, y); degrees clockwise from 12 o'clock. */
    private void arc(Canvas c, float x, float y, float rad, float from, float sweep, float wid, int color, float alpha) {
        c.save();
        c.translate(x, y);
        arc(c, rad, from, sweep, wid, color, alpha);
        c.restore();
    }

    // =====================================================================================================
    // 6  Grand Pendulum
    // =====================================================================================================

    private final Path pCase = new Path(), pBell = new Path(), pHour = new Path(), pMin = new Path();
    private LinearGradient pGold, pRod;
    private RadialGradient pDial;

    private void buildPendulum() {
        float R = r;
        pCase.rewind();                                                        // the glass case that hangs under the dial
        pCase.moveTo(-0.20f * R, 1.02f * R);
        pCase.cubicTo(-0.30f * R, 1.34f * R, -0.64f * R, 1.62f * R, -0.62f * R, 2.18f * R);
        pCase.cubicTo(-0.60f * R, 2.62f * R, 0.60f * R, 2.62f * R, 0.62f * R, 2.18f * R);
        pCase.cubicTo(0.64f * R, 1.62f * R, 0.30f * R, 1.34f * R, 0.20f * R, 1.02f * R);
        pCase.close();
        pBell.rewind();                                                        // a small brass bell above the case, pivot at its top
        pBell.moveTo(-0.115f * R, 0.13f * R);
        pBell.quadTo(-0.115f * R, -0.08f * R, 0f, -0.10f * R);
        pBell.quadTo(0.115f * R, -0.08f * R, 0.115f * R, 0.13f * R);
        pBell.quadTo(0f, 0.10f * R, -0.115f * R, 0.13f * R);
        pBell.close();
        pHour.rewind();                                                        // a spade hand
        pHour.moveTo(0f, -0.50f * R);
        pHour.lineTo(0.046f * R, -0.37f * R);
        pHour.quadTo(0.018f * R, -0.31f * R, 0.010f * R, -0.28f * R);
        pHour.lineTo(0.010f * R, 0.09f * R);
        pHour.lineTo(-0.010f * R, 0.09f * R);
        pHour.lineTo(-0.010f * R, -0.28f * R);
        pHour.quadTo(-0.018f * R, -0.31f * R, -0.046f * R, -0.37f * R);
        pHour.close();
        pMin.rewind();                                                         // a thin hand with a ring near the tip
        pMin.moveTo(0f, -0.80f * R);
        pMin.lineTo(0.010f * R, -0.70f * R);
        pMin.lineTo(0.010f * R, 0.10f * R);
        pMin.lineTo(-0.010f * R, 0.10f * R);
        pMin.lineTo(-0.010f * R, -0.70f * R);
        pMin.close();
        pGold = new LinearGradient(-R, -R, R, R, new int[]{GOLD_H, GOLD_D, GOLD_L, GOLD_D, GOLD_M}, new float[]{0f, 0.28f, 0.5f, 0.75f, 1f}, Shader.TileMode.CLAMP);
        pRod = new LinearGradient(-0.02f * R, 0f, 0.02f * R, 0f, new int[]{GOLD_D, GOLD_H, GOLD_D}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        pDial = new RadialGradient(0f, 0f, 0.93f * R, new int[]{0xFF1A2038, 0xFF0C0F1E, 0xFF04050B}, new float[]{0f, 0.65f, 1f}, Shader.TileMode.CLAMP);
    }

    private void pendArt(Canvas c, float b) {
        c.save();
        c.translate(cx, cy);
        float R = r;
        float rimT = seg(b, 0.04f, 0.30f), plateT = seg(b, 0.10f, 0.34f);
        if (rimT > 0.002f) {                                                   // a double gold bezel sweeps round
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.BUTT);
            sp.setStrokeWidth(0.085f * R);
            sp.setShader(pGold);
            sp.setColor(0xFFFFFFFF);
            rc.set(-0.975f * R, -0.975f * R, 0.975f * R, 0.975f * R);
            c.drawArc(rc, -90f, 360f * rimT, false, sp);
            sp.setShader(null);
            sp.setStrokeCap(Paint.Cap.ROUND);
            ring(c, 0f, 0f, 1.02f * R, 0.006f * R, 0xFF2A1A04, rimT);
            ring(c, 0f, 0f, 0.928f * R, 0.008f * R, 0xFF2A1A04, rimT);
            ring(c, 0f, 0f, 0.915f * R, 0.006f * R, GOLD_H, 0.7f * rimT);
        }
        if (plateT > 0.002f) {
            sp.setStyle(Paint.Style.FILL);
            sp.setShader(pDial);
            sp.setColor(al(0xFFFFFFFF, plateT));
            c.drawCircle(0f, 0f, 0.91f * R * (0.9f + 0.1f * plateT), sp);
            sp.setShader(null);
            ring(c, 0f, 0f, 0.50f * R, 0.006f * R, GOLD_M, 0.7f * plateT);
            ring(c, 0f, 0f, 0.495f * R, 0.003f * R, GOLD_H, 0.5f * plateT);
        }
        // the minute track and hour batons are stamped round the edge
        float trackT = seg(b, 0.40f, 0.62f);
        int n = 0, m = 0;
        for (int i = 0; i < 60; i++) {
            float ti = seg(b, 0.40f + i * 0.0025f, 0.50f + i * 0.0025f);
            if (ti < 0.01f) continue;
            float sx = sinD(i * 6f), sy = -cosD(i * 6f);
            if (i % 5 == 0) {
                buf[256 + m++] = sx * 0.835f * R;
                buf[256 + m++] = sy * 0.835f * R;
                buf[256 + m++] = sx * (0.835f + 0.075f * ti) * R;
                buf[256 + m++] = sy * (0.835f + 0.075f * ti) * R;
            } else {
                buf[n++] = sx * 0.875f * R;
                buf[n++] = sy * 0.875f * R;
                buf[n++] = sx * (0.875f + 0.035f * ti) * R;
                buf[n++] = sy * (0.875f + 0.035f * ti) * R;
            }
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, 0.005f * R));
        pt.setColor(al(GOLD_M, 0.85f));
        c.drawLines(buf, 0, n, pt);
        pt.setStrokeWidth(Math.max(1.5f, 0.012f * R));
        pt.setColor(al(GOLD_L, 0.95f));
        c.drawLines(buf, 256, m, pt);
        // Roman numerals travel out from the centre to their places, turned to face it
        float size = 0.165f * R;
        for (int i = 0; i < 12; i++) {
            float t0 = 0.22f + i * 0.026f, ai = seg(b, t0, t0 + 0.20f);
            if (ai < 0.01f) continue;
            float rad = (0.18f + 0.55f * outCubic(ai)) * R;
            c.save();
            c.translate(hx(0f, rad, i * 30f), hy(0f, rad, i * 30f));
            c.rotate(i >= 4 && i <= 8 ? i * 30f + 180f : i * 30f);
            text(c, ROMAN[i], 0.006f * R, size * 0.35f + 0.008f * R, size, SERIF_B, 0xFF000000, 0.6f * ai, null);
            text(c, ROMAN[i], 0f, size * 0.35f, size, SERIF_B, GOLD_L, ai, null);
            c.restore();
        }
        c.restore();
    }

    private void pendLive(Canvas c, float b, double td, long now) {
        float R = r;
        float tk = tk(FIRST + 1, now);
        float swing = seg(b, 0.62f, 0.92f);
        float kick = 0f, shake = 0f, glowK = 0f;
        int strikes = tapHour;
        if (tk >= 0f) {
            for (int i = 0; i < strikes; i++) {
                float age = tk - (0.35f + 0.64f * i);
                if (age < 0f || age > 1.8f) continue;
                float dec = (float) Math.exp(-age * 2.6);
                kick += 9f * dec;
                shake += 8f * dec * (float) Math.sin(age * 34f);
            }
        }
        c.save();
        c.translate(cx, cy);

        // the glass case under the dial, and the pendulum swinging in it
        float caseT = outBack(seg(b, 0.30f, 0.56f)), caseA = seg(b, 0.30f, 0.46f);
        if (caseA > 0.01f) {
            c.save();
            c.translate(0f, -(1f - caseT) * R * 0.9f);
            fillPath(c, pCase, 0xFF05060C, 0.55f * caseA);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeWidth(0.026f * R);
            sp.setShader(pGold);
            sp.setColor(al(0xFFFFFFFF, caseA));
            c.drawPath(pCase, sp);
            sp.setShader(null);
            strokePath(c, pCase, 0.006f * R, 0xFF2A1A04, caseA);
            arc(c, 0.52f * R, 232f, 36f, 0.020f * R, 0xFFFFFFFF, 0.12f * caseA);
            c.restore();
        }
        float rodT = outBack(seg(b, 0.58f, 0.80f)), amp = (12f + kick) * swing;
        if (rodT > 0.02f) {
            float ang = amp * sn(td, 2.0, 0.0);
            float len = 1.02f * R * rodT;
            c.save();
            c.translate(0f, 1.0f * R);
            c.rotate(ang);
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.BUTT);
            sp.setStrokeWidth(0.026f * R);
            sp.setShader(pRod);
            sp.setColor(0xFFFFFFFF);
            c.drawLine(0f, 0f, 0f, len, sp);
            sp.setShader(null);
            sp.setStrokeCap(Paint.Cap.ROUND);
            c.translate(0f, len);
            dot(c, 0.012f * R, 0.016f * R, 0.250f * R, 0xFF000000, 0.35f);
            dot(c, 0f, 0f, 0.250f * R, GOLD_D, 1f);
            sp.setStyle(Paint.Style.FILL);
            sp.setShader(pGold);
            sp.setColor(0xFFFFFFFF);
            c.drawCircle(0f, 0f, 0.236f * R, sp);
            sp.setShader(null);
            ring(c, 0f, 0f, 0.185f * R, 0.008f * R, 0xFF5A3C10, 0.9f);
            ring(c, 0f, 0f, 0.120f * R, 0.006f * R, 0xFF5A3C10, 0.9f);
            int n = 0;
            for (int i = 0; i < 12; i++) {
                buf[n++] = hx(0f, 0.125f * R, i * 30f);
                buf[n++] = hy(0f, 0.125f * R, i * 30f);
                buf[n++] = hx(0f, 0.183f * R, i * 30f);
                buf[n++] = hy(0f, 0.183f * R, i * 30f);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1f, 0.006f * R));
            pt.setColor(al(0xFF5A3C10, 0.8f));
            c.drawLines(buf, 0, n, pt);
            dot(c, 0f, 0f, 0.050f * R, GOLD_L, 1f);
            dot(c, 0f, 0f, 0.026f * R, RUBY, 1f);
            c.restore();
        }

        // the bell above the dial, shaken by each strike of the chime
        float bellA = seg(b, 0.50f, 0.66f);
        if (bellA > 0.01f) {
            c.save();
            c.translate(0f, -1.20f * R);
            c.rotate(shake);
            fillPath(c, pBell, GOLD_M, bellA);
            strokePath(c, pBell, 0.008f * R, 0xFF5A3C10, bellA);
            line(c, -0.060f * R, 0.02f * R, -0.050f * R, 0.10f * R, 0.014f * R, GOLD_H, 0.8f * bellA);
            dot(c, 0f, 0.16f * R, 0.024f * R, GOLD_D, bellA);
            dot(c, 0f, -0.115f * R, 0.022f * R, GOLD_L, bellA);
            c.restore();
        }

        // a sun medallion turns slowly in the middle of the dial
        float sunT = seg(b, 0.50f, 0.74f);
        if (sunT > 0.01f) {
            c.save();
            c.rotate((float) (td * 4.0) + (1f - sunT) * 200f);
            int n = 0;
            for (int i = 0; i < 24; i++) {
                float len = (i % 2 == 0 ? 0.30f : 0.20f) * R * sunT, ang = i * 15f;
                buf[n++] = hx(0f, 0.09f * R, ang);
                buf[n++] = hy(0f, 0.09f * R, ang);
                buf[n++] = hx(0f, 0.09f * R + len, ang);
                buf[n++] = hy(0f, 0.09f * R + len, ang);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1f, 0.010f * R));
            pt.setColor(al(GOLD_M, 0.85f * sunT));
            c.drawLines(buf, 0, n, pt);
            c.restore();
            ring(c, 0f, 0f, 0.13f * R * sunT, 0.010f * R, GOLD_L, 0.9f * sunT);
        }

        // the chime: a ring of sound and a glow on the numeral for each strike
        if (tk >= 0f) {
            for (int i = 0; i < strikes; i++) {
                float age = tk - (0.35f + 0.64f * i);
                if (age < 0f || age > 1.4f) continue;
                float f = age / 1.4f;
                ring(c, 0f, -1.20f * R, (0.14f + 1.5f * outCubic(f)) * R, 0.020f * R * (1f - f), GOLD_L, 0.55f * (1f - f));
                int num = (i + 1) % 12;
                float ga = (float) Math.sin(Math.PI * clamp01(age / 1.2f));
                dot(c, hx(0f, 0.73f * R, num * 30f), hy(0f, 0.73f * R, num * 30f), 0.13f * R, GOLD_H, 0.30f * ga);
            }
        }
        c.restore();
    }

    private void pendHands(Canvas c, float hDeg, float mDeg, float sDeg, float sa, float k, double td, long now) {
        float R = r;
        for (int hnd = 0; hnd < 2; hnd++) {
            c.save();
            c.translate(cx + 0.010f * R, cy + 0.016f * R);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, hnd == 0 ? pHour : pMin, 0xFF000000, 0.40f * k);
            c.restore();
            c.save();
            c.translate(cx, cy);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, hnd == 0 ? pHour : pMin, GOLD_M, k);
            strokePath(c, hnd == 0 ? pHour : pMin, 0.005f * R, 0xFF4A3008, k);
            if (hnd == 0) {
                line(c, 0f, -0.46f * R, 0f, -0.38f * R, 0.006f * R, GOLD_H, k);
            } else {
                ring(c, 0f, -0.66f * R, 0.040f * R, 0.012f * R, GOLD_M, k);
                ring(c, 0f, -0.66f * R, 0.040f * R, 0.004f * R, GOLD_H, k);
                line(c, 0f, -0.30f * R, 0f, -0.05f * R, 0.005f * R, GOLD_H, 0.8f * k);
            }
            c.restore();
        }
        if (sa > 0.02f) {
            c.save();
            c.translate(cx, cy);
            c.rotate(sDeg);
            c.scale(k, k);
            line(c, 0f, 0.20f * R, 0f, -0.84f * R, 0.006f * R, 0xFFE2644A, sa * k);
            dot(c, 0f, 0.20f * R, 0.024f * R, 0xFFE2644A, sa * k);
            ring(c, 0f, -0.70f * R, 0.020f * R, 0.006f * R, 0xFFE2644A, sa * k);
            c.restore();
        }
        dot(c, cx, cy, 0.046f * R, 0xFF2A1A04, k);
        dot(c, cx, cy, 0.032f * R, GOLD_M, k);
        dot(c, cx, cy, 0.016f * R, GOLD_H, k);
        arc(c, cx, cy, 0.84f * R, 215f, 60f, 0.040f * R, 0xFFFFFFFF, 0.06f * k);
        arc(c, cx, cy, 0.78f * R, 225f, 36f, 0.014f * R, 0xFFFFFFFF, 0.12f * k);
    }

    // =====================================================================================================
    // 7  Tourbillon
    // =====================================================================================================

    private final Path tG0 = new Path(), tG1 = new Path(), tG2 = new Path(), tG3 = new Path(), tHour = new Path(), tMin = new Path(),
            tSpiral = new Path();
    private LinearGradient tRose;
    private RadialGradient tPlate;

    // the gear train: pitch radius of a wheel with n teeth, all with the same tooth spacing
    private static final float PITCH = 0.0524f;
    private static float rp(int n) {
        return n * PITCH / TAU;
    }

    private static final float CAGE_Y = 0.44f;

    private void buildTourbillon() {
        float R = r;
        gear(tG0, 24, (rp(24) + 0.017f) * R, (rp(24) - 0.019f) * R);
        tG0.setFillType(Path.FillType.EVEN_ODD);
        tG0.addCircle(0f, 0f, 0.030f * R, Path.Direction.CW);
        int[] ns = {14, 12, 10};
        Path[] ps = {tG1, tG2, tG3};
        for (int g = 0; g < 3; g++) {
            float rr = rp(ns[g]);
            gear(ps[g], ns[g], (rr + 0.017f) * R, (rr - 0.019f) * R);
            ps[g].setFillType(Path.FillType.EVEN_ODD);
            for (int k = 0; k < 3; k++) ps[g].addCircle(hx(0f, rr * 0.52f * R, k * 120f), hy(0f, rr * 0.52f * R, k * 120f), rr * 0.20f * R, Path.Direction.CW);
        }
        tHour.rewind();                                                        // open baton hands
        tHour.moveTo(0f, -0.50f * R);
        tHour.lineTo(0.032f * R, -0.43f * R);
        tHour.lineTo(0.032f * R, 0.07f * R);
        tHour.lineTo(-0.032f * R, 0.07f * R);
        tHour.lineTo(-0.032f * R, -0.43f * R);
        tHour.close();
        tMin.rewind();
        tMin.moveTo(0f, -0.80f * R);
        tMin.lineTo(0.026f * R, -0.73f * R);
        tMin.lineTo(0.026f * R, 0.08f * R);
        tMin.lineTo(-0.026f * R, 0.08f * R);
        tMin.lineTo(-0.026f * R, -0.73f * R);
        tMin.close();
        tSpiral.rewind();
        for (int i = 0; i <= 60; i++) {
            float ang = i * 15f, rad = R * (0.012f + 0.060f * i / 60f);
            if (i == 0) tSpiral.moveTo(hx(0f, rad, ang), hy(0f, rad, ang));
            else tSpiral.lineTo(hx(0f, rad, ang), hy(0f, rad, ang));
        }
        tRose = new LinearGradient(-R, -R, R, R, new int[]{ROSE_L, ROSE_D, ROSE_M, ROSE_D, ROSE_L}, new float[]{0f, 0.3f, 0.5f, 0.74f, 1f}, Shader.TileMode.CLAMP);
        tPlate = new RadialGradient(0f, 0f, 0.93f * R, new int[]{0xFF222733, 0xFF11141B, 0xFF07080B}, new float[]{0f, 0.65f, 1f}, Shader.TileMode.CLAMP);
    }

    /** A bridge of the open-worked movement: a curved strap with a bevelled edge and two screws. */
    private void bridge(Canvas c, float rad, float from, float sweep, float wid, float alpha) {
        arc(c, rad, from, sweep, wid * 1.18f, 0xFF000000, 0.45f * alpha);
        arc(c, rad, from, sweep, wid, ROSE_D, alpha);
        arc(c, rad, from, sweep, wid * 0.62f, ROSE_M, alpha);
        arc(c, rad, from + 1f, Math.max(0f, sweep - 2f), wid * 0.14f, ROSE_L, 0.9f * alpha);
        for (int e = 0; e < 2; e++) {
            float ang = e == 0 ? from + 4f : from + sweep - 4f;
            float x = hx(0f, rad, ang), y = hy(0f, rad, ang);
            dot(c, x, y, wid * 0.24f, 0xFF2A2024, alpha);
            dot(c, x, y, wid * 0.18f, STEEL, alpha);
            line(c, x - wid * 0.13f, y - wid * 0.05f, x + wid * 0.13f, y + wid * 0.05f, wid * 0.04f, 0xFF2A2024, alpha);
        }
    }

    private void tourArt(Canvas c, float b) {
        c.save();
        float R = r;
        float plateT = seg(b, 0.10f, 0.34f), rimT = seg(b, 0.02f, 0.26f);
        if (plateT > 0.002f) {                                                 // Geneva stripes across the plate, clipped to the dial
            c.save();
            c.clipPath(disc);
            c.translate(cx, cy);
            sp.setStyle(Paint.Style.FILL);
            sp.setShader(tPlate);
            sp.setColor(al(0xFFFFFFFF, plateT));
            c.drawCircle(0f, 0f, 0.93f * R * (0.9f + 0.1f * plateT), sp);
            sp.setShader(null);
            int n = 0;
            for (int i = -15; i <= 15; i++) {
                buf[n++] = i * 0.062f * R;
                buf[n++] = -R;
                buf[n++] = i * 0.062f * R;
                buf[n++] = R;
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeCap(Paint.Cap.BUTT);
            pt.setStrokeWidth(0.020f * R);
            pt.setColor(al(0xFFFFFFFF, 0.045f * plateT));
            c.drawLines(buf, 0, n, pt);
            pt.setStrokeCap(Paint.Cap.ROUND);
            c.restore();
        }
        c.translate(cx, cy);
        if (rimT > 0.002f) {
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.BUTT);
            sp.setStrokeWidth(0.085f * R);
            sp.setShader(tRose);
            sp.setColor(0xFFFFFFFF);
            rc.set(-0.975f * R, -0.975f * R, 0.975f * R, 0.975f * R);
            c.drawArc(rc, -90f, 360f * rimT, false, sp);
            sp.setShader(null);
            sp.setStrokeCap(Paint.Cap.ROUND);
            ring(c, 0f, 0f, 1.02f * R, 0.006f * R, 0xFF1A0E0C, rimT);
            ring(c, 0f, 0f, 0.93f * R, 0.008f * R, 0xFF1A0E0C, rimT);
            ring(c, 0f, 0f, 0.918f * R, 0.005f * R, ROSE_L, 0.8f * rimT);
        }
        // bridges draw themselves round the movement
        float b1 = seg(b, 0.20f, 0.42f), b2 = seg(b, 0.26f, 0.48f), b3 = seg(b, 0.32f, 0.52f);
        if (b1 > 0.01f) bridge(c, 0.64f * R, 205f, 105f * b1, 0.085f * R, 1f);
        if (b2 > 0.01f) bridge(c, 0.64f * R, 25f, 105f * b2, 0.085f * R, 1f);
        if (b3 > 0.01f) bridge(c, 0.70f * R, 300f, 50f * b3, 0.050f * R, 1f);
        float wT = seg(b, 0.30f, 0.50f);                                       // the window round the tourbillon
        if (wT > 0.01f) {
            ring(c, 0f, CAGE_Y * R, 0.262f * R, 0.030f * R, ROSE_D, wT);
            ring(c, 0f, CAGE_Y * R, 0.262f * R, 0.018f * R, ROSE_M, wT);
            ring(c, 0f, CAGE_Y * R, 0.254f * R, 0.004f * R, ROSE_L, wT);
            ring(c, 0f, CAGE_Y * R, 0.270f * R, 0.004f * R, 0xFF000000, 0.6f * wT);
        }
        // hour batons are stamped round the edge, a small lume dot in each
        int n = 0;
        for (int i = 0; i < 12; i++) {
            float ti = seg(b, 0.36f + i * 0.016f, 0.50f + i * 0.016f);
            if (ti < 0.01f) continue;
            float len = (i % 3 == 0 ? 0.10f : 0.065f) * ti;
            buf[n++] = hx(0f, 0.895f * R, i * 30f);
            buf[n++] = hy(0f, 0.895f * R, i * 30f);
            buf[n++] = hx(0f, (0.895f - len) * R, i * 30f);
            buf[n++] = hy(0f, (0.895f - len) * R, i * 30f);
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeCap(Paint.Cap.BUTT);
        pt.setStrokeWidth(0.020f * R);
        pt.setColor(al(ROSE_D, 1f));
        c.drawLines(buf, 0, n, pt);
        pt.setStrokeWidth(0.012f * R);
        pt.setColor(al(ROSE_L, 1f));
        c.drawLines(buf, 0, n, pt);
        pt.setStrokeCap(Paint.Cap.ROUND);
        c.restore();
    }

    /** One wheel of the movement. kind 0 is the barrel with its spring, the others have jewels. */
    private void drawMoveGear(Canvas c, Path g, float x, float y, float rot, float sc, float alpha, int kind) {
        float R = r;
        c.save();
        c.translate(x, y);
        c.scale(sc, sc);
        c.save();
        c.rotate(rot);
        fillPath(c, g, kind == 0 ? 0xFF4A4F5C : ROSE_M, alpha);
        strokePath(c, g, 0.005f * R, kind == 0 ? 0xFFC9D2E0 : ROSE_L, alpha);
        if (kind == 0) {
            for (int k = 0; k < 4; k++) ring(c, 0f, 0f, (0.060f + 0.032f * k) * R, 0.006f * R, 0xFF9AA6B8, 0.8f * alpha);
            ring(c, 0f, 0f, 0.158f * R, 0.008f * R, 0xFF2A2E38, alpha);
            for (int k = 0; k < 6; k++) dot(c, hx(0f, 0.178f * R, k * 60f), hy(0f, 0.178f * R, k * 60f), 0.010f * R, STEEL, alpha);
            dot(c, 0f, 0f, 0.040f * R, 0xFF2A2E38, alpha);
            dot(c, 0f, 0f, 0.024f * R, RUBY, alpha);
        } else {
            dot(c, 0f, 0f, 0.030f * R, 0xFF2A2024, alpha);
            dot(c, 0f, 0f, 0.020f * R, RUBY, alpha);
        }
        c.restore();
        c.restore();
    }

    private void tourLive(Canvas c, float b, double td, long now) {
        float R = r;
        float tk = tk(FIRST + 2, now);
        float spin = tk < 0f ? 0f : seg(tk, 0f, 0.5f) * (1f - seg(tk, 3.4f, 4.6f));
        float gA = seg(b, 0.46f, 0.74f), cageA = seg(b, 0.54f, 0.82f);
        c.save();
        c.translate(cx, cy);
        if (gA > 0.01f) {
            float fly = 1f - seg(b, 0.46f, 0.78f);
            float sc = outBack(seg(b, 0.46f, 0.70f));
            float rotB = tickAngle(td, 15f, 24) + fly * fly * 400f + (tk < 0f ? 0f : 360f * outCubic(tk / 3f));
            float bx = -0.40f * R, by = -0.26f * R;
            // the chain of wheels, each meshing with the one before it
            float p0 = 360f / 24f, p1 = 360f / 14f, p2 = 360f / 12f, p3 = 360f / 10f;
            float f1 = 200f, f2 = 160f, f3 = 100f;
            float d1 = (rp(24) + rp(14)) * R, d2 = (rp(14) + rp(12)) * R, d3 = (rp(12) + rp(10)) * R;
            float x1 = bx + sinD(f1) * d1, y1 = by - cosD(f1) * d1;
            float x2 = x1 + sinD(f2) * d2, y2 = y1 - cosD(f2) * d2;
            float x3 = x2 + sinD(f3) * d3, y3 = y2 - cosD(f3) * d3;
            float r1 = meshAngle(f1, rotB, p0, p1), r2 = meshAngle(f2, r1, p1, p2), r3 = meshAngle(f3, r2, p2, p3);
            dot(c, bx + 0.008f * R, by + 0.012f * R, 0.215f * R * sc, 0xFF000000, 0.35f * gA);
            drawMoveGear(c, tG0, bx, by, rotB, sc, gA, 0);
            drawMoveGear(c, tG1, x1, y1, r1, sc, gA, 1);
            drawMoveGear(c, tG2, x2, y2, r2, sc, gA, 1);
            drawMoveGear(c, tG3, x3, y3, r3, sc, gA, 1);
        }
        if (cageA > 0.01f) {                                                   // the tourbillon: the whole cage turns once a minute
            float cs = outBack(seg(b, 0.54f, 0.78f));
            float turn = (float) ((td % 60.0) * 6.0) + (1f - cageA) * 300f + spin * 420f * (float) ((td * 0.35) % 1.0);
            float osc = (170f + 40f * spin) * sn(td, 1.1, 0.0);
            c.save();
            c.translate(0f, CAGE_Y * R);
            c.scale(cs, cs);
            sp.setStyle(Paint.Style.FILL);
            dot(c, 0f, 0f, 0.250f * R, 0xFF05060A, 0.85f * cageA);
            c.save();
            c.rotate(turn);
            ring(c, 0f, 0f, 0.205f * R, 0.020f * R, ROSE_M, cageA);
            ring(c, 0f, 0f, 0.205f * R, 0.006f * R, ROSE_L, cageA);
            for (int k = 0; k < 3; k++) {
                line(c, hx(0f, 0.04f * R, k * 120f), hy(0f, 0.04f * R, k * 120f), hx(0f, 0.195f * R, k * 120f), hy(0f, 0.195f * R, k * 120f), 0.026f * R, ROSE_D, cageA);
                line(c, hx(0f, 0.04f * R, k * 120f), hy(0f, 0.04f * R, k * 120f), hx(0f, 0.195f * R, k * 120f), hy(0f, 0.195f * R, k * 120f), 0.012f * R, ROSE_L, cageA);
                dot(c, hx(0f, 0.205f * R, k * 120f + 60f), hy(0f, 0.205f * R, k * 120f + 60f), 0.018f * R, STEEL, cageA);
            }
            // the escape wheel rides in the cage
            c.save();
            c.translate(hx(0f, 0.10f * R, 40f), hy(0f, 0.10f * R, 40f));
            c.rotate((float) (td * 40.0));
            int n = 0;
            for (int i = 0; i < 15; i++) {
                buf[n++] = hx(0f, 0.034f * R, i * 24f);
                buf[n++] = hy(0f, 0.034f * R, i * 24f);
                buf[n++] = hx(0f, 0.062f * R, i * 24f + 8f);
                buf[n++] = hy(0f, 0.062f * R, i * 24f + 8f);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1f, 0.010f * R));
            pt.setColor(al(ROSE_L, cageA));
            c.drawLines(buf, 0, n, pt);
            dot(c, 0f, 0f, 0.020f * R, RUBY, cageA);
            c.restore();
            // the balance wheel beats to and fro with its hairspring
            c.save();
            c.translate(hx(0f, 0.03f * R, 220f), hy(0f, 0.03f * R, 220f));
            c.rotate(osc);
            strokePath(c, tSpiral, 0.004f * R, 0xFF9FC0E8, 0.9f * cageA);
            ring(c, 0f, 0f, 0.100f * R, 0.014f * R, GOLD_M, cageA);
            line(c, -0.098f * R, 0f, 0.098f * R, 0f, 0.008f * R, GOLD_D, cageA);
            for (int k = 0; k < 4; k++) dot(c, hx(0f, 0.100f * R, k * 90f + 45f), hy(0f, 0.100f * R, k * 90f + 45f), 0.012f * R, GOLD_H, cageA);
            dot(c, 0f, 0f, 0.016f * R, RUBY, cageA);
            c.restore();
            c.restore();
            c.restore();
            arc(c, 0f, CAGE_Y * R, 0.268f * R, 215f, 50f, 0.016f * R, 0xFFFFFFFF, 0.16f * cageA);   // sapphire glare on the window
        }
        // a power reserve gauge on the right, its needle at the battery level
        float pa = seg(b, 0.66f, 0.84f);
        if (pa > 0.01f) {
            c.save();
            c.translate(0.47f * R, -0.20f * R);
            arc(c, 0.15f * R, -55f, 110f, 0.020f * R, 0xFF000000, 0.5f * pa);
            arc(c, 0.15f * R, -55f, 110f, 0.008f * R, ROSE_M, pa);
            int n = 0;
            for (int k = 0; k <= 4; k++) {
                float ang = -55f + 27.5f * k;
                buf[n++] = hx(0f, 0.125f * R, ang);
                buf[n++] = hy(0f, 0.125f * R, ang);
                buf[n++] = hx(0f, 0.15f * R, ang);
                buf[n++] = hy(0f, 0.15f * R, ang);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1f, 0.006f * R));
            pt.setColor(al(ROSE_L, pa));
            c.drawLines(buf, 0, n, pt);
            float na = -55f + 110f * pct / 100f;
            line(c, 0f, 0f, hx(0f, 0.14f * R, na), hy(0f, 0.14f * R, na), 0.010f * R, charging ? 0xFF7CFFB0 : ROSE_L, pa);
            dot(c, 0f, 0f, 0.018f * R, 0xFF2A2024, pa);
            c.restore();
        }
        // the date window: it slides open at three o'clock and the number rolls to today
        if (tk >= 0f) {
            float open = outBack(seg(tk, 0.1f, 0.8f)) * (1f - seg(tk, 4.2f, 5.0f));
            if (open > 0.01f) {
                float hw = 0.215f * R, hh = 0.095f * R * Math.min(1f, open);
                c.save();
                c.translate(0.60f * R, 0f);
                rc.set(-hw, -hh, hw, hh);
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(0xFF07080C, 0.94f));
                c.drawRoundRect(rc, 0.03f * R, 0.03f * R, pt);
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(Math.max(1.5f, 0.016f * R));
                pt.setColor(al(ROSE_M, 1f));
                c.drawRoundRect(rc, 0.03f * R, 0.03f * R, pt);
                pt.setStrokeWidth(Math.max(1f, 0.005f * R));
                pt.setColor(al(ROSE_L, 0.9f));
                c.drawRoundRect(rc, 0.03f * R, 0.03f * R, pt);
                if (open > 0.7f) {
                    float e = seg(tk, 0.9f, 2.0f), fa = seg(open, 0.7f, 1f);
                    c.save();
                    c.clipRect(-hw + 0.02f * R, -hh + 0.01f * R, hw - 0.02f * R, hh - 0.01f * R);
                    text(c, DAYS[tapWd], -0.105f * R, 0.030f * R, 0.082f * R, SANS, ROSE_L, fa, null);
                    float step = 0.17f * R;
                    text(c, prevStr, 0.115f * R, 0.052f * R - e * step, 0.150f * R, SANS, 0xFFFFFFFF, 0.9f * fa * (1f - e), null);
                    text(c, dayStr, 0.115f * R, 0.052f * R + (1f - e) * step, 0.150f * R, SANS, 0xFFFFFFFF, fa * (0.2f + 0.8f * e), null);
                    c.restore();
                }
                c.restore();
            }
        }
        c.restore();
    }

    private void tourHands(Canvas c, float hDeg, float mDeg, float sDeg, float sa, float k, double td, long now) {
        float R = r;
        for (int hnd = 0; hnd < 2; hnd++) {
            Path p = hnd == 0 ? tHour : tMin;
            c.save();
            c.translate(cx + 0.010f * R, cy + 0.016f * R);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, p, 0xFF000000, 0.35f * k);
            c.restore();
            c.save();
            c.translate(cx, cy);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, p, 0xFF0F1A1C, 0.55f * k);
            float len = hnd == 0 ? 0.40f : 0.70f;
            line(c, 0f, -len * R, 0f, -(hnd == 0 ? 0.12f : 0.14f) * R, hnd == 0 ? 0.030f * R : 0.020f * R, 0xFF9CFFE0, 0.55f * k);   // lume
            strokePath(c, p, 0.010f * R, ROSE_M, k);
            strokePath(c, p, 0.003f * R, ROSE_L, k);
            c.restore();
        }
        dot(c, cx, cy, 0.050f * R, 0xFF2A2024, k);
        dot(c, cx, cy, 0.036f * R, ROSE_M, k);
        dot(c, cx, cy, 0.018f * R, ROSE_L, k);
        dot(c, cx, cy, 0.008f * R, RUBY, k);
        if (sa > 0.02f) {                                                    // a bright spark rides the track as the seconds
            float x = hx(cx, 0.865f * R, sDeg), y = hy(cy, 0.865f * R, sDeg);
            dot(c, x, y, 0.040f * R, ROSE_L, 0.30f * sa * k);
            dot(c, x, y, 0.016f * R, 0xFFFFFFFF, sa * k);
        }
        arc(c, cx, cy, 0.84f * R, 215f, 60f, 0.040f * R, 0xFFFFFFFF, 0.05f * k);
        arc(c, cx, cy, 0.78f * R, 225f, 36f, 0.014f * R, 0xFFFFFFFF, 0.10f * k);
    }

    // =====================================================================================================
    // 8  Celestial Observatory
    // =====================================================================================================

    private final Path cMoon = new Path(), cHour = new Path(), cMin = new Path();
    private RadialGradient cSky;
    private final float[] cStar = new float[240];
    private float moonPhase = -1f;
    private long moonStamp = -1L;
    private static final float MOON_Y = 0.46f, MOON_R = 0.19f;
    // two small constellations inside the dial, in units of the radius
    private static final float[] CON = {-0.66f, -0.30f, -0.52f, -0.44f, -0.34f, -0.40f, -0.22f, -0.54f, -0.04f, -0.62f, 0.14f, -0.52f, 0.30f, -0.60f,
            0.52f, -0.06f, 0.62f, 0.12f, 0.50f, 0.28f, 0.66f, 0.40f};
    private static final int[] CON_LEN = {7, 4};

    private void buildCelestial() {
        float R = r;
        for (int i = 0; i < 120; i++) {
            cStar[2 * i] = star[3 * i] * R;
            cStar[2 * i + 1] = star[3 * i + 1] * R;
        }
        cHour.rewind();
        cHour.moveTo(0f, -0.52f * R);
        cHour.lineTo(0.026f * R, -0.40f * R);
        cHour.lineTo(0.012f * R, -0.34f * R);
        cHour.lineTo(0.012f * R, 0.09f * R);
        cHour.lineTo(-0.012f * R, 0.09f * R);
        cHour.lineTo(-0.012f * R, -0.34f * R);
        cHour.lineTo(-0.026f * R, -0.40f * R);
        cHour.close();
        cMin.rewind();
        cMin.moveTo(0f, -0.80f * R);
        cMin.lineTo(0.011f * R, -0.70f * R);
        cMin.lineTo(0.011f * R, 0.10f * R);
        cMin.lineTo(-0.011f * R, 0.10f * R);
        cMin.lineTo(-0.011f * R, -0.70f * R);
        cMin.close();
        cSky = new RadialGradient(0f, 0f, 0.93f * R, new int[]{0xFF1B2257, 0xFF0C1033, 0xFF03041A}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        moonStamp = -1L;
    }

    /** Moon phase 0..1 from the date (0 new, 0.5 full), using a known new moon and the mean synodic month. */
    private static float phaseAt(long now) {
        double days = (now - 947_182_440_000L) / 86_400_000.0;
        double p = (days % 29.530588853) / 29.530588853;
        return (float) (p < 0 ? p + 1.0 : p);
    }

    private void moonPath(float phase) {
        float p = phase < 0.5f ? phase : 1f - phase;
        float cs = (float) Math.cos(p * TAU), xr = Math.abs(cs);
        cMoon.rewind();
        rc.set(-1f, -1f, 1f, 1f);
        cMoon.arcTo(rc, -90f, 180f, true);
        rc.set(-xr, -1f, xr, 1f);
        if (cs > 0f) cMoon.arcTo(rc, 90f, -180f, false);
        else cMoon.arcTo(rc, 90f, 180f, false);
        cMoon.close();
    }

    private void moonRead(long now) {
        float ph = phaseAt(now);
        float illum = (1f - (float) Math.cos(ph * TAU)) / 2f;
        String nm = ph < 0.03f || ph > 0.97f ? "NEW MOON" : ph < 0.22f ? "WAXING CRESCENT" : ph < 0.28f ? "FIRST QUARTER" : ph < 0.47f ? "WAXING GIBBOUS"
                : ph < 0.53f ? "FULL MOON" : ph < 0.72f ? "WANING GIBBOUS" : ph < 0.78f ? "LAST QUARTER" : "WANING CRESCENT";
        moonName = nm;
        moonLine = nm + "  " + Math.round(illum * 100f) + "%";
    }

    /** A narrow four-pointed flare that sparkles. */
    private void flare(Canvas c, float x, float y, float s, int color, float alpha) {
        line(c, x - s, y, x + s, y, s * 0.12f, color, alpha);
        line(c, x, y - s, x, y + s, s * 0.12f, color, alpha);
        dot(c, x, y, s * 0.20f, 0xFFFFFFFF, alpha);
    }

    private void celArt(Canvas c, float b) {
        c.save();
        c.translate(cx, cy);
        float R = r;
        float rimT = seg(b, 0.03f, 0.28f), skyT = seg(b, 0.08f, 0.36f);
        if (rimT > 0.002f) {
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.BUTT);
            sp.setStrokeWidth(0.075f * R);
            sp.setShader(pGold);
            sp.setColor(0xFFFFFFFF);
            rc.set(-0.98f * R, -0.98f * R, 0.98f * R, 0.98f * R);
            c.drawArc(rc, -90f, 360f * rimT, false, sp);
            sp.setShader(null);
            sp.setStrokeCap(Paint.Cap.ROUND);
            ring(c, 0f, 0f, 1.017f * R, 0.006f * R, 0xFF1A1204, rimT);
            ring(c, 0f, 0f, 0.942f * R, 0.006f * R, 0xFF1A1204, rimT);
        }
        if (skyT > 0.002f) {
            sp.setStyle(Paint.Style.FILL);
            sp.setShader(cSky);
            sp.setColor(al(0xFFFFFFFF, skyT));
            c.drawCircle(0f, 0f, 0.935f * R * (0.9f + 0.1f * skyT), sp);
            sp.setShader(null);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1.5f, 0.010f * R));
            pt.setColor(al(0xFFDCE6FF, 0.55f * skyT));
            c.drawPoints(cStar, 0, 240, pt);
            ring(c, 0f, 0f, 0.885f * R, 0.004f * R, GOLD_M, 0.8f * skyT);
            ring(c, 0f, 0f, 0.775f * R, 0.004f * R, GOLD_M, 0.6f * skyT);
        }
        // degree ticks and twelve little stars, stamped round the rim
        int n = 0;
        for (int i = 0; i < 72; i++) {
            float ti = seg(b, 0.30f + i * 0.0015f, 0.42f + i * 0.0015f);
            if (ti < 0.01f) continue;
            buf[n++] = hx(0f, 0.885f * R, i * 5f);
            buf[n++] = hy(0f, 0.885f * R, i * 5f);
            buf[n++] = hx(0f, (0.885f - (i % 6 == 0 ? 0.040f : 0.020f) * ti) * R, i * 5f);
            buf[n++] = hy(0f, (0.885f - (i % 6 == 0 ? 0.040f : 0.020f) * ti) * R, i * 5f);
        }
        pt.setStyle(Paint.Style.STROKE);
        pt.setStrokeWidth(Math.max(1f, 0.005f * R));
        pt.setColor(al(GOLD_L, 0.85f));
        c.drawLines(buf, 0, n, pt);
        for (int i = 0; i < 12; i++) {
            float ai = seg(b, 0.38f + i * 0.02f, 0.52f + i * 0.02f);
            if (ai < 0.01f) continue;
            float big = (i % 3 == 0 ? 0.060f : 0.040f) * R * outBack(ai);
            flare(c, hx(0f, 0.825f * R, i * 30f), hy(0f, 0.825f * R, i * 30f), big, GOLD_L, ai);
        }
        // the window for the moon
        float wT = seg(b, 0.40f, 0.60f);
        if (wT > 0.01f) {
            ring(c, 0f, MOON_Y * R, (MOON_R + 0.030f) * R, 0.036f * R, GOLD_D, wT);
            ring(c, 0f, MOON_Y * R, (MOON_R + 0.030f) * R, 0.020f * R, GOLD_M, wT);
            ring(c, 0f, MOON_Y * R, (MOON_R + 0.020f) * R, 0.004f * R, GOLD_H, 0.8f * wT);
            ring(c, 0f, MOON_Y * R, (MOON_R + 0.043f) * R, 0.004f * R, 0xFF000000, 0.6f * wT);
        }
        c.restore();
    }

    private void celLive(Canvas c, float b, double td, long now) {
        float R = r;
        float tk = tk(FIRST + 3, now);
        c.save();
        c.clipPath(disc);
        c.translate(cx, cy);

        // stars twinkle in three groups
        float sa = seg(b, 0.30f, 0.50f);
        if (sa > 0.01f) {
            pt.setStyle(Paint.Style.STROKE);
            for (int g = 0; g < 3; g++) {
                float tw = 0.25f + 0.75f * (0.5f + 0.5f * sn(td, 2.4 + g * 1.1, g * 2.3));
                pt.setStrokeWidth(Math.max(1.8f, (0.011f + 0.004f * g) * R));
                pt.setColor(al(g == 1 ? 0xFFFFE8B0 : 0xFFFFFFFF, 0.95f * tw * sa));
                c.drawPoints(cStar, g * 80, 80, pt);
            }
        }
        // an armillary of two turning rings round the middle of the dial
        float arm = outBack(seg(b, 0.46f, 0.74f)), armA = seg(b, 0.46f, 0.62f);
        if (arm > 0.01f && armA > 0.01f) {
            for (int k = 0; k < 2; k++) {
                float th = (float) (td * 0.45 + k * 1.5708 + (1f - armA) * 3f);
                float sq = Math.max(0.06f, Math.abs((float) Math.cos(th)));
                float rad = 0.50f * R * arm;
                c.save();
                c.rotate(k == 0 ? 24f : -24f);
                rc.set(-rad, -rad * sq, rad, rad * sq);
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(Math.max(1.4f, 0.016f * R));
                pt.setColor(al(GOLD_D, 0.9f * armA));
                c.drawOval(rc, pt);
                pt.setStrokeWidth(Math.max(1f, 0.006f * R));
                pt.setColor(al(GOLD_H, 0.95f * armA));
                c.drawOval(rc, pt);
                c.restore();
            }
            ring(c, 0f, 0f, 0.50f * R * arm, 0.004f * R, GOLD_M, 0.45f * armA);
        }
        // the day track: the sun and the moon travel round it through the day
        float dayT = seg(b, 0.58f, 0.82f);
        if (dayT > 0.01f) {
            float ang = (dayFrac(now) - 0.5f) * 360f;
            ring(c, 0f, 0f, 0.675f * R, 0.004f * R, GOLD_M, 0.7f * dayT);
            float sx = hx(0f, 0.675f * R, ang), sy = hy(0f, 0.675f * R, ang);
            dot(c, sx, sy, 0.085f * R, 0xFFFFD27A, 0.20f * dayT);
            for (int k = 0; k < 8; k++) line(c, hx(sx, 0.050f * R, k * 45f), hy(sy, 0.050f * R, k * 45f), hx(sx, 0.078f * R, k * 45f), hy(sy, 0.078f * R, k * 45f), 0.008f * R, 0xFFFFD27A, dayT);
            dot(c, sx, sy, 0.040f * R, 0xFFFFC040, dayT);
            dot(c, sx, sy, 0.024f * R, 0xFFFFF0B0, dayT);
            float mx = hx(0f, 0.675f * R, ang + 180f), my = hy(0f, 0.675f * R, ang + 180f);
            dot(c, mx, my, 0.036f * R, 0xFFE9ECFF, dayT);
            dot(c, mx + 0.016f * R, my - 0.008f * R, 0.030f * R, 0xFF0C1033, dayT);
        }
        // the moon, with its real phase
        float mA = seg(b, 0.52f, 0.72f);
        if (mA > 0.01f) {
            if (moonStamp < 0L || now - moonStamp > 600_000L) {
                moonPhase = phaseAt(now);
                moonPath(moonPhase);
                moonStamp = now;
            }
            float grow = 1f, glow = 0f;
            if (tk >= 0f) {
                grow = 1f + 0.40f * seg(tk, 0.1f, 0.9f) * (1f - seg(tk, 4.2f, 5.2f));
                glow = seg(tk, 0.1f, 0.9f) * (1f - seg(tk, 4.2f, 5.2f));
            }
            c.save();
            c.translate(0f, MOON_Y * R);
            c.scale(grow, grow);
            if (glow > 0.01f) {
                dot(c, 0f, 0f, 0.38f * R, 0xFFBFD0FF, 0.16f * glow);
                dot(c, 0f, 0f, 0.28f * R, 0xFFDCE6FF, 0.18f * glow * (0.7f + 0.3f * (float) Math.sin(tk * 5f)));
            }
            dot(c, 0f, 0f, MOON_R * R, 0xFF0A0D26, mA);
            c.save();
            c.scale(MOON_R * R * mA, MOON_R * R * mA);
            if (moonPhase > 0.5f) c.scale(-1f, 1f);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFF1E9CE, 1f));
            c.drawPath(cMoon, pt);
            c.restore();
            dot(c, -0.05f * R, -0.04f * R, 0.030f * R, 0xFF8A8466, 0.22f * mA);
            dot(c, 0.06f * R, 0.03f * R, 0.020f * R, 0xFF8A8466, 0.22f * mA);
            dot(c, -0.02f * R, 0.08f * R, 0.014f * R, 0xFF8A8466, 0.22f * mA);
            ring(c, 0f, 0f, MOON_R * R, 0.004f * R, 0xFF9AA8FF, 0.5f * mA);
            c.restore();
        }
        // tap: constellations are drawn star to star, meteors cross the dial, the phase is read out
        if (tk >= 0f) {
            float env = seg(tk, 0f, 0.3f) * (1f - seg(tk, 4.4f, 5.4f));
            int o = 0;
            for (int g = 0; g < CON_LEN.length; g++) {
                int len = CON_LEN[g];
                for (int i = 0; i < len; i++) {
                    float t0 = 0.3f + i * 0.28f + g * 0.5f, ai = seg(tk, t0, t0 + 0.35f);
                    float x = CON[2 * (o + i)] * R, y = CON[2 * (o + i) + 1] * R;
                    if (i > 0 && ai > 0f) {
                        float px = CON[2 * (o + i - 1)] * R, py = CON[2 * (o + i - 1) + 1] * R;
                        line(c, px, py, px + (x - px) * ai, py + (y - py) * ai, 0.006f * R, 0xFFBFD0FF, 0.8f * env);
                    }
                    if (ai > 0.01f) flare(c, x, y, (0.030f + 0.022f * (float) Math.sin(Math.PI * clamp01((tk - t0) / 0.7f))) * R, 0xFFFFF0C0, ai * env);
                }
                o += len;
            }
            for (int k = 0; k < 3; k++) {
                float t0 = 0.5f + k * 0.9f, f = (tk - t0) / 1.1f;
                if (f <= 0f || f >= 1f) continue;
                float x0 = (0.75f - 0.2f * k) * R, y0 = (-0.55f + 0.18f * k) * R, dx = -1.1f * R, dy = 0.62f * R;
                for (int j = 0; j < 7; j++) {
                    float fj = f - j * 0.035f;
                    if (fj < 0f) break;
                    dot(c, x0 + dx * fj, y0 + dy * fj, (0.018f - j * 0.002f) * R, j == 0 ? 0xFFFFFFFF : 0xFFBFD0FF, (1f - j * 0.14f) * (float) Math.sin(Math.PI * f) * env);
                }
            }
            float la = seg(tk, 0.8f, 1.6f) * (1f - seg(tk, 4.3f, 5.2f));
            if (la > 0.01f) text(c, moonLine, 0f, 0.775f * R, 0.054f * R, SERIF_B, GOLD_L, la, null);
        }
        c.restore();
    }

    private void celHands(Canvas c, float hDeg, float mDeg, float sDeg, float sa, float k, double td, long now) {
        float R = r;
        for (int hnd = 0; hnd < 2; hnd++) {
            Path p = hnd == 0 ? cHour : cMin;
            c.save();
            c.translate(cx + 0.010f * R, cy + 0.016f * R);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, p, 0xFF000000, 0.38f * k);
            c.restore();
            c.save();
            c.translate(cx, cy);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, p, GOLD_M, k);
            strokePath(c, p, 0.005f * R, 0xFF4A3008, k);
            if (hnd == 0) {
                arc(c, 0f, -0.40f * R, 0.050f * R, 90f, 180f, 0.014f * R, GOLD_H, k);
                line(c, 0f, -0.48f * R, 0f, -0.34f * R, 0.006f * R, GOLD_H, k);
            } else {
                flare(c, 0f, -0.70f * R, 0.060f * R, GOLD_H, k);
                line(c, 0f, -0.62f * R, 0f, -0.08f * R, 0.005f * R, GOLD_H, 0.8f * k);
            }
            c.restore();
        }
        if (sa > 0.02f) {                                                    // a little comet on the rim marks the seconds
            for (int i = 6; i >= 1; i--) dot(c, hx(cx, 0.885f * R, sDeg - i * 4f), hy(cy, 0.885f * R, sDeg - i * 4f), (0.016f - i * 0.0018f) * R, 0xFFBFD0FF, 0.8f * sa * k * (1f - i / 7f));
            dot(c, hx(cx, 0.885f * R, sDeg), hy(cy, 0.885f * R, sDeg), 0.036f * R, 0xFF9AA8FF, 0.35f * sa * k);
            dot(c, hx(cx, 0.885f * R, sDeg), hy(cy, 0.885f * R, sDeg), 0.016f * R, 0xFFFFFFFF, sa * k);
        }
        dot(c, cx, cy, 0.046f * R, 0xFF2A1A04, k);
        dot(c, cx, cy, 0.032f * R, GOLD_M, k);
        dot(c, cx, cy, 0.016f * R, GOLD_H, k);
        arc(c, cx, cy, 0.84f * R, 215f, 60f, 0.040f * R, 0xFFFFFFFF, 0.05f * k);
    }

    // =====================================================================================================
    // 9  Royal Diamond
    // =====================================================================================================

    private final Path dGem = new Path(), dGemL = new Path(), dHour = new Path(), dHourL = new Path(), dMin = new Path(), dMinL = new Path();
    private SweepGradient dSun;
    private static final int[] RAINBOW = {0xFFFF6FA8, 0xFFFFC857, 0xFF7CFFB0, 0xFF6FD6FF, 0xFFA98BFF, 0xFFFFFFFF};

    private void buildDiamond() {
        float R = r;
        for (int k = 0; k < 2; k++) {                                          // a baguette stone pointing out from the centre
            Path g = k == 0 ? dGem : dGemL;
            float len = (k == 0 ? 0.105f : 0.150f) * R, wd = (k == 0 ? 0.030f : 0.040f) * R;
            g.rewind();
            g.moveTo(0f, -len);
            g.lineTo(wd, -len * 0.35f);
            g.lineTo(wd, len * 0.35f);
            g.lineTo(0f, len);
            g.lineTo(-wd, len * 0.35f);
            g.lineTo(-wd, -len * 0.35f);
            g.close();
        }
        for (int hnd = 0; hnd < 2; hnd++) {                                    // dauphine hands: a whole blade and its shaded half
            float len = hnd == 0 ? 0.50f : 0.80f, wd = hnd == 0 ? 0.040f : 0.030f, back = hnd == 0 ? 0.09f : 0.11f;
            Path p = hnd == 0 ? dHour : dMin, q = hnd == 0 ? dHourL : dMinL;
            p.rewind();
            p.moveTo(0f, -len * R);
            p.lineTo(wd * R, -len * 0.30f * R);
            p.lineTo(wd * 0.55f * R, back * R);
            p.lineTo(-wd * 0.55f * R, back * R);
            p.lineTo(-wd * R, -len * 0.30f * R);
            p.close();
            q.rewind();
            q.moveTo(0f, -len * R);
            q.lineTo(-wd * R, -len * 0.30f * R);
            q.lineTo(-wd * 0.55f * R, back * R);
            q.lineTo(0f, back * R);
            q.close();
        }
        int[] cols = new int[33];
        float[] st = new float[33];
        for (int j = 0; j < 33; j++) {
            cols[j] = j % 2 == 0 ? EMER_D : 0xFF0E8A62;
            st[j] = j / 32f;
        }
        dSun = new SweepGradient(0f, 0f, cols, st);
    }

    private void diaArt(Canvas c, float b) {
        c.save();
        c.translate(cx, cy);
        float R = r;
        float rimT = seg(b, 0.02f, 0.28f), plateT = seg(b, 0.10f, 0.36f);
        if (rimT > 0.002f) {
            sp.setStyle(Paint.Style.STROKE);
            sp.setStrokeCap(Paint.Cap.BUTT);
            sp.setStrokeWidth(0.10f * R);
            sp.setShader(pGold);
            sp.setColor(0xFFFFFFFF);
            rc.set(-0.965f * R, -0.965f * R, 0.965f * R, 0.965f * R);
            c.drawArc(rc, -90f, 360f * rimT, false, sp);
            sp.setShader(null);
            sp.setStrokeCap(Paint.Cap.ROUND);
            ring(c, 0f, 0f, 1.017f * R, 0.006f * R, 0xFF2A1A04, rimT);
            ring(c, 0f, 0f, 0.913f * R, 0.006f * R, 0xFF2A1A04, rimT);
        }
        for (int i = 0; i < 36; i++) {                                         // a ring of stones set in the bezel
            float ai = seg(b, 0.20f + i * 0.004f, 0.34f + i * 0.004f);
            if (ai < 0.01f) continue;
            float x = hx(0f, 0.965f * R, i * 10f), y = hy(0f, 0.965f * R, i * 10f), s = 0.024f * R * outBack(ai);
            dot(c, x, y, s * 1.35f, 0xFF3A2606, ai);
            dot(c, x, y, s, 0xFFEFFFF8, ai);
            dot(c, x, y, s * 0.55f, 0xFFBFE8FF, ai);
            line(c, x - s * 0.7f, y, x + s * 0.7f, y, s * 0.12f, 0xFFFFFFFF, 0.9f * ai);
            line(c, x, y - s * 0.7f, x, y + s * 0.7f, s * 0.12f, 0xFFFFFFFF, 0.9f * ai);
        }
        if (plateT > 0.002f) {                                                 // an emerald sunburst dial, engine-turned
            sp.setStyle(Paint.Style.FILL);
            sp.setShader(dSun);
            sp.setColor(al(0xFFFFFFFF, plateT));
            c.drawCircle(0f, 0f, 0.905f * R * (0.9f + 0.1f * plateT), sp);
            sp.setShader(null);
            for (int k = 0; k < 36; k++) {
                float ai = seg(b, 0.26f + k * 0.005f, 0.40f + k * 0.005f);
                if (ai < 0.01f) continue;
                ring(c, hx(0f, 0.30f * R, k * 10f), hy(0f, 0.30f * R, k * 10f), 0.40f * R, 0.004f * R, 0xFFFFFFFF, 0.05f * ai);
            }
            for (int k = 0; k < 3; k++) ring(c, 0f, 0f, (0.30f + 0.20f * k) * R, 0.004f * R, 0xFF000000, 0.18f * plateT);
            ring(c, 0f, 0f, 0.795f * R, 0.004f * R, GOLD_L, 0.8f * plateT);
            ring(c, 0f, 0f, 0.885f * R, 0.004f * R, GOLD_L, 0.6f * plateT);
            int n = 0;
            for (int i = 0; i < 60; i++) {
                if (i % 5 == 0) continue;
                buf[n++] = hx(0f, 0.84f * R, i * 6f);
                buf[n++] = hy(0f, 0.84f * R, i * 6f);
            }
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(Math.max(1.4f, 0.008f * R));
            pt.setColor(al(0xFFEFFFF8, 0.8f * plateT));
            c.drawPoints(buf, 0, n, pt);
        }
        // twelve baguette diamonds, one after another from twelve
        for (int i = 0; i < 12; i++) {
            float ai = seg(b, 0.44f + i * 0.025f, 0.58f + i * 0.025f);
            if (ai < 0.01f) continue;
            boolean big = i % 3 == 0;
            Path g = big ? dGemL : dGem;
            float sc = outBack(ai);
            c.save();
            c.translate(hx(0f, 0.70f * R, i * 30f), hy(0f, 0.70f * R, i * 30f));
            c.rotate(i * 30f);
            c.scale(sc, sc);
            fillPath(c, g, 0xFF3A2606, ai);
            c.save();
            c.scale(0.86f, 0.90f);
            fillPath(c, g, 0xFFEFFFF8, ai);
            c.restore();
            float len = (big ? 0.150f : 0.105f) * R * 0.9f, wd = (big ? 0.040f : 0.030f) * R * 0.86f;
            line(c, 0f, -len, 0f, len, Math.max(1f, wd * 0.12f), 0xFF9ADCF0, 0.9f * ai);
            line(c, -wd, -len * 0.30f, wd, -len * 0.30f, Math.max(1f, wd * 0.12f), 0xFF9ADCF0, 0.8f * ai);
            line(c, -wd, len * 0.30f, wd, len * 0.30f, Math.max(1f, wd * 0.12f), 0xFF9ADCF0, 0.8f * ai);
            strokePath(c, g, Math.max(1.4f, wd * 0.20f), GOLD_M, ai);
            c.restore();
        }
        c.restore();
    }

    private void diaLive(Canvas c, float b, double td, long now) {
        float R = r;
        float tk = tk(FIRST + 4, now);
        float vis = seg(b, 0.55f, 0.80f);
        c.save();
        c.clipPath(disc);
        c.translate(cx, cy);
        // light sweeps across the dial now and then
        float g = (float) ((td % 7.0) / 1.6);
        if (g < 1f && vis > 0.3f) {
            c.save();
            c.rotate(32f);
            float gx = (-1.3f + 2.6f * smooth(g)) * R, fa = (float) Math.sin(Math.PI * g) * vis;
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(al(0xFFD8FFF0, 0.07f * fa));
            c.drawRect(gx - 0.26f * R, -1.3f * R, gx + 0.26f * R, 1.3f * R, pt);
            pt.setColor(al(0xFFFFFFFF, 0.14f * fa));
            c.drawRect(gx - 0.08f * R, -1.3f * R, gx + 0.08f * R, 1.3f * R, pt);
            c.restore();
        }
        c.restore();
        c.save();
        c.translate(cx, cy);
        // stones catch the light: a few of the bezel stones and baguettes flare in turn
        if (vis > 0.01f) {
            long step = (long) Math.floor(td * 2.5);
            for (int k = 0; k < 4; k++) {
                float f = (float) (td * 2.5 - step), fa = (float) Math.sin(Math.PI * f);
                int i = (int) (hash((int) step * 7 + k * 13) * 36f) % 36;
                flare(c, hx(0f, 0.965f * R, i * 10f), hy(0f, 0.965f * R, i * 10f), (0.030f + 0.050f * fa) * R, RAINBOW[(i + k) % 6], 0.9f * fa * vis);
            }
        }
        // tap: a wave of brilliance runs round the bezel and the baguettes, the time is written in words
        if (tk >= 0f) {
            float env = seg(tk, 0f, 0.2f) * (1f - seg(tk, 4.0f, 4.6f));
            for (int wv = 0; wv < 2; wv++) {
                float head = (tk - wv * 1.1f) * 170f;
                if (head < 0f || head > 420f) continue;
                for (int i = 0; i < 36; i++) {
                    float d = head - i * 10f;
                    if (d < 0f || d > 60f) continue;
                    float f = 1f - d / 60f;
                    flare(c, hx(0f, 0.965f * R, i * 10f), hy(0f, 0.965f * R, i * 10f), (0.030f + 0.070f * f) * R, RAINBOW[i % 6], f * env);
                }
                for (int i = 0; i < 12; i++) {
                    float d = head - i * 30f;
                    if (d < 0f || d > 70f) continue;
                    float f = 1f - d / 70f;
                    dot(c, hx(0f, 0.70f * R, i * 30f), hy(0f, 0.70f * R, i * 30f), 0.09f * R, RAINBOW[(i + 2) % 6], 0.30f * f * env);
                    flare(c, hx(0f, 0.70f * R, i * 30f), hy(0f, 0.70f * R, i * 30f), 0.07f * R * f, 0xFFFFFFFF, f * env);
                }
            }
            float wa = seg(tk, 0.5f, 1.0f) * (1f - seg(tk, 3.8f, 4.5f));
            if (wa > 0.01f) {
                tp.setTypeface(SERIF_I);
                tp.setTextSize(0.098f * R);
                float tw = tp.measureText(words), pad = 0.10f * R;
                rc.set(-tw / 2f - pad, 0.265f * R, tw / 2f + pad, 0.445f * R);
                pt.setStyle(Paint.Style.FILL);
                pt.setColor(al(0xFF021A12, 0.70f * wa));
                c.drawRoundRect(rc, 0.05f * R, 0.05f * R, pt);
                pt.setStyle(Paint.Style.STROKE);
                pt.setStrokeWidth(Math.max(1f, 0.006f * R));
                pt.setColor(al(GOLD_L, 0.9f * wa));
                c.drawRoundRect(rc, 0.05f * R, 0.05f * R, pt);
                float wipe = seg(tk, 0.6f, 1.9f);
                c.save();
                c.clipRect(-tw / 2f - pad, 0.25f * R, -tw / 2f - pad + (tw + 2f * pad) * wipe, 0.46f * R);
                text(c, words, 0f, 0.372f * R, 0.098f * R, SERIF_I, GOLD_H, wa, null);
                c.restore();
                if (wipe < 0.99f) line(c, -tw / 2f - pad + (tw + 2f * pad) * wipe, 0.28f * R, -tw / 2f - pad + (tw + 2f * pad) * wipe, 0.43f * R, 0.010f * R, 0xFFFFFFFF, 0.9f * wa);
            }
        }
        c.restore();
    }

    private void wordsOf(int hour, int min) {
        int idx = (min + 2) / 5;
        String[] past = {"", "Five past ", "Ten past ", "Quarter past ", "Twenty past ", "Twenty-five past ", "Half past "};
        String[] to = {"Twenty-five to ", "Twenty to ", "Quarter to ", "Ten to ", "Five to "};
        if (idx == 0) words = HOUR_WORD[hour % 12] + " o\u2019clock";
        else if (idx <= 6) words = past[idx] + HOUR_WORD[hour % 12];
        else if (idx < 12) words = to[idx - 7] + HOUR_WORD[(hour + 1) % 12];
        else words = HOUR_WORD[(hour + 1) % 12] + " o\u2019clock";
    }

    private void diaHands(Canvas c, float hDeg, float mDeg, float sDeg, float sa, float k, double td, long now) {
        float R = r;
        for (int hnd = 0; hnd < 2; hnd++) {
            Path p = hnd == 0 ? dHour : dMin, q = hnd == 0 ? dHourL : dMinL;
            c.save();
            c.translate(cx + 0.010f * R, cy + 0.016f * R);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, p, 0xFF000000, 0.40f * k);
            c.restore();
            c.save();
            c.translate(cx, cy);
            c.rotate(hnd == 0 ? hDeg : mDeg);
            c.scale(k, k);
            fillPath(c, p, GOLD_L, k);
            fillPath(c, q, GOLD_D, k);
            strokePath(c, p, 0.004f * R, 0xFF3A2606, k);
            line(c, 0f, -(hnd == 0 ? 0.48f : 0.78f) * R, 0f, 0.05f * R, 0.004f * R, GOLD_H, 0.9f * k);
            c.restore();
        }
        if (sa > 0.02f) {                                                    // a spark of light rides the chapter ring
            float x = hx(cx, 0.84f * R, sDeg), y = hy(cy, 0.84f * R, sDeg);
            dot(c, x, y, 0.040f * R, 0xFF7CFFD2, 0.30f * sa * k);
            flare(c, x, y, 0.040f * R, 0xFFFFFFFF, sa * k);
        }
        // the hub is a round brilliant stone
        dot(c, cx, cy, 0.056f * R, 0xFF3A2606, k);
        dot(c, cx, cy, 0.046f * R, 0xFFEFFFF8, k);
        for (int i = 0; i < 8; i++) line(c, hx(cx, 0.014f * R, i * 45f), hy(cy, 0.014f * R, i * 45f), hx(cx, 0.044f * R, i * 45f), hy(cy, 0.044f * R, i * 45f), 0.004f * R, 0xFF7ACCE8, 0.9f * k);
        dot(c, cx, cy, 0.016f * R, 0xFFBFEFFF, k);
        arc(c, cx, cy, 0.84f * R, 215f, 60f, 0.040f * R, 0xFFFFFFFF, 0.05f * k);
        arc(c, cx, cy, 0.78f * R, 225f, 36f, 0.014f * R, 0xFFFFFFFF, 0.10f * k);
    }
}
