package com.rimon.livingclock;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Plays the score of Director's Cut (see CutSound) on the system-sound stream, so it follows the ringer and the
 * system volume, stays silent in silent mode and is never mistaken for music by the bands. Each sound has a
 * haptic pattern timed to it: the cut-on pattern ticks with the three countdown beats and lands a heavy thump on the hit.
 */
final class Chime {

    static final int ARM = 0, CUT_ON = 1, CUT_OFF = 2;

    private static final long[][] TIMES = {
            {0, 12, 130, 22},
            {0, 24, 396, 24, 396, 28, 396, 130, 70, 60},
            {0, 60, 70, 30}};
    private static final int[][] AMPS = {
            {0, 110, 0, 170},
            {0, 150, 0, 190, 0, 230, 0, 255, 0, 110},
            {0, 255, 0, 90}};

    private final Context app;
    private final Handler main;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final short[][] bank = new short[3][];
    private final List<AudioTrack> playing = new ArrayList<>();
    private boolean building, released;

    Chime(Context c, Handler main) {
        this.app = c.getApplicationContext();
        this.main = main;
    }

    /** Renders the three sounds in the background so the first tap is instant. */
    void warm() {
        if (building || released || bank[0] != null) return;
        building = true;
        pool.execute(() -> {
            short[] a = null, b = null, c = null;
            try {
                a = CutSound.arm();
                b = CutSound.on();
                c = CutSound.off();
            } catch (RuntimeException | OutOfMemoryError e) {
                a = b = c = null;
            }
            final short[] fa = a, fb = b, fc = c;
            main.post(() -> {
                building = false;
                if (released || fa == null) return;
                bank[ARM] = fa;
                bank[CUT_ON] = fb;
                bank[CUT_OFF] = fc;
            });
        });
    }

    void play(int id) {
        if (released) return;
        buzz(id);
        short[] pcm = bank[id];
        if (pcm == null) {
            warm();
            return;
        }
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(CutSound.RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build();
            final AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(pcm.length * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            if (track.write(pcm, 0, pcm.length) <= 0) {
                track.release();
                return;
            }
            playing.add(track);
            track.play();
            long ms = pcm.length / 2L * 1000L / CutSound.RATE + 300L;
            main.postDelayed(() -> free(track), ms);
        } catch (RuntimeException e) {
            // No audio output right now: the picture still plays.
        }
    }

    /** Length of a sound in milliseconds (0 until it has been rendered). */
    long lengthMs(int id) {
        short[] p = bank[id];
        return p == null ? 0L : p.length / 2L * 1000L / CutSound.RATE;
    }

    private void free(AudioTrack t) {
        if (!playing.remove(t)) return;
        try {
            t.stop();
        } catch (RuntimeException ignored) {
            // Already stopped.
        }
        t.release();
    }

    void release() {
        released = true;
        for (AudioTrack t : new ArrayList<>(playing)) free(t);
        pool.shutdown();
    }

    @SuppressWarnings("deprecation")
    private void buzz(int id) {
        try {
            Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) {
                if (v.hasAmplitudeControl()) v.vibrate(VibrationEffect.createWaveform(TIMES[id], AMPS[id], -1));
                else v.vibrate(VibrationEffect.createWaveform(TIMES[id], -1));
            } else {
                v.vibrate(TIMES[id], -1);
            }
        } catch (RuntimeException ignored) {
            // No vibrator permission or hardware.
        }
    }
}
