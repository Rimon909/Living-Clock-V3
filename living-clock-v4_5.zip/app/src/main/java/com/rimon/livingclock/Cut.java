package com.rimon.livingclock;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

/**
 * Director's Cut, the hidden premium mode. Unlock: four taps on the clock (a camera viewfinder locks on for six
 * seconds), then two taps on the top centre of the cutout. Same combo to cut.
 *
 * Switching on plays a film leader, 3 - 2 - 1 on a dark frame with scratches and grain, then smashes into the
 * picture: letterbox bars slam in, an anamorphic flare streaks across, and the time becomes a movie-poster title
 * standing BEHIND you, huge condensed digits that land one by one. Then it stays a film: slow dolly (the photo
 * pushes in while you push the other way, so you float in front of it), teal and orange grade, grain, a drifting
 * light leak, a REC light, a running timecode, the seconds as a film progress line, a tagline, and credits that
 * carry the real battery and date. Each minute is a scene cut: the digits roll and a flash passes.
 */
final class Cut {

    static final long ARM_MS = 6000L;

    private static final long LEADER = 1260L, COUNT = 420L, QUIET_SKIP = LEADER + 100L, OFF_MS = 700L, ROLL = 520L;
    private static final int CREAM = 0xFFFFF1DC, GOLD = 0xFFE9B45A, RED = 0xFFE5383B;
    private static final String[] TAGS = {
            "EVERY SECOND IS A FRAME", "THE LONG TAKE", "NO REHEARSALS. NO RETAKES.",
            "TIME NEVER CUTS", "ONLY THE PRESENT IS LIVE", "THE STORY IS STILL BEING WRITTEN"};

    /** Wanted state. Saved by the renderer. */
    boolean on;

    /** 0..1: how much the normal clock should give way to the poster. */
    float hide;

    private long changedAt = -1L, armedAt = -1L, lastWake = -1L, lastMs = -1L, tickAt = -1L;
    private boolean quiet, inited;
    private int w, h, laidW, laidH;
    private float vis, t, kOff = 1f, barP, gradeK, leaderA, flash, tagA, dolly, cyIn;
    private final float[] rev = new float[4];
    private int pct = 100;
    private boolean charging;

    private final char[] now4 = new char[4], cur4 = new char[4], prev4 = new char[4];
    private final long[] chAt = new long[4];
    private final Calendar cal = Calendar.getInstance();
    private int dateDay = -1;
    private String dateText = "";
    private int tagIndex;
    private final StringBuilder sb = new StringBuilder(16);
    private final char[] glyph = new char[1];

    // title geometry
    private float digitH, cellW, gap, bTop, barH;
    private final float[] lineTop = new float[2];
    private float titleCy;

    private final Paint digit = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint();
    private final Paint barText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tint = new Paint();
    private final Paint leak = new Paint();
    private final Paint vig = new Paint();
    private final Paint streak = new Paint();
    private final Paint grain = new Paint();
    private final Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flashPaint = new Paint();
    private final RectF oval = new RectF();
    private final Rect tb = new Rect();
    private final Matrix gm = new Matrix();
    private BitmapShader grainShader;
    private final Random rnd = new Random();
    private LinearGradient streakShader, tintShader;
    private RadialGradient glowShader, leakShader, vigShader;

    Cut() {
        digit.setTextAlign(Paint.Align.CENTER);
        digit.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        shadow.setTextAlign(Paint.Align.CENTER);
        shadow.setTypeface(digit.getTypeface());
        shadow.setColor(Color.BLACK);
        barPaint.setColor(Color.BLACK);
        barText.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        barText.setColor(CREAM);
        barText.setLetterSpacing(0.22f);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        streak.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        leak.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        num.setTextAlign(Paint.Align.CENTER);
        num.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        num.setColor(0xFFF2EBDD);
        buildGrain();
    }

    // ---------- state ----------

    void arm(long now) {
        armedAt = now;
    }

    boolean armed(long now) {
        return armedAt >= 0 && now - armedAt < ARM_MS;
    }

    void disarm() {
        armedAt = -1L;
    }

    /** The unlock succeeded: the full show, on or off. Returns the new state. */
    boolean toggle(long now) {
        on = !on;
        changedAt = now;
        quiet = false;
        armedAt = -1L;
        return on;
    }

    /** Settings changed from outside (startup, the app): follow without the leader and the flash. */
    void sync(boolean want, long now) {
        if (want == on) return;
        on = want;
        changedAt = now;
        quiet = true;
    }

    /** The wallpaper woke up: the picture opens again with a short reveal (no leader), at most every few seconds. */
    void wake(long now) {
        if (!on || now - lastWake < 4000L) return;
        lastWake = now;
        changedAt = now;
        quiet = true;
    }

    boolean transition(long now) {
        if (changedAt < 0) return false;
        return now - changedAt < (on ? LEADER + 2200L : OFF_MS + 200L) || (tickAt >= 0 && now - tickAt < 700L);
    }

    boolean live(long now) {
        return on || kOff > 0.001f || armed(now);
    }

    // ---------- per frame ----------

    void step(long now, boolean enabled, int width, int height, float cy, int batteryPct, boolean isCharging) {
        w = width;
        h = height;
        cyIn = cy;
        pct = batteryPct;
        charging = isCharging;
        float dt = lastMs < 0 ? 0.016f : Math.min(0.1f, (now - lastMs) / 1000f);
        lastMs = now;
        if (w <= 0 || h <= 0) return;
        if (laidW != w || laidH != h) layout();

        float to = enabled ? 1f : 0f;
        vis += Math.max(-dt * 2f, Math.min(dt * 2f, to - vis));

        // the digits of the real time; a change rolls the digit and starts a scene-cut flash
        cal.setTimeInMillis(now);
        int hr = cal.get(Calendar.HOUR);
        if (hr == 0) hr = 12;
        int mn = cal.get(Calendar.MINUTE);
        now4[0] = (char) ('0' + hr / 10);
        now4[1] = (char) ('0' + hr % 10);
        now4[2] = (char) ('0' + mn / 10);
        now4[3] = (char) ('0' + mn % 10);
        for (int i = 0; i < 4; i++) {
            if (!inited) {
                cur4[i] = prev4[i] = now4[i];
                chAt[i] = -100000L;
            } else if (cur4[i] != now4[i]) {
                prev4[i] = cur4[i];
                cur4[i] = now4[i];
                chAt[i] = now;
                tickAt = now;
            }
        }
        inited = true;
        int day = cal.get(Calendar.DAY_OF_YEAR);
        if (day != dateDay) {
            dateDay = day;
            dateText = new SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(cal.getTime()).toUpperCase(Locale.getDefault());
        }
        tagIndex = (day + cal.get(Calendar.HOUR_OF_DAY) / 4) % TAGS.length;
        dolly = 0.5f - 0.5f * (float) Math.cos(now / 15000.0 * 2.0 * Math.PI);

        flash = 0f;
        leaderA = 0f;
        if (on) {
            t = (changedAt < 0 ? 0L : now - changedAt) + (quiet ? QUIET_SKIP : 0L);
            kOff = 1f;
            barP = smooth((t - LEADER) / 450f) * vis;
            gradeK = smooth((t - LEADER) / 900f) * vis;
            hide = smooth(t / 150f) * vis;
            tagA = smooth((t - LEADER - 1100f) / 500f) * vis;
            for (int i = 0; i < 4; i++) rev[i] = smooth((t - LEADER - 80f - i * 110f) / 550f) * vis;
            if (t < LEADER) leaderA = smooth(t / 120f) * vis;
            float p = (t - LEADER) / 380f;
            if (p >= 0f && p < 1f) flash = (1f - p) * (1f - p) * 0.95f;
        } else {
            long o = changedAt < 0 ? OFF_MS : now - changedAt;
            kOff = 1f - Math.max(0f, Math.min(1f, o / (float) OFF_MS));
            float k = smooth(kOff) * vis;
            barP = gradeK = hide = tagA = k;
            for (int i = 0; i < 4; i++) rev[i] = k;
            t = -1f;
            if (!quiet && o < 320L) {
                float p = o / 320f;
                flash = (1f - p) * (1f - p) * 0.5f;
            }
        }
        if (tickAt >= 0 && now - tickAt < 160L) flash = Math.max(flash, 0.16f * (1f - (now - tickAt) / 160f) * gradeK);
    }

    /** The photo pushes in slowly. */
    void applyBg(Canvas c) {
        if (gradeK < 0.002f) return;
        float s = 1f + 0.05f * gradeK * dolly;
        c.scale(s, s, w / 2f, h / 2f);
    }

    /** You push the other way, so there is depth between you and the photo. */
    void applySubject(Canvas c, float px, float py) {
        if (gradeK < 0.002f) return;
        float s = 1f + 0.012f * gradeK * dolly;
        c.scale(s, s, px, py);
    }

    // ---------- drawing ----------

    /** Grade, light leak and vignette, straight over the photo. */
    void drawBase(Canvas c, long now) {
        if (gradeK < 0.01f || w <= 0) return;
        tint.setShader(tintShader);
        tint.setAlpha((int) (255 * gradeK));
        c.drawRect(0f, 0f, w, h, tint);

        float lx = w * (0.10f + 0.12f * (float) Math.sin(now / 7300.0));
        float ly = h * (0.34f + 0.18f * (float) Math.sin(now / 9100.0 + 1.0));
        c.save();
        c.translate(lx, ly);
        leak.setShader(leakShader);
        leak.setAlpha((int) (255 * gradeK * (0.62f + 0.38f * (float) Math.sin(now / 3300.0))));
        float lr = w * 0.75f;
        c.drawRect(-lr, -lr, lr, lr, leak);
        c.restore();

        vig.setShader(vigShader);
        vig.setAlpha((int) (255 * gradeK));
        c.drawRect(0f, 0f, w, h, vig);
    }

    /** The time as a poster title. Drawn before the cutout, so it stands behind you. */
    void drawTitle(Canvas c, long now) {
        if (w <= 0 || (rev[0] < 0.01f && rev[3] < 0.01f)) return;
        float minY = barH + (2f * digitH + gap) / 2f + h * 0.025f;
        float yc = Math.max(minY, Math.min(Math.max(minY, h * 0.56f), cyIn));
        float y0 = yc - (2f * digitH + gap) / 2f;
        lineTop[0] = y0;
        lineTop[1] = y0 + digitH + gap;
        titleCy = y0 + digitH + gap / 2f;
        for (int i = 0; i < 4; i++) drawDigit(c, i, now);

        float a = rev[3];
        if (a < 0.01f) return;
        float hy = lineTop[1] + digitH + digitH * 0.17f, x0 = w * 0.08f, x1 = w * 0.92f;
        float prog = (now % 60_000L) / 60_000f;
        line.setStrokeWidth(Math.max(2f, h * 0.0012f));
        line.setColor(CREAM);
        line.setAlpha((int) (255 * a * 0.28f));
        c.drawLine(x0, hy, x1, hy, line);
        for (int q = 0; q <= 4; q++) {
            float qx = x0 + (x1 - x0) * q / 4f;
            c.drawLine(qx, hy - h * 0.006f, qx, hy + h * 0.006f, line);
        }
        line.setColor(GOLD);
        line.setStrokeWidth(Math.max(3f, h * 0.0019f));
        line.setAlpha((int) (255 * a * 0.95f));
        float hx = x0 + (x1 - x0) * prog;
        c.drawLine(x0, hy, hx, hy, line);
        fill.setColor(0xFFFFF6DE);
        fill.setAlpha((int) (255 * a));
        c.drawCircle(hx, hy, h * 0.0042f, fill);
        fill.setColor(GOLD);
        fill.setAlpha((int) (255 * a * 0.30f));
        c.drawCircle(hx, hy, h * 0.012f, fill);

        if (tagA > 0.01f) {
            barText.setTextAlign(Paint.Align.CENTER);
            barText.setTextSize(w * 0.027f);
            barText.setLetterSpacing(0.34f);
            barText.setAlpha((int) (255 * tagA * 0.88f));
            c.drawText(TAGS[tagIndex], w / 2f, hy + h * 0.036f, barText);
            barText.setLetterSpacing(0.22f);
        }
    }

    private void drawDigit(Canvas c, int i, long now) {
        float r = rev[i];
        if (r < 0.01f) return;
        int ln = i >> 1;
        float x = w / 2f + ((i & 1) == 0 ? -cellW / 2f : cellW / 2f);
        float base = lineTop[ln] - bTop;
        float e = 1f - (1f - r) * (1f - r) * (1f - r);
        float sc = 1.2f - 0.2f * e;
        c.save();
        c.translate(x, base - digitH / 2f);
        c.scale(sc, sc);
        c.translate(0f, digitH / 2f);
        long since = now - chAt[i];
        if (since >= 0 && since < ROLL && on) {
            float p = smooth(since / (float) ROLL), rd = digitH * 0.30f;
            glyph(c, prev4[i], -p * rd, (1f - p) * r);
            glyph(c, cur4[i], (1f - p) * rd, p * r);
        } else {
            glyph(c, cur4[i], 0f, r);
        }
        c.restore();
    }

    private void glyph(Canvas c, char ch, float dy, float a) {
        if (a < 0.01f) return;
        glyph[0] = ch;
        shadow.setAlpha((int) (255 * a * 0.38f));
        c.drawText(glyph, 0, 1, 0f, dy + digitH * 0.03f, shadow);
        digit.setAlpha((int) (255 * a * 0.97f));
        c.drawText(glyph, 0, 1, 0f, dy, digit);
    }

    /** The anamorphic streak: one sweeping pass at the hit, a faint drifting one afterwards. Over the cutout. */
    void drawFlare(Canvas c, long now) {
        if (w <= 0 || gradeK < 0.01f) return;
        float y = titleCy;
        float sp = (t - LEADER - 120f) / 1100f;
        if (on && sp > 0f && sp < 1f) {
            float e = sp * sp * (3f - 2f * sp);
            streakAt(c, -0.45f * w + 1.9f * w * e, y, (float) Math.sin(Math.PI * sp));
        }
        float pulse = tickAt >= 0 ? (float) Math.exp(-(now - tickAt) / 500.0) : 0f;
        float x = w * (0.5f + 0.36f * (float) Math.sin(now / 9000.0));
        streakAt(c, x, y, 0.20f * gradeK * (1f + 1.6f * pulse));
    }

    private void streakAt(Canvas c, float x, float y, float a) {
        if (a < 0.01f || streakShader == null) return;
        a = Math.min(1f, a);
        float th = Math.max(2f, h * 0.0015f), reach = w * 0.78f;
        c.save();
        c.translate(x, y);
        streak.setShader(streakShader);
        streak.setAlpha((int) (255 * a));
        c.drawRect(-reach, -th, reach, th, streak);
        streak.setAlpha((int) (255 * a * 0.20f));
        c.drawRect(-reach, -th * 8f, reach, th * 8f, streak);
        streak.setShader(glowShader);
        streak.setAlpha((int) (255 * a * 0.75f));
        float g = h * 0.045f;
        c.drawRect(-g, -g, g, g, streak);
        c.restore();
    }

    /** Leader, bars with their text, grain and the white flashes. Over everything. */
    void drawOverlay(Canvas c, long now) {
        if (w <= 0) return;
        if (leaderA > 0.01f) drawLeader(c, now);
        if (barP > 0.01f) drawBars(c, now);
        float gk = Math.max(gradeK * 0.55f, leaderA * 0.95f);
        if (gk > 0.01f) {
            long f = now / 83L;
            rnd.setSeed(f * 7919L);
            gm.setTranslate(rnd.nextInt(160), rnd.nextInt(160));
            grainShader.setLocalMatrix(gm);
            grain.setShader(grainShader);
            grain.setAlpha((int) (255 * Math.min(1f, gk)));
            c.drawRect(0f, 0f, w, h, grain);
        }
        if (flash > 0.01f) {
            flashPaint.setColor(0xFFFFFFFF);
            flashPaint.setAlpha((int) (255 * Math.min(1f, flash)));
            c.drawRect(0f, 0f, w, h, flashPaint);
        }
    }

    private void drawLeader(Canvas c, long now) {
        c.drawColor(((int) (255 * 0.94f * leaderA)) << 24);
        int idx = Math.max(0, Math.min(2, (int) (t / COUNT)));
        float local = Math.max(0f, Math.min(1f, (t - idx * COUNT) / (float) COUNT));
        float R = w * 0.27f;
        rnd.setSeed((now / 83L) * 104729L);
        float cx = w / 2f + (rnd.nextFloat() - 0.5f) * 3f, cy = h * 0.46f + (rnd.nextFloat() - 0.5f) * 3f;
        float a = leaderA;

        fill.setColor(0xFFF2EBDD);
        fill.setAlpha((int) (255 * a * 0.16f));
        oval.set(cx - R, cy - R, cx + R, cy + R);
        c.drawArc(oval, -90f, 360f * local, true, fill);          // the clock wipe of a real leader

        line.setColor(0xFFF2EBDD);
        line.setAlpha((int) (255 * a * 0.9f));
        line.setStrokeWidth(R * 0.022f);
        c.drawCircle(cx, cy, R, line);
        line.setStrokeWidth(R * 0.01f);
        c.drawCircle(cx, cy, R * 0.82f, line);
        c.drawLine(cx - R * 1.18f, cy, cx + R * 1.18f, cy, line);
        c.drawLine(cx, cy - R * 1.18f, cx, cy + R * 1.18f, line);

        float punch = 1f + 0.14f * (1f - smooth(local * 4f));
        num.setTextSize(R * 1.30f * punch);
        num.setAlpha((int) (255 * a * 0.95f));
        c.drawText(String.valueOf(3 - idx), cx, cy + R * 0.46f * punch, num);

        long f = now / 70L;                                         // scratches and dust
        rnd.setSeed(f * 31L);
        line.setStrokeWidth(Math.max(1.5f, w * 0.0016f));
        for (int i = 0; i < 3; i++) {
            if (rnd.nextFloat() < 0.45f) continue;
            float x = rnd.nextFloat() * w;
            line.setAlpha((int) (255 * a * (0.12f + 0.25f * rnd.nextFloat())));
            c.drawLine(x, 0f, x + (rnd.nextFloat() - 0.5f) * 8f, h, line);
        }
        if (local < 0.08f) {                                        // a tiny brightness kick on each count
            flashPaint.setColor(0xFFFFFFFF);
            flashPaint.setAlpha((int) (255 * 0.10f * (1f - local / 0.08f) * a));
            c.drawRect(0f, 0f, w, h, flashPaint);
        }
    }

    private void drawBars(Canvas c, long now) {
        float p = barP;
        float topEdge = barH * p;                                   // bottom edge of the top bar
        float botEdge = h - barH * p;                               // top edge of the bottom bar
        c.drawRect(0f, 0f, w, topEdge, barPaint);
        c.drawRect(0f, botEdge, w, h, barPaint);
        line.setColor(GOLD);
        line.setStrokeWidth(Math.max(1.5f, h * 0.0009f));
        line.setAlpha((int) (255 * p * 0.65f));
        c.drawLine(0f, topEdge, w, topEdge, line);
        c.drawLine(0f, botEdge, w, botEdge, line);

        float ta = smooth((p - 0.5f) / 0.5f);
        if (ta < 0.01f) return;
        float size = w * 0.0245f, pad = w * 0.06f;
        barText.setTextSize(size);
        barText.setAlpha((int) (255 * ta * 0.88f));
        float topBase = topEdge - barH + barH * 0.64f, botBase = botEdge + barH * 0.62f;

        boolean blink = (now / 520L) % 2L == 0L;                    // REC
        fill.setColor(RED);
        fill.setAlpha((int) (255 * ta * (blink ? 1f : 0.25f)));
        c.drawCircle(pad + size * 0.35f, topBase - size * 0.34f, size * 0.34f, fill);
        barText.setTextAlign(Paint.Align.LEFT);
        c.drawText("REC", pad + size * 1.25f, topBase, barText);
        barText.setTextAlign(Paint.Align.CENTER);
        c.drawText("A LIVING CLOCK PICTURE", w / 2f, topBase, barText);

        sb.setLength(0);                                            // running timecode HH:MM:SS:FF at 24 frames
        two(sb, cal.get(Calendar.HOUR_OF_DAY)).append(':');
        two(sb, cal.get(Calendar.MINUTE)).append(':');
        two(sb, cal.get(Calendar.SECOND)).append(':');
        two(sb, (int) ((now % 1000L) * 24L / 1000L));
        Typeface keep = barText.getTypeface();
        barText.setTypeface(Typeface.MONOSPACE);
        barText.setTextAlign(Paint.Align.RIGHT);
        c.drawText(sb, 0, sb.length(), w - pad, topBase, barText);
        barText.setTypeface(keep);

        sb.setLength(0);
        sb.append(charging ? "CHARGING " : "RUNTIME ").append(pct).append('%');
        barText.setTextAlign(Paint.Align.LEFT);
        c.drawText(sb, 0, sb.length(), pad, botBase, barText);
        barText.setTextAlign(Paint.Align.CENTER);
        c.drawText(dateText, w / 2f, botBase, barText);
        barText.setTextAlign(Paint.Align.RIGHT);
        c.drawText("DIRECTED BY TIME", w - pad, botBase, barText);
        barText.setTextAlign(Paint.Align.CENTER);
    }

    private static StringBuilder two(StringBuilder s, int v) {
        if (v < 10) s.append('0');
        return s.append(v);
    }

    /** The viewfinder that locks onto the clock while the unlock waits for its last two taps. */
    void drawArm(Canvas c, long now, float cx, float cy, float r) {
        if (!armed(now)) return;
        float t0 = now - armedAt;
        float a = smooth(t0 / 200f) * smooth((ARM_MS - t0) / 450f);
        float rem = 1f - t0 / (float) ARM_MS;
        float settle = 1f + 0.38f * (1f - smooth(t0 / 380f));      // focus pull: the frame closes in
        float half = r * 1.22f * settle, len = half * 0.40f;
        float sw = Math.max(3f, r * 0.026f);
        float pulse = 0.5f + 0.5f * (float) Math.sin(t0 / 160.0);

        for (int pass = 0; pass < 2; pass++) {
            line.setColor(pass == 0 ? GOLD : 0xFFFFF4DC);
            line.setStrokeWidth(pass == 0 ? sw * 3.2f : sw);
            line.setAlpha((int) (255 * a * (pass == 0 ? 0.16f : 0.96f)));
            for (int sx = -1; sx <= 1; sx += 2) {
                for (int sy = -1; sy <= 1; sy += 2) {
                    float px = cx + sx * half, py = cy + sy * half;
                    c.drawLine(px, py, px - sx * len, py, line);
                    c.drawLine(px, py, px, py - sy * len, line);
                }
            }
        }
        line.setColor(0xFFFFF4DC);
        line.setStrokeWidth(sw * 0.6f);
        line.setAlpha((int) (255 * a * (0.45f + 0.4f * pulse)));
        float cr = r * 0.075f;
        c.drawLine(cx - cr, cy, cx + cr, cy, line);
        c.drawLine(cx, cy - cr, cx, cy + cr, line);

        boolean blink = (now / 400L) % 2L == 0L;                    // REC light above the frame
        fill.setColor(RED);
        fill.setAlpha((int) (255 * a * (blink ? 1f : 0.2f)));
        float dr = r * 0.05f;
        c.drawCircle(cx - half + dr, cy - half - dr * 2.6f, dr, fill);
        barText.setTextAlign(Paint.Align.LEFT);
        barText.setTextSize(r * 0.15f);
        barText.setAlpha((int) (255 * a * 0.9f));
        c.drawText("REC", cx - half + dr * 3.2f, cy - half - dr * 1.4f, barText);

        float by = cy + half + r * 0.16f;                           // the six seconds, running out
        line.setColor(CREAM);
        line.setStrokeWidth(sw * 0.7f);
        line.setAlpha((int) (255 * a * 0.25f));
        c.drawLine(cx - half, by, cx + half, by, line);
        line.setColor(GOLD);
        line.setAlpha((int) (255 * a * 0.95f));
        c.drawLine(cx - half, by, cx - half + 2f * half * rem, by, line);
        barText.setTextAlign(Paint.Align.CENTER);
    }

    // ---------- helpers ----------

    private static float smooth(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x * x * (3f - 2f * x);
    }

    private void layout() {
        laidW = w;
        laidH = h;
        digit.setTextSize(100f);
        digit.setShader(null);
        digit.getTextBounds("0", 0, 1, tb);
        float m = digit.measureText("0") * 1.06f;
        float bh = Math.max(1f, tb.height());
        float sW = 100f * (0.84f * w) / (2f * m);
        float sH = 100f * (h * 0.27f) / bh;
        float size = Math.min(sW, sH), k = size / 100f;
        digit.setTextSize(size);
        shadow.setTextSize(size);
        digitH = bh * k;
        bTop = tb.top * k;
        cellW = m * k;
        gap = digitH * 0.14f;
        barH = h * 0.055f;
        digit.setShader(new LinearGradient(0f, bTop, 0f, tb.bottom * k,
                new int[]{0xFFFFFFFF, 0xFFF3DDB5, 0xFFDDB070}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));

        float reach = w * 0.78f;
        streakShader = new LinearGradient(-reach, 0f, reach, 0f,
                new int[]{0x00A8E2FF, 0x66A8E2FF, 0xFFEAF7FF, 0x66A8E2FF, 0x00A8E2FF},
                new float[]{0f, 0.35f, 0.5f, 0.65f, 1f}, Shader.TileMode.CLAMP);
        float g = h * 0.045f;
        glowShader = new RadialGradient(0f, 0f, g, new int[]{0xFFFFFFFF, 0x66BFE8FF, 0x00BFE8FF},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP);
        tintShader = new LinearGradient(0f, 0f, 0f, h,
                new int[]{0x380FA3B8, 0x00000000, 0x00000000, 0x38FF8A3C}, new float[]{0f, 0.38f, 0.62f, 1f}, Shader.TileMode.CLAMP);
        float lr = w * 0.75f;
        leakShader = new RadialGradient(0f, 0f, lr, new int[]{0x66FF7A2E, 0x22FF7A2E, 0x00FF7A2E},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        vigShader = new RadialGradient(w / 2f, h / 2f, (float) Math.hypot(w, h) * 0.55f,
                new int[]{0x00000000, 0x00000000, 0xA0000000}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
    }

    private void buildGrain() {
        int n = 160;
        int[] px = new int[n * n];
        Random r = new Random(42);
        for (int i = 0; i < px.length; i++) {
            int v = r.nextBoolean() ? 255 : 0;
            int a = 8 + r.nextInt(34);
            px[i] = (a << 24) | (v << 16) | (v << 8) | v;
        }
        Bitmap b = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888);
        grainShader = new BitmapShader(b, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }
}
