package com.rimon.livingclock;

import java.util.Random;

/**
 * The score of Director's Cut, synthesised sample by sample. No Android classes in here, so it can be run and
 * measured anywhere. Everything is built the way a trailer is built:
 *
 * on  : a three-beat countdown (kick, tom, ticks) under a rising air sweep and a climbing saw, a breath of silence,
 *       then the hit: sub boom, kick, noise burst, metallic ring, a detuned growling "braam", a wide pad chord and a
 *       glass arpeggio, all in a stereo room.
 * arm : a camera-motor heartbeat (two soft kicks), a click and a short rising sweep ending in a clean ping.
 * off : a hard cut, a tape stop that drags the pad down, and a falling swell.
 *
 * Output is interleaved stereo, 16 bit, RATE Hz.
 */
final class CutSound {

    static final int RATE = 44100;

    private static final double TAU = Math.PI * 2.0;

    private CutSound() {}

    // ================= the three scores =================

    static short[] on() {
        float len = 5.9f;
        int n = (int) (RATE * len);
        float[] bass = new float[n];       // kept dry and tight
        float[] air = new float[n];        // goes through the room
        Random r = new Random(11);
        float beat = 0.42f, hit = 1.26f;

        riserNoise(air, 0f, 1.17f, 0.34f, 260f, 5200f, r);
        riserSaw(air, 0f, 1.17f, 0.17f, 82.41f, 329.63f);
        float[] tomHz = {98f, 110f, 123.5f};                          // G2 A2 B2: the tension climbs
        for (int i = 0; i < 3; i++) {
            float at = i * beat;
            kick(bass, at, 0.80f + 0.10f * i, 138f + 8f * i, 46f, 0.19f, r);
            tom(bass, at, 0.34f, tomHz[i], 0.20f);
            tick(air, at, 0.34f, r);
            tick(air, at + beat * 0.5f, 0.15f, r);                    // off-beat ticks keep it nervous
        }

        // the hit
        kick(bass, hit, 1.10f, 150f, 40f, 0.30f, r);
        sub(bass, hit, 0.95f, 88f, 34f, 1.05f, 3.6f);
        braam(bass, hit, 0.80f, 55f, 3.0f);
        noiseHit(air, hit, 0.95f, r);
        metal(air, hit, 0.42f);

        // after the hit: the pad opens, glass sparkles over it
        float[] chord = {110f, 164.81f, 220f, 261.63f, 329.63f, 493.88f};   // Am(add9)
        pad(air, hit + 0.06f, 3.7f, 0.26f, chord);
        float[] arp = {880f, 1046.5f, 1318.5f, 1760f};
        for (int i = 0; i < arp.length; i++) glass(air, hit + 0.20f + 0.115f * i, arp[i], 0.16f, 1.05f);
        glass(air, hit + 0.78f, 2637f, 0.10f, 1.3f);
        return mix(bass, air, 0.78f, 0.62f, 1.22f);
    }

    static short[] arm() {
        int n = (int) (RATE * 1.25f);
        float[] bass = new float[n];
        float[] air = new float[n];
        Random r = new Random(5);
        kick(bass, 0.00f, 0.60f, 118f, 52f, 0.12f, r);               // ba...
        kick(bass, 0.16f, 0.42f, 108f, 50f, 0.14f, r);               // ...dum
        tick(air, 0.00f, 0.50f, r);
        tick(air, 0.16f, 0.30f, r);
        sweepSine(air, 0.04f, 0.30f, 0.11f, 520f, 2600f);
        glass(air, 0.34f, 2093f, 0.20f, 0.30f);
        glass(air, 0.34f, 3136f, 0.09f, 0.22f);
        return mix(bass, air, 0.85f, 0.45f, 1.0f);
    }

    static short[] off() {
        int n = (int) (RATE * 1.9f);
        float[] bass = new float[n];
        float[] air = new float[n];
        Random r = new Random(23);
        kick(bass, 0f, 0.85f, 120f, 42f, 0.20f, r);
        sub(bass, 0f, 0.55f, 70f, 36f, 0.5f, 1.2f);
        tick(air, 0f, 0.40f, r);
        float[] chord = {110f, 164.81f, 220f, 329.63f};
        tapeStop(air, 0.02f, 1.0f, 0.24f, chord);
        noiseFall(air, 0.04f, 0.9f, 0.20f, 4200f, 220f, r);
        glass(air, 0.06f, 1318.5f, 0.12f, 0.35f);
        glass(air, 0.20f, 880f, 0.12f, 0.45f);
        return mix(bass, air, 0.80f, 0.50f, 1.0f);
    }

    // ================= instruments =================

    /** A kick drum: a sine that falls fast from f0 to f1, plus a few milliseconds of click. */
    private static void kick(float[] out, float at, float amp, float f0, float f1, float decay, Random r) {
        int s = (int) (at * RATE);
        double ph = 0.0;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > decay * 7f) break;
            double f = f1 + (f0 - f1) * Math.exp(-t / 0.028);
            ph += TAU * f / RATE;
            float env = (float) Math.exp(-t / decay) * Math.min(1f, t / 0.0014f);
            float v = (float) Math.sin(ph) * env;
            if (t < 0.004f) v += 0.45f * (r.nextFloat() * 2f - 1f) * (1f - t / 0.004f);
            out[s + i] += amp * v;
        }
    }

    /** A low tom: a sine with a short pitch drop. */
    private static void tom(float[] out, float at, float amp, float f, float decay) {
        int s = (int) (at * RATE);
        double ph = 0.0;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > decay * 6f) break;
            double fr = f * (1.0 + 0.35 * Math.exp(-t / 0.04));
            ph += TAU * fr / RATE;
            out[s + i] += amp * (float) (Math.sin(ph) * Math.exp(-t / decay) * Math.min(1f, t / 0.004f));
        }
    }

    /** Deep boom: pitch falls from f0 to f1, long tail. */
    private static void sub(float[] out, float at, float amp, float f0, float f1, float decay, float len) {
        int s = (int) (at * RATE);
        double ph = 0.0;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > len) break;
            double f = f1 + (f0 - f1) * Math.exp(-t / 0.22);
            ph += TAU * f / RATE;
            float env = (float) Math.exp(-t / decay) * Math.min(1f, t / 0.006f);
            out[s + i] += amp * env * (float) Math.sin(ph);
        }
    }

    /** A tiny noise click, differenced so it has no low end. */
    private static void tick(float[] out, float at, float amp, Random r) {
        int s = (int) (at * RATE);
        float prev = 0f;
        for (int i = 0; s + i < out.length && i < RATE / 90; i++) {
            float t = i / (float) RATE;
            float nz = r.nextFloat() * 2f - 1f;
            float hp = nz - prev;
            prev = nz;
            out[s + i] += amp * 0.5f * hp * (float) Math.exp(-t / 0.0022);
        }
    }

    /** Air that climbs: band-passed noise whose centre rises, swelling as it goes. */
    private static void riserNoise(float[] out, float at, float len, float amp, float f0, float f1, Random r) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        float low = 0f, band = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double fc = f0 * Math.pow(f1 / f0, p);
            float f = (float) (2.0 * Math.sin(Math.PI * fc / RATE));
            float x = r.nextFloat() * 2f - 1f;
            low += f * band;
            float high = x - low - 0.55f * band;
            band += f * high;
            float env = (float) Math.pow(p, 1.7) * Math.min(1f, (n - i) / (RATE * 0.012f));
            out[s + i] += amp * 1.6f * env * band;
        }
    }

    /** A saw that glides up while its filter opens: the rising tone under the countdown. */
    private static void riserSaw(float[] out, float at, float len, float amp, float f0, float f1) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        double ph = 0.0;
        float lp = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double f = f0 * Math.pow(f1 / f0, p);
            ph += f / RATE;
            ph -= Math.floor(ph);
            float saw = (float) (2.0 * ph - 1.0);
            float fc = 500f + 3200f * p;
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (saw - lp);
            float env = (float) Math.pow(p, 1.4) * Math.min(1f, (n - i) / (RATE * 0.012f));
            out[s + i] += amp * env * lp;
        }
    }

    /** The burst at the hit: dark noise whose brightness collapses, so it feels like a wall falling over. */
    private static void noiseHit(float[] out, float at, float amp, Random r) {
        int s = (int) (at * RATE);
        float lp = 0f;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > 1.8f) break;
            float k = 0.55f * (float) Math.exp(-t / 0.16) + 0.012f;
            lp += k * ((r.nextFloat() * 2f - 1f) - lp);
            out[s + i] += amp * 1.5f * lp * (float) Math.exp(-t / 0.34) * Math.min(1f, t / 0.0015f);
        }
    }

    /** Inharmonic partials that ring after the hit, like struck metal. */
    private static void metal(float[] out, float at, float amp) {
        float[] f = {187.3f, 262.7f, 391.9f, 611.3f, 917.7f, 1403f};
        float[] g = {0.50f, 0.42f, 0.30f, 0.20f, 0.12f, 0.07f};
        int s = (int) (at * RATE);
        for (int p = 0; p < f.length; p++) {
            double w = TAU * f[p] / RATE;
            float tau = 1.1f / (1f + 0.35f * p);
            for (int i = 0; s + i < out.length; i++) {
                float t = i / (float) RATE;
                if (t > tau * 6f) break;
                out[s + i] += amp * g[p] * (float) (Math.sin(w * i) * Math.exp(-t / tau) * Math.min(1f, t / 0.002f));
            }
        }
    }

    /**
     * The "braam": three detuned saws and a sub octave, pushed hard through a soft clipper, with a filter that
     * opens after the hit and closes again. Pitch starts a little sharp and settles.
     */
    private static void braam(float[] out, float at, float amp, float f, float len) {
        int s = (int) (at * RATE);
        double p0 = 0, p1 = 0, p2 = 0, p3 = 0;
        float lp = 0f;
        for (int i = 0; s + i < out.length; i++) {
            float t = i / (float) RATE;
            if (t > len) break;
            double fr = f * (1.0 + 0.22 * Math.exp(-t / 0.07));
            p0 += fr * 0.994 / RATE;
            p1 += fr / RATE;
            p2 += fr * 1.006 / RATE;
            p3 += fr * 0.5 / RATE;
            p0 -= Math.floor(p0);
            p1 -= Math.floor(p1);
            p2 -= Math.floor(p2);
            p3 -= Math.floor(p3);
            float x = (float) ((2 * p0 - 1) + (2 * p1 - 1) + (2 * p2 - 1)) / 3f * 0.9f + (float) Math.sin(TAU * p3) * 0.7f;
            x = (float) Math.tanh(x * 3.6f);
            double open = Math.exp(-Math.pow((t - 0.28) / 0.34, 2));
            float fc = (float) (200.0 + 1500.0 * open);
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (x - lp);
            float env = Math.min(1f, t / 0.01f) * (float) Math.exp(-t / 0.95f) * Math.min(1f, (len - t) / 0.3f);
            out[s + i] += amp * env * lp;
        }
    }

    /** A wide pad: three detuned saws per note, a filter that slowly opens, a slow attack and a long release. */
    private static void pad(float[] out, float at, float len, float amp, float[] notes) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        float[] det = {0.9962f, 1.0f, 1.0038f};
        double[] ph = new double[notes.length * 3];
        for (int i = 0; i < ph.length; i++) ph[i] = (i * 0.37) % 1.0;
        float lp = 0f, lp2 = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float t = i / (float) RATE;
            float sum = 0f;
            for (int v = 0; v < notes.length; v++) {
                for (int d = 0; d < 3; d++) {
                    int idx = v * 3 + d;
                    ph[idx] += notes[v] * det[d] / RATE;
                    ph[idx] -= Math.floor(ph[idx]);
                    sum += (float) (2.0 * ph[idx] - 1.0);
                }
            }
            sum /= ph.length;
            float up = Math.min(1f, t / 1.6f);
            float fc = 520f + 1700f * up * up;
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (sum - lp);
            lp2 += k * (lp - lp2);                                    // two poles: warm, no fizz
            float att = Math.min(1f, t / 0.55f);
            att *= att;
            float rel = Math.min(1f, (len - t) / 1.4f);
            out[s + i] += amp * 3.0f * att * rel * lp2;
        }
    }

    /** A struck-glass note: inharmonic partials, the high ones dying faster, a slightly detuned twin for shimmer. */
    private static void glass(float[] out, float at, float freq, float amp, float tau) {
        int s = (int) (at * RATE);
        float[] ratio = {1f, 2.0f, 2.76f, 5.4f};
        float[] gain = {1f, 0.34f, 0.20f, 0.08f};
        for (int p = 0; p < ratio.length; p++) {
            float f = freq * ratio[p];
            if (f > RATE * 0.42f) continue;
            float decay = tau / (1f + 0.7f * p);
            double w = TAU * f / RATE, w2 = TAU * f * 1.0032 / RATE;
            for (int i = 0; s + i < out.length; i++) {
                float t = i / (float) RATE;
                if (t > decay * 8f) break;
                float env = (float) Math.exp(-t / decay) * Math.min(1f, t / 0.004f);
                out[s + i] += amp * gain[p] * env * (float) (Math.sin(w * i) + 0.45 * Math.sin(w2 * i));
            }
        }
    }

    private static void sweepSine(float[] out, float at, float len, float amp, float f0, float f1) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        double ph = 0.0;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            ph += TAU * (f0 * Math.pow(f1 / f0, p)) / RATE;
            float env = (float) Math.sin(Math.PI * Math.pow(p, 0.8));
            out[s + i] += amp * env * (float) Math.sin(ph);
        }
    }

    /** The pad being dragged down by a stopping tape: pitch and level fall together. */
    private static void tapeStop(float[] out, float at, float len, float amp, float[] notes) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        double[] ph = new double[notes.length];
        float lp = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double speed = Math.pow(1.0 - p, 1.8);
            float sum = 0f;
            for (int v = 0; v < notes.length; v++) {
                ph[v] += notes[v] * speed / RATE;
                ph[v] -= Math.floor(ph[v]);
                sum += (float) (2.0 * ph[v] - 1.0);
            }
            sum /= notes.length;
            float fc = (float) (180.0 + 1500.0 * speed);
            float k = 1f - (float) Math.exp(-TAU * fc / RATE);
            lp += k * (sum - lp);
            out[s + i] += amp * 2.4f * (float) Math.pow(1.0 - p, 1.2) * lp;
        }
    }

    private static void noiseFall(float[] out, float at, float len, float amp, float f0, float f1, Random r) {
        int s = (int) (at * RATE), n = (int) (len * RATE);
        float low = 0f, band = 0f;
        for (int i = 0; i < n && s + i < out.length; i++) {
            float p = i / (float) n;
            double fc = f0 * Math.pow(f1 / f0, p);
            float f = (float) (2.0 * Math.sin(Math.PI * Math.min(fc, 6000.0) / RATE));
            float x = r.nextFloat() * 2f - 1f;
            low += f * band;
            float high = x - low - 0.6f * band;
            band += f * high;
            out[s + i] += amp * 1.5f * (float) Math.pow(1.0 - p, 1.6) * Math.min(1f, p / 0.03f) * band;
        }
    }

    // ================= room and mix =================

    /** A small stereo room: four damped combs and two all-pass filters per side. */
    private static void room(float[] in, float[] outL, float[] outR) {
        int[] dl = {1307, 1637, 1811, 1931}, dr = {1337, 1667, 1847, 1973};
        side(in, outL, dl, 556);
        side(in, outR, dr, 579);
    }

    private static void side(float[] in, float[] out, int[] delays, int apDelay) {
        float fb = 0.90f, damp = 0.35f;
        float[][] buf = new float[delays.length][];
        int[] pos = new int[delays.length];
        float[] store = new float[delays.length];
        for (int c = 0; c < delays.length; c++) buf[c] = new float[delays[c]];
        float[] ap1 = new float[apDelay], ap2 = new float[apDelay * 4 / 5];
        int a1 = 0, a2 = 0;
        for (int i = 0; i < in.length; i++) {
            float x = in[i] * 0.18f, sum = 0f;
            for (int c = 0; c < delays.length; c++) {
                float y = buf[c][pos[c]];
                store[c] = y * (1f - damp) + store[c] * damp;
                buf[c][pos[c]] = x + store[c] * fb;
                if (++pos[c] >= delays[c]) pos[c] = 0;
                sum += y;
            }
            float z = sum * 0.5f;
            float b = ap1[a1];
            float o = -z + b;
            ap1[a1] = z + b * 0.5f;
            if (++a1 >= ap1.length) a1 = 0;
            float b2 = ap2[a2];
            float o2 = -o + b2;
            ap2[a2] = o + b2 * 0.5f;
            if (++a2 >= ap2.length) a2 = 0;
            out[i] = o2;
        }
    }

    /** Dry bass + air with its room, a touch of width, a soft ceiling, a short fade, 16-bit stereo. */
    private static short[] mix(float[] bass, float[] air, float airDry, float roomAmt, float drive) {
        int n = bass.length;
        float[] rl = new float[n], rr = new float[n];
        room(air, rl, rr);
        int haas = (int) (RATE * 0.011f);
        float[] l = new float[n], r = new float[n];
        float peak = 1e-6f;
        for (int i = 0; i < n; i++) {
            float aL = air[i], aR = i >= haas ? air[i - haas] : 0f;
            l[i] = bass[i] + airDry * aL + roomAmt * rl[i];
            r[i] = bass[i] + airDry * aR + roomAmt * rr[i];
            peak = Math.max(peak, Math.max(Math.abs(l[i]), Math.abs(r[i])));
        }
        float g = drive / peak;
        int fade = (int) (RATE * 0.22f), head = (int) (RATE * 0.002f);
        short[] pcm = new short[n * 2];
        for (int i = 0; i < n; i++) {
            float f = 1f;
            if (n - i < fade) f = (n - i) / (float) fade;
            if (i < head) f *= i / (float) head;
            float vl = (float) Math.tanh(l[i] * g * 1.15f) * 0.9f * f;
            float vr = (float) Math.tanh(r[i] * g * 1.15f) * 0.9f * f;
            pcm[2 * i] = (short) Math.round(vl * 32767f);
            pcm[2 * i + 1] = (short) Math.round(vr * 32767f);
        }
        return pcm;
    }
}
