plugins {
    id("com.android.application")
}

android {
    namespace = "com.rimon.livingclock"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rimon.livingclock"
        minSdk = 23
        targetSdk = 34
        versionCode = 19
        versionName = "4.6"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Person cutout only.
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
