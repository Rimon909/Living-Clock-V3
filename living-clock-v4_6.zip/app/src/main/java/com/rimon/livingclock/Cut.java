package com.rimon.livingclock;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/**
 * Director's Cut: the signature of the project. A short, heavy, hidden sequence that takes the wallpaper apart,
 * lets you move through it, puts it back together with weight nobody expected, signs it, and vanishes.
 *
 * Unlock: four taps on the clock (a reactor ring charges around the dial for six seconds), then two taps on the
 * top centre of the cutout.
 *
 * 1 TEARDOWN   the picture splits into its three real layers (background, time, you) that float apart in depth.
 * 2 INSPECT    drag anywhere: the whole stack turns in space; every few degrees is a detent.
 * 3 PULL APART slide up: the layers separate further.
 * 4 LOAD       press and hold: the stack is pulled together under pressure; the clicks get lower as it gets heavier.
 * 5 ASSEMBLY   the layers slam shut with a weight that was not there before.
 *   SIGNED     "Rimon" writes itself in one pen stroke, and everything fades until nothing is left of it.
 *
 * While it runs, the renderer draws only the three layers and this class. Nothing else is on: no bands, no
 * Supers, no pendulum, no hanging numerals, no stars, no sleep clock. When it ends the wallpaper is exactly as it was.
 * Every stage has a time cap, so the whole thing is over in well under a minute even if nobody touches the screen.
 *
 * Nothing in the frame loop allocates. Layers are projected with one 4-point matrix each.
 */
final class Cut {

    /** Cues for sound and haptics. rate: playback speed (lower is heavier). strength: 0..1. */
    interface Cue {
        void on(int id, float rate, float strength);
    }

    static final int CUE_ENTER = 0, CUE_DETENT = 1, CUE_LOCK = 2, CUE_SLAM = 3, CUE_VANISH = 4, CUE_STOP = 5;
    static final long ARM_MS = 6000L;

    Cue cue;

    private static final int IDLE = 0, TEAR = 1, INSPECT = 2, PULL = 3, LOAD = 4, SLAM = 5, SIGN = 6;
    private static final long TEAR_MS = 2600L, INSPECT_MAX = 14_000L, PULL_MAX = 12_000L, LOAD_MAX = 12_000L,
            SLAM_MS = 2700L, SIGN_MS = 6500L, IMPACT_AT = 360L;

    private static final int STEEL = 0xFF8FB4C8, ICE = 0xFFDCEBF5, AMBER = 0xFFFFB340, INK = 0xFF06090D, PEN = 0xFFFFF4DE;
    private static final String[] STAGE = {"", "01  TEARDOWN", "02  INSPECT", "03  PULL APART", "04  LOAD", "05  ASSEMBLY"};
    private static final String[] HINT = {"", "", "DRAG ANYWHERE", "SLIDE UP", "PRESS AND HOLD", ""};
    private static final String[] LAYER = {"BACKGROUND  01", "TIME  02", "YOU  03"};

    /** "Rimon": one connected stroke, the dot of the i, and an underline. Points in a 100 x 44 box. */
    private static final float[][] SIG = {
            {5f, 38f, 8f, 28f, 11f, 14f, 13f, 5f, 20f, 2f, 29f, 6f, 31f, 14f, 24f, 21f, 15f, 23f, 12f, 23f, 19f, 27f, 27f, 35f, 33f, 36f,
                    37f, 30f, 38f, 22f, 39f, 16f, 40f, 24f, 41f, 33f, 44f, 34f, 47f, 26f, 49f, 17f, 52f, 16f, 55f, 22f, 56f, 31f, 57f, 22f,
                    60f, 16f, 64f, 17f, 66f, 24f, 67f, 33f, 69f, 33f, 72f, 26f, 76f, 20f, 81f, 19f, 84f, 24f, 81f, 32f, 76f, 32f, 74f, 26f,
                    77f, 20f, 83f, 20f, 88f, 24f, 89f, 33f, 91f, 25f, 93f, 19f, 97f, 19f, 99f, 26f, 98f, 36f, 100f, 38f},
            {40.5f, 8f, 40.06f, 9.06f, 39f, 9.5f, 37.94f, 9.06f, 37.5f, 8f, 37.94f, 6.94f, 39f, 6.5f, 40.06f, 6.94f, 40.5f, 8f},
            {12f, 41f, 34f, 40f, 58f, 40.5f, 84f, 38f, 97f, 34f}};

    // ---------- state ----------

    private int stage = IDLE;
    private long stageAt, lastMs = -1L, goalAt = -1L, armedAt = -1L;
    private int w, h;
    private float yaw, pitch, yawT, pitchT, spread, spreadT, weight, maxYaw;
    private float spreadFrom, yawFrom, pitchFrom;
    private float flash, shx, shy, punch = 1f, hudA, vig, sigP, sigA;
    private int detentIdx, spreadIdx, weightIdx;
    private boolean pressed, hit;
    private float lastX, lastY;
    private float cosY = 1f, sinY, cosP = 1f, sinP, gapPx;

    // ---------- reusable objects ----------

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint();
    private final Paint vigPaint = new Paint();
    private final Paint ink = new Paint();
    private final Matrix m = new Matrix();
    private final RectF oval = new RectF();
    private final float[] src = new float[8], dst = new float[8], pos = new float[2];
    private float[] grid = new float[0];
    private int gridN;
    private RadialGradient glowShader, vigShader;
    private final Path sigPath = new Path(), seg = new Path();
    private final PathMeasure pm = new PathMeasure();
    private float sigTotal;
    private int laidW, laidH;

    Cut() {
        text.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        text.setLetterSpacing(0.22f);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        ink.setColor(INK);
    }

    // ---------- unlock ----------

    void arm(long now) {
        armedAt = now;
    }

    boolean armed(long now) {
        return armedAt >= 0 && now - armedAt < ARM_MS;
    }

    void disarm() {
        armedAt = -1L;
    }

    boolean active() {
        return stage != IDLE;
    }

    void start(long now) {
        if (stage != IDLE) return;
        stage = TEAR;
        stageAt = now;
        lastMs = now;
        goalAt = -1L;
        armedAt = -1L;
        yaw = pitch = yawT = pitchT = maxYaw = 0f;
        spread = spreadT = 0f;
        weight = 0f;
        flash = 0f;
        hit = false;
        pressed = false;
        detentIdx = 0;
        spreadIdx = 0;
        weightIdx = 0;
        sigP = 0f;
        sigA = 1f;
        vig = 0f;
        fire(CUE_ENTER, 1f, 1f);
    }

    /** Something else needs the screen (sleep clock, kill switch): leave at once. */
    void abort() {
        if (stage == IDLE) return;
        stage = IDLE;
        pressed = false;
        fire(CUE_STOP, 1f, 0f);
    }

    private void fire(int id, float rate, float strength) {
        if (cue != null) cue.on(id, rate, strength);
    }

    private void go(int s, long now) {
        stage = s;
        stageAt = now;
        goalAt = -1L;
        if (s == LOAD) {
            weight = 0f;
            weightIdx = 0;
        } else if (s == SLAM) {
            spreadFrom = spread;
            yawFrom = yaw;
            pitchFrom = pitch;
            hit = false;
            fire(CUE_SLAM, 1f, 1f);
        } else if (s == SIGN) {
            fire(CUE_VANISH, 1f, 1f);
        }
    }

    // ---------- touch ----------

    /** action: 0 down, 1 move, 2 up. */
    void touch(int action, float x, float y, long now) {
        if (stage == IDLE) return;
        if (action == 0) {
            pressed = true;
            lastX = x;
            lastY = y;
            return;
        }
        if (action == 2) {
            pressed = false;
            return;
        }
        float dx = x - lastX, dy = y - lastY;
        lastX = x;
        lastY = y;
        if (stage == INSPECT) {
            yawT = clamp(yawT + dx * 0.15f, -40f, 40f);
            pitchT = clamp(pitchT - dy * 0.09f, -26f, 26f);
        } else if (stage == PULL) {
            spreadT = clamp(spreadT - dy / (0.30f * Math.max(1, h)), 0.35f, 1.9f);
            yawT = clamp(yawT + dx * 0.06f, -40f, 40f);
        }
    }

    // ---------- per frame ----------

    void step(long now, int width, int height) {
        if (stage == IDLE) return;
        if (width != laidW || height != laidH) layout(width, height);
        long gap = now - lastMs;
        lastMs = now;
        float dt = 0.016f;
        if (gap > 400L) {                                          // the screen was off: the show waits
            stageAt += gap;
            if (goalAt >= 0) goalAt += gap;
        } else {
            dt = Math.min(0.05f, gap / 1000f);
        }
        long t = now - stageAt;
        float k = 1f - (float) Math.exp(-dt * 10f);
        flash = Math.max(0f, flash - dt * 3.2f);
        shx = shy = 0f;
        punch = 1f;

        switch (stage) {
            case TEAR: {
                float p = clamp(t / (float) TEAR_MS, 0f, 1f);
                float q = 1f - p;
                spread = spreadT = 1f - q * q * q;
                if (t >= TEAR_MS) go(INSPECT, now);
                break;
            }
            case INSPECT: {
                yaw += (yawT - yaw) * k;
                pitch += (pitchT - pitch) * k;
                spread += (spreadT - spread) * k;
                int idx = Math.round(yaw / 6f);
                if (idx != detentIdx) {
                    detentIdx = idx;
                    fire(CUE_DETENT, 0.95f + 0.04f * Math.min(6, Math.abs(idx)), 0.5f);
                }
                maxYaw = Math.max(maxYaw, Math.abs(yaw));
                if (goalAt < 0 && maxYaw >= 24f) goalAt = now;
                if ((goalAt >= 0 && now - goalAt > 600L) || t > INSPECT_MAX) go(PULL, now);
                break;
            }
            case PULL: {
                yawT *= 1f - dt * 0.5f;
                pitchT *= 1f - dt * 0.5f;
                yaw += (yawT - yaw) * k;
                pitch += (pitchT - pitch) * k;
                spread += (spreadT - spread) * k;
                int idx = (int) (spread * 8f);
                if (idx != spreadIdx) {
                    spreadIdx = idx;
                    fire(CUE_DETENT, 0.80f + 0.03f * Math.min(12, idx), 0.6f);
                }
                if (goalAt < 0 && spread >= 1.6f) goalAt = now;
                if ((goalAt >= 0 && now - goalAt > 600L) || t > PULL_MAX) go(LOAD, now);
                break;
            }
            case LOAD: {
                yawT = pitchT = 0f;
                yaw += (yawT - yaw) * k;
                pitch += (pitchT - pitch) * k;
                if (goalAt < 0) {
                    if (pressed) weight += dt / 1.9f;
                    else weight -= dt / 1.4f;
                    if (t > 8000L) weight = Math.max(weight, (t - 8000L) / 2500f);     // never stuck
                    weight = clamp(weight, 0f, 1f);
                }
                spreadT = 1f - 0.5f * weight;
                spread += (spreadT - spread) * k;
                int wi = (int) (weight * 10f);
                if (wi > weightIdx && goalAt < 0) {
                    fire(CUE_DETENT, 1.65f - 1.05f * weight, 0.35f + 0.65f * weight);
                }
                weightIdx = wi;
                float amp = 5f * weight * weight * Math.min(1f, w / 1080f * 1.4f);
                shx = amp * (float) Math.sin(now * 0.071);
                shy = amp * (float) Math.cos(now * 0.093);
                if (goalAt < 0 && weight >= 1f) {
                    goalAt = now;
                    flash = 0.35f;
                    fire(CUE_LOCK, 1f, 1f);
                }
                if (goalAt >= 0 && now - goalAt > 380L) go(SLAM, now);
                else if (t > LOAD_MAX) go(SLAM, now);
                break;
            }
            case SLAM: {
                float p1 = clamp(t / (float) IMPACT_AT, 0f, 1f);
                float c3 = p1 * p1 * p1;
                spread = spreadFrom * (1f - c3);
                yaw = yawFrom * (1f - p1);
                pitch = pitchFrom * (1f - p1);
                if (t >= IMPACT_AT) {
                    float u = (t - IMPACT_AT) / 1000f;
                    if (!hit) {
                        hit = true;
                        flash = 1f;
                    }
                    spread = 0f;
                    yaw = pitch = 0f;
                    float amp = 22f * (float) Math.exp(-5f * u) * Math.min(1f, w / 1080f * 1.4f);
                    shx = amp * (float) Math.sin(u * 60f);
                    shy = amp * 0.6f * (float) Math.cos(u * 47f);
                    punch = 1f + 0.045f * (float) Math.exp(-6f * u) * (float) Math.cos(u * 22f);
                }
                if (t >= SLAM_MS) go(SIGN, now);
                break;
            }
            case SIGN: {
                spread = 0f;
                yaw = pitch = 0f;
                sigP = smooth((t - 300f) / 2600f);
                sigA = 1f - smooth((t - 3900f) / 1800f);
                vig = 0.34f * smooth(t / 500f) * (1f - smooth((t - 3300f) / 2700f));
                if (t >= SIGN_MS) {
                    stage = IDLE;
                    pressed = false;
                }
                break;
            }
            default:
                break;
        }

        hudA = (stage >= TEAR && stage <= LOAD) ? 1f : (stage == SLAM ? Math.max(0f, 1f - t / 200f) : 0f);
        if (stage == TEAR) hudA = smooth(t / 500f);
        float sway = 1.4f * (float) Math.sin(now / 1700.0) * Math.min(1f, spread);
        double ya = Math.toRadians(yaw + sway), pa = Math.toRadians(pitch);
        cosY = (float) Math.cos(ya);
        sinY = (float) Math.sin(ya);
        cosP = (float) Math.cos(pa);
        sinP = (float) Math.sin(pa);
        gapPx = spread * 0.26f * w;
    }

    // ---------- layers ----------

    /** Starts drawing one layer (0 background, 1 time, 2 you) in its place in the exploded stack. */
    void beginLayer(Canvas c, int i) {
        float z = (1 - i) * gapPx;
        float cx0 = w / 2f, cy0 = h / 2f, big = 1.5f * h;
        for (int k = 0; k < 4; k++) {
            float x = (k == 1 || k == 2) ? w : 0f, y = k >= 2 ? h : 0f;
            float xx = x - cx0, yy = y - cy0;
            float xr = xx * cosY + z * sinY;
            float zr = -xx * sinY + z * cosY;
            float yr = yy * cosP - zr * sinP;
            float zr2 = yy * sinP + zr * cosP;
            float s = big / (big + zr2);
            dst[2 * k] = cx0 + xr * s + shx;
            dst[2 * k + 1] = cy0 + yr * s + shy;
        }
        m.setPolyToPoly(src, 0, dst, 0, 4);
        if (punch != 1f) m.postScale(punch, punch, cx0, cy0);
        c.save();
        c.concat(m);
    }

    /** Closes the layer: its frame, corner marks and label, drawn in the layer's own space. */
    void endLayer(Canvas c, int i) {
        float fa = smooth(spread * 1.4f) * hudA;
        if (fa > 0.01f) {
            float sw = Math.max(2f, w * 0.0024f);
            line.setStrokeWidth(sw);
            line.setColor(STEEL);
            line.setAlpha((int) (150 * fa));
            c.drawRect(sw, sw, w - sw, h - sw, line);
            line.setColor(AMBER);
            line.setStrokeWidth(sw * 2f);
            line.setAlpha((int) (230 * fa));
            float len = w * 0.07f, o = sw * 2f;
            c.drawLine(o, o, o + len, o, line);
            c.drawLine(o, o, o, o + len, line);
            c.drawLine(w - o, o, w - o - len, o, line);
            c.drawLine(w - o, o, w - o, o + len, line);
            c.drawLine(o, h - o, o + len, h - o, line);
            c.drawLine(o, h - o, o, h - o - len, line);
            c.drawLine(w - o, h - o, w - o - len, h - o, line);
            c.drawLine(w - o, h - o, w - o, h - o - len, line);
            text.setTextAlign(Paint.Align.LEFT);
            text.setTextSize(w * 0.027f);
            text.setColor(ICE);
            text.setAlpha((int) (235 * fa));
            c.drawText(LAYER[i], w * 0.055f, h * (0.115f + 0.034f * i), text);
        }
        c.restore();
    }

    /** The dark room behind the exploded stack, with a faint grid. Invisible when the stack is closed. */
    void drawBackdrop(Canvas c) {
        float a = clamp(spread, 0f, 1f);
        if (a < 0.01f) return;
        ink.setAlpha((int) (255 * a));
        c.drawRect(0f, 0f, w, h, ink);
        glow.setShader(glowShader);
        glow.setAlpha((int) (200 * a));
        c.drawRect(0f, 0f, w, h, glow);
        c.save();
        c.translate(-yaw * 2.2f, -pitch * 2.2f);
        line.setColor(STEEL);
        line.setStrokeWidth(Math.max(1f, w * 0.0010f));
        line.setAlpha((int) (28 * a));
        c.drawLines(grid, 0, gridN, line);
        c.restore();
    }

    // ---------- overlay ----------

    void drawOverlay(Canvas c, long now) {
        if (stage == IDLE) return;
        if (vig > 0.01f) {
            vigPaint.setShader(vigShader);
            vigPaint.setAlpha((int) (255 * vig));
            c.drawRect(0f, 0f, w, h, vigPaint);
        }
        if (hudA > 0.01f) drawHud(c, now);
        if (pressed && stage >= INSPECT && stage <= LOAD) drawReticle(c);
        if (stage == SLAM && hit) drawShock(c, now);
        if (flash > 0.01f) {
            fill.setColor(ICE);
            fill.setAlpha((int) (255 * Math.min(1f, flash) * 0.9f));
            c.drawRect(0f, 0f, w, h, fill);
        }
        if (stage == SIGN && sigA > 0.01f) drawSignature(c);
    }

    private void drawHud(Canvas c, long now) {
        float a = hudA;
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(w * 0.024f);
        text.setColor(STEEL);
        text.setAlpha((int) (210 * a));
        c.drawText("DIRECTOR'S CUT", w / 2f, h * 0.058f, text);
        text.setTextSize(w * 0.031f);
        text.setColor(ICE);
        text.setAlpha((int) (245 * a));
        if (stage >= TEAR && stage <= SLAM) c.drawText(STAGE[stage], w / 2f, h * 0.058f + w * 0.058f, text);

        float segW = w * 0.075f, gapW = w * 0.016f, x0 = w / 2f - (5f * segW + 4f * gapW) / 2f, y = h * 0.058f + w * 0.085f;
        line.setStrokeWidth(Math.max(3f, w * 0.0055f));
        line.setStrokeCap(Paint.Cap.BUTT);
        for (int i = 1; i <= 5; i++) {
            float xs = x0 + (i - 1) * (segW + gapW);
            boolean done = i < stage, cur = i == stage;
            line.setColor(done || cur ? AMBER : STEEL);
            line.setAlpha((int) ((done ? 230 : cur ? 255 : 70) * a));
            c.drawLine(xs, y, xs + segW, y, line);
        }
        line.setStrokeCap(Paint.Cap.ROUND);

        String hint = stage <= SLAM ? HINT[stage] : "";
        if (hint.length() > 0) {
            float pulse = 0.55f + 0.45f * (float) Math.sin(now / 260.0);
            text.setTextSize(w * 0.029f);
            text.setColor(AMBER);
            text.setAlpha((int) (255 * a * pulse));
            c.drawText(hint, w / 2f, h * 0.915f, text);
        }
    }

    private void drawReticle(Canvas c) {
        float r0 = w * 0.05f;
        line.setStrokeWidth(Math.max(2f, w * 0.003f));
        line.setColor(ICE);
        line.setAlpha(150);
        c.drawCircle(lastX, lastY, r0, line);
        fill.setColor(ICE);
        fill.setAlpha(210);
        c.drawCircle(lastX, lastY, w * 0.006f, fill);
        if (stage != LOAD) return;
        float rr = w * (0.22f - 0.125f * weight);
        line.setColor(STEEL);
        line.setAlpha((int) (140 * (1f - weight * 0.5f)));
        c.drawCircle(lastX, lastY, rr, line);
        float ra = w * 0.095f;
        oval.set(lastX - ra, lastY - ra, lastX + ra, lastY + ra);
        line.setColor(AMBER);
        line.setStrokeWidth(Math.max(4f, w * 0.009f));
        line.setAlpha(255);
        c.drawArc(oval, -90f, 360f * weight, false, line);
    }

    private void drawShock(Canvas c, long now) {
        float u = (now - stageAt - IMPACT_AT) / 1000f;
        if (u < 0f || u > 1.3f) return;
        float rad = u * (float) Math.hypot(w, h) * 0.85f;
        float a = (float) Math.exp(-u * 3.2f);
        line.setColor(ICE);
        line.setStrokeWidth(Math.max(3f, w * 0.012f * (1f - u * 0.6f)));
        line.setAlpha((int) (210 * a));
        c.drawCircle(w / 2f, h / 2f, rad, line);
        line.setColor(AMBER);
        line.setStrokeWidth(Math.max(2f, w * 0.004f));
        line.setAlpha((int) (200 * a));
        c.drawCircle(w / 2f, h / 2f, rad * 0.93f, line);
    }

    private void drawSignature(Canvas c) {
        float want = sigTotal * sigP;
        pm.setPath(sigPath, false);
        seg.rewind();
        float left = want, tx = -1f, ty = -1f;
        do {
            float len = pm.getLength();
            if (left <= 0f) break;
            float d = Math.min(len, left);
            pm.getSegment(0f, d, seg, true);
            pm.getPosTan(d, pos, null);
            tx = pos[0];
            ty = pos[1];
            left -= len;
        } while (pm.nextContour());

        line.setColor(PEN);
        line.setStrokeWidth(w * 0.018f);
        line.setAlpha((int) (36 * sigA));
        c.drawPath(seg, line);
        line.setStrokeWidth(w * 0.0085f);
        line.setAlpha((int) (110 * sigA));
        c.drawPath(seg, line);
        line.setStrokeWidth(Math.max(3f, w * 0.0038f));
        line.setAlpha((int) (255 * sigA));
        c.drawPath(seg, line);
        if (sigP < 0.999f && tx >= 0f) {
            fill.setColor(AMBER);
            fill.setAlpha((int) (90 * sigA));
            c.drawCircle(tx, ty, w * 0.020f, fill);
            fill.setColor(0xFFFFFFFF);
            fill.setAlpha((int) (255 * sigA));
            c.drawCircle(tx, ty, w * 0.0065f, fill);
        }
    }

    // ---------- the unlock ring: a reactor charging around the clock ----------

    void drawArm(Canvas c, long now, float cx, float cy, float r) {
        if (!armed(now)) return;
        float t0 = now - armedAt;
        float a = smooth(t0 / 200f) * smooth((ARM_MS - t0) / 450f);
        float prog = clamp(t0 / (float) ARM_MS, 0f, 1f);
        float rr = r * 1.18f;
        float sw = Math.max(3f, r * 0.03f);
        oval.set(cx - rr, cy - rr, cx + rr, cy + rr);

        line.setStrokeWidth(sw * 0.8f);
        line.setColor(STEEL);
        line.setAlpha((int) (60 * a));
        c.drawCircle(cx, cy, rr, line);                              // the empty ring
        line.setStrokeWidth(sw);
        line.setColor(AMBER);
        line.setAlpha((int) (235 * a));
        c.drawArc(oval, -90f, 360f * (1f - prog), false, line);      // what is left of the six seconds

        float pulse = 0.5f + 0.5f * (float) Math.sin(t0 / 150.0);
        line.setStrokeWidth(sw * 0.7f);
        for (int i = 0; i < 12; i++) {                               // twelve cells that go dark one by one
            boolean lit = i / 12f >= prog;
            double ang = Math.toRadians(-90.0 + i * 30.0 + 15.0);
            float x0 = cx + (float) Math.cos(ang) * r * 1.34f, y0 = cy + (float) Math.sin(ang) * r * 1.34f;
            float x1 = cx + (float) Math.cos(ang) * r * 1.44f, y1 = cy + (float) Math.sin(ang) * r * 1.44f;
            line.setColor(lit ? ICE : STEEL);
            line.setAlpha((int) ((lit ? 120 + 110 * pulse : 40) * a));
            c.drawLine(x0, y0, x1, y1, line);
        }
        if (t0 < 450f) {                                             // the moment it arms: a ripple off the dial
            float p = t0 / 450f;
            float e = 1f - (1f - p) * (1f - p) * (1f - p);
            line.setColor(ICE);
            line.setStrokeWidth(Math.max(2f, r * 0.02f));
            line.setAlpha((int) (200 * (1f - p)));
            c.drawCircle(cx, cy, r * (1.0f + 0.5f * e), line);
        }
    }

    // ---------- helpers ----------

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private void layout(int width, int height) {
        w = laidW = width;
        h = laidH = height;
        src[0] = 0f;
        src[1] = 0f;
        src[2] = w;
        src[3] = 0f;
        src[4] = w;
        src[5] = h;
        src[6] = 0f;
        src[7] = h;

        float step = Math.max(40f, w / 11f);                        // grid lines, a little larger than the screen
        int cols = (int) (w / step) + 3, rows = (int) (h / step) + 3;
        grid = new float[(cols + rows) * 4];
        int p = 0;
        for (int i = -1; i < cols - 1; i++) {
            float x = i * step;
            grid[p++] = x;
            grid[p++] = -step;
            grid[p++] = x;
            grid[p++] = h + step;
        }
        for (int j = -1; j < rows - 1; j++) {
            float y = j * step;
            grid[p++] = -step;
            grid[p++] = y;
            grid[p++] = w + step;
            grid[p++] = y;
        }
        gridN = p;

        glowShader = new RadialGradient(w / 2f, h * 0.45f, h * 0.6f, new int[]{0x553B6A82, 0x00000000},
                new float[]{0f, 1f}, Shader.TileMode.CLAMP);
        vigShader = new RadialGradient(w / 2f, h / 2f, (float) Math.hypot(w, h) * 0.55f,
                new int[]{0x00000000, 0x00000000, 0xFF000000}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);

        sigPath.rewind();
        float s = 0.62f * w / 100f, ox = w * 0.5f - 50f * s, oy = h * 0.70f;
        for (float[] stroke : SIG) addStroke(sigPath, stroke, s, ox, oy);
        pm.setPath(sigPath, false);
        sigTotal = 0f;
        do {
            sigTotal += pm.getLength();
        } while (pm.nextContour());
    }

    /** Smooth pen stroke through the points (Catmull-Rom turned into cubic curves). */
    private static void addStroke(Path path, float[] a, float s, float ox, float oy) {
        int n = a.length / 2;
        float[] px = new float[n + 2], py = new float[n + 2];
        for (int i = 0; i < n; i++) {
            px[i + 1] = a[2 * i];
            py[i + 1] = a[2 * i + 1];
        }
        px[0] = px[1];
        py[0] = py[1];
        px[n + 1] = px[n];
        py[n + 1] = py[n];
        path.moveTo(ox + px[1] * s, oy + py[1] * s);
        for (int i = 1; i < n; i++) {
            float c1x = px[i] + (px[i + 1] - px[i - 1]) / 6f, c1y = py[i] + (py[i + 1] - py[i - 1]) / 6f;
            float c2x = px[i + 1] - (px[i + 2] - px[i]) / 6f, c2y = py[i + 1] - (py[i + 2] - py[i]) / 6f;
            path.cubicTo(ox + c1x * s, oy + c1y * s, ox + c2x * s, oy + c2y * s, ox + px[i + 1] * s, oy + py[i + 1] * s);
        }
    }
}
