# Living Clock

A live wallpaper: your photo, a glass clock behind you, and three shooting stars each time the minute changes.

- Choose a background photo and a subject photo separately (the subject is cut out automatically, or use a transparent PNG).
- Drag the subject or the clock on the live preview to place them.
- Adjust subject size, clock size, and turn shooting stars on or off.
- Set it as your live wallpaper from the app.

Build: push to `main`. GitHub Actions builds the debug APK and uploads it as the `Living-Clock-debug` artifact.

## Intro

When the wallpaper appears (returning home, screen on, unlock) it plays a short intro, at most once every few seconds: the subject enters in one of three random styles (settle, bloom, sheen), then the clock lifts above the subject with a soft glow while the background dims, rewinds, returns to now and settles back behind the subject. It can be switched off in the app.

### Rewind styles (choose in the app, each previews when selected)

1. **Luminous wake + spring landing**: a gold wedge and faint ghost hands trail the minute hand; the hands overshoot slightly on the way home, then a soft ring pulses.
2. **Mechanical ticking snap**: the hands ratchet in crisp steps that speed up going back and slow down coming home.
3. **Dial ticks light up**: ticks glow as the minute hand passes; numerals appear briefly at the old time.
4. **Quick and subtle**: a single fast, clean sweep of about 1.3 seconds.
5. **Wake + ticks combined**.

The seconds hand fades out while time is moving, because at rewind speed it would only flicker.

## Tap the clock

Tapping the clock face on the home screen drops dark numbers that leave thin rays. This relies on the launcher forwarding taps on empty wallpaper areas. Use **Test number drop** in the app to preview it.
