package com.rimon.livingclock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Background and subject prepared for one screen size. Built off the UI thread. */
final class Scene {

    interface Callback {
        void onScene(Scene scene);
    }

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    final Bitmap bg;       // screen-sized, centre-cropped photo
    final Bitmap subject;  // cutout scaled to the user's size, positioned by the renderer

    private Scene(Bitmap bg, Bitmap subject) {
        this.bg = bg;
        this.subject = subject;
    }

    static void buildAsync(Context c, int w, int h, float subjScale, Callback cb) {
        Context app = c.getApplicationContext();
        POOL.execute(() -> {
            Scene s = build(app, w, h, subjScale);
            MAIN.post(() -> cb.onScene(s));
        });
    }

    void recycle() {
        if (bg != null) bg.recycle();
        if (subject != null) subject.recycle();
    }

    private static Scene build(Context app, int w, int h, float subjScale) {
        Bitmap bg = null, subject = null;
        try {
            File bgFile = new File(app.getFilesDir(), Assets.BG);
            if (bgFile.exists()) {
                Bitmap src = Assets.decode(bgFile, Math.max(w, h));
                if (src != null) bg = cover(src, w, h);
            }
            File subjFile = new File(app.getFilesDir(), Assets.SUBJ);
            if (subjFile.exists()) {
                Bitmap src = Assets.decode(subjFile, Math.max(w, h));
                if (src != null) {
                    float s = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight()) * subjScale;
                    subject = Bitmap.createScaledBitmap(src,
                            Math.max(1, Math.round(src.getWidth() * s)),
                            Math.max(1, Math.round(src.getHeight() * s)), true);
                    if (subject != src) src.recycle();
                }
            }
        } catch (OutOfMemoryError e) {
            // Fall back to a plain clock rather than crashing the wallpaper.
        }
        return new Scene(bg, subject);
    }

    /** Scales src to cover w x h and crops from the centre. Recycles src. */
    private static Bitmap cover(Bitmap src, int w, int h) {
        float s = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight());
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Matrix m = new Matrix();
        m.setScale(s, s);
        m.postTranslate((w - src.getWidth() * s) / 2f, (h - src.getHeight() * s) / 2f);
        new Canvas(out).drawBitmap(src, m, new Paint(Paint.FILTER_BITMAP_FLAG));
        src.recycle();
        return out;
    }
}
