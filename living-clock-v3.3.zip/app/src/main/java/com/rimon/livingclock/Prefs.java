package com.rimon.livingclock;

import android.content.Context;
import android.content.SharedPreferences;

/** All saved settings in one place. */
final class Prefs {

    static final String FILE = "living_clock";
    static final String CLOCK_X = "clock_x", CLOCK_Y = "clock_y", CLOCK_SIZE = "clock_size";
    static final String SUBJ_X = "subj_x", SUBJ_Y = "subj_y", SUBJ_SCALE = "subj_scale";
    static final String STARS = "stars";
    static final String INTRO = "intro";
    static final String REWIND = "rewind";
    static final String IMG = "img_version";

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Tells the wallpaper that the photos changed so it rebuilds its scene. */
    static void bump(Context c) {
        SharedPreferences p = get(c);
        p.edit().putInt(IMG, p.getInt(IMG, 0) + 1).apply();
    }

    static void resetSubject(Context c) {
        get(c).edit()
                .putFloat(SUBJ_X, 0.5f)
                .putFloat(SUBJ_Y, 0.5f)
                .putFloat(SUBJ_SCALE, 1f)
                .apply();
        bump(c);
    }
}
