package com.rimon.livingclock;

import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

/**
 * Live wallpaper. Idle: one draw a second. During the intro, falling numbers and shooting stars it
 * follows the display refresh through Choreographer, then goes back to idle. Nothing draws while hidden.
 */
public class LivingClockService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new ClockEngine();
    }

    private final class ClockEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {

        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Choreographer choreographer = Choreographer.getInstance();
        private final Renderer renderer = new Renderer();
        private final Runnable tick = this::frame;
        private final Choreographer.FrameCallback vsync = t -> frame();

        private final BroadcastReceiver wakeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                renderer.playIntro(System.currentTimeMillis(), false);
                schedule(0);
            }
        };

        private SharedPreferences prefs;
        private Scene scene;
        private boolean visible, ready, destroyed, receiverOn;
        private int width, height, generation, imageVersion;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
            prefs = Prefs.get(LivingClockService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            imageVersion = prefs.getInt(Prefs.IMG, 0);
            renderer.readConfig(prefs);

            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            LivingClockService.this.registerReceiver(wakeReceiver, filter);
            receiverOn = true;
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                renderer.playIntro(System.currentTimeMillis(), false);
                schedule(0);
            } else {
                stop();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            ready = w > 0 && h > 0;
            if (!ready) return;
            if (w == width && h == height && scene != null) {
                schedule(0);
                return;
            }
            width = w;
            height = h;
            renderer.setSize(w, h);
            rebuild();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            ready = false;
            stop();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            destroyed = true;
            stop();
            prefs.unregisterOnSharedPreferenceChangeListener(this);
            if (receiverOn) {
                try {
                    LivingClockService.this.unregisterReceiver(wakeReceiver);
                } catch (IllegalArgumentException ignored) {
                    // Already unregistered.
                }
                receiverOn = false;
            }
            renderer.release();
            if (scene != null) scene.recycle();
            scene = null;
            super.onDestroy();
        }

        // ---------- taps ----------

        @Override
        public void onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) tap(e.getX(), e.getY());
        }

        /** Most launchers forward taps on empty home-screen areas as this command. */
        @Override
        public Bundle onCommand(String action, int x, int y, int z, Bundle extras, boolean resultRequested) {
            if (WallpaperManager.COMMAND_TAP.equals(action)) tap(x, y);
            return null;
        }

        private void tap(float x, float y) {
            if (renderer.tap(x, y, System.currentTimeMillis())) schedule(0);
        }

        // ---------- settings and scene ----------

        @Override
        public void onSharedPreferenceChanged(SharedPreferences p, String key) {
            renderer.readConfig(p);
            int v = p.getInt(Prefs.IMG, 0);
            if (v != imageVersion) {
                imageVersion = v;
                rebuild();
            } else {
                schedule(0);
            }
        }

        private void rebuild() {
            if (!ready || destroyed) return;
            final int gen = ++generation;
            Scene.buildAsync(LivingClockService.this, width, height,
                    prefs.getFloat(Prefs.SUBJ_SCALE, 1f), built -> {
                        if (destroyed || gen != generation) {
                            built.recycle();
                            return;
                        }
                        Scene old = scene;
                        scene = built;
                        renderer.setScene(built);
                        if (old != null) old.recycle();
                        schedule(0);
                    });
        }

        // ---------- frame loop ----------

        private void stop() {
            handler.removeCallbacks(tick);
            choreographer.removeFrameCallback(vsync);
        }

        private void schedule(long delayMs) {
            stop();
            if (visible && ready && !destroyed) handler.postDelayed(tick, delayMs);
        }

        private void frame() {
            if (!visible || !ready || destroyed) return;
            drawFrame(System.currentTimeMillis());
            long now = System.currentTimeMillis();
            if (renderer.animating(now)) choreographer.postFrameCallback(vsync);
            else handler.postDelayed(tick, renderer.delay(now));
        }

        private void drawFrame(long now) {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                if (Build.VERSION.SDK_INT >= 26) canvas = holder.lockHardwareCanvas();
                if (canvas == null) canvas = holder.lockCanvas();
                if (canvas != null) renderer.draw(canvas, now);
            } catch (RuntimeException ignored) {
                // The surface can vanish mid-frame during rotation or lock-screen changes.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (RuntimeException ignored) {
                        // Surface no longer valid.
                    }
                }
            }
        }
    }
}
