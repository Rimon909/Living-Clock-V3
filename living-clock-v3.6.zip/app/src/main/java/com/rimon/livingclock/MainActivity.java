package com.rimon.livingclock;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_BG = 1, REQ_SUBJ = 2;
    private static final String[] REWIND_NAMES = {"Luminous wake + spring landing", "Mechanical ticking snap",
            "Dial ticks light up", "Quick and subtle", "Wake + ticks combined", "Lightsaber forge"};
    private static final String[] INDICATOR_NAMES = {"Off", "Rim arc", "Lit ticks", "Tiny percentage",
            "Intro-only arc", "Arc + percentage"};
    private static final int BG = 0xFF0A0E16, CARD = 0xFF182030, EDGE = 0xFF2C3545;
    private static final int GOLD = 0xFFFFDC8A, MUTED = 0xFF9DA9BB, WHITE = 0xFFFFFFFF;

    private interface IntSink {
        void accept(int v);
    }

    private SharedPreferences prefs;
    private Preview preview;
    private TextView status;
    private Button subjectMode, clockMode;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = Prefs.get(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column();
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("LIVING CLOCK", 24, WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        root.addView(text("Time, with depth.", 12, MUTED));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int sw = Math.min(dm.widthPixels, dm.heightPixels);
        int sh = Math.max(dm.widthPixels, dm.heightPixels);
        int ph = dp(460);
        int pw = ph * sw / sh;

        preview = new Preview(this);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(pw, ph);
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        plp.topMargin = dp(18);
        root.addView(preview, plp);

        status = text("Drag the subject or the clock on the preview.", 12, MUTED);
        status.setGravity(Gravity.CENTER);
        root.addView(status, matchWrap(dp(10)));

        LinearLayout modes = row();
        subjectMode = button("Move subject", v -> setDragSubject(true));
        clockMode = button("Move clock", v -> setDragSubject(false));
        modes.addView(subjectMode, weight());
        modes.addView(clockMode, weight());
        root.addView(modes, matchWrap(dp(14)));

        LinearLayout card = column();
        card.setPadding(dp(16), dp(14), dp(16), dp(16));
        card.setBackground(rounded(CARD, EDGE));
        root.addView(card, matchWrap(dp(14)));

        card.addView(button("Choose background photo", v -> pick(REQ_BG)), matchWrap(0));
        card.addView(button("Choose subject photo", v -> pick(REQ_SUBJ)), matchWrap(dp(10)));

        card.addView(slider("Subject size", 50, 160,
                        Math.round(prefs.getFloat(Prefs.SUBJ_SCALE, 1f) * 100),
                        v -> { },
                        v -> {
                            prefs.edit().putFloat(Prefs.SUBJ_SCALE, v / 100f).apply();
                            Prefs.bump(this);
                            preview.rebuild();
                        }),
                matchWrap(dp(14)));

        card.addView(slider("Clock size", 60, 160,
                        prefs.getInt(Prefs.CLOCK_SIZE, 100),
                        v -> preview.setClockSize(v),
                        v -> prefs.edit().putInt(Prefs.CLOCK_SIZE, v).apply()),
                matchWrap(dp(14)));

        Switch stars = new Switch(this);
        stars.setText("Shooting stars each minute");
        stars.setTextColor(WHITE);
        stars.setChecked(prefs.getBoolean(Prefs.STARS, true));
        stars.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean(Prefs.STARS, on).apply();
            preview.setStars(on);
        });
        card.addView(stars, matchWrap(dp(14)));
        card.addView(button("Test shooting stars", v -> preview.spawnStars()), matchWrap(dp(8)));
        card.addView(button("Preview intro", v -> preview.playIntro()), matchWrap(dp(8)));
        card.addView(text("Hanging numerals (one tap on the clock)", 13, WHITE), matchWrap(dp(14)));
        RadioGroup numeralGroup = new RadioGroup(this);
        for (int i = 0; i < Hang.NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(4000 + i);
            rb.setText(Hang.NAMES[i]);
            rb.setTextColor(WHITE);
            numeralGroup.addView(rb);
        }
        numeralGroup.check(4000 + prefs.getInt(Prefs.NUMERALS, 0));
        numeralGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.NUMERALS, id - 4000).apply();
            preview.setNumerals(id - 4000);
        });
        card.addView(numeralGroup, matchWrap(0));
        card.addView(button("Test hanging numerals (tap again to drop)", v -> preview.toggleNumerals()), matchWrap(dp(8)));

        card.addView(text("While charging: everything sleeps, hands rest at 6", 13, WHITE), matchWrap(dp(14)));
        RadioGroup sleepGroup = new RadioGroup(this);
        String[] sleepNames = {"Off", "Settle (hands swing down)", "Breathing (slow dim)"};
        for (int i = 0; i < sleepNames.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(5000 + i);
            rb.setText(sleepNames[i]);
            rb.setTextColor(WHITE);
            sleepGroup.addView(rb);
        }
        sleepGroup.check(5000 + prefs.getInt(Prefs.SLEEP, 1));
        sleepGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.SLEEP, id - 5000).apply();
            preview.setSleepStyle(id - 5000);
        });
        card.addView(sleepGroup, matchWrap(0));
        card.addView(button("Test charging sleep (tap again to wake)", v -> preview.toggleSleep()), matchWrap(dp(8)));

        Switch introSwitch = new Switch(this);
        introSwitch.setText("Play intro when waking");
        introSwitch.setTextColor(WHITE);
        introSwitch.setChecked(prefs.getBoolean(Prefs.INTRO, true));
        introSwitch.setOnCheckedChangeListener((b, on) -> {
            prefs.edit().putBoolean(Prefs.INTRO, on).apply();
            preview.setIntro(on);
        });
        card.addView(introSwitch, matchWrap(dp(14)));

        card.addView(text("Intro animation", 13, WHITE), matchWrap(dp(4)));
        RadioGroup rewindGroup = new RadioGroup(this);
        for (int i = 0; i < REWIND_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(REWIND_NAMES[i]);
            rb.setTextColor(WHITE);
            rewindGroup.addView(rb);
        }
        rewindGroup.check(1000 + prefs.getInt(Prefs.REWIND, 0));
        rewindGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.REWIND, id - 1000).apply();
            preview.setRewind(id - 1000);
        });
        card.addView(rewindGroup, matchWrap(0));

        card.addView(text("Clock theme (double tap the top of the cutout to change)", 13, WHITE), matchWrap(dp(14)));
        RadioGroup themeGroup = new RadioGroup(this);
        for (int i = 0; i < Themes.NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(3000 + i);
            rb.setText(Themes.NAMES[i]);
            rb.setTextColor(WHITE);
            themeGroup.addView(rb);
        }
        themeGroup.check(3000 + prefs.getInt(Prefs.THEME, 0));
        themeGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.THEME, id - 3000).apply();
            preview.setTheme(id - 3000);
        });
        card.addView(themeGroup, matchWrap(0));

        card.addView(text("Battery indicator", 13, WHITE), matchWrap(dp(14)));
        RadioGroup indicatorGroup = new RadioGroup(this);
        for (int i = 0; i < INDICATOR_NAMES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(2000 + i);
            rb.setText(INDICATOR_NAMES[i]);
            rb.setTextColor(WHITE);
            indicatorGroup.addView(rb);
        }
        indicatorGroup.check(2000 + prefs.getInt(Prefs.INDICATOR, 1));
        indicatorGroup.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putInt(Prefs.INDICATOR, id - 2000).apply();
            preview.setIndicator(id - 2000);
        });
        card.addView(indicatorGroup, matchWrap(0));
        card.addView(button("Test pendulum (double tap centre)", v -> preview.togglePendulum()), matchWrap(dp(10)));
        card.addView(button("Test flip (triple tap)", v -> preview.toggleFlip()), matchWrap(dp(8)));

        Button apply = button("Set as live wallpaper", v -> applyWallpaper());
        apply.setBackground(rounded(GOLD, GOLD));
        apply.setTextColor(BG);
        root.addView(apply, matchWrap(dp(16)));

        setDragSubject(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        preview.setActive(true);
    }

    @Override
    protected void onPause() {
        preview.setActive(false);
        super.onPause();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        status.setText("Working…");
        if (req == REQ_BG) Assets.importBackground(this, uri, this::finishImport);
        else if (req == REQ_SUBJ) Assets.importSubject(this, uri, this::finishImport);
    }

    private void finishImport(boolean ok, String message) {
        status.setText(message);
        if (ok) preview.load();
    }

    private void pick(int req) {
        startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), req);
    }

    private void setDragSubject(boolean subject) {
        preview.setDragSubject(subject);
        subjectMode.setTextColor(subject ? GOLD : MUTED);
        clockMode.setTextColor(subject ? MUTED : GOLD);
    }

    private void applyWallpaper() {
        try {
            startActivity(new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            new ComponentName(this, LivingClockService.class)));
        } catch (Exception e) {
            toast("Couldn't open the wallpaper picker.");
        }
    }

    // ---------- live preview ----------

    /** Same renderer and scene as the wallpaper, at the phone's aspect ratio. Dragging edits positions live. */
    private final class Preview extends View {

        private final Renderer renderer = new Renderer();
        private final Tilt tilt = new Tilt(MainActivity.this, new Handler(Looper.getMainLooper()),
                (ax, ay, az) -> renderer.gauge.setGravity(ax, ay));
        private Scene scene;
        private int generation;
        private boolean active, dragSubject = true, dragging;
        private float downX, downY, baseX, baseY;

        Preview(Context c) {
            super(c);
            renderer.readConfig(prefs);
        }

        void setActive(boolean on) {
            active = on;
            if (on) {
                invalidate();
            } else {
                tilt.stop();
                renderer.closeGauge();
                renderer.setSleeping(false, System.currentTimeMillis(), true);
            }
        }

        void setDragSubject(boolean on) {
            dragSubject = on;
        }

        void setClockSize(int pct) {
            renderer.setClockSize(pct);
            invalidate();
        }

        void setStars(boolean on) {
            renderer.setStars(on);
            invalidate();
        }

        void spawnStars() {
            renderer.spawnStars(System.currentTimeMillis());
            invalidate();
        }

        void playIntro() {
            renderer.playIntro(System.currentTimeMillis(), true);
            invalidate();
        }

        void toggleNumerals() {
            renderer.tapNumerals(System.currentTimeMillis());
            invalidate();
        }

        void setNumerals(int preset) {
            renderer.hang.preset = preset;
            invalidate();
        }

        void setSleepStyle(int style) {
            renderer.setSleepStyle(style);
            invalidate();
        }

        void toggleSleep() {
            renderer.setSleeping(!renderer.sleeping(), System.currentTimeMillis(), false);
            invalidate();
        }

        void setIntro(boolean on) {
            renderer.setIntro(on);
        }

        void setIndicator(int style) {
            renderer.gauge.indicator = style;
            invalidate();
        }

        void setTheme(int theme) {
            renderer.setTheme(theme, System.currentTimeMillis());
            invalidate();
        }

        void togglePendulum() {
            renderer.gauge.togglePendulum(System.currentTimeMillis());
            invalidate();
        }

        void toggleFlip() {
            renderer.gauge.toggleFlip(System.currentTimeMillis());
            invalidate();
        }

        /** Picks a rewind style and plays it right away. */
        void setRewind(int style) {
            renderer.setRewind(style);
            renderer.playIntro(System.currentTimeMillis(), true);
            invalidate();
        }

        void load() {
            renderer.readConfig(prefs);
            rebuild();
        }

        void rebuild() {
            if (getWidth() <= 0) return;
            final int gen = ++generation;
            Scene.buildAsync(getContext(), getWidth(), getHeight(),
                    prefs.getFloat(Prefs.SUBJ_SCALE, 1f), built -> {
                        if (gen != generation) {
                            built.recycle();
                            return;
                        }
                        Scene old = scene;
                        scene = built;
                        renderer.setScene(built);
                        if (old != null) old.recycle();
                        invalidate();
                    });
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            renderer.setSize(w, h);
            rebuild();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            long now = System.currentTimeMillis();
            renderer.draw(canvas, now);
            if (renderer.gauge.due) renderer.gauge.readFrom(getContext());
            boolean need = active && renderer.sensing();
            if (need != tilt.running()) {
                if (need) tilt.start();
                else tilt.stop();
            }
            if (!active) return;
            if (renderer.animating(now)) postInvalidateOnAnimation();
            else postInvalidateDelayed(renderer.delay(now));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    downX = e.getX();
                    downY = e.getY();
                    baseX = dragSubject ? renderer.subjX() : renderer.clockX();
                    baseY = dragSubject ? renderer.subjY() : renderer.clockY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!dragging) return true;
                    float x = baseX + (e.getX() - downX) / getWidth();
                    float y = baseY + (e.getY() - downY) / getHeight();
                    if (dragSubject) renderer.setSubject(x, y);
                    else renderer.setClock(x, y);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (dragging) {
                        dragging = false;
                        SharedPreferences.Editor ed = prefs.edit();
                        if (dragSubject) {
                            ed.putFloat(Prefs.SUBJ_X, renderer.subjX()).putFloat(Prefs.SUBJ_Y, renderer.subjY());
                        } else {
                            ed.putFloat(Prefs.CLOCK_X, renderer.clockX()).putFloat(Prefs.CLOCK_Y, renderer.clockY());
                        }
                        ed.apply();
                    }
                    return true;
            }
            return super.onTouchEvent(e);
        }
    }

    // ---------- view helpers ----------

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextColor(WHITE);
        b.setBackground(rounded(CARD, EDGE));
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout slider(String label, int min, int max, int value, IntSink live, IntSink done) {
        LinearLayout box = column();
        TextView t = text(label + "  " + value, 13, WHITE);
        box.addView(t);
        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = p + min;
                t.setText(label + "  " + v);
                if (fromUser) live.accept(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) { }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                done.accept(s.getProgress() + min);
            }
        });
        box.addView(bar);
        return box;
    }

    private GradientDrawable rounded(int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(16));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout.LayoutParams matchWrap(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = top;
        return lp;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
