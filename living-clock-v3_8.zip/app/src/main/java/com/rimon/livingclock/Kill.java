package com.rimon.livingclock;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.MessageDigest;

/**
 * The kill switch. Turning it on (stopping everything) needs no password; turning the app back on needs the
 * code. Only a salted hash is stored in the app, and repeated wrong codes lock the dialog for a while.
 */
final class Kill {

    private static final String SALT = "lc.kill.v1:";
    private static final String HASH = "4e9f96a17f2579212b66c70e390fffe3ef4f7c5670edc5fbb7a112c9a6ac8e4d";
    private static final int MAX_FAILS = 5;
    private static final long LOCK_MS = 60_000L;

    private Kill() {}

    static boolean isOn(Context c) {
        return Prefs.get(c).getBoolean(Prefs.KILL, false);
    }

    /** Stops everything at once. */
    static void engage(Context c) {
        Prefs.get(c).edit().putBoolean(Prefs.KILL, true).commit();
    }

    /** Milliseconds left on a lockout, or 0. */
    static long lockedFor(Context c) {
        return Math.max(0L, Prefs.get(c).getLong(Prefs.KILL_LOCK, 0L) - System.currentTimeMillis());
    }

    /** Checks the code; on success the app starts again. */
    static boolean release(Context c, String pin) {
        SharedPreferences p = Prefs.get(c);
        if (lockedFor(c) > 0L) return false;
        if (matches(pin)) {
            p.edit().putBoolean(Prefs.KILL, false).putInt(Prefs.KILL_FAILS, 0).commit();
            return true;
        }
        int fails = p.getInt(Prefs.KILL_FAILS, 0) + 1;
        SharedPreferences.Editor ed = p.edit();
        if (fails >= MAX_FAILS) {
            ed.putInt(Prefs.KILL_FAILS, 0).putLong(Prefs.KILL_LOCK, System.currentTimeMillis() + LOCK_MS);
        } else {
            ed.putInt(Prefs.KILL_FAILS, fails);
        }
        ed.commit();
        return false;
    }

    private static boolean matches(String pin) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest((SALT + pin).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            String a = sb.toString();
            int diff = a.length() ^ HASH.length();
            for (int i = 0; i < Math.min(a.length(), HASH.length()); i++) diff |= a.charAt(i) ^ HASH.charAt(i);
            return diff == 0;
        } catch (Exception e) {
            return false;
        }
    }
}
