package com.rimon.livingclock;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.Random;

/**
 * The clock turns into twelve band members while music plays, and builds itself back when it stops.
 *
 * Members: the twelve hour ticks. Each one becomes a player with its own frequency range and character
 * (see Beat). They line up in a straight row at the clock's height.
 *
 * Looks 0-4 follow the clock theme: glass capsules, planets and moons, resonance rings, kinetic numerals,
 * noir blades. Four more patterns can be chosen in the app: 5 sunburst (rays around the dial), 6 mirror
 * ribbon (an aurora that breathes both ways), 7 LED matrix (dot columns with falling peak dots) and
 * 8 liquid wave (three layers of water with droplets). Each is a core, a thin film of glow and a soft halo.
 *
 * Five entrances: 0 unwind (a swirling cascade), 1 drop and bounce, 2 implode and burst,
 * 3 wave slide from the centre, 4 card flip. The hands never snap away: a soft-edged circle closes
 * around the hub and draws them in, tip first.
 *
 * Three reassemblies: 0 transformer (plates ratchet back along the dial and dock with a spark), 1 comet
 * gather (the members become comets that spiral home and a shockwave leaves the hub), 2 card fan (the
 * members stack at the hub and fan out clockwise onto the dial). All end with a ring locking around the rim,
 * the glass fading in and the hands unfolding from the hub to the real time while the dim lifts.
 *
 * The bands only follow real sound: silence, a mute or a pause sends them home, and a short listener wakes
 * them again when sound returns.
 *
 * Cost: nothing runs when no music plays. While playing: twelve springs and about forty strokes per frame,
 * no bitmaps, no blur filters, no allocation.
 */
final class Band {

    static final int N = Beat.N;

    private static final int OFF = 0, ENTER = 1, PLAY = 2, EXIT = 3;
    private static final long ENTER_MS = 1900, EXIT_MS = 2700, STOP_AFTER_MS = 900;
    private static final float SILENT_EXIT_SEC = 1.3f;
    private static final int SUN = 5, RIB = 6, LED = 7, WAVE = 8, ROWS = 10;
    private static final long[] ENTER_DUR = {1000, 1100, 1100, 950, 1000};

    private static final int IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A, CRIMSON = 0xFFD94452, ICE = 0xFF9ED2FF, AMBER = 0xFFFFA94D;
    private static final int TEAL = 0xFF5EEAD4, CORAL = 0xFFFF6B6B, PERI = 0xFF7C9CFF, SUNC = 0xFFFF8A4C;
    private static final int[] CORE = {IVORY, IVORY, IVORY, IVORY, 0xFFFFE9EA, 0xFFFFF1DC, 0xFFE8FFFB, IVORY, 0xFFEAF0FF};
    private static final int[] HALO = {GOLD, ICE, AMBER, GOLD, CRIMSON, SUNC, TEAL, GOLD, PERI};
    private static final int[] LEDC = new int[ROWS];

    static {
        for (int k = 0; k < ROWS; k++) {
            float f = k / (float) (ROWS - 1);
            LEDC[k] = f < 0.55f ? mix(TEAL, GOLD, f / 0.55f) : mix(GOLD, CORAL, (f - 0.55f) / 0.45f);
        }
    }
    private static final String[] LABEL = {"12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"};

    // Each member is a spring so a kick overshoots and settles while a cymbal shivers.
    private static final float[] STIFF = {900f, 260f, 520f, 1100f, 380f, 420f, 480f, 1200f, 1300f, 1700f, 700f, 1500f};
    private static final float[] DAMP = {26f, 22f, 24f, 34f, 24f, 24f, 24f, 36f, 38f, 44f, 20f, 40f};
    private static final float[] PUNCH = {0.34f, 0.20f, 0.26f, 0.30f, 0.14f, 0.14f, 0.16f, 0.24f, 0.22f, 0.20f, 0.18f, 0.22f};

    final Beat beat = new Beat();

    // Read by the renderer every frame.
    float clockAlpha = 1f;   // how much of the glass clock is still visible
    float cut = 1f;          // radius of the circle that keeps the hands visible (1 = all, 0 = none)
    float dim = 0f;          // how far the background has dimmed

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path blade = new Path();
    private final RectF oval = new RectF();
    private final Random random = new Random();

    private Context ctx;
    private boolean enabled = true, wantReal = true, music, demo, latch;
    private int enterPref = 5, enterStyle, state = OFF, theme, pattern, exitPref = 3, exitStyle, look;
    private long retryAt;
    private long curT;
    private float shapeA, spinC = 1f;
    private long t0, last = -1L, offSince = -1L, tNow;
    private float cx, cy, radius, width, height;
    private float rowX0, rowStep, rowY, barW, minH, maxH, tickLen, tickW;

    private final float[] sp = new float[N], sv = new float[N], delay = new float[N], frozen = new float[N];
    private final int[] order = new int[N];
    private final float[] slotX = new float[N], slotY = new float[N], slotR = new float[N];
    private final float[] frozenX = new float[N], frozenY = new float[N], frozenR = new float[N];
    private final float[] peakHold = new float[N], peakAge = new float[N];
    private final float[] tx = new float[N], ty = new float[N];
    private final Path ribbon = new Path(), ghost = new Path(), water = new Path();
    private float qx, qy;

    // Scratch pose for the member being drawn.
    private float px, py, pw, ph, prot, pa, pglow, ptick, psx;

    Band() {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    // ---------- control ----------

    void attach(Context c) {
        ctx = c.getApplicationContext();
    }

    void readConfig(SharedPreferences p) {
        enabled = p.getBoolean(Prefs.BAND, true);
        enterPref = Math.max(0, Math.min(5, p.getInt(Prefs.BAND_ENTER, 5)));
        wantReal = p.getBoolean(Prefs.BAND_REAL, true);
        pattern = Math.max(0, Math.min(4, p.getInt(Prefs.BAND_STYLE, 0)));
        exitPref = Math.max(0, Math.min(3, p.getInt(Prefs.BAND_EXIT, 3)));
        retryAt = 0L;
        if (!enabled && !demo && state != OFF) kill();
    }

    /** True from the first frame of the entrance to the last frame of the reassembly. */
    boolean active() {
        return state != OFF;
    }

    boolean playing() {
        return state == ENTER || state == PLAY;
    }

    /** A real signal from the system: music started or stopped. */
    void setMusic(boolean on) {
        if (on == music) return;
        music = on;
        latch = false;
        retryAt = 0L;
        if (on) offSince = -1L;
    }

    /** The bands left because the sound went quiet while the system still reports playback. */
    boolean needsProbe() {
        return latch && music && enabled && wantReal && !demo && state == OFF;
    }

    /** The short listener heard sound again. */
    void sound() {
        latch = false;
        retryAt = 0L;
    }

    /** The app's test button: bands with the simulated groove, until switched off. */
    void setDemo(boolean on, long now) {
        demo = on;
        if (on) offSince = -1L;
        else if (state == PLAY || state == ENTER) offSince = now - STOP_AFTER_MS;   // leave at once
    }

    boolean demo() {
        return demo;
    }

    /** Hard stop: wallpaper hidden, charging started, or the feature switched off. */
    void kill() {
        beat.stop();
        state = OFF;
        music = false;
        demo = false;
        latch = false;
        retryAt = 0L;
        offSince = -1L;
        clockAlpha = 1f;
        cut = 1f;
        dim = 0f;
    }

    void place(float cx, float cy, float radius, int w, int h) {
        this.cx = cx;
        this.cy = cy;
        this.radius = radius;
        width = w;
        height = h;
        float rowW = Math.min(w * 0.9f, radius * 5.4f);
        rowStep = rowW / (N - 1);
        rowX0 = w / 2f - rowW / 2f;
        rowY = cy;
        barW = Math.min(rowStep * 0.46f, radius * 0.20f);
        minH = radius * 0.16f;
        maxH = Math.min(radius * 1.9f, h * 0.30f);
        tickLen = radius * 0.14f;
        tickW = radius * 0.035f;
    }

    // ---------- state machine ----------

    void update(long now, int theme) {
        this.theme = theme;
        tNow = now;
        float dt = last < 0 ? 0f : Math.min(0.05f, (now - last) / 1000f);
        last = now;

        boolean want = enabled && (demo || (music && !latch));
        boolean silent = state != OFF && !demo && beat.real && beat.silentSec > SILENT_EXIT_SEC;
        boolean broken = state != OFF && !demo && wantReal && beat.lost;
        if (state == OFF) {
            if (want && now >= retryAt) begin(now);
        } else if (state == ENTER) {
            if (now - t0 >= ENTER_MS) state = PLAY;
        } else if (state == PLAY) {
            if (silent || broken) {                       // paused, muted or the listener died: leave now
                if (silent && music) latch = true;
                if (broken) retryAt = now + 6000L;
                beginExit(now);
            } else if (want) {
                offSince = -1L;
            } else {
                if (offSince < 0) offSince = now;
                if (now - offSince >= STOP_AFTER_MS) beginExit(now);
            }
        } else if (now - t0 >= EXIT_MS) {
            state = OFF;
            clockAlpha = 1f;
            cut = 1f;
            dim = 0f;
            return;
        }
        if (state == OFF) return;

        long t = now - t0;
        if (state == ENTER || state == PLAY) {
            beat.update(now, dt);
            springs(dt);
            computeSlots();
        }
        if (state == ENTER) {
            clockAlpha = 1f - smooth((t - 250f) / 650f);
            cut = 1f - easeInOut(clamp(t / 650f, 0f, 1f));
            dim = smooth(t / 1400f);
        } else if (state == PLAY) {
            clockAlpha = 0f;
            cut = 0f;
            dim = 1f;
        } else {
            dim = 1f - smooth((t - 1300f) / 1200f);
            clockAlpha = smooth((t - 1450f) / 500f);
            cut = t < 1900 ? 0f : backOut(clamp((t - 1900f) / 700f, 0f, 1f));
        }
    }

    private void begin(long now) {
        state = ENTER;
        t0 = now;
        enterStyle = enterPref < 5 ? enterPref : random.nextInt(5);
        look = pattern == 0 ? theme : 4 + pattern;
        if (!beat.start(ctx, wantReal && !demo) && !demo) {   // no permission or blocked: never fake it
            state = OFF;
            retryAt = now + 8000L;
            return;
        }
        java.util.Arrays.fill(peakHold, 0f);
        java.util.Arrays.fill(peakAge, 0f);
        java.util.Arrays.fill(sp, 0f);
        java.util.Arrays.fill(sv, 0f);
        for (int i = 0; i < N; i++) order[i] = i;
        if (enterStyle == 1) {
            for (int i = N - 1; i > 0; i--) {
                int j = random.nextInt(i + 1), v = order[i];
                order[i] = order[j];
                order[j] = v;
            }
        }
        for (int i = 0; i < N; i++) {
            float mid = Math.abs(i - 5.5f);
            switch (enterStyle) {
                case 0: delay[i] = i * 45f; break;
                case 1: delay[i] = order[i] * 40f; break;
                case 2: delay[i] = mid * 25f; break;
                case 3: delay[i] = mid * 50f; break;
                default: delay[i] = (i & 1) * 120f + i * 22f; break;
            }
        }
    }

    private void beginExit(long now) {
        state = EXIT;
        t0 = now;
        beat.stop();
        System.arraycopy(sp, 0, frozen, 0, N);
        System.arraycopy(slotX, 0, frozenX, 0, N);
        System.arraycopy(slotY, 0, frozenY, 0, N);
        System.arraycopy(slotR, 0, frozenR, 0, N);
        exitStyle = exitPref < 3 ? exitPref : random.nextInt(3);
    }

    private void springs(float dt) {
        float h = dt * 0.5f;
        for (int s = 0; s < 2; s++) {
            for (int i = 0; i < N; i++) {
                float target = 0.05f + 0.95f * beat.level[i] + PUNCH[i] * beat.hit[i];
                if (target > 1.15f) target = 1.15f;
                sv[i] += (STIFF[i] * (target - sp[i]) - DAMP[i] * sv[i]) * h;
                sp[i] += sv[i] * h;
                if (sp[i] < 0f) {
                    sp[i] = 0f;
                    sv[i] = 0f;
                }
            }
        }
        for (int i = 0; i < N; i++) {                   // LED peak dots hold, then fall
            float v = Math.min(1f, sp[i]);
            if (v >= peakHold[i]) {
                peakHold[i] = v;
                peakAge[i] = 0f;
            } else {
                peakAge[i] += dt;
                if (peakAge[i] > 0.35f) peakHold[i] = Math.max(v, peakHold[i] - dt * 0.7f);
            }
        }
    }

    /** Where each member rests this frame: a straight row, or rays around the dial for the sunburst. */
    private void computeSlots() {
        look = pattern == 0 ? theme : 4 + pattern;
        for (int i = 0; i < N; i++) {
            if (look == SUN) {
                float ang = i * 30f + beat.phase * 4f;
                double a = Math.toRadians(ang);
                float rr = radius * 0.50f + audioH(i, sp[i]) * 0.5f;
                slotX[i] = cx + (float) Math.sin(a) * rr;
                slotY[i] = cy - (float) Math.cos(a) * rr;
                slotR[i] = ang;
            } else {
                slotX[i] = rowSlotX(i);
                slotY[i] = rowY;
                slotR[i] = 0f;
            }
        }
    }

    // ---------- drawing ----------

    /** Dim overlay: a flat veil with a breath of the beat, so the room seems to pulse with the music. */
    void drawDim(Canvas c) {
        if (dim <= 0.002f) return;
        float pulse = state == PLAY || state == ENTER ? beat.beatPulse * beat.energy : 0f;
        float a = dim * (0.58f - 0.07f * pulse);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(0x05070C, (int) (255 * a)));
        c.drawRect(0f, 0f, width, height, paint);
    }

    void draw(Canvas c) {
        if (state == OFF) return;
        cv = c;
        long t = tNow - t0;
        curT = t;
        boolean exit = state == EXIT;
        look = pattern == 0 ? theme : 4 + pattern;
        shapeA = state == PLAY ? 1f : (state == ENTER ? smooth((t - 520f) / 800f) : 1f - smooth(t / 420f));

        // Row hairline, a faint stage line under the players.
        float rowA = state == PLAY ? 1f : (state == ENTER ? smooth((t - 900f) / 500f) : 1f - smooth(t / 400f));
        if (rowA > 0.01f && look < SUN) {
            float pulse = state == PLAY || state == ENTER ? beat.beatPulse : 0f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(Math.max(1f, radius * 0.008f));
            paint.setColor(withAlpha(HALO[look], (int) ((38 + 60 * pulse) * rowA)));
            c.drawLine(rowX0 - barW, rowY, rowX0 + rowStep * (N - 1) + barW, rowY, paint);
        }

        if (state == ENTER && enterStyle == 2) hubFlash(c, t);
        if (shapeA > 0.01f) {
            if (look == SUN) sunCore(c);
            else if (look == RIB) ribbonShape(c);
            else if (look == WAVE) waveShape(c);
        }
        if (exit && exitStyle == 2) fanHub(c, t);

        for (int i = 0; i < N; i++) {
            if (exit) exitPose(i, t);
            else enterPose(i, t);
            if (pa > 0.01f) drawMember(i);
        }

        if (exit && exitStyle == 1) cometTrails(c, t);
        if (exit) ringLock(c, t);
        if (exit && exitStyle == 1) shock(c, t);
    }

    // ---------- poses ----------

    private float audioH(int i, float s) {
        float v = s > 1.15f ? 1.15f : s;
        float top = look == SUN ? Math.min(maxH, radius * 0.95f) : maxH;
        return minH + (top - minH) * v;
    }

    private float rowSlotX(int i) {
        float sway = state == PLAY && look < SUN ? (float) Math.sin(beat.phase * Math.PI + i * 0.45f) * barW * 0.22f * beat.energy : 0f;
        return rowX0 + rowStep * i + sway;
    }

    private float dialX(int i, float rr) {
        return cx + Renderer.COS[i * 5] * rr;
    }

    private float dialY(int i, float rr) {
        return cy + Renderer.SIN[i * 5] * rr;
    }

    private void enterPose(int i, long t) {
        float dur = ENTER_DUR[enterStyle];
        float u = clamp((t - delay[i]) / dur, 0f, 1f);
        float sx = dialX(i, radius * 0.87f), sy = dialY(i, radius * 0.87f);
        float ex = slotX[i], ey = slotY[i];
        float ang = i * 30f, dAng = wrap180(slotR[i] - ang);
        float hs = smooth((u - 0.5f) / 0.5f);
        float barH = audioH(i, sp[i]);
        float e;

        pa = 1f;
        psx = 1f;
        pglow = hs;
        switch (enterStyle) {
            case 0: {                                           // unwind: a swirling cascade
                e = easeInOut(u);
                float dx = ex - sx, dy = ey - sy, len = Math.max(1f, (float) Math.hypot(dx, dy));
                float sw = (float) Math.sin(Math.PI * e) * radius * 0.6f;
                px = sx + dx * e - dy / len * sw;
                py = sy + dy * e + dx / len * sw;
                prot = ang + dAng * e;
                break;
            }
            case 1: {                                           // drop and bounce
                px = sx + (ex - sx) * easeOutCubic(clamp(u * 1.4f, 0f, 1f));
                py = sy + (ey - sy) * bounce(u);
                e = easeOutCubic(u);
                prot = ang + dAng * e;
                break;
            }
            case 2: {                                           // implode to the hub, then burst
                if (u < 0.35f) {
                    e = easeIn(u / 0.35f);
                    px = sx + (cx - sx) * e;
                    py = sy + (cy - sy) * e;
                    prot = ang + 90f * e;
                    float shrink = 1f - 0.8f * e;
                    ph = tickLen * shrink;
                    pw = tickW * shrink;
                    ptick = 1f;
                    pglow = e;
                    return;
                }
                e = backOut((u - 0.35f) / 0.65f);
                px = cx + (ex - cx) * e;
                py = cy + (ey - cy) * e;
                prot = slotR[i] + (ang + 90f - slotR[i]) * (1f - clamp(e, 0f, 1f));
                break;
            }
            case 3: {                                           // wave slide: x leads, y follows with a spring
                px = sx + (ex - sx) * easeInOut(u);
                py = sy + (ey - sy) * backOut(clamp(u * 1.12f, 0f, 1f));
                e = easeInOut(u);
                prot = ang + dAng * e;
                break;
            }
            default: {                                          // card flip: turns twice on its way
                e = easeInOut(u);
                px = sx + (ex - sx) * e;
                py = sy + (ey - sy) * e;
                prot = ang + dAng * e;
                psx = Math.max(0.06f, Math.abs((float) Math.cos(Math.PI * 2f * e)));
                pglow = hs + (u > 0.9f ? (1f - u) * 6f : 0f);
                break;
            }
        }
        float wu = smooth(u);
        ph = tickLen + (barH - tickLen) * hs;
        pw = tickW + (barW - tickW) * wu;
        ptick = 1f - smooth(u / 0.4f);
    }

    private void exitPose(int i, long t) {
        float fa = smooth(t / 450f);
        float barH = audioH(i, frozen[i]);
        float plate = tickLen;
        float startX = frozenX[i], startY = frozenY[i];
        float flick = (t < 360 && ((t / 45) & 1) == 1) ? 0.55f : 1f;   // power-down flicker

        ph = barH + (plate - barH) * fa;
        pw = barW + (tickW * 1.6f - barW) * fa;
        pa = flick * (1f - smooth((t - 1700f) / 400f));
        psx = 1f;
        pglow = 0.6f * (1f - fa);
        ptick = 0f;
        if (exitStyle == 1) cometPose(i, t, startX, startY);
        else if (exitStyle == 2) fanPose(i, t, startX, startY);
        else ratchetPose(i, t, startX, startY);
    }

    /** 0: plates ratchet back along the dial in six crisp steps and dock with a spark. */
    private void ratchetPose(int i, long t, float startX, float startY) {
        float u = clamp((t - 400f - i * 55f) / 1000f, 0f, 1f);
        float er = ratchet(u);
        float r0 = (float) Math.hypot(startX - cx, startY - cy), r1 = radius * 0.87f;
        float a0 = (float) Math.atan2(startY - cy, startX - cx);
        float a1 = (float) Math.toRadians(i * 30f - 90f);
        float da = a1 - a0;
        da = (float) (da - 2 * Math.PI * Math.floor((da + Math.PI) / (2 * Math.PI)));
        float r = r0 + (r1 - r0) * er, a = a0 + da * er;
        px = cx + (float) Math.cos(a) * r;
        py = cy + (float) Math.sin(a) * r;
        prot = frozenR[i] + wrap180(i * 30f - frozenR[i]) * er;
        ph = ph + (tickLen - ph) * er;
        pw = pw + (tickW - pw) * er;
        ptick = smooth((u - 0.75f) / 0.25f);
        float dock = (t - (400f + i * 55f + 1000f)) / 260f;     // a spark where each plate locks in
        if (dock > 0f && dock < 1f) pglow = 1f + 1.6f * (1f - dock);
    }

    private float cometU(int i, long t) {
        return clamp((t - 350f - i * 45f) / 950f, 0f, 1f);
    }

    /** Position of comet i at progress u along its spiral home; the result lands in qx, qy. */
    private void cometAt(int i, float u) {
        float e = smooth(u);
        float r0 = (float) Math.hypot(frozenX[i] - cx, frozenY[i] - cy), r1 = radius * 0.87f;
        float a0 = (float) Math.atan2(frozenY[i] - cy, frozenX[i] - cx);
        float a1 = (float) Math.toRadians(i * 30f - 90f);
        float da = a1 - a0;
        da = (float) (da - 2 * Math.PI * Math.floor((da + Math.PI) / (2 * Math.PI)));
        float r = r0 + (r1 - r0) * e + (float) Math.sin(Math.PI * e) * radius * 0.18f;
        float a = a0 + da * e + (float) Math.sin(Math.PI * e) * 1.5f;   // swirls clockwise on the way
        qx = cx + (float) Math.cos(a) * r;
        qy = cy + (float) Math.sin(a) * r;
    }

    /** 1: each member becomes a comet that spirals home. */
    private void cometPose(int i, long t, float startX, float startY) {
        float u = cometU(i, t), e = smooth(u);
        cometAt(i, u);
        px = qx;
        py = qy;
        prot = frozenR[i] + wrap180(i * 30f - frozenR[i]) * e;
        float fly = (float) Math.sin(Math.PI * e);
        ph = ph + (tickLen * (1f + 0.5f * fly) - ph) * e;
        pw = pw + (tickW * (1f + 0.6f * fly) - pw) * e;
        pglow = Math.max(pglow, 0.9f + 0.7f * fly);
        ptick = smooth((u - 0.8f) / 0.2f);
        float dock = (t - (350f + i * 45f + 950f)) / 260f;
        if (dock > 0f && dock < 1f) pglow = 1f + 1.6f * (1f - dock);
    }

    /** 2: everyone slides to the hub as a stack, then fans out clockwise onto the dial with a springy settle. */
    private void fanPose(int i, long t, float startX, float startY) {
        float k = Math.abs(i - 5.5f);
        float u1 = clamp((t - 80f - (5.5f - k) * 25f) / 520f, 0f, 1f), e1 = easeInOut(u1);
        float u2 = clamp((t - 640f - i * 50f) / 700f, 0f, 1f);
        if (u2 <= 0f) {
            px = startX + (cx - startX) * e1;
            py = startY + (cy - startY) * e1;
            prot = frozenR[i] * (1f - e1);
            ph = ph + (tickLen * 1.3f - ph) * e1;
            pw = pw + (tickW * 2f - pw) * e1;
            pglow = Math.max(pglow, 0.8f * e1);
            return;
        }
        float e2 = backOut(u2), sw = smooth(u2);
        float ang = i * 30f * sw, rad = radius * 0.87f * e2;
        double a = Math.toRadians(ang);
        px = cx + (float) Math.sin(a) * rad;
        py = cy - (float) Math.cos(a) * rad;
        prot = ang;
        ph = tickLen * (1.3f - 0.3f * sw);
        pw = tickW * (2f - sw);
        pglow = 0.9f * (1f - sw);
        ptick = smooth((u2 - 0.7f) / 0.3f);
        float dock = (t - (640f + i * 50f + 600f)) / 260f;
        if (dock > 0f && dock < 1f) pglow = 1f + 1.6f * (1f - dock);
    }

    /** Short fading ghosts behind each comet. */
    private void cometTrails(Canvas c, long t) {
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < N; i++) {
            float u = cometU(i, t);
            if (u <= 0.02f || u >= 0.97f) continue;
            for (int g = 1; g <= 3; g++) {
                float uu = u - g * 0.05f;
                if (uu <= 0f) break;
                cometAt(i, uu);
                float f = 1f - g / 4f;
                paint.setColor(withAlpha(HALO[look], (int) (150 * f * pa)));
                c.drawCircle(qx, qy, radius * 0.032f * f, paint);
            }
        }
    }

    /** A ring leaves the hub once the comets are home. */
    private void shock(Canvas c, long t) {
        float p = clamp((t - 1250f) / 800f, 0f, 1f);
        if (p <= 0f || p >= 1f) return;
        float e = 1f - (1f - p) * (1f - p);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(radius * 0.05f * (1f - p) + 1f);
        paint.setColor(withAlpha(HALO[look], (int) (90 * (1f - p))));
        c.drawCircle(cx, cy, radius * (0.1f + 0.9f * e), paint);
        paint.setStrokeWidth(radius * 0.01f + 1f);
        paint.setColor(withAlpha(0xFFFFFF, (int) (200 * (1f - p))));
        c.drawCircle(cx, cy, radius * (0.1f + 0.9f * e), paint);
    }

    /** The stack at the hub glows while the members gather. */
    private void fanHub(Canvas c, long t) {
        float p = clamp((t - 250f) / 900f, 0f, 1f);
        if (p <= 0f || p >= 1f) return;
        float k = (float) Math.sin(Math.PI * p);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(HALO[look], (int) (80 * k)));
        c.drawCircle(cx, cy, radius * (0.08f + 0.22f * k), paint);
        paint.setColor(withAlpha(0xFFFFFF, (int) (210 * k)));
        c.drawCircle(cx, cy, radius * 0.05f * (0.6f + k), paint);
    }

    private void hubFlash(Canvas c, long t) {
        float p = clamp((t - 250f) / 650f, 0f, 1f);
        if (p <= 0f || p >= 1f) return;
        float k = (float) Math.sin(Math.PI * p);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(GOLD, (int) (70 * k)));
        c.drawCircle(cx, cy, radius * (0.1f + 0.35f * k), paint);
        paint.setColor(withAlpha(0xFFFFFF, (int) (200 * k)));
        c.drawCircle(cx, cy, radius * 0.06f * (0.5f + k), paint);
    }

    /** A thin ring draws itself clockwise around the rim as the plates lock in. */
    private void ringLock(Canvas c, long t) {
        float p = clamp((t - 1450f) / 600f, 0f, 1f);
        if (p <= 0f) return;
        float fade = 1f - smooth((t - 2050f) / 450f);
        if (fade <= 0.01f) return;
        float e = easeInOut(p), r = radius * 0.98f;
        oval.set(cx - r, cy - r, cx + r, cy + r);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.05f);
        paint.setColor(withAlpha(HALO[look], (int) (60 * fade)));
        c.drawArc(oval, -90f, 360f * e, false, paint);
        paint.setStrokeWidth(radius * 0.012f);
        paint.setColor(withAlpha(CORE[look], (int) (230 * fade)));
        c.drawArc(oval, -90f, 360f * e, false, paint);
        if (p < 1f) {                                           // the bright head of the sweep
            double a = Math.toRadians(-90f + 360f * e);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(0xFFFFFF, (int) (255 * fade)));
            c.drawCircle(cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, radius * 0.03f, paint);
        }
    }

    // ---------- member shapes ----------

    private void drawMember(int i) {
        float lv = state == EXIT ? frozen[i] : sp[i];
        float hit = state == EXIT ? 0f : beat.hit[i];
        float shape = 1f - ptick;

        saveMember();
        if (shape > 0.02f) {
            switch (look) {
                case 1: planet(i, lv, hit, shape); break;
                case 2: resonance(i, lv, hit, shape); break;
                case 3: numeral(i, lv, hit, shape); break;
                case 4: noir(i, lv, hit, shape); break;
                case 5: ray(i, lv, hit, shape); break;
                case 6:
                case 8: bead(i, hit, shape); break;
                case 7: led(i, lv, hit, shape); break;
                default: glass(i, hit, shape); break;
            }
        }
        if (ptick > 0.02f) tick(ptick);
        restoreMember();
    }

    private Canvas cv;

    private void saveMember() {
        cv.save();
        cv.translate(px, py);
        cv.rotate(prot);
        if (psx != 1f) cv.scale(psx, 1f);
    }

    private void restoreMember() {
        cv.restore();
    }

    private void glowLine(float hl, float w, int core, int halo, float a, float g) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(w * 2.8f);
        paint.setColor(withAlpha(halo, (int) (62 * a * g)));
        cv.drawLine(0f, -hl, 0f, hl, paint);
        paint.setStrokeWidth(w * 1.5f);
        paint.setColor(withAlpha(halo, (int) (105 * a * g)));
        cv.drawLine(0f, -hl, 0f, hl, paint);
        paint.setStrokeWidth(w);
        paint.setColor(withAlpha(core, (int) (255 * a)));
        cv.drawLine(0f, -hl, 0f, hl, paint);
    }

    private void tick(float a) {
        glowLine(Math.max(0f, ph / 2f - pw / 2f), pw, IVORY, GOLD, pa * a, Math.min(1f, pglow + 0.3f));
    }

    /** 0: frosted capsule with a bright rim and a spark on the hit. */
    private void glass(int i, float hit, float a) {
        float hl = Math.max(0f, ph / 2f - pw / 2f);
        glowLine(hl, pw, IVORY, GOLD, pa * a * 0.62f, pglow + 0.4f);
        paint.setStrokeWidth(Math.max(1f, pw * 0.2f));
        paint.setColor(withAlpha(0xFFFFFF, (int) (210 * pa * a)));
        cv.drawLine(-pw * 0.22f, -hl * 0.82f, -pw * 0.22f, hl * 0.82f, paint);
        if (hit > 0.35f) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(0xFFFFFF, (int) (255 * hit * pa * a)));
            cv.drawCircle(0f, -ph / 2f, pw * 0.5f * hit, paint);
        }
    }

    /** 1: a ringed planet at the top of a hairline orbit, a small moon below. Hits swell the ring. */
    private void planet(int i, float lv, float hit, float a) {
        float hl = Math.max(0f, ph / 2f - pw / 2f);
        float pr = pw * (0.55f + 0.45f * Math.min(1f, lv));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, pw * 0.12f));
        paint.setColor(withAlpha(0xFFFFFF, (int) (90 * pa * a)));
        cv.drawLine(0f, -hl, 0f, hl * 0.6f, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(ICE, (int) (60 * pa * a * (pglow + 0.4f))));
        cv.drawCircle(0f, -hl, pr * 2.1f, paint);
        paint.setColor(withAlpha(IVORY, (int) (255 * pa * a)));
        cv.drawCircle(0f, -hl, pr, paint);
        paint.setColor(withAlpha(ICE, (int) (240 * pa * a)));
        cv.drawCircle(0f, hl * 0.6f, pr * 0.45f, paint);

        cv.save();
        cv.scale(1f, 0.35f, 0f, -hl);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, pw * 0.14f));
        paint.setColor(withAlpha(ICE, (int) ((150 + 80 * hit) * pa * a)));
        cv.drawCircle(0f, -hl, pr * (1.9f + 0.9f * hit), paint);
        cv.restore();
    }

    /** 2: a resonance ring whose arc grows with the level and turns with the beat. */
    private void resonance(int i, float lv, float hit, float a) {
        float rr = Math.min(rowStep * 0.40f, radius * 0.36f);
        float sweep = 28f + 320f * Math.min(1f, lv);
        float start = -90f + beat.phase * 90f * ((i & 1) == 0 ? 1f : -1f);
        oval.set(-rr, -rr, rr, rr);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, pw * 0.9f));
        paint.setColor(withAlpha(AMBER, (int) (60 * pa * a * (pglow + 0.4f))));
        cv.drawArc(oval, start, sweep, false, paint);
        paint.setStrokeWidth(Math.max(1f, pw * 0.34f));
        paint.setColor(withAlpha(IVORY, (int) (255 * pa * a)));
        cv.drawArc(oval, start, sweep, false, paint);
        if (hit > 0.05f) {
            paint.setStrokeWidth(Math.max(1f, pw * 0.14f));
            paint.setColor(withAlpha(GOLD, (int) (150 * hit * pa * a)));
            cv.drawCircle(0f, 0f, rr * (1f + 0.7f * (1f - hit)), paint);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(GOLD, (int) (255 * pa * a)));
        cv.drawCircle(0f, 0f, pw * 0.2f * (1f + hit), paint);
    }

    /** 3: the member is its own numeral; it swells with the level and bounces on a hit. */
    private void numeral(int i, float lv, float hit, float a) {
        float size = pw * (1.5f + 2.2f * Math.min(1f, lv)) * (1f + 0.25f * hit);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(size * 1.28f);
        paint.setColor(withAlpha(GOLD, (int) (38 * pa * a * (pglow + 0.4f))));
        cv.drawText(LABEL[i], 0f, size * 0.45f, paint);
        paint.setTextSize(size * 1.1f);
        paint.setColor(withAlpha(GOLD, (int) (80 * pa * a)));
        cv.drawText(LABEL[i], 0f, size * 0.40f, paint);
        paint.setTextSize(size);
        paint.setColor(withAlpha(IVORY, (int) (255 * pa * a)));
        cv.drawText(LABEL[i], 0f, size * 0.35f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, pw * 0.16f));
        paint.setColor(withAlpha(GOLD, (int) (170 * pa * a)));
        cv.drawLine(-pw * 0.7f, size * 0.7f, pw * 0.7f, size * 0.7f, paint);
    }

    /** 4: a slim dauphine blade that sways with the beat, crimson core and a white-hot edge. */
    private void noir(int i, float lv, float hit, float a) {
        float sway = ((i & 1) == 0 ? 1f : -1f) * 8f * Math.min(1f, lv) * (float) Math.sin(beat.phase * Math.PI * 2f);
        cv.rotate(sway);
        float hh = ph / 2f, ww = pw * 0.65f;
        blade.rewind();
        blade.moveTo(0f, -hh);
        blade.lineTo(ww, 0f);
        blade.lineTo(0f, hh);
        blade.lineTo(-ww, 0f);
        blade.close();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(pw * 1.3f);
        paint.setColor(withAlpha(CRIMSON, (int) (66 * pa * a * (pglow + 0.4f))));
        cv.drawPath(blade, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(CRIMSON, (int) (225 * pa * a)));
        cv.drawPath(blade, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, pw * 0.12f));
        paint.setColor(withAlpha(0xFFFFFF, (int) ((170 + 80 * hit) * pa * a)));
        cv.drawPath(blade, paint);
        paint.setStrokeJoin(Paint.Join.MITER);
    }

    // ---------- new patterns ----------

    /** 5: sunburst. A glowing core in the middle, rays that grow outward and a slow turn with the beat. */
    private void sunCore(Canvas c) {
        float k = shapeA;
        float pulse = beat.beatPulse * beat.energy + 0.25f * beat.hit[0];
        float r = radius * 0.30f * (1f + 0.14f * pulse);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(HALO[look], (int) (40 * k)));
        c.drawCircle(cx, cy, r * 1.7f, paint);
        paint.setColor(withAlpha(HALO[look], (int) (95 * k)));
        c.drawCircle(cx, cy, r * 1.2f, paint);
        paint.setColor(withAlpha(CORE[look], (int) (235 * k)));
        c.drawCircle(cx, cy, r * 0.55f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, radius * 0.008f));
        paint.setColor(withAlpha(HALO[look], (int) ((50 + 60 * beat.beatPulse) * k)));
        c.drawCircle(cx, cy, radius * 0.5f, paint);
    }

    private void ray(int i, float lv, float hit, float a) {
        float hl = Math.max(0f, ph / 2f - pw / 2f);
        glowLine(hl, pw * 0.8f, CORE[look], HALO[look], pa * a, pglow + 0.45f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(0xFFFFFF, (int) ((150 + 105 * hit) * pa * a)));
        cv.drawCircle(0f, -ph / 2f, pw * (0.5f + 0.5f * hit), paint);
    }

    /** A bead that stands in for a member while the ribbon or the wave is not yet fully drawn. */
    private void bead(int i, float hit, float a) {
        float k = pa * a * (1f - shapeA);
        if (k < 0.01f) return;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(HALO[look], (int) (90 * k)));
        cv.drawCircle(0f, 0f, pw * 1.1f, paint);
        paint.setColor(withAlpha(CORE[look], (int) (255 * k)));
        cv.drawCircle(0f, 0f, pw * 0.5f, paint);
    }

    /** 7: LED matrix. Dot columns light from the bottom; a white peak dot holds, then falls. */
    private void led(int i, float lv, float hit, float a) {
        float squash = state == EXIT ? 1f - smooth(curT / 450f) : 1f;
        float dy = maxH * 0.80f / ROWS * squash;
        float r = Math.min(maxH * 0.80f / ROWS * 0.36f, rowStep * 0.22f) * (0.55f + 0.45f * squash);
        float lit = clamp(lv, 0f, 1.1f) * ROWS * squash;
        float y0 = (ROWS - 1) * dy * 0.5f;
        paint.setStyle(Paint.Style.FILL);
        for (int k = 0; k < ROWS; k++) {
            float f = clamp(lit - k, 0f, 1f);
            float y = y0 - k * dy;
            paint.setColor(withAlpha(LEDC[k], (int) ((26 + 229 * f) * pa * a)));
            cv.drawCircle(0f, y, r, paint);
            if (f > 0.5f && lit - k < 1.5f) {                // a soft glow on the top lit dot
                paint.setColor(withAlpha(LEDC[k], (int) ((55 + 90 * hit) * pa * a)));
                cv.drawCircle(0f, y, r * (1.8f + 0.6f * hit), paint);
            }
        }
        int pk = Math.min(ROWS - 1, (int) (peakHold[i] * ROWS));
        if (pk >= (int) lit && peakHold[i] > 0.05f && squash > 0.5f) {
            paint.setColor(withAlpha(0xFFFFFF, (int) (235 * pa * a)));
            cv.drawCircle(0f, y0 - pk * dy, r * 0.9f, paint);
        }
    }

    private void seg(Path p, int i, boolean rev) {
        int i0 = Math.max(i - 1, 0), i3 = Math.min(i + 2, N - 1);
        float c1x = tx[i] + (tx[i + 1] - tx[i0]) / 6f, c1y = ty[i] + (ty[i + 1] - ty[i0]) / 6f;
        float c2x = tx[i + 1] - (tx[i3] - tx[i]) / 6f, c2y = ty[i + 1] - (ty[i3] - ty[i]) / 6f;
        if (!rev) {
            p.cubicTo(c1x, c1y, c2x, c2y, tx[i + 1], ty[i + 1]);
        } else {
            float m = 2f * rowY;
            p.cubicTo(c2x, m - c2y, c1x, m - c1y, tx[i], m - ty[i]);
        }
    }

    /** 6: mirror ribbon. A soft aurora that breathes up and down together, with a fainter ghost inside. */
    private void ribbonShape(Canvas c) {
        float k = shapeA, wob = beat.phase * 6.2832f;
        for (int i = 0; i < N; i++) tx[i] = slotX[i];
        for (int layer = 0; layer < 2; layer++) {
            float scale = layer == 0 ? 0.55f : 1f;
            for (int i = 0; i < N; i++) {
                float half = minH * 0.45f + (maxH * 0.5f - minH * 0.45f) * Math.min(1.1f, sp[i]);
                float flow = 1f + 0.06f * beat.energy * (float) Math.sin(wob * 0.5f + i * 0.7f + layer * 1.9f);
                ty[i] = rowY - half * scale * flow;
            }
            Path p = layer == 0 ? ghost : ribbon;
            p.rewind();
            p.moveTo(tx[0], ty[0]);
            for (int i = 0; i < N - 1; i++) seg(p, i, false);
            p.lineTo(tx[N - 1], 2f * rowY - ty[N - 1]);
            for (int i = N - 2; i >= 0; i--) seg(p, i, true);
            p.close();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(layer == 0 ? ICE : HALO[look], (int) ((layer == 0 ? 55 : 70) * k)));
            c.drawPath(p, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeWidth(Math.max(1f, barW * (layer == 0 ? 0.25f : 0.9f)));
            paint.setColor(withAlpha(layer == 0 ? ICE : HALO[look], (int) ((layer == 0 ? 60 : 70) * k)));
            c.drawPath(p, paint);
            paint.setStrokeWidth(Math.max(1f, barW * (layer == 0 ? 0.1f : 0.26f)));
            paint.setColor(withAlpha(layer == 0 ? 0xFFFFFF : CORE[look], (int) ((layer == 0 ? 120 : 235) * k)));
            c.drawPath(p, paint);
            paint.setStrokeJoin(Paint.Join.MITER);
        }
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Math.max(1f, barW * 0.12f));
        for (int i = 0; i < N; i++) {                        // spokes and beads at the nodes
            float half = rowY - ty[i];
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(withAlpha(CORE[look], (int) (46 * k)));
            c.drawLine(tx[i], rowY - half, tx[i], rowY + half, paint);
            paint.setStyle(Paint.Style.FILL);
            float h = beat.hit[i];
            paint.setColor(withAlpha(0xFFFFFF, (int) ((170 + 85 * h) * k)));
            float br = barW * (0.34f + 0.3f * h);
            c.drawCircle(tx[i], rowY - half, br, paint);
            c.drawCircle(tx[i], rowY + half, br, paint);
        }
    }

    /** 8: liquid wave. Three layers of water that rise with each member, with droplets thrown on hits. */
    private void waveShape(Canvas c) {
        float k = shapeA, wob = beat.phase * 3.1416f;
        float base = rowY + maxH * 0.32f;
        for (int i = 0; i < N; i++) tx[i] = slotX[i];
        for (int layer = 0; layer < 3; layer++) {
            for (int i = 0; i < N; i++) {
                float h = (minH * 0.3f + (maxH * 0.75f - minH * 0.3f) * Math.min(1.1f, sp[i])) * (1f - 0.12f * (2 - layer));
                float w = (float) Math.sin(wob + i * 0.55f + layer * 1.7f) * maxH * 0.03f * (0.3f + beat.energy);
                ty[i] = base - h + w;
            }
            water.rewind();
            float x0 = tx[0] - rowStep * 0.6f, x1 = tx[N - 1] + rowStep * 0.6f;
            water.moveTo(x0, ty[0]);
            water.lineTo(tx[0], ty[0]);
            for (int i = 0; i < N - 1; i++) seg(water, i, false);
            water.lineTo(x1, ty[N - 1]);
            water.lineTo(x1, base);
            water.lineTo(x0, base);
            water.close();
            paint.setStyle(Paint.Style.FILL);
            int col = layer == 0 ? ICE : (layer == 1 ? HALO[look] : CORE[look]);
            paint.setColor(withAlpha(col, (int) ((layer == 0 ? 60 : (layer == 1 ? 105 : 70)) * k)));
            c.drawPath(water, paint);
            if (layer == 2) {                                   // bright crest on the front layer
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setStrokeWidth(Math.max(1f, barW * 0.5f));
                paint.setColor(withAlpha(HALO[look], (int) (80 * k)));
                c.drawPath(water, paint);
                paint.setStrokeWidth(Math.max(1f, barW * 0.16f));
                paint.setColor(withAlpha(0xFFFFFF, (int) (230 * k)));
                c.drawPath(water, paint);
                paint.setStrokeJoin(Paint.Join.MITER);
            }
        }
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < N; i++) {                          // droplets: a stateless arc driven by the hit decay
            float h = beat.hit[i];
            if (h < 0.12f) continue;
            float u = 1f - h, rise = u * (1f - u) * 4f * maxH * 0.30f * (0.5f + 0.5f * PUNCH[i] * 4f);
            float y = ty[i] - rise - barW * 0.4f;
            paint.setColor(withAlpha(HALO[look], (int) (90 * h * k)));
            c.drawCircle(tx[i], y, barW * 0.7f * h + 1f, paint);
            paint.setColor(withAlpha(0xFFFFFF, (int) (240 * h * k)));
            c.drawCircle(tx[i], y, barW * 0.32f * h + 1f, paint);
        }
    }

    private static int mix(int a, int b, float f) {
        f = f < 0f ? 0f : (f > 1f ? 1f : f);
        int r = (int) (((a >> 16) & 255) * (1f - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1f - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1f - f) + (b & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------- easing ----------

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static float easeInOut(float x) {
        x = clamp(x, 0f, 1f);
        return x < 0.5f ? 4f * x * x * x : 1f - (float) Math.pow(-2f * x + 2f, 3) / 2f;
    }

    private static float easeOutCubic(float x) {
        float u = 1f - clamp(x, 0f, 1f);
        return 1f - u * u * u;
    }

    private static float easeIn(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * x;
    }

    /** Ends exactly at 1 after overshooting by about 2%. */
    private static float backOut(float p) {
        p = clamp(p, 0f, 1f);
        float u = p - 1f;
        return 1f + 1.8f * u * u * u + 0.8f * u * u;
    }

    private static float bounce(float x) {
        x = clamp(x, 0f, 1f);
        if (x < 1f / 2.75f) return 7.5625f * x * x;
        if (x < 2f / 2.75f) {
            x -= 1.5f / 2.75f;
            return 7.5625f * x * x + 0.75f;
        }
        if (x < 2.5f / 2.75f) {
            x -= 2.25f / 2.75f;
            return 7.5625f * x * x + 0.9375f;
        }
        x -= 2.625f / 2.75f;
        return 7.5625f * x * x + 0.984375f;
    }

    /** Six crisp steps with a quick glide between them, like a ratcheting mechanism. */
    private static float ratchet(float x) {
        float v = clamp(x, 0f, 1f) * 6f, f = (float) Math.floor(v);
        if (f >= 6f) return 1f;
        return (f + smooth((v - f) * 1.7f)) / 6f;
    }

    private static float wrap180(float d) {
        return d - 360f * (float) Math.floor((d + 180f) / 360f);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
    }
}
