# Living Clock

A live wallpaper: your photo, a glass clock behind you, and three shooting stars each time the minute changes.

- Choose a background photo and a subject photo separately (the subject is cut out automatically, or use a transparent PNG).
- Drag the subject or the clock on the live preview to place them.
- Adjust subject size, clock size, and turn shooting stars on or off.
- Set it as your live wallpaper from the app.

Build: push to `main`. GitHub Actions builds the debug APK and uploads it as the `Living-Clock-debug` artifact.

## Intro

When the wallpaper appears (returning home, screen on, unlock) it plays a short intro, at most once every few seconds: the subject enters in one of three random styles (settle, bloom, sheen), then the clock lifts above the subject with a soft glow while the background dims, rewinds three hours, returns to now and settles back behind the subject. It can be switched off in the app.

## Tap the clock

Tapping the clock face on the home screen drops dark numbers that leave thin rays. This relies on the launcher forwarding taps on empty wallpaper areas. Use **Test number drop** in the app to preview it.
