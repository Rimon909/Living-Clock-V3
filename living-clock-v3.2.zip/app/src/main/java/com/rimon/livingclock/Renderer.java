package com.rimon.livingclock;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Calendar;
import java.util.Random;

/**
 * One frame: photo, glass dial, gold seconds trail, hands, subject, falling numbers, shooting stars.
 *
 * Intro (about 7 seconds): the subject enters in one of three styles, the clock lifts above the subject
 * with a soft glow while the background dims, rewinds three hours and returns to now, then settles
 * back behind the subject. Tapping the clock drops dark numbers that leave thin rays behind them.
 */
final class Renderer {

    private static final int BG = 0xFF0E1420, IVORY = 0xFFFFF4E2, GOLD = 0xFFFFDC8A;
    private static final int AMBER = 0xFFFFA94D, STAR = 0xFFFFF6DC;
    private static final int TRAIL = 10;

    // Shooting stars: slow and bold.
    private static final long STAR_MS = 1800, STAR_END = 600 + 1800;
    private static final long[] STAR_DELAY = {0, 300, 600};

    // Intro timeline in milliseconds.
    private static final long ENTER_MS = 1300;
    private static final long LIFT_IN_AT = 500, LIFT_IN_LEN = 700;
    private static final long BACK_AT = 1200, BACK_LEN = 2200, HOLD_LEN = 300, FWD_LEN = 2400;
    private static final long FWD_AT = BACK_AT + BACK_LEN + HOLD_LEN;
    private static final long LIFT_OUT_AT = FWD_AT + FWD_LEN + 100, LIFT_OUT_LEN = 900;
    private static final long INTRO_MS = LIFT_OUT_AT + LIFT_OUT_LEN;
    private static final long INTRO_COOLDOWN_MS = INTRO_MS + 1000;
    private static final long REWIND_SPAN_MS = 3L * 3_600_000L;

    // Falling numbers.
    private static final int DROPS = 9;
    private static final long DROP_MS = 3600, DROP_DEBOUNCE_MS = 350;
    private static final int[] INK = {0xFF1B2A41, 0xFF2B2D42, 0xFF3C1F33, 0xFF0F3D3E,
            0xFF4A1D1F, 0xFF22223B, 0xFF14213D};
    private static final String[] DIGIT = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

    private static final float[] COS = new float[60];
    private static final float[] SIN = new float[60];

    static {
        for (int i = 0; i < 60; i++) {
            double a = Math.toRadians(i * 6 - 90);
            COS[i] = (float) Math.cos(a);
            SIN[i] = (float) Math.sin(a);
        }
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint();
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint revealPaint = new Paint();
    private final Paint sheenPaint = new Paint();
    private final RadialGradient reveal = new RadialGradient(0f, 0f, 100f,
            new int[]{0xFF000000, 0xFF000000, 0x00000000}, new float[]{0f, 0.72f, 1f}, Shader.TileMode.CLAMP);
    private final LinearGradient sheen = new LinearGradient(-100f, 0f, 100f, 0f,
            new int[]{0x00FFF1D6, 0x70FFF1D6, 0x00FFF1D6}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
    private final Matrix fx = new Matrix();
    private final Path hourPath = new Path();
    private final Path minutePath = new Path();
    private final Calendar calendar = Calendar.getInstance();
    private final Random random = new Random();

    private final float[] dX = new float[DROPS], dY = new float[DROPS], dVx = new float[DROPS];
    private final float[] dVy = new float[DROPS], dSize = new float[DROPS], dDelay = new float[DROPS];
    private final int[] dDigit = new int[DROPS], dColor = new int[DROPS];

    private Scene scene;
    private Bitmap dial;
    private int width, height, clockSize = 100;
    private boolean dirty = true, stars = true, introOn = true;
    private float cx, cy, radius;
    private float clockX = 0.34f, clockY = 0.27f, subjX = 0.5f, subjY = 0.5f;
    private int lastMinute = -1, introStyle;
    private long starBase = -1L, introBase = -1L, dropBase = -1L;

    Renderer() {
        revealPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        sheenPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        textPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    // ---------- configuration ----------

    void setSize(int w, int h) {
        if (w != width || h != height) {
            width = w;
            height = h;
            dirty = true;
        }
    }

    void setScene(Scene s) {
        scene = s;
    }

    void readConfig(SharedPreferences p) {
        clockX = p.getFloat(Prefs.CLOCK_X, 0.34f);
        clockY = p.getFloat(Prefs.CLOCK_Y, 0.27f);
        clockSize = p.getInt(Prefs.CLOCK_SIZE, 100);
        subjX = p.getFloat(Prefs.SUBJ_X, 0.5f);
        subjY = p.getFloat(Prefs.SUBJ_Y, 0.5f);
        stars = p.getBoolean(Prefs.STARS, true);
        introOn = p.getBoolean(Prefs.INTRO, true);
        dirty = true;
    }

    void setClock(float x, float y) {
        clockX = clamp(x, 0f, 1f);
        clockY = clamp(y, 0f, 1f);
        cx = clockX * width;
        cy = clockY * height;
    }

    void setSubject(float x, float y) {
        subjX = clamp(x, -0.5f, 1.5f);
        subjY = clamp(y, -0.5f, 1.5f);
    }

    void setClockSize(int pct) {
        clockSize = pct;
        dirty = true;
    }

    void setStars(boolean on) {
        stars = on;
    }

    void setIntro(boolean on) {
        introOn = on;
    }

    void spawnStars(long now) {
        starBase = now;
    }

    /** Starts the intro. Ignored while one is playing, unless forced (the app's preview button). */
    void playIntro(long now, boolean force) {
        if (!force && (!introOn || (introBase >= 0 && now - introBase < INTRO_COOLDOWN_MS))) return;
        introBase = now;
        introStyle = random.nextInt(3);
    }

    /** A tap on the clock face drops the numbers. Returns true when it hit. */
    boolean tap(float x, float y, long now) {
        float dx = x - cx, dy = y - cy, r = radius * 1.15f;
        if (dx * dx + dy * dy > r * r) return false;
        dropNumbers(now);
        return true;
    }

    void dropNumbers(long now) {
        if (dropBase >= 0 && now - dropBase < DROP_DEBOUNCE_MS) return;
        dropBase = now;
        for (int i = 0; i < DROPS; i++) {
            float a = random.nextFloat() * 6.2832f;
            float d = radius * 0.75f * (float) Math.sqrt(random.nextFloat());
            dX[i] = cx + (float) Math.cos(a) * d;
            dY[i] = cy + (float) Math.sin(a) * d;
            dVx[i] = (random.nextFloat() - 0.5f) * width * 0.16f;
            dVy[i] = -random.nextFloat() * height * 0.03f;
            dSize[i] = width * (0.05f + random.nextFloat() * 0.04f);
            dDelay[i] = random.nextFloat() * 0.35f;
            dDigit[i] = random.nextInt(10);
            dColor[i] = INK[random.nextInt(INK.length)];
        }
    }

    float clockX() { return clockX; }
    float clockY() { return clockY; }
    float subjX() { return subjX; }
    float subjY() { return subjY; }

    void release() {
        if (dial != null) {
            dial.recycle();
            dial = null;
        }
    }

    /** True while something is moving and frames should follow the display refresh. */
    boolean animating(long now) {
        return (introBase >= 0 && now - introBase < INTRO_MS)
                || (stars && starBase >= 0 && now - starBase < STAR_END)
                || (dropBase >= 0 && now - dropBase < DROP_MS);
    }

    /** Idle: wake once a second, just after the second changes. */
    long delay(long now) {
        return 1000 - now % 1000 + 5;
    }

    // ---------- drawing ----------

    void draw(Canvas c, long now) {
        if (width <= 0 || height <= 0) return;
        if (dirty) layout();

        calendar.setTimeInMillis(now);
        int realMin = calendar.get(Calendar.MINUTE);
        if (realMin != lastMinute) {
            if (lastMinute >= 0 && stars) starBase = now;
            lastMinute = realMin;
        }

        long t = introBase >= 0 ? now - introBase : -1L;
        boolean intro = t >= 0 && t < INTRO_MS;
        float lift = 0f, dialAlpha = 1f, rewind = 0f;
        if (intro) {
            lift = smooth((t - LIFT_IN_AT) / (float) LIFT_IN_LEN)
                    * (1f - smooth((t - LIFT_OUT_AT) / (float) LIFT_OUT_LEN));
            dialAlpha = smooth(t / 700f);
            if (t >= BACK_AT && t < FWD_AT) rewind = sine((t - BACK_AT) / (float) BACK_LEN);
            else if (t >= FWD_AT) rewind = 1f - sine((t - FWD_AT) / (float) FWD_LEN);
            if (rewind > 0f) calendar.setTimeInMillis(now - (long) (REWIND_SPAN_MS * rewind));
        }

        int sec = calendar.get(Calendar.SECOND);
        float secF = intro ? sec + calendar.get(Calendar.MILLISECOND) / 1000f : sec;
        float minF = calendar.get(Calendar.MINUTE) + secF / 60f;
        float hourF = calendar.get(Calendar.HOUR) + minF / 60f;
        float scale = 1f + 0.12f * lift;

        if (scene != null && scene.bg != null) c.drawBitmap(scene.bg, 0f, 0f, bitmapPaint);
        else c.drawColor(BG);

        if (lift > 0f) {
            dimPaint.setAlpha((int) (255 * lift));
            c.save();
            c.translate(cx, cy);
            c.drawRect(-cx, -cy, width - cx, height - cy, dimPaint);
            c.restore();
        }

        // Clock behind the subject. While lifted, a second copy with a glow fades in above the subject.
        drawClock(c, hourF * 30f, minF * 6f, secF * 6f, sec, scale, dialAlpha);
        if (scene != null && scene.subject != null) drawSubject(c, intro ? t : -1L);
        if (lift > 0f) {
            float r = radius * 2.3f;
            int sc = c.saveLayerAlpha(cx - r, cy - r, cx + r, cy + r, (int) (255 * lift));
            drawGlow(c, scale);
            drawClock(c, hourF * 30f, minF * 6f, secF * 6f, sec, scale, 1f);
            c.restoreToCount(sc);
        }

        if (dropBase >= 0 && now - dropBase < DROP_MS) drawDrops(c, now);
        if (stars && starBase >= 0) drawStars(c, now);
    }

    private void layout() {
        dirty = false;
        radius = Math.min(width * 0.21f * clockSize / 100f, width * 0.46f);
        cx = clockX * width;
        cy = clockY * height;

        int size = (int) Math.ceil(radius * 2.1f) + 4;
        if (dial == null || dial.getWidth() != size) {
            if (dial != null) dial.recycle();
            dial = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        } else {
            dial.eraseColor(0);
        }
        drawDial(new Canvas(dial), size / 2f);

        // Soft halo and background vignette: gradients drawn around (0, 0) and moved with translate().
        glowPaint.setShader(new RadialGradient(0f, 0f, radius * 2f,
                new int[]{0x00FFC773, 0x66FFC773, 0x2AFFB35A, 0x00FFB35A},
                new float[]{0f, 0.45f, 0.72f, 1f}, Shader.TileMode.CLAMP));
        dimPaint.setShader(new RadialGradient(0f, 0f, Math.max(width, height) * 0.8f,
                new int[]{0x20000000, 0x55000000, 0xB8000000},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));

        float hourLen = radius * 0.52f, minLen = radius * 0.80f, hw = radius * 0.05f;
        hourPath.rewind();
        hourPath.moveTo(0, radius * 0.12f);
        hourPath.quadTo(hw * 1.8f, -hourLen * 0.35f, 0, -hourLen);
        hourPath.quadTo(-hw * 1.8f, -hourLen * 0.35f, 0, radius * 0.12f);
        hourPath.close();

        minutePath.rewind();
        float mw = radius * 0.016f, d = radius * 0.07f, dy = -minLen * 0.78f;
        minutePath.addRect(-mw, -minLen, mw, radius * 0.14f, Path.Direction.CW);
        minutePath.moveTo(0, dy - d);
        minutePath.lineTo(d * 0.55f, dy);
        minutePath.lineTo(0, dy + d);
        minutePath.lineTo(-d * 0.55f, dy);
        minutePath.close();
    }

    private void drawClock(Canvas c, float hDeg, float mDeg, float sDeg, int sec, float scale, float alpha) {
        int sc = -1;
        if (alpha < 1f) {
            float r = radius * 2.3f;
            sc = c.saveLayerAlpha(cx - r, cy - r, cx + r, cy + r, (int) (255 * alpha));
        }
        c.save();
        c.scale(scale, scale, cx, cy);
        c.drawBitmap(dial, cx - dial.getWidth() / 2f, cy - dial.getHeight() / 2f, bitmapPaint);
        drawTrail(c, sec);
        drawHands(c, hDeg, mDeg, sDeg);
        c.restore();
        if (sc >= 0) c.restoreToCount(sc);
    }

    private void drawGlow(Canvas c, float scale) {
        c.save();
        c.translate(cx, cy);
        c.scale(scale, scale);
        c.drawCircle(0f, 0f, radius * 2f, glowPaint);
        c.restore();
    }

    /**
     * The subject never slides, so its edges stay put. Three entrances: settle (fade with a slight
     * zoom-out from the feet), bloom (soft circular reveal growing from the clock), sheen (fade in
     * with a diagonal band of light sweeping across).
     */
    private void drawSubject(Canvas c, long t) {
        Bitmap s = scene.subject;
        float left = subjX * width - s.getWidth() / 2f, top = subjY * height - s.getHeight() / 2f;
        if (t < 0 || t >= ENTER_MS) {
            c.drawBitmap(s, left, top, bitmapPaint);
            return;
        }

        float p = t / (float) ENTER_MS;
        float e = 1f - (1f - p) * (1f - p) * (1f - p);
        if (introStyle == 0) {
            c.save();
            float k = 1.04f - 0.04f * e;
            c.scale(k, k, subjX * width, top + s.getHeight());
            bitmapPaint.setAlpha((int) (255 * e));
            c.drawBitmap(s, left, top, bitmapPaint);
            bitmapPaint.setAlpha(255);
            c.restore();
            return;
        }

        int sc = c.saveLayer(0f, 0f, width, height, null);
        if (introStyle == 1) {
            c.drawBitmap(s, left, top, bitmapPaint);
            float reach = (float) Math.hypot(Math.max(cx, width - cx), Math.max(cy, height - cy)) * 1.2f;
            float k = Math.max(0.01f, reach * e / 100f);
            fx.setScale(k, k);
            fx.postTranslate(cx, cy);
            reveal.setLocalMatrix(fx);
            revealPaint.setShader(reveal);
            c.drawRect(0f, 0f, width, height, revealPaint);
        } else {
            bitmapPaint.setAlpha((int) (255 * Math.min(1f, p / 0.35f)));
            c.drawBitmap(s, left, top, bitmapPaint);
            bitmapPaint.setAlpha(255);
            float q = p * p * (3f - 2f * p);
            fx.setScale(width * 0.0045f, 1f);
            fx.postRotate(20f);
            fx.postTranslate(width * (-0.35f + 1.7f * q), height * 0.5f);
            sheen.setLocalMatrix(fx);
            sheenPaint.setShader(sheen);
            c.drawRect(0f, 0f, width, height, sheenPaint);
        }
        c.restoreToCount(sc);
    }

    private void drawDial(Canvas k, float c0) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(c0, c0, radius,
                new int[]{0x40FFFFFF, 0x1CFFFFFF, 0x66000000},
                new float[]{0f, 0.8f, 1f}, Shader.TileMode.CLAMP));
        k.drawCircle(c0, c0, radius, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.02f);
        paint.setColor(0x33000000);
        k.drawCircle(c0, c0, radius * 0.98f, paint);
        paint.setStrokeWidth(radius * 0.006f);
        paint.setColor(0x80FFFFFF);
        k.drawCircle(c0, c0, radius * 0.98f, paint);

        for (int i = 0; i < 60; i++) {
            boolean hour = i % 5 == 0;
            float rin = radius * (hour ? 0.80f : 0.90f), rout = radius * 0.94f;
            float x1 = c0 + COS[i] * rin, y1 = c0 + SIN[i] * rin;
            float x2 = c0 + COS[i] * rout, y2 = c0 + SIN[i] * rout;
            float w = radius * (hour ? 0.035f : 0.013f);
            paint.setStrokeWidth(w + radius * 0.02f);
            paint.setColor(0x55000000);
            k.drawLine(x1, y1, x2, y2, paint);
            paint.setStrokeWidth(w);
            paint.setColor(IVORY);
            k.drawLine(x1, y1, x2, y2, paint);
        }
    }

    private void drawTrail(Canvas c, int sec) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int t = 0; t < TRAIL; t++) {
            float f = 1f - t / (float) TRAIL;
            float a = f * f;
            int i = (sec - t + 60) % 60;
            float rin = radius * (i % 5 == 0 ? 0.80f : 0.90f), rout = radius * 0.94f;
            float x1 = cx + COS[i] * rin, y1 = cy + SIN[i] * rin;
            float x2 = cx + COS[i] * rout, y2 = cy + SIN[i] * rout;

            paint.setStrokeWidth(radius * 0.05f * (0.5f + 0.5f * f));
            paint.setColor(withAlpha(AMBER, (int) (120 * a)));
            c.drawLine(x1, y1, x2, y2, paint);
            paint.setStrokeWidth(radius * 0.016f);
            paint.setColor(withAlpha(GOLD, (int) (255 * a)));
            c.drawLine(x1, y1, x2, y2, paint);
        }
    }

    private void drawHands(Canvas c, float hourDeg, float minuteDeg, float secDeg) {
        hand(c, hourPath, hourDeg, 0.03f);
        hand(c, minutePath, minuteDeg, 0.024f);

        c.save();
        c.translate(cx, cy);
        c.rotate(secDeg);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(radius * 0.05f);
        paint.setColor(withAlpha(GOLD, 70));
        c.drawLine(0, radius * 0.18f, 0, -radius * 0.9f, paint);
        paint.setStrokeWidth(radius * 0.012f);
        paint.setColor(GOLD);
        c.drawLine(0, radius * 0.18f, 0, -radius * 0.9f, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawCircle(0, radius * 0.18f, radius * 0.035f, paint);
        c.restore();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x80000000);
        c.drawCircle(cx, cy, radius * 0.065f, paint);
        paint.setColor(IVORY);
        c.drawCircle(cx, cy, radius * 0.05f, paint);
        paint.setColor(GOLD);
        c.drawCircle(cx, cy, radius * 0.018f, paint);
    }

    private void hand(Canvas c, Path p, float deg, float outline) {
        c.save();
        c.translate(cx, cy);
        c.rotate(deg);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(radius * outline);
        paint.setColor(0x80000000);
        c.drawPath(p, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(IVORY);
        c.drawPath(p, paint);
        c.restore();
    }

    /** Dark numbers fall under gravity. Each leaves a thin ray, with a faint light edge so it reads on any photo. */
    private void drawDrops(Canvas c, long now) {
        float s0 = (now - dropBase) / 1000f;
        float fade = clamp((DROP_MS / 1000f - s0) / 0.5f, 0f, 1f);
        float g = height * 0.75f, lw = Math.max(1.2f, width * 0.002f);

        for (int i = 0; i < DROPS; i++) {
            float s = s0 - dDelay[i];
            if (s <= 0f) continue;
            float x = dX[i] + dVx[i] * s, y = dY[i] + dVy[i] * s + 0.5f * g * s * s;
            if (y > height + dSize[i]) continue;
            float a = fade * clamp(s / 0.15f, 0f, 1f);

            float trail = Math.min(s, 0.3f), px = x, py = y;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int k = 1; k <= 4; k++) {
                float s2 = s - trail * k / 4f;
                float x2 = dX[i] + dVx[i] * s2, y2 = dY[i] + dVy[i] * s2 + 0.5f * g * s2 * s2;
                float f = a * (1f - (k - 1) / 4f);
                paint.setStrokeWidth(lw * 3f);
                paint.setColor(withAlpha(IVORY, (int) (55 * f)));
                c.drawLine(px, py, x2, y2, paint);
                paint.setStrokeWidth(lw);
                paint.setColor(withAlpha(dColor[i], (int) (230 * f)));
                c.drawLine(px, py, x2, y2, paint);
                px = x2;
                py = y2;
            }

            c.save();
            c.rotate(dVx[i] * s * 0.05f, x, y);
            textPaint.setTextSize(dSize[i]);
            float base = y + dSize[i] * 0.35f;
            textPaint.setStyle(Paint.Style.STROKE);
            textPaint.setStrokeWidth(dSize[i] * 0.07f);
            textPaint.setColor(withAlpha(IVORY, (int) (130 * a)));
            c.drawText(DIGIT[dDigit[i]], x, base, textPaint);
            textPaint.setStyle(Paint.Style.FILL);
            textPaint.setColor(withAlpha(dColor[i], (int) (255 * a)));
            c.drawText(DIGIT[dDigit[i]], x, base, textPaint);
            c.restore();
        }
    }

    /** Three slow, bold stars leave the top centre for the bottom-left, bottom-right and bottom-centre. */
    private void drawStars(Canvas c, long now) {
        float x0 = width * 0.5f, y0 = -height * 0.02f;
        float[] tx = {-width * 0.03f, width * 1.03f, width * 0.5f};
        float ty = height * 1.03f;
        float bw = Math.max(3f, width * 0.0075f);

        for (int i = 0; i < 3; i++) {
            float t = (now - starBase - STAR_DELAY[i]) / (float) STAR_MS;
            if (t < 0f || t > 1f) continue;

            float e = t * t * (3f - 2f * t);
            float fade = t < 0.75f ? 1f : (1f - t) / 0.25f;
            float dx = tx[i] - x0, dy = ty - y0;
            float tail = Math.max(0f, e - 0.45f);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            for (int k = 0; k < 6; k++) {
                float p0 = tail + (e - tail) * k / 6f;
                float p1 = tail + (e - tail) * (k + 1) / 6f;
                paint.setStrokeWidth(bw * (0.35f + 0.65f * (k + 1) / 6f));
                paint.setColor(withAlpha(STAR, (int) (255 * fade * (k + 1) / 6f)));
                c.drawLine(x0 + dx * p0, y0 + dy * p0, x0 + dx * p1, y0 + dy * p1, paint);
            }

            float hx = x0 + dx * e, hy = y0 + dy * e;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(STAR, (int) (90 * fade)));
            c.drawCircle(hx, hy, bw * 2.6f, paint);
            paint.setColor(withAlpha(0xFFFFFF, (int) (255 * fade)));
            c.drawCircle(hx, hy, bw, paint);
        }
    }

    // ---------- helpers ----------

    private static float smooth(float x) {
        x = clamp(x, 0f, 1f);
        return x * x * (3f - 2f * x);
    }

    private static float sine(float p) {
        return 0.5f - 0.5f * (float) Math.cos(Math.PI * clamp(p, 0f, 1f));
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
